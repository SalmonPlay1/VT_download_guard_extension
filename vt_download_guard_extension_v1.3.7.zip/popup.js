function setSafeHtml(el, htmlStr) {
  if (!el) return;
  el.textContent = "";
  if (!htmlStr) return;
  const parser = new DOMParser();
  const doc = parser.parseFromString(String(htmlStr), "text/html");
  while (doc.body.firstChild) {
    el.appendChild(doc.body.firstChild);
  }
}


// Универсальные обёртки chrome.storage.local (работают даже на старых сборках Chromium в урезанных Windows 10 Lite/LTSC)
function safeStorageGet(defaults) {
  return new Promise((resolve) => {
    try {
      if (!chrome?.storage?.local) {
        resolve({ ...defaults });
        return;
      }
      chrome.storage.local.get(defaults, (res) => {
        if (chrome.runtime?.lastError || !res) {
          resolve({ ...defaults });
        } else {
          resolve({ ...defaults, ...res });
        }
      });
    } catch (_) {
      resolve({ ...defaults });
    }
  });
}

function safeStorageSet(data) {
  return new Promise((resolve) => {
    try {
      if (!chrome?.storage?.local) {
        resolve();
        return;
      }
      chrome.storage.local.set(data, () => resolve());
    } catch (_) {
      resolve();
    }
  });
}

// Полный каталог форматов файлов по 8 категориям без единого дубликата (296 базовых расширений)
const CATEGORIES = [
  {
    id: "all",
    label: "Все форматы",
    extensions: []
  },
  {
    id: "exec",
    label: "⚙️ Программы и APK",
    extensions: [
      "exe", "msi", "msp", "msix", "appx", "apk", "aab", "xapk", "apkm", "ipa",
      "dmg", "pkg", "mpkg", "app", "deb", "rpm", "run", "bin", "elf", "appimage",
      "flatpak", "snap", "bat", "cmd", "com", "scr", "ps1", "vbs", "vbe", "wsf",
      "wsh", "hta", "cpl", "jar", "gadget"
    ]
  },
  {
    id: "arch",
    label: "📦 Архивы и ISO",
    extensions: [
      "zip", "zipx", "rar", "7z", "tar", "gz", "tgz", "bz2", "tbz2", "xz",
      "txz", "zst", "lz", "lzma", "lzh", "arj", "cab", "ace", "iso", "img",
      "nrg", "mdf", "mds", "vhd", "vhdx", "vmdk", "ova", "ovf", "wim", "cpio"
    ]
  },
  {
    id: "docs",
    label: "📄 Документы и Офис",
    extensions: [
      "pdf", "doc", "docx", "docm", "dot", "dotx", "dotm", "xls", "xlsx", "xlsm",
      "xlsb", "xlt", "xltm", "ppt", "pptx", "pptm", "pps", "ppsx", "ppsm", "odt",
      "ods", "odp", "odg", "rtf", "txt", "csv", "tsv", "md", "tex", "epub",
      "mobi", "azw3", "fb2", "djvu", "chm", "hlp", "one", "vsd", "vsdx", "pub"
    ]
  },
  {
    id: "img",
    label: "🖼️ Фото, Графика и 3D",
    extensions: [
      "png", "jpg", "jpeg", "jfif", "webp", "gif", "svg", "svgz", "ico", "cur",
      "ani", "bmp", "dib", "tiff", "tif", "heic", "heif", "avif", "jxl", "psd",
      "psb", "ai", "eps", "cdr", "indd", "xcf", "sketch", "fig", "raw", "cr2",
      "cr3", "nef", "arw", "dng", "stl", "obj", "fbx", "blend", "dwg", "dxf"
    ]
  },
  {
    id: "media",
    label: "🎬 Аудио и Видео",
    extensions: [
      "mp3", "wav", "flac", "aac", "ogg", "oga", "opus", "m4a", "wma", "aiff",
      "alac", "amr", "ape", "mid", "midi", "mp4", "mkv", "avi", "mov", "wmv",
      "flv", "webm", "m4v", "mpg", "mpeg", "3gp", "3g2", "mts", "m2ts",
      "vob", "ogv", "m3u", "m3u8", "pls"
    ]
  },
  {
    id: "code",
    label: "💻 Код и Скрипты",
    extensions: [
      "js", "mjs", "cjs", "jse", "ts", "jsx", "tsx", "py", "pyc", "pyo",
      "pyw", "rb", "pl", "pm", "lua", "tcl", "sh", "bash", "zsh",
      "fish", "ksh", "go", "rs", "c", "cpp", "cc", "cxx", "h", "hpp",
      "cs", "java", "class", "kt", "kts", "swift", "dart", "scala", "groovy", "r",
      "jl", "wasm"
    ]
  },
  {
    id: "data",
    label: "🗄️ Данные и Сертификаты",
    extensions: [
      "json", "xml", "xsd", "xsl", "yaml", "yml", "toml", "ini", "cfg", "conf",
      "config", "properties", "env", "reg", "inf", "sql", "sqlite", "sqlite3", "db", "mdb",
      "accdb", "dbf", "parquet", "avro", "orc", "cer", "crt", "der", "pem", "p7b",
      "p7c", "p12", "pfx", "key", "ovpn"
    ]
  },
  {
    id: "sys",
    label: "🔧 Системные и Торренты",
    extensions: [
      "dll", "sys", "drv", "ocx", "ax", "so", "dylib", "ko", "lnk", "url",
      "webloc", "desktop", "scf", "pif", "torrent", "pcap", "pcapng", "cap", "ttf", "otf",
      "woff", "woff2", "eot", "fon", "bak", "old", "tmp", "dat", "rom", "sav",
      "pak", "crx", "xpi"
    ]
  },
  {
    id: "custom",
    label: "✨ Свои",
    extensions: []
  }
];

const KNOWN_EXTENSIONS = Array.from(
  new Set(CATEGORIES.flatMap(c => c.extensions))
);

const DANGEROUS_PRESET = Array.from(
  new Set([
    ...CATEGORIES.find(c => c.id === "exec").extensions,
    ...CATEGORIES.find(c => c.id === "arch").extensions,
    "docm", "dotm", "xlsm", "xlsb", "xltm", "pptm", "ppsm", "chm", "hlp",
    "js", "jse", "py", "sh", "bash", "reg", "inf", "dll", "sys", "drv", "ocx", "lnk", "url", "scf", "pif", "torrent", "crx", "xpi"
  ])
);

const DEFAULT_WHITELIST_DOMAINS = [
  "github.com",
  "githubusercontent.com",
  "microsoft.com",
  "windowsupdate.com",
  "google.com",
  "googleapis.com",
  "gstatic.com",
  "mozilla.org",
  "apple.com",
  "localhost",
  "127.0.0.1",
  "192.168.*",
  "10.*"
];

let currentSettings = {
  enabled: true,
  apiKey: "",
  scanWindowDisplayMode: "card_on_top",
  hybridProtectionEnabled: true,
  autonomousNoAvCoreEnabled: true,
  vtApiKeyModeEnabled: true,
  zeroKeyAndPcAvModeEnabled: true,
  noKeyMode: "pc_antivirus_mode",
  localPcAntivirusEnabled: true,
  proxyUrl: "",
  filterMode: "all",
  extensions: [...KNOWN_EXTENSIONS],
  autoDownloadSafe: true,
  keepScanOnTabClose: true,
  showDetailedVendors: true,
  vendorDisplayMode: "inline_and_modal",
  uploadPolicy: "ask",
  autoBlockEnabled: true,
  autoBlockThreshold: 1,
  autoBlockIncludeSuspicious: false,
  falsePositiveMode: "smart",
  strictBlockLock: false,
  sizeLimitEnabled: false,
  maxFileSizeMB: 500,
  maxHeavyCategoryMB: 200,
  whitelistEnabled: false,
  domainWhitelist: [...DEFAULT_WHITELIST_DOMAINS],
  theme: "salmon_ocean",
  iconStyle: "auto",
  bgImageEnabled: true,
  bgOpacity: 36,
  cardBgOpacity: 48,
  glassBlurEnabled: true,
  customBgDataUrl: "",
  stickersEnabled: true,
  stickerLockClickThrough: true,
  stickerPreset: "auto_theme",
  customStickerDataUrl: "",
  stickerSize: 78,
  stickerOpacity: 85,
  stickerPosition: "bottom-right",
  stickerCustomX: 80,
  stickerCustomY: 75,
  soundPreset: "auto_theme",
  soundVolume: 70,
  customSoundDataUrl: "",
  customFontName: "",
  customFontDataUrl: "",
  customTextColorEnabled: false,
  customTextMainColor: "#f0f9ff",
  customTextSubColor: "#7dd3fc",
  customFontFamily: "system",
  customFontScale: 100,
  customBorderRadius: 10,
  customPopupWidth: 450,
  customColorsEnabled: false,
  customBgColor: "#051622",
  customCardColor: "#0a2538",
  customAccentColor: "#ff856d",
  bannerPosition: "top-right",
  autoCloseSafeSec: 8,
  soundAlertsEnabled: true,
  hoverBadgeEnabled: false,
  hoverTriggerMode: "alt_only",
  uiLang: "ru",
  tutorialCompleted: false,
  selectionPopupEnabled: true,
  unshortenLinksEnabled: true,
  antiPhishingEnabled: true,
  clickFixShieldEnabled: true,
  clipboardHelperEnabled: true,
  peSignatureCheckEnabled: true,
  archiveLnkInspectEnabled: true,
  domainAgeCheckEnabled: true,
  trustScoreEnabled: true,
  smartSummaryEnabled: true,
  xrayRadarEnabled: true,
  encryptedArchiveDetectEnabled: true,
  htmlSmugglingProtectionEnabled: true,
  liveParticlesEnabled: true,
  neonGlowIntensity: 35,
  cardAnimStyle: "slide",
  miniPillModeEnabled: false,
  activeSecurityPreset: "comfort",
  userCustomPresets: [],
  hotkeysEnabled: false,
  hotkeyToggle: "Alt+Shift+V",
  hotkeyScan: "Alt+Shift+S",
  hotkeyCloseAll: "Alt+Shift+C",
  snoozeUntil: 0,
  trustedHashes: [],
  totalScansCount: 0,
  totalThreatsBlocked: 0,
  totalCacheHits: 0,
  migrationV32DefaultsDone: false,
  migrationV33DefaultsDone: false,
  migrationV34DefaultsDone: false,
  migrationV35DefaultsDone: false,
  migrationV36DefaultsDone: false,
  scanHistory: []
};

const DEFAULT_POPUP_SETTINGS = JSON.parse(JSON.stringify(currentSettings));
let allAvailableExtensions = new Set(KNOWN_EXTENSIONS);
let activeCategoryId = "all";
let searchQuery = "";

// DOM-элементы
const enabledToggle = document.getElementById("enabledToggle");
const autoDownloadSafe = document.getElementById("autoDownloadSafe");
const showDetailedVendors = document.getElementById("showDetailedVendors");
const vendorModeBox = document.getElementById("vendorModeBox");
const vendorDisplayMode = document.getElementById("vendorDisplayMode");
const rateLimitBadgeMain = document.getElementById("rateLimitBadgeMain");
const rateLimitBadgeSettings = document.getElementById("rateLimitBadgeSettings");

const historyFilterSelect = document.getElementById("historyFilterSelect");
const clearHistoryBtn = document.getElementById("clearHistoryBtn");
const historyList = document.getElementById("historyList");

const selectedCountBadge = document.getElementById("selectedCountBadge");
const modeAll = document.getElementById("modeAll");
const modeSelected = document.getElementById("modeSelected");
const extensionsBlock = document.getElementById("extensionsBlock");
const categoryTabs = document.getElementById("categoryTabs");
const searchExtInput = document.getElementById("searchExtInput");
const extChipsContainer = document.getElementById("extChipsContainer");
const customExtInput = document.getElementById("customExtInput");
const addExtBtn = document.getElementById("addExtBtn");
const selectAllPreset = document.getElementById("selectAllPreset");
const clearAllPreset = document.getElementById("clearAllPreset");
const selectExecPreset = document.getElementById("selectExecPreset");
const toggleCategoryBtn = document.getElementById("toggleCategoryBtn");

const sizeLimitEnabled = document.getElementById("sizeLimitEnabled");
const sizeLimitBox = document.getElementById("sizeLimitBox");
const maxFileSizeMB = document.getElementById("maxFileSizeMB");
const maxHeavyCategoryMB = document.getElementById("maxHeavyCategoryMB");

const apiKeyInput = document.getElementById("apiKeyInput");
const toggleKeyBtn = document.getElementById("toggleKeyBtn");
const verifyKeyBtn = document.getElementById("verifyKeyBtn");
const keyValidationMsg = document.getElementById("keyValidationMsg");
const uploadPolicy = document.getElementById("uploadPolicy");
const noKeyModeSelect = document.getElementById("noKeyModeSelect");
const proxyUrlInput = document.getElementById("proxyUrlInput");
const dropZoneBox = document.getElementById("dropZoneBox");
const manualFileInput = document.getElementById("manualFileInput");
const manualQueryInput = document.getElementById("manualQueryInput");
const manualCheckBtn = document.getElementById("manualCheckBtn");
const manualResultBox = document.getElementById("manualResultBox");

const autoBlockEnabled = document.getElementById("autoBlockEnabled");
const autoBlockSettings = document.getElementById("autoBlockSettings");
const falsePositiveMode = document.getElementById("falsePositiveMode");
const autoBlockSlider = document.getElementById("autoBlockSlider");
const autoBlockInput = document.getElementById("autoBlockInput");
const autoBlockIncludeSuspicious = document.getElementById("autoBlockIncludeSuspicious");
const strictBlockLock = document.getElementById("strictBlockLock");

const whitelistEnabled = document.getElementById("whitelistEnabled");
const whitelistBox = document.getElementById("whitelistBox");
const whitelistChips = document.getElementById("whitelistChips");
const customDomainInput = document.getElementById("customDomainInput");
const addDomainBtn = document.getElementById("addDomainBtn");

const exportSettingsBtn = document.getElementById("exportSettingsBtn");
const importSettingsBtn = document.getElementById("importSettingsBtn");
const importFileInput = document.getElementById("importFileInput");
const saveStatus = document.getElementById("saveStatus");

// Переключение вкладок (Табов) в шапке
document.querySelectorAll(".main-tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".main-tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-pane").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    const targetPane = document.getElementById(btn.dataset.tab);
    if (targetPane) targetPane.classList.add("active");
  });
});

function sanitizeKeyInput(raw) {
  if (!raw) return "";
  const match = String(raw).match(/[a-fA-F0-9]{64}/);
  if (match) return match[0].toLowerCase();
  return String(raw).trim();
}

function updateKeyHint(key) {
  const isEn = currentSettings.uiLang === "en";
  const hybOn = currentSettings.hybridProtectionEnabled !== false;
  const autoNoAvOn = currentSettings.autonomousNoAvCoreEnabled !== false;
  const apiModeOn = currentSettings.vtApiKeyModeEnabled !== false;
  const zkModeOn = currentSettings.zeroKeyAndPcAvModeEnabled !== false;
  const hybMainEl = document.getElementById("hybridProtectionMainToggle");
  const hybSetEl = document.getElementById("hybridProtectionEnabled");
  const autoMainEl = document.getElementById("autonomousNoAvMainToggle");
  const autoSetEl = document.getElementById("autonomousNoAvCoreEnabled");
  const hybMsg = document.getElementById("hybridValidationMsg");
  if (hybMainEl) hybMainEl.checked = hybOn;
  if (hybSetEl) hybSetEl.checked = hybOn;
  if (autoMainEl) autoMainEl.checked = autoNoAvOn;
  if (autoSetEl) autoSetEl.checked = autoNoAvOn;
  if (hybMsg) {
    if (hybOn) {
      hybMsg.className = "key-msg ok";
      hybMsg.style.color = "";
      hybMsg.textContent = isEn
        ? "✓ Hybrid Protection is ON: VirusTotal API (when key is set) + Autonomous 6-Engine Core (works without API key and even if the PC has NO antivirus at all)."
        : "✓ Гибридная защита ВКЛЮЧЕНА: работают вместе API-ключ VT (если введён) + Автономный антивирус расширения (без ключа и даже если на ПК вообще нет антивируса).";
    } else {
      hybMsg.className = "key-msg";
      hybMsg.style.color = "#fbbf24";
      hybMsg.textContent = isEn
        ? "⏸️ Hybrid Protection is OFF: scan modes below operate separately."
        : "⏸️ Гибридная защита ВЫКЛЮЧЕНА: режимы ниже работают раздельно по вашему выбору.";
    }
  }
  const apiBox = document.getElementById("vtApiKeyControlsBox");
  const zkBox = document.getElementById("zeroKeyControlsBox");
  const zkMsg = document.getElementById("zeroKeyValidationMsg");

  if (apiBox) {
    apiBox.style.opacity = apiModeOn ? "1" : "0.45";
    apiBox.style.pointerEvents = apiModeOn ? "auto" : "none";
  }
  if (zkBox) {
    zkBox.style.opacity = zkModeOn ? "1" : "0.45";
    zkBox.style.pointerEvents = zkModeOn ? "auto" : "none";
  }
  if (zkMsg) {
    if (!zkModeOn) {
      zkMsg.className = "key-msg";
      zkMsg.textContent = isEn
        ? "⏸️ Zero-Key & PC Antivirus mode is OFF."
        : "⏸️ Режим БЕЗ API-ключа (Антивирус ПК + Zero-Key) ВЫКЛЮЧЕН.";
    } else if (apiModeOn && key && /^[a-f0-9]{64}$/i.test(key)) {
      zkMsg.className = "key-msg ok";
      zkMsg.textContent = isEn
        ? "✓ Combined Mode Active: Default PC Antivirus + Zero-Key + VirusTotal API Key work together!"
        : "✓ Активен ДВОЙНОЙ РЕЖИМ: Антивирус ПК + Zero-Key работают совместно с вашим API-ключом VirusTotal!";
    } else {
      zkMsg.className = "key-msg ok";
      zkMsg.textContent = isEn
        ? "✓ Zero-Key Mode Active (Default PC Antivirus + Local Deep Inspector + MalwareBazaar/CIRCL)."
        : "✓ Активен режим БЕЗ API-ключа (Встроенный антивирус ПК по умолчанию + локальный щит + базы угроз).";
    }
  }

  if (!apiModeOn) {
    keyValidationMsg.className = "key-msg";
    keyValidationMsg.textContent = isEn
      ? "⏸️ VirusTotal API Key mode is turned OFF (using PC Antivirus & Zero-Key mode)."
      : "⏸️ Проверка по API-ключу VirusTotal ВЫКЛЮЧЕНА (используется Антивирус ПК и режим БЕЗ ключа).";
    return;
  }
  if (!key) {
    keyValidationMsg.className = "key-msg ok";
    keyValidationMsg.textContent = isEn
      ? "ℹ️ Optional: enter a 64-hex key for 72+ cloud AVs, or use PC Antivirus & Zero-Key below without a key."
      : "ℹ️ Ключ не введён — проверка выполняется режимом БЕЗ ключа (Антивирус ПК + Zero-Key).";
    return;
  }
  if (/^[a-f0-9]{64}$/i.test(key)) {
    keyValidationMsg.className = "key-msg ok";
    keyValidationMsg.textContent = isEn
      ? "✓ Key format is valid (64 hex chars). Click 'Verify' to test connection."
      : "✓ Формат ключа корректен (64 hex-символа). Нажмите «Проверить» для теста связи.";
  } else {
    keyValidationMsg.className = "key-msg err";
    keyValidationMsg.textContent = isEn
      ? `❌ Invalid key format (current length: ${key.length}, required: 64 hex chars 0-9, a-f).`
      : `❌ Неверный формат ключа (сейчас символов: ${key.length}, нужно 64 символа 0-9, a-f).`;
  }
}

let flashSavedTimer = null;
function flashSaved(customText) {
  const isEn = currentSettings.uiLang === "en";
  let msg = customText || (isEn ? "✓ Settings saved" : "✓ Настройки сохранены");
  if (isEn && typeof translateDynamicRuToEn === "function") {
    msg = translateDynamicRuToEn(msg);
  }
  saveStatus.textContent = msg;
  if (flashSavedTimer) clearTimeout(flashSavedTimer);
  flashSavedTimer = setTimeout(() => {
    saveStatus.textContent = currentSettings.uiLang === "en"
      ? "All changes are saved automatically"
      : "Все изменения сохраняются автоматически";
  }, 1600);
}

let saveSettingsDebounceTimer = null;

function saveSettings() {
  if (saveSettingsDebounceTimer) clearTimeout(saveSettingsDebounceTimer);
  saveSettingsDebounceTimer = setTimeout(() => {
    saveSettingsImmediate();
  }, 160);
}

async function saveSettingsImmediate() {
  const toSave = { ...currentSettings };
  delete toSave.scanHistory;
  delete toSave.totalScansCount;
  delete toSave.totalThreatsBlocked;
  delete toSave.totalCacheHits;
  await safeStorageSet(toSave);
  flashSaved();
}

function getExtensionsForCategory(catId) {
  if (catId === "all") {
    return Array.from(allAvailableExtensions);
  }
  if (catId === "custom") {
    const builtInSet = new Set(KNOWN_EXTENSIONS);
    return Array.from(allAvailableExtensions).filter(e => !builtInSet.has(e));
  }
  const cat = CATEGORIES.find(c => c.id === catId);
  return cat ? cat.extensions : [];
}

// Синхронизированная отрисовка вкладок категорий и кнопки «Выбрать все (N)»
function renderCategoryTabs() {
  categoryTabs.textContent = "";
  const activeSet = new Set(currentSettings.extensions.map(e => e.toLowerCase()));
  const totalCount = allAvailableExtensions.size;

  // Динамически синхронизируем число на кнопке «Выбрать все (N)» с общим числом доступных форматов!
  selectAllPreset.textContent = `Выбрать все (${totalCount})`;

  for (const cat of CATEGORIES) {
    const catExts = getExtensionsForCategory(cat.id);
    if (cat.id === "custom" && catExts.length === 0) continue;

    const selectedInCat = catExts.filter(e => activeSet.has(e)).length;
    const tab = document.createElement("button");
    tab.type = "button";
    tab.className = `cat-tab ${activeCategoryId === cat.id ? "active" : ""}`;
    tab.textContent = `${cat.label} (${selectedInCat}/${catExts.length})`;
    tab.addEventListener("click", () => {
      activeCategoryId = cat.id;
      renderCategoryTabs();
      renderChips();
    });
    categoryTabs.appendChild(tab);
  }
  if (currentSettings.uiLang === "en" && typeof applyPopupLanguage === "function") applyPopupLanguage("en");
}

function renderChips() {
  extChipsContainer.textContent = "";
  const activeSet = new Set(currentSettings.extensions.map(e => e.toLowerCase()));

  selectedCountBadge.textContent =
    currentSettings.filterMode === "all"
      ? `Все форматы (${allAvailableExtensions.size}/${allAvailableExtensions.size})`
      : `${activeSet.size} из ${allAvailableExtensions.size} выбрано`;

  let visibleExtensions = getExtensionsForCategory(activeCategoryId);
  if (searchQuery) {
    const q = searchQuery.toLowerCase().replace(/^\./, "");
    visibleExtensions = Array.from(allAvailableExtensions).filter(ext => ext.includes(q));
  }

  if (visibleExtensions.length === 0) {
    setSafeHtml(extChipsContainer, `<div class="empty-history" style="width:100%;">Форматы не найдены. Добавьте свой формат ниже.</div>`);
  } else {
    const frag = document.createDocumentFragment();
    for (const ext of visibleExtensions) {
      const chip = document.createElement("div");
      const isActive = activeSet.has(ext);
      chip.className = `chip ${isActive ? "active" : ""}`;
      chip.textContent = `.${ext}`;
      chip.addEventListener("click", () => {
        if (activeSet.has(ext)) {
          activeSet.delete(ext);
          chip.classList.remove("active");
        } else {
          activeSet.add(ext);
          chip.classList.add("active");
        }
        currentSettings.extensions = Array.from(activeSet);
        renderCategoryTabs();
        selectedCountBadge.textContent =
          currentSettings.filterMode === "all"
            ? `Все форматы (${allAvailableExtensions.size}/${allAvailableExtensions.size})`
            : `${activeSet.size} из ${allAvailableExtensions.size} выбрано`;
        saveSettings();
      });
      frag.appendChild(chip);
    }
    extChipsContainer.appendChild(frag);
  }

  extensionsBlock.style.opacity = currentSettings.filterMode === "all" ? "0.45" : "1";
  extensionsBlock.style.pointerEvents = currentSettings.filterMode === "all" ? "none" : "auto";
}

function renderWhitelistChips() {
  whitelistChips.textContent = "";
  const list = Array.isArray(currentSettings.domainWhitelist) ? currentSettings.domainWhitelist : [];
  if (list.length === 0) {
    setSafeHtml(whitelistChips, `<div class="empty-history" style="width:100%;">Белый список доменов пуст</div>`);
    return;
  }

  for (const domain of list) {
    const chip = document.createElement("div");
    chip.className = "chip active";
    chip.title = "Нажмите, чтобы удалить домен из белого списка";
    chip.textContent = `${domain} ×`;
    chip.addEventListener("click", () => {
      currentSettings.domainWhitelist = currentSettings.domainWhitelist.filter(d => d !== domain);
      renderWhitelistChips();
      saveSettings();
    });
    whitelistChips.appendChild(chip);
  }
}

function updateToggleDependentUIs() {
  autoBlockSettings.style.opacity = currentSettings.autoBlockEnabled ? "1" : "0.45";
  autoBlockSettings.style.pointerEvents = currentSettings.autoBlockEnabled ? "auto" : "none";

  vendorModeBox.style.opacity = currentSettings.showDetailedVendors ? "1" : "0.45";
  vendorModeBox.style.pointerEvents = currentSettings.showDetailedVendors ? "auto" : "none";

  sizeLimitBox.style.opacity = currentSettings.sizeLimitEnabled ? "1" : "0.45";
  sizeLimitBox.style.pointerEvents = currentSettings.sizeLimitEnabled ? "auto" : "none";

  whitelistBox.style.opacity = currentSettings.whitelistEnabled ? "1" : "0.45";
  whitelistBox.style.pointerEvents = currentSettings.whitelistEnabled ? "auto" : "none";
}

function renderHistory(scanHistory = []) {
  const filterVal = historyFilterSelect.value;
  const hQuery = (document.getElementById("historySearchInput")?.value || "").trim().toLowerCase();
  let filtered =
    filterVal === "threats"
      ? scanHistory.filter(i => (i.malicious || 0) > 0 || (i.suspicious || 0) > 0 || i.verdict === "danger")
      : scanHistory;
  if (hQuery) {
    filtered = filtered.filter(
      i => (i.filename || "").toLowerCase().includes(hQuery) || (i.sha256 || "").toLowerCase().includes(hQuery)
    );
  }

  if (!filtered.length) {
    setSafeHtml(historyList, `<div class="empty-history">${
      filterVal === "threats" ? "Угроз в истории не обнаружено" : "Пока нет проверенных объектов"
    }</div>`);
    return;
  }

  historyList.textContent = "";
  for (const item of filtered.slice(0, 15)) {
    const row = document.createElement("div");
    row.className = "history-item";

    const isEn = currentSettings.uiLang === "en";
    const name = document.createElement("span");
    name.className = "history-name";
    name.style.cursor = "pointer";
    name.title = isEn ? `${item.filename} (Click to open scan window)` : `${item.filename} (Нажмите, чтобы открыть окно проверки)`;
    name.textContent = `${item.autoBlocked ? "🛑 " : ""}${item.filename}`;
    const openHistoryItemCard = (forcePageCard = false) => {
      chrome.runtime.sendMessage({ type: "VT_REOPEN_SCAN_CARD", scanId: item.scanId, historyItem: item, forcePageCard }, (res) => {
        if (res && res.ok && res.payload && manualResultBox) {
          manualResultBox.style.display = "block";
          renderFullScanCardInPopup(manualResultBox, res.payload, false);
          manualResultBox.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
      });
    };

    name.addEventListener("click", () => openHistoryItemCard(true));

    const actions = document.createElement("div");
    actions.className = "history-actions";

    const scoreSpan = document.createElement("span");
    const badgeClass =
      item.verdict === "danger"
        ? "badge-danger"
        : item.verdict === "warning"
        ? "badge-warn"
        : "badge-safe";
    scoreSpan.className = badgeClass;
    scoreSpan.textContent = `${item.malicious || 0}/${item.total || 0}`;
    actions.appendChild(scoreSpan);

    const dlNowBtn = document.createElement("button");
    dlNowBtn.type = "button";
    dlNowBtn.className = "hist-act-btn";
    dlNowBtn.style.cssText = "background:rgba(16,185,129,0.2);color:#34d399;border-color:rgba(16,185,129,0.45);font-weight:800;";
    dlNowBtn.title = isEn ? "Unblock / Save (Download) this file now" : "Разблокировать и сохранить (скачать) этот файл";
    dlNowBtn.textContent = isEn ? "📥 Save" : "📥 Скачать";
    dlNowBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const origTxt = dlNowBtn.textContent;
      dlNowBtn.textContent = "⏳...";
      chrome.runtime.sendMessage({
        type: "VT_FORCE_DOWNLOAD_ITEM",
        scanId: item.scanId,
        downloadId: item.downloadId,
        fileUrl: item.fileUrl,
        filename: item.filename
      }, (res) => {
        dlNowBtn.textContent = (res && res.ok) ? (isEn ? "✅ Saved!" : "✅ Скачано!") : (isEn ? "✓ Opened" : "✓ Открыто");
        setTimeout(() => { dlNowBtn.textContent = origTxt; }, 1800);
        openHistoryItemCard(false);
      });
    });
    actions.appendChild(dlNowBtn);

    const openCardBtn = document.createElement("button");
    openCardBtn.type = "button";
    openCardBtn.className = "hist-act-btn";
    openCardBtn.title = isEn ? "Open full scan report card" : "Открыть полное окно отчёта проверки";
    openCardBtn.textContent = isEn ? "🔍 Window" : "🔍 Окно";
    openCardBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const origTxt = openCardBtn.textContent;
      openCardBtn.textContent = isEn ? "✅ Opened" : "✅ Открыто";
      setTimeout(() => { openCardBtn.textContent = origTxt; }, 1400);
      openHistoryItemCard(true);
    });
    actions.appendChild(openCardBtn);

    const copyVal = (item.sha256 && /^[a-f0-9]{32,64}$/i.test(item.sha256))
      ? item.sha256
      : (item.sha256 || item.fileUrl || item.reportUrl || item.filename || "");
    if (copyVal) {
      const copyHashBtn = document.createElement("button");
      copyHashBtn.type = "button";
      copyHashBtn.className = "hist-act-btn";
      copyHashBtn.title = isEn ? `Copy: ${copyVal}` : `Скопировать: ${copyVal}`;
      copyHashBtn.textContent = isEn ? "📋 Hash" : "📋 Хеш";
      copyHashBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        let copiedOk = false;
        try {
          await navigator.clipboard.writeText(copyVal);
          copiedOk = true;
        } catch (_) {
          try {
            const ta = document.createElement("textarea");
            ta.value = copyVal;
            ta.style.cssText = "position:fixed;left:-9999px;top:-9999px;";
            document.body.appendChild(ta);
            ta.select();
            document.execCommand("copy");
            ta.remove();
            copiedOk = true;
          } catch (__) {}
        }
        if (copiedOk) {
          copyHashBtn.style.color = "#34d399";
          copyHashBtn.textContent = isEn ? "✅ Copied!" : "✅ Скопировано!";
          setTimeout(() => {
            copyHashBtn.style.color = "";
            copyHashBtn.textContent = isEn ? "📋 Hash" : "📋 Хеш";
          }, 1600);
        }
        flashSaved(isEn ? "✓ Copied to clipboard" : "✓ Скопировано в буфер обмена");
      });
      actions.appendChild(copyHashBtn);
    }

    if (item.reportUrl) {
      const openBtn = document.createElement("a");
      openBtn.className = "hist-act-btn";
      openBtn.href = item.reportUrl;
      openBtn.target = "_blank";
      openBtn.rel = "noopener noreferrer";
      openBtn.title = "Открыть отчёт на сайте VirusTotal";
      openBtn.textContent = "↗";
      actions.appendChild(openBtn);
    }

    row.appendChild(name);
    row.appendChild(actions);
    historyList.appendChild(row);
  }
}

function refreshRateLimitsBadge() {
  chrome.runtime.sendMessage({ type: "VT_GET_RATE_LIMITS" }, (res) => {
    if (!res) return;
    const qPart = res.queueLength > 0 ? ` | Очередь: ${res.queueLength}` : "";
    const txt = `Лимиты: ${res.minuteUsed}/${res.minuteLimit} в мин | ${res.dailyUsed}/${res.dailyLimit} сегодня${qPart}`;
    const finalTxt = (currentSettings.uiLang === "en" && typeof translateDynamicRuToEn === "function")
      ? translateDynamicRuToEn(txt)
      : txt;
    if (rateLimitBadgeMain) rateLimitBadgeMain.textContent = finalTxt;
    if (rateLimitBadgeSettings) rateLimitBadgeSettings.textContent = finalTxt;
    const cSpan = document.getElementById("cacheCountSpan");
    if (cSpan) cSpan.textContent = String(res.cacheCount || 0);
    const tSpan = document.getElementById("trustedCountSpan");
    if (tSpan) tSpan.textContent = String(res.trustedCount || 0);
  });
}

async function init() {
  // Сразу убираем предупреждающий бейдж ("1!", "1?") с иконки расширения при открытии окна просмотра!
  try { (chrome.action || chrome.browserAction).setBadgeText({ text: "" }); } catch (_) {}
  try { chrome.runtime.sendMessage({ type: "VT_CLEAR_BADGE" }); } catch (_) {}

  const stored = await safeStorageGet({ ...DEFAULT_POPUP_SETTINGS, migrationV32DefaultsDone: false });
  if (!stored.migrationV32DefaultsDone) {
    stored.filterMode = "all";
    stored.sizeLimitEnabled = false;
    stored.whitelistEnabled = false;
    stored.stickerLockClickThrough = true;
    stored.migrationV32DefaultsDone = true;
    await safeStorageSet({
      filterMode: "all",
      sizeLimitEnabled: false,
      whitelistEnabled: false,
      stickerLockClickThrough: true,
      migrationV32DefaultsDone: true
    });
  }
  if (!stored.migrationV33DefaultsDone) {
    stored.noKeyMode = "pc_antivirus_mode";
    stored.localPcAntivirusEnabled = true;
    stored.migrationV33DefaultsDone = true;
    await safeStorageSet({
      noKeyMode: "pc_antivirus_mode",
      localPcAntivirusEnabled: true,
      migrationV33DefaultsDone: true
    });
  }
  if (!stored.migrationV34DefaultsDone) {
    stored.hotkeysEnabled = false;
    stored.vtApiKeyModeEnabled = true;
    stored.zeroKeyAndPcAvModeEnabled = true;
    stored.migrationV34DefaultsDone = true;
    await safeStorageSet({
      hotkeysEnabled: false,
      vtApiKeyModeEnabled: true,
      zeroKeyAndPcAvModeEnabled: true,
      migrationV34DefaultsDone: true
    });
  }
  if (!stored.migrationV35DefaultsDone) {
    stored.hoverBadgeEnabled = false;
    stored.noKeyMode = "autonomous_all_in_one";
    stored.migrationV35DefaultsDone = true;
    await safeStorageSet({
      hoverBadgeEnabled: false,
      noKeyMode: "autonomous_all_in_one",
      migrationV35DefaultsDone: true
    });
  }
  currentSettings = { ...DEFAULT_POPUP_SETTINGS, ...(stored || {}) };

  const blockedWebExts = new Set(["php", "html", "htm", "xhtml", "mhtml", "css", "scss", "less", "asp", "aspx", "jsp"]);
  if (Array.isArray(stored.extensions)) {
    stored.extensions = stored.extensions.filter(e => !blockedWebExts.has(String(e).toLowerCase()));
    currentSettings.extensions = [...stored.extensions];
  }
  allAvailableExtensions = new Set(KNOWN_EXTENSIONS);
  for (const ext of stored.extensions || []) {
    if (!blockedWebExts.has(ext.toLowerCase())) {
      allAvailableExtensions.add(ext.toLowerCase());
    }
  }

  enabledToggle.checked = Boolean(stored.enabled);
  autoDownloadSafe.checked = Boolean(stored.autoDownloadSafe);
  showDetailedVendors.checked = Boolean(stored.showDetailedVendors);
  vendorDisplayMode.value = stored.vendorDisplayMode || "inline_and_modal";
  uploadPolicy.value = stored.uploadPolicy || "ask";
  if (noKeyModeSelect) noKeyModeSelect.value = stored.noKeyMode || "hybrid_web";
  if (proxyUrlInput) proxyUrlInput.value = stored.proxyUrl || "";

  apiKeyInput.value = stored.apiKey || "";
  updateKeyHint(currentSettings.apiKey);

  autoBlockEnabled.checked = Boolean(stored.autoBlockEnabled);
  falsePositiveMode.value = stored.falsePositiveMode || "smart";
  const thresh = Math.max(1, Number(stored.autoBlockThreshold) || 1);
  autoBlockSlider.value = String(Math.min(30, thresh));
  autoBlockInput.value = String(thresh);
  autoBlockIncludeSuspicious.checked = Boolean(stored.autoBlockIncludeSuspicious);
  strictBlockLock.checked = Boolean(stored.strictBlockLock);

  sizeLimitEnabled.checked = Boolean(stored.sizeLimitEnabled);
  maxFileSizeMB.value = String(stored.maxFileSizeMB || 500);
  maxHeavyCategoryMB.value = String(stored.maxHeavyCategoryMB || 200);

  whitelistEnabled.checked = Boolean(stored.whitelistEnabled);

  modeAll.checked = stored.filterMode === "all";
  modeSelected.checked = stored.filterMode !== "all";

  updateToggleDependentUIs();
  applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
  renderCategoryTabs();
  renderChips();
  renderWhitelistChips();
  renderHistory(stored.scanHistory);
  refreshRateLimitsBadge();
  setInterval(refreshRateLimitsBadge, 2500);
  const initUrlParams = new URLSearchParams(window.location.search);
  const isInPagePanel = initUrlParams.get("inpage_panel") === "1";
  const isStandalone = Boolean(initUrlParams.get("standalone_scan"));

  // Подключаем порт жизненного цикла попапа, чтобы в режиме «🔄 Оба окна рядом» карточка на сайте мгновенно сдвигалась левее окна расширения (на 625px) без перекрытия!
  try {
    chrome.runtime.connect({ name: "vt_popup_lifecycle" });
  } catch (_) {}

  // Если выбран режим «📊 Само окно вывода проверки поверх (перекрывает окно расширения)» (card_on_top)
  // и пользователь нажал на иконку расширения в браузере, когда на странице открыта карточка проверки —
  // открываем окно расширения прямо на странице ПОД карточкой проверки (чтобы карточка проверки физически ПЕРЕКРЫВАЛА окно расширения сверху!)
  if (!isInPagePanel && !isStandalone && (currentSettings.scanWindowDisplayMode || "card_on_top") === "card_on_top") {
    chrome.runtime.sendMessage({
      type: "VT_HANDOFF_TO_INPAGE_EXT",
      scanWindowDisplayMode: "card_on_top"
    }, (res) => {
      if (res && res.handedOff) {
        window.close();
      }
    });
  }
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.scanHistory && Array.isArray(changes.scanHistory.newValue)) {
        currentSettings.scanHistory = changes.scanHistory.newValue;
        renderHistory(currentSettings.scanHistory);
      }
    });
  } catch (_) {}
  if (typeof initV30LanguageAndTutorial === "function") {
    initV30LanguageAndTutorial();
  }
}

enabledToggle.addEventListener("change", () => {
  currentSettings.enabled = enabledToggle.checked;
  applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
  saveSettings();
});

autoDownloadSafe.addEventListener("change", () => {
  currentSettings.autoDownloadSafe = autoDownloadSafe.checked;
  saveSettings();
});

showDetailedVendors.addEventListener("change", () => {
  currentSettings.showDetailedVendors = showDetailedVendors.checked;
  updateToggleDependentUIs();
  applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
  saveSettings();
});

vendorDisplayMode.addEventListener("change", () => {
  currentSettings.vendorDisplayMode = vendorDisplayMode.value;
  saveSettings();
});

uploadPolicy.addEventListener("change", () => {
  currentSettings.uploadPolicy = uploadPolicy.value;
  saveSettings();
});

apiKeyInput.addEventListener("input", () => {
  const cleaned = sanitizeKeyInput(apiKeyInput.value);
  currentSettings.apiKey = cleaned;
  updateKeyHint(cleaned);
  saveSettings();
});

toggleKeyBtn.addEventListener("click", () => {
  apiKeyInput.type = apiKeyInput.type === "password" ? "text" : "password";
});

verifyKeyBtn.addEventListener("click", () => {
  const cleaned = sanitizeKeyInput(apiKeyInput.value);
  apiKeyInput.value = cleaned;
  currentSettings.apiKey = cleaned;
  saveSettings();

  verifyKeyBtn.disabled = true;
  verifyKeyBtn.textContent = "Проверка...";
  chrome.runtime.sendMessage({ type: "VT_VERIFY_API_KEY", apiKey: cleaned }, (res) => {
    verifyKeyBtn.disabled = false;
    verifyKeyBtn.textContent = "Проверить";
    if (res && res.ok) {
      keyValidationMsg.className = "key-msg ok";
      keyValidationMsg.textContent = "✅ Ключ активен! VirusTotal API v3 успешно отвечает.";
    } else {
      keyValidationMsg.className = "key-msg err";
      keyValidationMsg.textContent = `❌ ${res?.error || "Не удалось проверить ключ"}`;
    }
  });
});

autoBlockEnabled.addEventListener("change", () => {
  currentSettings.autoBlockEnabled = autoBlockEnabled.checked;
  updateToggleDependentUIs();
  applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
  saveSettings();
});

falsePositiveMode.addEventListener("change", () => {
  currentSettings.falsePositiveMode = falsePositiveMode.value;
  saveSettings();
});

autoBlockSlider.addEventListener("input", () => {
  const val = Math.max(1, Number(autoBlockSlider.value) || 1);
  autoBlockInput.value = String(val);
  currentSettings.autoBlockThreshold = val;
  saveSettings();
});

autoBlockInput.addEventListener("change", () => {
  const val = Math.max(1, Math.min(75, Number(autoBlockInput.value) || 1));
  autoBlockInput.value = String(val);
  autoBlockSlider.value = String(Math.min(30, val));
  currentSettings.autoBlockThreshold = val;
  saveSettings();
});

autoBlockIncludeSuspicious.addEventListener("change", () => {
  currentSettings.autoBlockIncludeSuspicious = autoBlockIncludeSuspicious.checked;
  saveSettings();
});

strictBlockLock.addEventListener("change", () => {
  currentSettings.strictBlockLock = strictBlockLock.checked;
  saveSettings();
});

sizeLimitEnabled.addEventListener("change", () => {
  currentSettings.sizeLimitEnabled = sizeLimitEnabled.checked;
  updateToggleDependentUIs();
  applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
  saveSettings();
});

maxFileSizeMB.addEventListener("change", () => {
  currentSettings.maxFileSizeMB = Math.max(10, Number(maxFileSizeMB.value) || 500);
  saveSettings();
});

maxHeavyCategoryMB.addEventListener("change", () => {
  currentSettings.maxHeavyCategoryMB = Math.max(10, Number(maxHeavyCategoryMB.value) || 200);
  saveSettings();
});

whitelistEnabled.addEventListener("change", () => {
  currentSettings.whitelistEnabled = whitelistEnabled.checked;
  updateToggleDependentUIs();
  applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
  saveSettings();
});

function addWhitelistDomains() {
  const raw = customDomainInput.value.trim();
  if (!raw) return;
  const parts = raw
    .split(/[\s,;]+/)
    .map(d => d.replace(/^https?:\/\//i, "").split("/")[0].toLowerCase().trim())
    .filter(Boolean);

  const set = new Set(currentSettings.domainWhitelist || []);
  for (const p of parts) set.add(p);
  currentSettings.domainWhitelist = Array.from(set);
  customDomainInput.value = "";
  renderWhitelistChips();
  saveSettings();
}

addDomainBtn.addEventListener("click", addWhitelistDomains);
customDomainInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addWhitelistDomains();
});

modeAll.addEventListener("change", () => {
  if (modeAll.checked) {
    currentSettings.filterMode = "all";
    renderCategoryTabs();
    renderChips();
    saveSettings();
  }
});

modeSelected.addEventListener("change", () => {
  if (modeSelected.checked) {
    currentSettings.filterMode = "selected";
    renderCategoryTabs();
    renderChips();
    saveSettings();
  }
});

searchExtInput.addEventListener("input", () => {
  searchQuery = searchExtInput.value.trim();
  renderChips();
});

selectAllPreset.addEventListener("click", () => {
  currentSettings.extensions = Array.from(allAvailableExtensions);
  renderCategoryTabs();
  renderChips();
  saveSettings();
});

clearAllPreset.addEventListener("click", () => {
  currentSettings.extensions = [];
  renderCategoryTabs();
  renderChips();
  saveSettings();
});

selectExecPreset.addEventListener("click", () => {
  currentSettings.extensions = [...DANGEROUS_PRESET];
  renderCategoryTabs();
  renderChips();
  saveSettings();
});

toggleCategoryBtn.addEventListener("click", () => {
  const catExts = getExtensionsForCategory(activeCategoryId);
  const activeSet = new Set(currentSettings.extensions.map(e => e.toLowerCase()));
  const allSelected = catExts.every(e => activeSet.has(e));

  for (const e of catExts) {
    if (allSelected) {
      activeSet.delete(e);
    } else {
      activeSet.add(e);
    }
  }
  currentSettings.extensions = Array.from(activeSet);
  renderCategoryTabs();
  renderChips();
  saveSettings();
});

function addCustomExtensions() {
  const raw = customExtInput.value.trim();
  if (!raw) return;
  const parts = raw
    .split(/[\s,;]+/)
    .map(s => s.replace(/^\./, "").toLowerCase().trim())
    .filter(Boolean);

  const activeSet = new Set(currentSettings.extensions.map(e => e.toLowerCase()));
  for (const p of parts) {
    allAvailableExtensions.add(p);
    activeSet.add(p);
  }
  currentSettings.extensions = Array.from(activeSet);
  customExtInput.value = "";
  renderCategoryTabs();
  renderChips();
  saveSettings();
}

addExtBtn.addEventListener("click", addCustomExtensions);
customExtInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") addCustomExtensions();
});

historyFilterSelect.addEventListener("change", () => {
  renderHistory(currentSettings.scanHistory);
});

clearHistoryBtn.addEventListener("click", async () => {
  currentSettings.scanHistory = [];
  await safeStorageSet({ scanHistory: [] });
  try { (chrome.action || chrome.browserAction).setBadgeText({ text: "" }); } catch (_) {}
  try { chrome.runtime.sendMessage({ type: "VT_CLEAR_BADGE" }); } catch (_) {}
  renderHistory([]);
  flashSaved("✓ История и предупреждения очищены");
});

// Полный экспорт всех настроек, кастомизации и пресетов в JSON-файл
exportSettingsBtn.addEventListener("click", () => {
  const settingsCopy = { ...currentSettings };
  delete settingsCopy.scanHistory;
  const exportData = {
    version: "2.9.0",
    exportedAt: new Date().toISOString(),
    settings: settingsCopy
  };
  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "vt_download_guard_settings_v2.9.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  flashSaved("✓ Все настройки и темы экспортированы в JSON");
});

// Импорт настроек из JSON-файла
importSettingsBtn.addEventListener("click", () => {
  importFileInput.click();
});

importFileInput.addEventListener("change", (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const parsed = JSON.parse(String(reader.result));
      const imported = parsed.settings || parsed;
      currentSettings = { ...currentSettings, ...imported };
      await saveSettings();
      await init();
      flashSaved("✓ Настройки успешно импортированы!");
    } catch (_) {
      flashSaved("❌ Ошибка чтения JSON-файла настроек");
    }
  };
  reader.readAsText(file);
});

if (proxyUrlInput) {
  proxyUrlInput.addEventListener("input", () => {
    currentSettings.proxyUrl = proxyUrlInput.value.trim();
    saveSettings();
  });
}

if (noKeyModeSelect) {
  noKeyModeSelect.addEventListener("change", () => {
    currentSettings.noKeyMode = noKeyModeSelect.value;
    saveSettings();
  });
}

// Полноценная отрисовка карточки проверки (1-в-1 как плашка на сайте при скачивании!)

let lastRenderedPopupScanPayload = null;
function applyPopupWindowPriorityView(modeOverride) {
  const urlP = new URLSearchParams(window.location.search);
  // Скрываем меню расширения ТОЛЬКО если пользователь сам открыл отдельное мини-окно карточки (?standalone_scan=...&view=card)
  if (!urlP.get("standalone_scan") || urlP.get("view") !== "card") {
    return;
  }
  const mode = modeOverride || currentSettings.scanWindowDisplayMode || "card_on_top";
  const isEn = currentSettings.uiLang === "en";
  const hasActiveCard = Boolean(manualResultBox && manualResultBox.style.display !== "none" && lastRenderedPopupScanPayload);
  const toToggle = document.querySelectorAll(".header, .main-tabs, .lifetime-stats-bar, .footer, #tabMain > section.card");
  let existingBar = document.getElementById("vtPopupViewSwitchBar");

  if (mode === "card_on_top" && hasActiveCard) {
    // Прячем интерфейс настроек расширения и оставляем ТОЛЬКО чистое окно вывода проверки!
    document.querySelectorAll(".main-tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === "tabMain"));
    document.querySelectorAll(".tab-pane").forEach(p => p.classList.toggle("active", p.id === "tabMain"));
    toToggle.forEach((el) => {
      if (manualResultBox && el.contains(manualResultBox)) {
        Array.from(el.children).forEach(ch => {
          if (ch !== manualResultBox && ch.id !== "vtPopupViewSwitchBar") ch.style.display = "none";
        });
        el.style.padding = "0";
        el.style.border = "none";
        el.style.background = "transparent";
      } else {
        el.style.display = "none";
      }
    });
    if (!existingBar && manualResultBox && manualResultBox.parentNode) {
      existingBar = document.createElement("div");
      existingBar.id = "vtPopupViewSwitchBar";
      existingBar.style.cssText = "display:flex;justify-content:space-between;align-items:center;gap:6px;margin-bottom:6px;";
      setSafeHtml(existingBar, `
        <button type="button" id="vtBackToFullExtBtn" class="mini-btn accent" style="font-weight:700;">
          ${isEn ? "← Back to Extension Menu" : "← Назад в меню расширения"}
        </button>
        <span style="font-size:10.5px;color:#7dd3fc;font-weight:700;">
          ${isEn ? "📊 Mode: Scan Card Only" : "📊 Режим: Только вывод проверки"}
        </span>
      `);
      manualResultBox.parentNode.insertBefore(existingBar, manualResultBox);
      const backBtn = existingBar.querySelector("#vtBackToFullExtBtn");
      if (backBtn) {
        backBtn.addEventListener("click", () => {
          toToggle.forEach((el) => {
            el.style.display = "";
            if (manualResultBox && el.contains(manualResultBox)) {
              Array.from(el.children).forEach(ch => { ch.style.display = ""; });
              el.style.padding = "";
              el.style.border = "";
              el.style.background = "";
            }
          });
          if (existingBar) existingBar.remove();
        });
      }
    }
  } else {
    // Режим «🛡️ Окно с расширением поверх» или «🔄 Оба окна рядом» — показываем полный интерфейс расширения!
    toToggle.forEach((el) => {
      el.style.display = "";
      if (manualResultBox && el.contains(manualResultBox)) {
        Array.from(el.children).forEach(ch => { ch.style.display = ""; });
        el.style.padding = "";
        el.style.border = "";
        el.style.background = "";
      }
    });
    if (existingBar) existingBar.remove();
  }
}

function renderFullScanCardInPopup(targetContainer, data, isStandaloneWindow = false) {
  if (!targetContainer || !data) return;
  lastRenderedPopupScanPayload = data;
  const isEn = currentSettings.uiLang === "en";
  targetContainer.style.display = "block";
  targetContainer.style.padding = "12px";
  targetContainer.style.borderRadius = "12px";
  targetContainer.style.border = data.verdict === "danger"
    ? "1.5px solid #ef4444"
    : data.verdict === "warning"
    ? "1.5px solid #f59e0b"
    : "1.5px solid #10b981";
  targetContainer.style.background = "rgba(10, 22, 40, 0.92)";
  targetContainer.style.boxShadow = "0 12px 28px rgba(0,0,0,0.55)";

  const tr = (str) => (typeof translateDynamicRuToEn === "function" && isEn ? translateDynamicRuToEn(str) : str);

  if (data.state === "scanning") {
    setSafeHtml(targetContainer, `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <strong style="color:#38bdf8;font-size:13px;">🐟 VT Salmon Ocean Guard</strong>
        <span style="background:#1e293b;color:#94a3b8;border:1px solid #334155;font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:6px;text-transform:uppercase;">.${data.ext || "file"}</span>
      </div>
      <div style="font-size:13px;font-weight:800;color:#f8fafc;word-break:break-all;margin-bottom:8px;">${data.filename || "File"}</div>
      <div style="padding:10px;border-radius:8px;background:rgba(15,23,42,0.75);border:1px solid #1e293b;color:#cbd5e1;font-size:12px;margin-bottom:8px;">
        ⏳ ${tr(data.stepText || "Проверка файла в VirusTotal...")}
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <button type="button" id="popupSkipScanSaveBtn" style="flex:1;background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;border-radius:8px;padding:8px 10px;font-size:11.5px;font-weight:800;cursor:pointer;">
          ${isEn ? "⚡ Cancel Scan & Save (Download)" : "⚡ Отменить проверку и скачать (сохранить)"}
        </button>
        <button type="button" id="popupAbortScanDelBtn" style="background:#1e293b;color:#fca5a5;border:1px solid rgba(248,113,113,0.4);border-radius:8px;padding:8px 10px;font-size:11.5px;font-weight:700;cursor:pointer;">
          ${isEn ? "✕ Delete" : "✕ Удалить"}
        </button>
      </div>
    `);
    const skipBtn = targetContainer.querySelector("#popupSkipScanSaveBtn");
    if (skipBtn) {
      skipBtn.addEventListener("click", () => {
        skipBtn.disabled = true;
        skipBtn.textContent = isEn ? "✓ Saving file..." : "✓ Сохранение файла...";
        chrome.runtime.sendMessage(
          { type: "VT_SKIP_SCAN_AND_SAVE", scanId: data.scanId, filename: data.filename },
          () => {
            if (isStandaloneWindow) {
              window.close();
            } else {
              targetContainer.style.display = "none";
              flashSaved(isEn ? "✓ Scan cancelled, file saved!" : "✓ Проверка отменена, файл сохранён!");
            }
          }
        );
      });
    }
    const delBtn = targetContainer.querySelector("#popupAbortScanDelBtn");
    if (delBtn) {
      delBtn.addEventListener("click", () => {
        delBtn.disabled = true;
        chrome.runtime.sendMessage(
          { type: "VT_CANCEL_DOWNLOAD", scanId: data.scanId },
          () => {
            if (isStandaloneWindow) {
              window.close();
            } else {
              targetContainer.style.display = "none";
              flashSaved(isEn ? "✓ Download cancelled and removed" : "✓ Загрузка отменена и удалена");
            }
          }
        );
      });
    }
    applyPopupWindowPriorityView();
    return;
  }

  const ts = data.trustScore !== undefined && data.trustScore !== null ? Number(data.trustScore) : (data.smartSummary?.trustScore ?? 94);
  const tsColor = ts >= 80 ? "#34d399" : ts >= 55 ? "#fbbf24" : "#ef4444";
  const sm = data.smartSummary || null;

  let smHtml = "";
  if (sm) {
    const whatCouldBeBlock = sm.whatFileCouldBe
      ? `<div style="margin-bottom:6px;padding:6px 8px;border-radius:6px;background:rgba(56,189,248,0.11);border-left:3px solid ${sm.riskColor || '#38bdf8'};font-size:11.5px;line-height:1.45;">
           <strong>${isEn ? "🎯 What this file could be:" : "🎯 Чем может являться файл:"}</strong> ${tr(sm.whatFileCouldBe)}
         </div>`
      : "";

    const capsListHtml = Array.isArray(sm.capabilities) && sm.capabilities.length > 0
      ? `<div style="font-weight:700;color:#94a3b8;margin:5px 0 3px 0;font-size:11px;">${isEn ? "🔍 Inside & What the file can do:" : "🔍 Что внутри и что может делать файл:"}</div>
         <ul style="margin:0 0 6px 16px;padding:0;font-size:11px;line-height:1.45;color:#e2e8f0;">
           ${sm.capabilities.map(c => `<li style="margin-bottom:2px;">${tr(c)}</li>`).join("")}
         </ul>`
      : "";

    let radarHtml = "";
    if (Array.isArray(sm.radarMetrics) && sm.radarMetrics.length > 0) {
      const rows = sm.radarMetrics.map(m => {
        const pct = Math.min(100, Math.max(4, (m.score || 0) * 10));
        const col = m.score >= 7 ? "#ef4444" : m.score >= 4 ? "#fbbf24" : "#34d399";
        return `
          <div style="display:grid;grid-template-columns:138px 1fr 28px;align-items:center;gap:6px;font-size:10px;">
            <span style="color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${tr(m.label)}</span>
            <div style="height:4.5px;background:#1e293b;border-radius:3px;overflow:hidden;">
              <div style="width:${pct}%;height:100%;background:${col};"></div>
            </div>
            <span style="text-align:right;color:${col};font-weight:700;">${m.score}/10</span>
          </div>
        `;
      }).join("");
      radarHtml = `
        <div style="margin:6px 0;padding:6px 8px;border-radius:6px;background:rgba(15,23,42,0.55);border:1px solid rgba(148,163,184,0.18);display:flex;flex-direction:column;gap:3px;">
          <div style="font-size:10px;font-weight:700;color:#94a3b8;margin-bottom:2px;">${isEn ? "📡 Risk Factor Radar (0–10):" : "📡 Радар факторов риска (0–10):"}</div>
          ${rows}
        </div>
      `;
    }

    let xrayHtml = "";
    if (sm.xrayBreakdown) {
      const xb = sm.xrayBreakdown;
      xrayHtml = `
        <div style="margin:5px 0;padding:5px 8px;border-radius:6px;background:rgba(15,23,42,0.55);border:1px solid rgba(148,163,184,0.18);">
          <div style="display:flex;justify-content:space-between;font-size:10px;color:#94a3b8;margin-bottom:3px;">
            <span>${isEn ? "🔬 File Structure X-Ray (Entropy:" : "🔬 Рентген структуры файла (Энтропия:"} ${xb.entropy}/8.0)</span>
            <span>${xb.certPct > 0 ? (isEn ? "🔏 Signed" : "🔏 Подписан") : (isEn ? "Unsigned" : "Без ЭЦП")}</span>
          </div>
          <div style="display:flex;width:100%;height:6px;border-radius:3px;overflow:hidden;gap:1px;">
            <div style="width:${xb.headerPct}%;background:#38bdf8;"></div>
            <div style="width:${xb.codePct}%;background:#10b981;"></div>
            <div style="width:${xb.packedPct}%;background:#a855f7;"></div>
            ${xb.certPct > 0 ? `<div style="width:${xb.certPct}%;background:#facc15;"></div>` : ""}
          </div>
        </div>
      `;
    }

    smHtml = `
      <div style="margin-top:8px;padding:9px 10px;border-radius:9px;background:rgba(15,23,42,0.78);border:1.5px solid ${sm.riskColor || '#38bdf8'};">
        <div style="font-size:12px;font-weight:800;color:${sm.riskColor || '#34d399'};margin-bottom:6px;">🧠 ${tr(sm.riskBadge)}</div>
        <div style="margin-bottom:6px;padding:6px 8px;border-radius:6px;background:rgba(15,23,42,0.65);border:1px solid rgba(148,163,184,0.2);">
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:10.5px;font-weight:700;margin-bottom:4px;">
            <span>${isEn ? "📊 Trust Score (by complaint classifier):" : "📊 Уровень доверия (по классификатору жалоб):"}</span>
            <span style="color:${tsColor};font-size:11.5px;">${ts}% / 100%</span>
          </div>
          <div style="width:100%;height:6px;background:#1e293b;border-radius:4px;overflow:hidden;">
            <div style="width:${ts}%;height:100%;background:${tsColor};"></div>
          </div>
          ${sm.trustReason ? `<div style="font-size:10px;color:#94a3b8;margin-top:3px;">↳ ${isEn ? "Basis:" : "Основание оценки:"} ${tr(sm.trustReason)}</div>` : ""}
        </div>
        ${whatCouldBeBlock}
        <div style="font-size:11.5px;line-height:1.45;color:#f1f5f9;margin-bottom:5px;">
          <strong>${isEn ? "What AVs flag:" : "На что жалуются АВ:"}</strong> ${tr(sm.whatComplains)}
        </div>
        ${capsListHtml}
        ${radarHtml}
        ${xrayHtml}
        <div style="font-size:11px;font-weight:700;color:#bae6fd;border-top:1px dashed rgba(148,163,184,0.25);padding-top:5px;margin-top:4px;">
          ${tr(sm.recommendation || "")}
        </div>
      </div>
    `;
  }

  const vendors = Array.isArray(data.allVendors) ? data.allVendors : [];
  let vendorsHtml = "";
  if (vendors.length > 0) {
    const rows = vendors.slice(0, 72).map(v => {
      const col = v.category === "malicious" ? "#f87171" : v.category === "suspicious" ? "#fbbf24" : "#34d399";
      const star = v.trusted ? `<span style="color:#facc15;" title="Trusted Vendor">★</span> ` : "";
      return `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:3px 6px;border-bottom:1px solid rgba(51,65,85,0.45);font-size:10.5px;">
          <span style="color:#e2e8f0;font-weight:600;">${star}${v.engine}</span>
          <span style="color:${col};font-weight:700;">${v.result || (v.category === "harmless" ? "Clean" : "Undetected")}</span>
        </div>
      `;
    }).join("");
    vendorsHtml = `
      <div style="margin-top:8px;border:1px solid #334155;border-radius:8px;overflow:hidden;background:rgba(15,23,42,0.65);">
        <div style="padding:5px 8px;background:#1e293b;font-size:10.5px;font-weight:700;color:#94a3b8;display:flex;justify-content:space-between;">
          <span>Security vendors' analysis (${vendors.length})</span>
          <span>★ = Trusted AV</span>
        </div>
        <div style="max-height:130px;overflow-y:auto;">${rows}</div>
      </div>
    `;
  }

  const shaStr = data.fileMeta?.sha256 || "";
  const vtLink = data.reportUrl || (shaStr.length === 64 ? `https://www.virustotal.com/gui/file/${shaStr}` : "https://www.virustotal.com/gui/home/upload");

  const autoSavedBannerHtml = data.autoDownloaded
    ? `<div style="padding:6px 9px;border-radius:7px;background:rgba(16,185,129,0.16);border:1px solid rgba(52,211,153,0.45);color:#34d399;font-size:11px;font-weight:800;margin-top:6px;margin-bottom:4px;text-align:center;">
         ✅ ${isEn ? "File is clean — automatically saved to Downloads!" : "Файл чист — автоматически сохранён в Загрузки!"}
       </div>`
    : "";
  const standaloneActionsHtml = `${autoSavedBannerHtml}<div style="display:flex;gap:6px;margin-top:6px;margin-bottom:6px;">
         <button type="button" id="popupCardBlockBtn" class="mini-btn" style="flex:1;background:rgba(239,68,68,0.18);color:#fca5a5;border:1px solid rgba(248,113,113,0.45);padding:7px;font-weight:700;">🗑️ ${isEn ? "Delete File" : "Удалить файл"}</button>
         <button type="button" id="popupCardDownloadBtn" class="mini-btn accent" style="flex:1;background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;padding:7px;font-weight:800;">📥 ${data.autoDownloaded ? (isEn ? "Save Copy Again" : "Сохранить ещё раз") : (isEn ? "Save (Download) File" : "Сохранить (скачать) файл")}</button>
       </div>`;

  setSafeHtml(targetContainer, `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px;">
      <strong style="color:#38bdf8;font-size:12.5px;">🐟 VT Salmon Ocean Guard</strong>
      <div style="display:flex;align-items:center;gap:5px;">
        <span style="background:rgba(15,23,42,0.85);color:${tsColor};border:1px solid ${tsColor};font-size:10px;font-weight:800;padding:2px 6px;border-radius:6px;">📊 ${isEn ? "Trust:" : "Доверие:"} ${ts}%</span>
        <span style="background:#1e293b;color:#94a3b8;border:1px solid #334155;font-size:10px;font-weight:700;padding:2px 6px;border-radius:6px;text-transform:uppercase;">.${data.ext || "file"}</span>
      </div>
    </div>
    <div style="font-size:13px;font-weight:800;color:#f8fafc;word-break:break-all;margin-bottom:4px;">${data.filename || "File"}</div>
    ${shaStr ? `<div style="font-size:10px;color:#94a3b8;font-family:monospace;word-break:break-all;margin-bottom:6px;">SHA-256: ${shaStr}</div>` : ""}
    <div style="font-size:11.5px;font-weight:700;color:${data.verdict === 'danger' ? '#f87171' : data.verdict === 'warning' ? '#fbbf24' : '#34d399'};margin-bottom:6px;">
      ${data.verdict === 'danger' ? '🚨' : data.verdict === 'warning' ? '⚠️' : '✅'} ${tr(data.summaryText || "")}
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:6px;">
      <div style="background:#0f172a;border:1px solid #1e293b;border-radius:7px;padding:5px;text-align:center;">
        <div style="font-size:14px;font-weight:800;color:#f87171;">${data.stats?.malicious || 0}</div>
        <div style="font-size:9.5px;color:#94a3b8;">${isEn ? "Threats" : "Угрозы"}</div>
      </div>
      <div style="background:#0f172a;border:1px solid #1e293b;border-radius:7px;padding:5px;text-align:center;">
        <div style="font-size:14px;font-weight:800;color:#fbbf24;">${data.stats?.suspicious || 0}</div>
        <div style="font-size:9.5px;color:#94a3b8;">${isEn ? "Suspicious" : "Подозрит."}</div>
      </div>
      <div style="background:#0f172a;border:1px solid #1e293b;border-radius:7px;padding:5px;text-align:center;">
        <div style="font-size:14px;font-weight:800;color:#34d399;">${data.stats?.harmless || 0}</div>
        <div style="font-size:9.5px;color:#94a3b8;">${isEn ? "Clean" : "Чисто"}</div>
      </div>
    </div>
    ${standaloneActionsHtml}
    <div class="manual-actions-row" style="margin-top:4px;margin-bottom:8px;padding-bottom:7px;border-bottom:1px solid rgba(148,163,184,0.2);">
      ${!isStandaloneWindow ? `<button type="button" id="openVtMiniPopupBtn" class="mini-btn accent" title="${isEn ? "Open this scan report card in a separate floating mini-window" : "Открыть карточку вывода этой проверки в отдельном мини-окне поверх экрана"}">🪟 ${isEn ? "Open in Mini-Window" : "Открыть в мини-окне"}</button>` : ""}
      <a href="${vtLink}" target="_blank" rel="noopener noreferrer" class="mini-btn" style="text-decoration:none;" title="${isEn ? "Open external VirusTotal webpage" : "Открыть веб-сайт VirusTotal в браузере"}">🌐 ${isEn ? "VirusTotal Site ↗" : "Сайт VirusTotal ↗"}</a>
      ${shaStr.length === 64 ? `<button type="button" id="copyManualShaBtn" class="mini-btn">📋 ${isEn ? "Copy SHA-256" : "Скопировать SHA-256"}</button>` : ""}
    </div>
    ${smHtml}
    ${vendorsHtml}
  `);

  const popupBtn = targetContainer.querySelector("#openVtMiniPopupBtn");
  if (popupBtn) {
    popupBtn.addEventListener("click", () => {
      const viewMode = (currentSettings.scanWindowDisplayMode || "card_on_top") === "extension_on_top" ? "ext" : "card";
      chrome.runtime.sendMessage({
        type: "VT_OPEN_OWN_MINI_WINDOW",
        scanId: data.scanId || `vt_mini_${Date.now()}`,
        payload: data,
        viewType: viewMode
      });
    });
  }
  const copyBtn = targetContainer.querySelector("#copyManualShaBtn");
  if (copyBtn && shaStr) {
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(shaStr);
      flashSaved(isEn ? "✓ SHA-256 copied!" : "✓ SHA-256 скопирован!");
    });
  }
  const blockBtn = targetContainer.querySelector("#popupCardBlockBtn");
  if (blockBtn) {
    blockBtn.addEventListener("click", () => {
      blockBtn.disabled = true;
      blockBtn.textContent = isEn ? "✓ Deleted" : "✓ Удалено";
      chrome.runtime.sendMessage({ type: "VT_CANCEL_DOWNLOAD", scanId: data.scanId, filename: data.filename }, () => {
        if (isStandaloneWindow) {
          window.close();
        } else {
          targetContainer.style.display = "none";
          flashSaved(isEn ? "✓ File download cancelled & deleted" : "✓ Загрузка отменена и файл удалён");
        }
      });
    });
  }
  const dlBtn = targetContainer.querySelector("#popupCardDownloadBtn");
  if (dlBtn) {
    dlBtn.addEventListener("click", () => {
      dlBtn.disabled = true;
      dlBtn.textContent = isEn ? "⏳ Saving..." : "⏳ Сохранение...";
      chrome.runtime.sendMessage({
        type: "VT_FORCE_DOWNLOAD_ITEM",
        scanId: data.scanId,
        downloadId: data.downloadId,
        fileUrl: data.fileUrl,
        filename: data.filename
      }, () => {
        dlBtn.textContent = isEn ? "✅ Saved!" : "✅ Файл сохранён!";
        setTimeout(() => {
          dlBtn.disabled = false;
          dlBtn.textContent = isEn ? "📥 Save (Download) File" : "📥 Сохранить (скачать) файл";
        }, 1800);
        if (isStandaloneWindow) {
          setTimeout(() => window.close(), 450);
        } else {
          flashSaved(isEn ? "✓ File saved!" : "✓ Файл разблокирован и сохранён!");
        }
      });
    });
  }
  applyPopupWindowPriorityView();
}

let lastManualFileSig = "";
let lastManualFileTs = 0;
async function handleManualLocalFile(file) {
  if (!file || !manualResultBox) return;
  const sig = `${file.name}_${file.size}_${file.lastModified}`;
  const now = Date.now();
  if (sig === lastManualFileSig && now - lastManualFileTs < 1500) return;
  lastManualFileSig = sig;
  lastManualFileTs = now;
  const isEn = currentSettings.uiLang === "en";
  manualResultBox.style.display = "block";
  setSafeHtml(manualResultBox, isEn
    ? "⏳ Computing SHA-256 & running full VT Download Guard inspection..."
    : "⏳ Расчёт SHA-256 и полная проверка файла (сигнатуры, Умная сводка и база VT)...");
  try {
    const buf = await file.arrayBuffer();
    const u8 = new Uint8Array(buf);
    const hashBuf = await crypto.subtle.digest("SHA-256", buf);
    const hashArray = Array.from(new Uint8Array(hashBuf));
    const sha256 = hashArray.map(b => b.toString(16).padStart(2, "0")).join("");

    const headBytes = Array.from(u8.subarray(0, Math.min(32768, u8.byteLength)));
    const tailBytes = Array.from(u8.subarray(Math.max(0, u8.byteLength - 65536), u8.byteLength));

    chrome.runtime.sendMessage(
      {
        type: "VT_FULL_MANUAL_FILE_SCAN",
        filename: file.name,
        fileSize: file.size,
        sha256,
        headBytes,
        tailBytes
      },
      (res) => {
        if (res && res.ok && res.payload) {
          renderFullScanCardInPopup(manualResultBox, res.payload, false);
          // Обновляем счётчики и историю
          safeStorageGet(DEFAULT_POPUP_SETTINGS).then(st => {
            renderHistory(st.scanHistory || []);
          });
        } else {
          manualResultBox.textContent = isEn ? "Error scanning file." : "Ошибка при проверке файла.";
        }
      }
    );
  } catch (err) {
    manualResultBox.textContent = (isEn ? "File read error: " : "Ошибка чтения файла: ") + (err.message || err);
  }
}

if (dropZoneBox && manualFileInput) {
  dropZoneBox.addEventListener("click", () => manualFileInput.click());
  dropZoneBox.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZoneBox.classList.add("dragover");
  });
  dropZoneBox.addEventListener("dragleave", () => dropZoneBox.classList.remove("dragover"));
  dropZoneBox.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZoneBox.classList.remove("dragover");
    const f = e.dataTransfer?.files?.[0];
    if (f) handleManualLocalFile(f);
  });
  manualFileInput.addEventListener("change", (e) => {
    const f = e.target.files?.[0];
    if (f) {
      handleManualLocalFile(f);
      manualFileInput.value = "";
    }
  });
}

function triggerManualQueryCheck() {
  const raw = (manualQueryInput?.value || "").trim();
  if (!raw || !manualResultBox) return;
  const isEn = currentSettings.uiLang === "en";
  manualResultBox.style.display = "block";
  setSafeHtml(manualResultBox, isEn
    ? "⏳ Checking URL / Hash reputation, Anti-Phishing, RDAP & VirusTotal database..."
    : "⏳ Проверка ссылки / хеша (Анти-фишинг, возраст домена RDAP и база VirusTotal)...");

  chrome.runtime.sendMessage(
    {
      type: "VT_FULL_MANUAL_URL_OR_HASH_SCAN",
      query: raw
    },
    (res) => {
      if (res && res.ok && res.payload) {
        renderFullScanCardInPopup(manualResultBox, res.payload, false);
        safeStorageGet(DEFAULT_POPUP_SETTINGS).then(st => {
          renderHistory(st.scanHistory || []);
        });
      } else {
        manualResultBox.textContent = (res && res.error)
          ? res.error
          : (isEn ? "Error checking URL or hash." : "Ошибка при проверке ссылки или хеша.");
      }
    }
  );
}

if (manualCheckBtn && manualQueryInput) {
  manualCheckBtn.addEventListener("click", triggerManualQueryCheck);
  manualQueryInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") triggerManualQueryCheck();
  });
}


// Позволяем переключать тумблеры кликом по всей строке описания (без конфликта вложенных label)
document.querySelectorAll(".toggle-feature-row").forEach((row) => {
  row.addEventListener("click", (e) => {
    if (e.target.closest(".switch, button, a, input, select")) return; // Клик по самому тумблеру уже обрабатывается нативно
    const cb = row.querySelector('input[type="checkbox"]');
    if (cb) {
      cb.checked = !cb.checked;
      cb.dispatchEvent(new Event("change", { bubbles: true }));
    }
  });
});


// ==================== v1.8.0: УПРАВЛЕНИЕ ТЕМАМИ, ИКОНКАМИ, ПОЗИЦИЕЙ ПЛАШКИ И ЗВУКОМ ====================
const THEMES_ORDER = ["salmon_ocean", "helldivers2", "ozen_abyss", "vocaloid_teto", "vocaloid_miku", "dark_cyber", "oled_matrix", "purple_synth", "crimson_guard", "light_clean"];
const THEME_TO_ICON = {
  dark_cyber: "blue",
  salmon_ocean: "salmon",
  helldivers2: "helldivers",
  ozen_abyss: "ozen",
  vocaloid_teto: "teto",
  vocaloid_miku: "miku",
  oled_matrix: "emerald",
  purple_synth: "purple",
  crimson_guard: "crimson",
  light_clean: "blue"
};

const THEME_FLAVOR_TEXT = {
  salmon_ocean: "🐟 SALMON & LOSOS OCEAN // БЕРЕГОВАЯ ОХРАНА ФАЙЛОВ 🌊",
  helldivers2: "💀 SUPER EARTH MINISTRY OF DEFENSE // ЗА СУПЕР-ЗЕМЛЮ! ⬆️➡️⬇️⬇️⬇️",
  ozen_abyss: "⛓️ MADE IN ABYSS // СТРАЖ БЕЗДНЫ И БЕЛОГО СВИСТКА",
  vocaloid_teto: "🥖 KASANE TETO // CV:0401 TWIN-DRILL SYNTHV GUARD 🎶",
  vocaloid_miku: "🎵 HATSUNE MIKU // CV01 DIGITAL VOCALOID SHIELD ✨"
};

const headerLogoImg = document.getElementById("headerLogoImg");
const quickThemeBtn = document.getElementById("quickThemeBtn");
const themeSelect = document.getElementById("themeSelect");
const iconStylePicker = document.getElementById("iconStylePicker");
const bannerPositionSelect = document.getElementById("bannerPositionSelect");
const autoCloseSafeSelect = document.getElementById("autoCloseSafeSelect");
const soundAlertsEnabled = document.getElementById("soundAlertsEnabled");
const hoverBadgeEnabled = document.getElementById("hoverBadgeEnabled");
const antiPhishingEnabled = document.getElementById("antiPhishingEnabled");
const hotkeysEnabled = document.getElementById("hotkeysEnabled");
const testSoundBtn = document.getElementById("testSoundBtn");

const statTotalScans = document.getElementById("statTotalScans");
const statThreatsBlocked = document.getElementById("statThreatsBlocked");
const statCacheHits = document.getElementById("statCacheHits");

const POPUP_SOUND_MELODIES = {
  salmon_wave:          { wave: "sine",     notes: [493.88, 659.25, 783.99, 987.77], step: 0.065 },
  helldivers_stratagem: { wave: "triangle", notes: [440, 440, 587.33, 659.25, 880],  step: 0.06  },
  ozen_abyss_bell:      { wave: "sine",     notes: [293.66, 440, 587.33],            step: 0.095 },
  teto_pop:             { wave: "square",   notes: [587.33, 739.99, 880, 1174.66],   step: 0.055 },
  miku_cyber:           { wave: "sine",     notes: [523.25, 659.25, 783.99, 1046.5], step: 0.06  },
  retro_coin:           { wave: "square",   notes: [987.77, 1318.51],                step: 0.075 },
  sonar_ping:           { wave: "sine",     notes: [880, 1760],                      step: 0.09  },
  crystal_chime:        { wave: "sine",     notes: [783.99, 987.77, 1174.66, 1567.98], step: 0.055 },
  cyber_sonar:          { wave: "triangle", notes: [587.33, 880],                    step: 0.07  }
};

const POPUP_THEME_TO_SOUND = {
  salmon_ocean: "salmon_wave",
  helldivers2: "helldivers_stratagem",
  ozen_abyss: "ozen_abyss_bell",
  vocaloid_teto: "teto_pop",
  vocaloid_miku: "miku_cyber",
  oled_matrix: "retro_coin",
  purple_synth: "crystal_chime",
  crimson_guard: "helldivers_stratagem",
  dark_cyber: "cyber_sonar",
  light_clean: "crystal_chime"
};

function playPopupDemoSound() {
  try {
    const vol = Math.max(0.02, Math.min(1, Number(currentSettings.soundVolume ?? 70) / 100));
    const preset = currentSettings.soundPreset || "auto_theme";
    if (preset === "custom_audio" && currentSettings.customSoundDataUrl) {
      const audio = new Audio(currentSettings.customSoundDataUrl);
      audio.volume = vol;
      audio.play().catch(() => {});
      return;
    }
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const key = preset === "auto_theme"
      ? (POPUP_THEME_TO_SOUND[currentSettings.theme || "salmon_ocean"] || "salmon_wave")
      : (POPUP_SOUND_MELODIES[preset] ? preset : "salmon_wave");
    const cfg = POPUP_SOUND_MELODIES[key] || POPUP_SOUND_MELODIES.salmon_wave;
    cfg.notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = cfg.wave;
      osc.frequency.setValueAtTime(freq, now + idx * cfg.step);
      gain.gain.setValueAtTime(0.09 * vol, now + idx * cfg.step);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * cfg.step + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * cfg.step);
      osc.stop(now + idx * cfg.step + 0.17);
    });
    setTimeout(() => { try { ctx.close(); } catch (_) {} }, 800);
  } catch (_) {}
}

function applyThemeAndIconUI() {
  const theme = currentSettings.theme || "dark_cyber";
  document.body.setAttribute("data-theme", theme);
  if (themeSelect) themeSelect.value = theme;

  const iconStyle = currentSettings.iconStyle || "auto";
  const resolvedColor = !currentSettings.enabled
    ? "gray"
    : iconStyle === "auto"
    ? (THEME_TO_ICON[theme] || "blue")
    : iconStyle;

  if (headerLogoImg) {
    headerLogoImg.src = `icons/icon_${resolvedColor}_48.png`;
  }

  try {
    const actionApi = chrome.action || chrome.browserAction;
    if (actionApi && typeof actionApi.setIcon === "function") {
      actionApi.setIcon({
        path: {
          "16": `icons/icon_${resolvedColor}_16.png`,
          "48": `icons/icon_${resolvedColor}_48.png`,
          "128": `icons/icon_${resolvedColor}_128.png`
        }
      });
    }
  } catch (_) {}

  if (iconStylePicker) {
    iconStylePicker.querySelectorAll(".icon-choice-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.icon === iconStyle);
    });
  }

  const scanWinModeEl = document.getElementById("scanWindowDisplayModeSelect");
  if (scanWinModeEl) scanWinModeEl.value = currentSettings.scanWindowDisplayMode || "card_on_top";
  if (bannerPositionSelect) bannerPositionSelect.value = currentSettings.bannerPosition || "top-right";
  const autoCloseInputEl = document.getElementById("autoCloseSafeInput");
  if (autoCloseInputEl) autoCloseInputEl.value = String(currentSettings.autoCloseSafeSec ?? 8);
  const cacheDaysEl = document.getElementById("cacheTtlDaysInput");
  if (cacheDaysEl) cacheDaysEl.value = String(currentSettings.cacheTtlDays || 7);
  const flavorBanner = document.getElementById("themeFlavorBanner");
  if (typeof applyV22CustomVisuals === 'function') applyV22CustomVisuals();
  if (flavorBanner) {
    if (THEME_FLAVOR_TEXT[theme]) {
      flavorBanner.textContent = THEME_FLAVOR_TEXT[theme];
      flavorBanner.style.display = "block";
    } else {
      flavorBanner.style.display = "none";
    }
  }
  if (soundAlertsEnabled) soundAlertsEnabled.checked = currentSettings.soundAlertsEnabled !== false;
  if (hoverBadgeEnabled) hoverBadgeEnabled.checked = currentSettings.hoverBadgeEnabled !== false;
  if (antiPhishingEnabled) antiPhishingEnabled.checked = currentSettings.antiPhishingEnabled !== false;
  if (hotkeysEnabled) hotkeysEnabled.checked = currentSettings.hotkeysEnabled !== false;

  if (statTotalScans) statTotalScans.textContent = String(currentSettings.totalScansCount || (currentSettings.scanHistory || []).length || 0);
  if (statThreatsBlocked) statThreatsBlocked.textContent = String(currentSettings.totalThreatsBlocked || 0);
  if (statCacheHits) statCacheHits.textContent = String(currentSettings.totalCacheHits || 0);
}

if (quickThemeBtn) {
  quickThemeBtn.addEventListener("click", () => {
    const cur = currentSettings.theme || "dark_cyber";
    const nextIdx = (THEMES_ORDER.indexOf(cur) + 1) % THEMES_ORDER.length;
    currentSettings.theme = THEMES_ORDER[nextIdx];
    applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved(`🎨 Тема изменена: ${themeSelect?.options[themeSelect.selectedIndex]?.text || currentSettings.theme}`);
  });
}

if (headerLogoImg) {
  const ICON_CYCLE = ["auto", "salmon", "helldivers", "ozen", "teto", "miku", "blue", "emerald", "purple", "crimson", "gold"];
  headerLogoImg.addEventListener("click", () => {
    const cur = currentSettings.iconStyle || "auto";
    const next = ICON_CYCLE[(ICON_CYCLE.indexOf(cur) + 1) % ICON_CYCLE.length];
    currentSettings.iconStyle = next;
    applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved(`🛡️ Стиль иконки: ${next.toUpperCase()}`);
  });
}

if (themeSelect) {
  themeSelect.addEventListener("change", () => {
    currentSettings.theme = themeSelect.value;
    applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (iconStylePicker) {
  iconStylePicker.querySelectorAll(".icon-choice-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      currentSettings.iconStyle = btn.dataset.icon || "auto";
      applyThemeAndIconUI();
  syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
      saveSettings();
    });
  });
}

const scanWindowDisplayModeSelect = document.getElementById("scanWindowDisplayModeSelect");
if (scanWindowDisplayModeSelect) {
  scanWindowDisplayModeSelect.addEventListener("change", () => {
    const isEn = currentSettings.uiLang === "en";
    const chosenMode = scanWindowDisplayModeSelect.value || "card_on_top";
    currentSettings.scanWindowDisplayMode = chosenMode;
    safeStorageSet({ scanWindowDisplayMode: chosenMode });
    saveSettingsImmediate();
    chrome.runtime.sendMessage({ type: "VT_APPLY_WINDOW_MODE_NOW", scanWindowDisplayMode: chosenMode }).catch(() => {});

    // Если уже есть проверенный файл в истории или открыта карточка — сразу применяем выбранный вид, чтобы пользователь увидел разницу!
    const topHist = Array.isArray(currentSettings.scanHistory) && currentSettings.scanHistory.length > 0 ? currentSettings.scanHistory[0] : null;
    if (chosenMode === "card_on_top" && (lastRenderedPopupScanPayload || topHist)) {
      if (!lastRenderedPopupScanPayload && topHist) {
        chrome.runtime.sendMessage({ type: "VT_REOPEN_SCAN_CARD", scanId: topHist.scanId, historyItem: topHist, forcePageCard: true });
      } else if (lastRenderedPopupScanPayload) {
        chrome.runtime.sendMessage({ type: "VT_REOPEN_SCAN_CARD", scanId: lastRenderedPopupScanPayload.scanId, forcePageCard: true });
      }
    } else if (chosenMode === "both_windows" && (lastRenderedPopupScanPayload || topHist)) {
      const targetItem = lastRenderedPopupScanPayload || topHist;
      chrome.runtime.sendMessage({ type: "VT_REOPEN_SCAN_CARD", scanId: targetItem.scanId, historyItem: topHist || undefined, forcePageCard: true });
    }

    const modeLabelsRu = {
      card_on_top: "📊 Режим: Само окно вывода проверки поверх (чистая карточка отчёта)",
      extension_on_top: "🛡️ Режим: Окно с расширением поверх (внутри VT Download Guard)",
      both_windows: "🔄 Режим: Оба окна рядом (и в расширении, и плашка на сайте без перекрытия)"
    };
    const modeLabelsEn = {
      card_on_top: "📊 Mode: Scan result card on top (clean report card)",
      extension_on_top: "🛡️ Mode: Extension window on top (inside VT Download Guard)",
      both_windows: "🔄 Mode: Both windows side-by-side without overlap"
    };
    flashSaved(isEn ? (modeLabelsEn[chosenMode] || "✓ Saved") : (modeLabelsRu[chosenMode] || "✓ Сохранено"));
  });
}

if (bannerPositionSelect) {
  bannerPositionSelect.addEventListener("change", () => {
    currentSettings.bannerPosition = bannerPositionSelect.value;
    saveSettings();
  });
}

if (autoCloseSafeSelect) {
  autoCloseSafeSelect.addEventListener("change", () => {
    currentSettings.autoCloseSafeSec = Number(autoCloseSafeSelect.value) || 0;
    saveSettings();
  });
}

if (soundAlertsEnabled) {
  soundAlertsEnabled.addEventListener("change", () => {
    currentSettings.soundAlertsEnabled = soundAlertsEnabled.checked;
    saveSettings();
  });
}

if (testSoundBtn) {
  testSoundBtn.addEventListener("click", () => {
    playPopupDemoSound();
    flashSaved("🎵 Звуковое оповещение активно!");
  });
}

if (hoverBadgeEnabled) {
  hoverBadgeEnabled.addEventListener("change", () => {
    currentSettings.hoverBadgeEnabled = hoverBadgeEnabled.checked;
    saveSettings();
  });
}
if (antiPhishingEnabled) {
  antiPhishingEnabled.addEventListener("change", () => {
    currentSettings.antiPhishingEnabled = antiPhishingEnabled.checked;
    saveSettings();
  });
}
if (hotkeysEnabled) {
  hotkeysEnabled.addEventListener("change", () => {
    currentSettings.hotkeysEnabled = hotkeysEnabled.checked;
    saveSettings();
  });
}


// ==================== v1.0: СИНХРОНИЗАЦИЯ ТУМБЛЕРОВ ССЫЛОК/ТЕКСТА, ЗАПИСЬ ГОРЯЧИХ КЛАВИШ И ПАУЗА SNOOZE ====================
const hoverBadgeMainToggle = document.getElementById("hoverBadgeMainToggle");
const selectionPopupMainToggle = document.getElementById("selectionPopupMainToggle");
const hotkeysMainToggle = document.getElementById("hotkeysMainToggle");
const hotkeyQuickSummary = document.getElementById("hotkeyQuickSummary");

const hoverTriggerModeSelect = document.getElementById("hoverTriggerModeSelect");
const selectionPopupEnabled = document.getElementById("selectionPopupEnabled");
const unshortenLinksEnabled = document.getElementById("unshortenLinksEnabled");
const hotkeyConfigBox = document.getElementById("hotkeyConfigBox");
const hotkeyToggleInput = document.getElementById("hotkeyToggleInput");
const hotkeyScanInput = document.getElementById("hotkeyScanInput");
const hotkeyCloseAllInput = document.getElementById("hotkeyCloseAllInput");

const snoozeStatusLbl = document.getElementById("snoozeStatusLbl");
const cancelSnoozeBtn = document.getElementById("cancelSnoozeBtn");

function syncV20FeatureUIs() {
  const hEnabled = currentSettings.hoverBadgeEnabled !== false;
  const sEnabled = currentSettings.selectionPopupEnabled !== false;
  const kEnabled = currentSettings.hotkeysEnabled !== false;

  if (hoverBadgeMainToggle) hoverBadgeMainToggle.checked = hEnabled;
  if (hoverBadgeEnabled) hoverBadgeEnabled.checked = hEnabled;
  if (hoverTriggerModeSelect) hoverTriggerModeSelect.value = currentSettings.hoverTriggerMode || "always";

  if (selectionPopupMainToggle) selectionPopupMainToggle.checked = sEnabled;
  if (selectionPopupEnabled) selectionPopupEnabled.checked = sEnabled;

  if (unshortenLinksEnabled) unshortenLinksEnabled.checked = currentSettings.unshortenLinksEnabled !== false;

  if (hotkeysMainToggle) hotkeysMainToggle.checked = kEnabled;
  if (hotkeysEnabled) hotkeysEnabled.checked = kEnabled;

  const hkToggle = currentSettings.hotkeyToggle || "Alt+Shift+V";
  const hkScan = currentSettings.hotkeyScan || "Alt+Shift+S";
  const hkClose = currentSettings.hotkeyCloseAll || "Alt+Shift+C";

  if (hotkeyToggleInput) hotkeyToggleInput.value = hkToggle;
  if (hotkeyScanInput) hotkeyScanInput.value = hkScan;
  if (hotkeyCloseAllInput) hotkeyCloseAllInput.value = hkClose;
  if (hotkeyQuickSummary) {
    hotkeyQuickSummary.textContent = `Вкл/Выкл: ${hkToggle} • Проверка: ${hkScan} • Сброс: ${hkClose}`;
  }

  if (hotkeyConfigBox) {
    hotkeyConfigBox.style.opacity = kEnabled ? "1" : "0.45";
    hotkeyConfigBox.style.pointerEvents = kEnabled ? "auto" : "none";
  }

  const snoozeLeftMs = (Number(currentSettings.snoozeUntil) || 0) - Date.now();
  if (!currentSettings.enabled && snoozeLeftMs > 0) {
    const mins = Math.ceil(snoozeLeftMs / 60000);
    if (snoozeStatusLbl) snoozeStatusLbl.textContent = `⏸️ На паузе (включится через ~${mins} мин.)`;
    if (cancelSnoozeBtn) cancelSnoozeBtn.style.display = "inline-block";
  } else {
    if (snoozeStatusLbl) snoozeStatusLbl.textContent = "⏱️ Временная пауза защиты:";
    if (cancelSnoozeBtn) cancelSnoozeBtn.style.display = "none";
  }
}

if (hoverBadgeMainToggle) {
  hoverBadgeMainToggle.addEventListener("change", () => {
    currentSettings.hoverBadgeEnabled = hoverBadgeMainToggle.checked;
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (hoverBadgeEnabled) {
  hoverBadgeEnabled.addEventListener("change", () => {
    currentSettings.hoverBadgeEnabled = hoverBadgeEnabled.checked;
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (hoverTriggerModeSelect) {
  hoverTriggerModeSelect.addEventListener("change", () => {
    currentSettings.hoverTriggerMode = hoverTriggerModeSelect.value;
    saveSettings();
  });
}

if (selectionPopupMainToggle) {
  selectionPopupMainToggle.addEventListener("change", () => {
    currentSettings.selectionPopupEnabled = selectionPopupMainToggle.checked;
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (selectionPopupEnabled) {
  selectionPopupEnabled.addEventListener("change", () => {
    currentSettings.selectionPopupEnabled = selectionPopupEnabled.checked;
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (unshortenLinksEnabled) {
  unshortenLinksEnabled.addEventListener("change", () => {
    currentSettings.unshortenLinksEnabled = unshortenLinksEnabled.checked;
    saveSettings();
  });
}

if (hotkeysMainToggle) {
  hotkeysMainToggle.addEventListener("change", () => {
    currentSettings.hotkeysEnabled = Boolean(hotkeysMainToggle.checked);
    syncV20FeatureUIs();
    applyAllCustomVisualsUnified();
    safeStorageSet({ hotkeysEnabled: currentSettings.hotkeysEnabled });
    saveSettingsImmediate();
  });
}

if (hotkeysEnabled) {
  hotkeysEnabled.addEventListener("change", () => {
    currentSettings.hotkeysEnabled = Boolean(hotkeysEnabled.checked);
    syncV20FeatureUIs();
    applyAllCustomVisualsUnified();
    safeStorageSet({ hotkeysEnabled: currentSettings.hotkeysEnabled });
    saveSettingsImmediate();
  });
}

// Интерактивная запись горячих клавиш по клику на поле
function bindHotkeyRecorder(inputEl, settingKey) {
  if (!inputEl) return;
  inputEl.addEventListener("click", () => {
    inputEl.classList.add("recording");
    inputEl.value = "Нажмите клавиши...";
  });
  inputEl.addEventListener("blur", () => {
    inputEl.classList.remove("recording");
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
  });
  inputEl.addEventListener("keydown", (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.key === "Escape") {
      inputEl.blur();
      return;
    }
    const parts = [];
    if (e.ctrlKey || e.metaKey) parts.push("Ctrl");
    if (e.altKey) parts.push("Alt");
    if (e.shiftKey) parts.push("Shift");
    const code = e.code || "";
    let keyName = "";
    if (code.startsWith("Key")) keyName = code.slice(3).toUpperCase();
    else if (code.startsWith("Digit")) keyName = code.slice(5);
    else if (/^F([1-9]|1[0-2])$/.test(code)) keyName = code;
    else if (["Space", "Enter", "Backquote"].includes(code)) keyName = code;

    if (!keyName) return; // Ждём нажатия основной клавиши вместе с модификатором
    if (parts.length === 0) parts.push("Alt"); // Гарантируем хотя бы 1 модификатор
    parts.push(keyName);
    const combo = parts.join("+");
    currentSettings[settingKey] = combo;
    inputEl.classList.remove("recording");
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved(`⌨️ Назначена комбинация: ${combo}`);
    inputEl.blur();
  });
}

bindHotkeyRecorder(hotkeyToggleInput, "hotkeyToggle");
bindHotkeyRecorder(hotkeyScanInput, "hotkeyScan");
bindHotkeyRecorder(hotkeyCloseAllInput, "hotkeyCloseAll");

// Кнопки временной паузы ("На 15 мин", "На 1 час")
document.querySelectorAll(".snooze-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const mins = Number(btn.dataset.mins) || 15;
    currentSettings.enabled = false;
    currentSettings.snoozeUntil = Date.now() + mins * 60000;
    enabledToggle.checked = false;
    applyThemeAndIconUI();
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved(`⏸️ Защита поставлена на паузу на ${mins} мин.`);
  });
});

if (cancelSnoozeBtn) {
  cancelSnoozeBtn.addEventListener("click", () => {
    currentSettings.enabled = true;
    currentSettings.snoozeUntil = 0;
    enabledToggle.checked = true;
    applyThemeAndIconUI();
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved("🛡️ Защита снова включена!");
  });
}


// ==================== v1.0: СВОЁ ВРЕМЯ ПАУЗЫ, АВТОСКРЫТИЯ ПЛАШКИ И СРОКА КЭША ====================
const customSnoozeMinsInput = document.getElementById("customSnoozeMinsInput");
const customSnoozeApplyBtn = document.getElementById("customSnoozeApplyBtn");
const autoCloseSafeInput = document.getElementById("autoCloseSafeInput");
const cacheTtlDaysInput = document.getElementById("cacheTtlDaysInput");
const clearHashCacheBtn = document.getElementById("clearHashCacheBtn");
const clearTrustedHashesBtn = document.getElementById("clearTrustedHashesBtn");

if (customSnoozeApplyBtn && customSnoozeMinsInput) {
  customSnoozeApplyBtn.addEventListener("click", () => {
    const mins = Math.max(1, Math.min(1440, Number(customSnoozeMinsInput.value) || 30));
    customSnoozeMinsInput.value = String(mins);
    currentSettings.enabled = false;
    currentSettings.snoozeUntil = Date.now() + mins * 60000;
    enabledToggle.checked = false;
    applyThemeAndIconUI();
    syncV20FeatureUIs();
  applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved(`⏸️ Защита поставлена на паузу на ${mins} мин.`);
  });
}

if (autoCloseSafeInput) {
  autoCloseSafeInput.addEventListener("change", () => {
    const sec = Math.max(0, Math.min(300, Number(autoCloseSafeInput.value) || 0));
    autoCloseSafeInput.value = String(sec);
    currentSettings.autoCloseSafeSec = sec;
    saveSettings();
    flashSaved(sec > 0 ? `⏱️ Автоскрытие чистой плашки: через ${sec} сек.` : "⏱️ Автоскрытие плашки отключено");
  });
}

document.querySelectorAll(".autoclose-preset-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const sec = Number(btn.dataset.sec) || 0;
    currentSettings.autoCloseSafeSec = sec;
    if (autoCloseSafeInput) autoCloseSafeInput.value = String(sec);
    saveSettings();
    flashSaved(sec > 0 ? `⏱️ Автоскрытие чистой плашки: через ${sec} сек.` : "⏱️ Автоскрытие плашки отключено");
  });
});

if (cacheTtlDaysInput) {
  cacheTtlDaysInput.addEventListener("change", async () => {
    const days = Math.max(1, Math.min(90, Number(cacheTtlDaysInput.value) || 7));
    cacheTtlDaysInput.value = String(days);
    currentSettings.cacheTtlDays = days;
    await safeStorageSet({ cacheTtlDays: days });
    flashSaved(`✓ Срок хранения кэша SHA-256: ${days} дн.`);
  });
}

if (clearHashCacheBtn) {
  clearHashCacheBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "VT_CLEAR_HASH_CACHE" }, () => {
      refreshRateLimitsBadge();
      flashSaved("✓ Локальный кэш SHA-256 очищен");
    });
  });
}

if (clearTrustedHashesBtn) {
  clearTrustedHashesBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "VT_CLEAR_TRUSTED_HASHES" }, () => {
      refreshRateLimitsBadge();
      flashSaved("✓ Белый список доверенных файлов очищен");
    });
  });
}


// ==================== v1.0: ФОНОВЫЕ КАРТИНКИ ПОД КАЖДУЮ ТЕМУ + СТУДИЯ КАСТОМНОГО ОФОРМЛЕНИЯ ====================
const POPUP_FONT_STACKS = {
  system: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, sans-serif',
  monospace: '"JetBrains Mono", Consolas, "Courier New", monospace',
  cyber: 'Bahnschrift, "Arial Black", Impact, "Segoe UI", sans-serif',
  rounded: '"Trebuchet MS", Nunito, Verdana, sans-serif',
  serif: 'Georgia, "Palatino Linotype", "Times New Roman", serif',
  impact: 'Impact, "Arial Black", sans-serif',
  comic: '"Comic Sans MS", cursive, sans-serif',
  terminal: '"Courier New", Lucida Console, monospace'
};

const popupBgArtLayer = document.getElementById("popupBgArtLayer");
const quickBgToggleBtn = document.getElementById("quickBgToggleBtn");
const bgImageEnabledToggle = document.getElementById("bgImageEnabledToggle");
const bgImageControlsBox = document.getElementById("bgImageControlsBox");
const bgOpacitySlider = document.getElementById("bgOpacitySlider");
const bgOpacityValLbl = document.getElementById("bgOpacityValLbl");
const glassBlurEnabled = document.getElementById("glassBlurEnabled");
const customBgFileInput = document.getElementById("customBgFileInput");
const uploadCustomBgBtn = document.getElementById("uploadCustomBgBtn");
const resetCustomBgBtn = document.getElementById("resetCustomBgBtn");

const customFontFamilySelect = document.getElementById("customFontFamilySelect");
const customFontScaleSlider = document.getElementById("customFontScaleSlider");
const customFontScaleInput = document.getElementById("customFontScaleInput");
const fontScaleValLbl = document.getElementById("fontScaleValLbl");
const customBorderRadiusSlider = document.getElementById("customBorderRadiusSlider");
const borderRadiusValLbl = document.getElementById("borderRadiusValLbl");
const customPopupWidthSlider = document.getElementById("customPopupWidthSlider");
const popupWidthValLbl = document.getElementById("popupWidthValLbl");

const customColorsEnabledToggle = document.getElementById("customColorsEnabledToggle");
const customColorPickersRow = document.getElementById("customColorPickersRow");
const customBgColorPicker = document.getElementById("customBgColorPicker");
const customCardColorPicker = document.getElementById("customCardColorPicker");
const customAccentColorPicker = document.getElementById("customAccentColorPicker");
const resetVisualsBtn = document.getElementById("resetVisualsBtn");
const testDemoBannerBtn = document.getElementById("testDemoBannerBtn");
const historySearchInput = document.getElementById("historySearchInput");

function applyV22CustomVisuals() {
  const theme = currentSettings.theme || "salmon_ocean";
  const bgOn = currentSettings.bgImageEnabled !== false;
  const opacityPct = Math.max(5, Math.min(75, Number(currentSettings.bgOpacity ?? 28)));
  const glassOn = currentSettings.glassBlurEnabled !== false;

  if (bgImageEnabledToggle) bgImageEnabledToggle.checked = bgOn;
  if (quickBgToggleBtn) {
    quickBgToggleBtn.style.opacity = bgOn ? "1" : "0.45";
    quickBgToggleBtn.title = bgOn ? "Фоновая картинка темы ВКЛЮЧЕНА (нажмите, чтобы скрыть)" : "Фоновая картинка темы ВЫКЛЮЧЕНА (нажмите, чтобы включить)";
  }
  if (bgImageControlsBox) {
    bgImageControlsBox.style.opacity = bgOn ? "1" : "0.45";
    bgImageControlsBox.style.pointerEvents = bgOn ? "auto" : "none";
  }
  if (bgOpacitySlider) bgOpacitySlider.value = String(opacityPct);
  if (bgOpacityValLbl) bgOpacityValLbl.textContent = `${opacityPct}%`;
  if (glassBlurEnabled) glassBlurEnabled.checked = glassOn;

  document.body.classList.toggle("glass-cards", Boolean(bgOn && glassOn));

  if (popupBgArtLayer) {
    if (!bgOn) {
      popupBgArtLayer.style.display = "none";
    } else {
      popupBgArtLayer.style.display = "block";
      popupBgArtLayer.style.opacity = String(opacityPct / 100);
      const artUrl = currentSettings.customBgDataUrl
        ? currentSettings.customBgDataUrl
        : `backgrounds/bg_${theme}.png`;
      popupBgArtLayer.style.backgroundImage = `url("${artUrl}")`;
    }
  }

  // Шрифт, масштаб, радиус скругления и ширина окна
  const fontKey = currentSettings.customFontFamily || "system";
  const fontScale = Math.max(85, Math.min(120, Number(currentSettings.customFontScale || 100)));
  const radiusPx = Math.max(0, Math.min(20, Number(currentSettings.customBorderRadius ?? 10)));
  const widthPx = Math.max(400, Math.min(540, Number(currentSettings.customPopupWidth || 450)));

  document.documentElement.style.setProperty("--custom-font", POPUP_FONT_STACKS[fontKey] || POPUP_FONT_STACKS.system);
  document.documentElement.style.setProperty("--custom-radius", `${radiusPx}px`);
  document.body.style.width = `${widthPx}px`;
  document.body.style.zoom = "1";
  let dynScaleStyle = document.getElementById("vtPopupSmoothFontScaleStyle");
  if (!dynScaleStyle) {
    dynScaleStyle = document.createElement("style");
    dynScaleStyle.id = "vtPopupSmoothFontScaleStyle";
    document.head.appendChild(dynScaleStyle);
  }
  const sc = fontScale / 100;
  dynScaleStyle.textContent = sc === 1 ? "" : `
    .app .feature-title { font-size: ${(12.5 * sc).toFixed(1)}px !important; }
    .app .feature-sub, .app .checkbox-row span, .app .threshold-row span, .app .field-label { font-size: ${(11.2 * sc).toFixed(1)}px !important; }
    .app .section-label span { font-size: ${(12 * sc).toFixed(1)}px !important; }
    .app .mini-btn, .app .select-input, .app input[type="text"] { font-size: ${(11.2 * sc).toFixed(1)}px !important; }
  `;

  if (customFontFamilySelect) customFontFamilySelect.value = fontKey;
  if (customFontScaleSlider) customFontScaleSlider.value = String(fontScale);
  if (customFontScaleInput) customFontScaleInput.value = String(fontScale);
  if (fontScaleValLbl) fontScaleValLbl.textContent = `${fontScale}%`;
  if (customBorderRadiusSlider) customBorderRadiusSlider.value = String(radiusPx);
  if (borderRadiusValLbl) borderRadiusValLbl.textContent = `${radiusPx}px`;
  if (customPopupWidthSlider) customPopupWidthSlider.value = String(widthPx);
  if (popupWidthValLbl) popupWidthValLbl.textContent = `${widthPx}px`;

  // Своя кастомная палитра цветов поверх темы
  const customColOn = Boolean(currentSettings.customColorsEnabled);
  if (customColorsEnabledToggle) customColorsEnabledToggle.checked = customColOn;
  if (customColorPickersRow) {
    customColorPickersRow.style.opacity = customColOn ? "1" : "0.45";
    customColorPickersRow.style.pointerEvents = customColOn ? "auto" : "none";
  }
  if (customBgColorPicker) customBgColorPicker.value = currentSettings.customBgColor || "#051622";
  if (customCardColorPicker) customCardColorPicker.value = currentSettings.customCardColor || "#0a2538";
  if (customAccentColorPicker) customAccentColorPicker.value = currentSettings.customAccentColor || "#ff856d";

  if (customColOn) {
    document.body.style.setProperty("--bg-main", currentSettings.customBgColor || "#051622");
    document.body.style.setProperty("--bg-card", currentSettings.customCardColor || "#0a2538");
    document.body.style.setProperty("--accent-color", currentSettings.customAccentColor || "#ff856d");
    document.body.style.setProperty("--border-color", currentSettings.customAccentColor || "#ff856d");
  } else {
    document.body.style.removeProperty("--bg-main");
    document.body.style.removeProperty("--bg-card");
    document.body.style.removeProperty("--accent-color");
    document.body.style.removeProperty("--border-color");
  }
}

if (quickBgToggleBtn) {
  quickBgToggleBtn.addEventListener("click", () => {
    currentSettings.bgImageEnabled = !(currentSettings.bgImageEnabled !== false);
    applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved(currentSettings.bgImageEnabled ? "🖼️ Фоновый арт темы ВКЛЮЧЁН" : "🖼️ Фоновый арт темы СКРЫТ");
  });
}

if (bgImageEnabledToggle) {
  bgImageEnabledToggle.addEventListener("change", () => {
    currentSettings.bgImageEnabled = bgImageEnabledToggle.checked;
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (bgOpacitySlider) {
  bgOpacitySlider.addEventListener("input", () => {
    currentSettings.bgOpacity = Number(bgOpacitySlider.value) || 28;
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (glassBlurEnabled) {
  glassBlurEnabled.addEventListener("change", () => {
    currentSettings.glassBlurEnabled = glassBlurEnabled.checked;
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (uploadCustomBgBtn && customBgFileInput) {
  uploadCustomBgBtn.addEventListener("click", () => customBgFileInput.click());
  customBgFileInput.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3.5 * 1024 * 1024) {
      flashSaved("❌ Выберите изображение до 3.5 МБ");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      currentSettings.customBgDataUrl = String(reader.result || "");
      currentSettings.bgImageEnabled = true;
      applyAllCustomVisualsUnified();
      saveSettings();
      flashSaved("🖼️ Свой пользовательский фон установлен!");
    };
    reader.readAsDataURL(file);
  });
}

if (resetCustomBgBtn) {
  resetCustomBgBtn.addEventListener("click", () => {
    currentSettings.customBgDataUrl = "";
    currentSettings.bgImageEnabled = true;
    applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved("✓ Восстановлен родной арт выбранной темы");
  });
}

if (customFontFamilySelect) {
  customFontFamilySelect.addEventListener("change", () => {
    currentSettings.customFontFamily = customFontFamilySelect.value;
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (customFontScaleSlider) {
  customFontScaleSlider.addEventListener("input", () => {
    const v = Number(customFontScaleSlider.value) || 100;
    if (fontScaleValLbl) fontScaleValLbl.textContent = `${v}%`;
    if (customFontScaleInput) customFontScaleInput.value = String(v);
  });
  customFontScaleSlider.addEventListener("change", () => {
    currentSettings.customFontScale = Number(customFontScaleSlider.value) || 100;
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

const fontScaleMinusBtn = document.getElementById("fontScaleMinusBtn");
const fontScalePlusBtn = document.getElementById("fontScalePlusBtn");
if (fontScaleMinusBtn) {
  fontScaleMinusBtn.addEventListener("click", () => {
    currentSettings.customFontScale = Math.max(85, (Number(currentSettings.customFontScale) || 100) - 2);
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}
if (fontScalePlusBtn) {
  fontScalePlusBtn.addEventListener("click", () => {
    currentSettings.customFontScale = Math.min(120, (Number(currentSettings.customFontScale) || 100) + 2);
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (customFontScaleInput) {
  customFontScaleInput.addEventListener("change", () => {
    const val = Math.max(85, Math.min(120, Number(customFontScaleInput.value) || 100));
    currentSettings.customFontScale = val;
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (customBorderRadiusSlider) {
  customBorderRadiusSlider.addEventListener("input", () => {
    currentSettings.customBorderRadius = Number(customBorderRadiusSlider.value ?? 10);
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (customPopupWidthSlider) {
  // Обновляем только подпись во время движения ползунка, чтобы окно не прыгало под курсором мыши!
  customPopupWidthSlider.addEventListener("input", () => {
    const w = Number(customPopupWidthSlider.value || 450);
    if (popupWidthValLbl) popupWidthValLbl.textContent = `${w}px`;
  });
  customPopupWidthSlider.addEventListener("change", () => {
    currentSettings.customPopupWidth = Number(customPopupWidthSlider.value || 450);
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

const popupWidthMinusBtn = document.getElementById("popupWidthMinusBtn");
const popupWidthPlusBtn = document.getElementById("popupWidthPlusBtn");
if (popupWidthMinusBtn) {
  popupWidthMinusBtn.addEventListener("click", () => {
    currentSettings.customPopupWidth = Math.max(400, (Number(currentSettings.customPopupWidth) || 450) - 10);
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}
if (popupWidthPlusBtn) {
  popupWidthPlusBtn.addEventListener("click", () => {
    currentSettings.customPopupWidth = Math.min(540, (Number(currentSettings.customPopupWidth) || 450) + 10);
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

if (customColorsEnabledToggle) {
  customColorsEnabledToggle.addEventListener("change", () => {
    currentSettings.customColorsEnabled = customColorsEnabledToggle.checked;
    applyAllCustomVisualsUnified();
    saveSettings();
  });
}

[
  [customBgColorPicker, "customBgColor"],
  [customCardColorPicker, "customCardColor"],
  [customAccentColorPicker, "customAccentColor"]
].forEach(([picker, key]) => {
  if (picker) {
    picker.addEventListener("input", () => {
      currentSettings[key] = picker.value;
      currentSettings.customColorsEnabled = true;
      applyAllCustomVisualsUnified();
      saveSettings();
    });
  }
});

if (resetVisualsBtn) {
  resetVisualsBtn.addEventListener("click", () => {
    currentSettings.customFontFamily = "system";
    currentSettings.customFontScale = 100;
    currentSettings.customBorderRadius = 10;
    currentSettings.customPopupWidth = 450;
    currentSettings.customColorsEnabled = false;
    currentSettings.bgOpacity = 28;
    currentSettings.glassBlurEnabled = true;
    applyAllCustomVisualsUnified();
    saveSettings();
    flashSaved("✓ Шрифт, размер и пропорции сброшены по умолчанию");
  });
}

if (testDemoBannerBtn) {
  testDemoBannerBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "VT_TEST_DEMO_BANNER" }, () => {
      flashSaved("👁️ Демо-плашка показана на открытой вкладке сайта!");
    });
  });
}

if (historySearchInput) {
  historySearchInput.addEventListener("input", () => {
    renderHistory(currentSettings.scanHistory);
  });
}


// ==================== v1.0: ПРОЗРАЧНОСТЬ ЗА ТЕКСТОМ, СТИКЕРЫ (DRAG & DROP), СВОЙ ЗВУК, СВОЙ ШРИФТ И ЦВЕТ ТЕКСТА ====================
const POPUP_THEME_TO_STICKER = {
  salmon_ocean: "salmon",
  helldivers2: "helldivers",
  ozen_abyss: "ozen",
  vocaloid_teto: "teto",
  vocaloid_miku: "miku",
  dark_cyber: "cyber",
  oled_matrix: "matrix",
  purple_synth: "synth",
  crimson_guard: "crimson",
  light_clean: "star"
};

const cardBgOpacitySlider = document.getElementById("cardBgOpacitySlider");
const cardBgOpacityValLbl = document.getElementById("cardBgOpacityValLbl");

const popupStickerOverlay = document.getElementById("popupStickerOverlay");
const quickStickerToggleBtn = document.getElementById("quickStickerToggleBtn");
const stickersEnabledToggle = document.getElementById("stickersEnabledToggle");
const stickersControlsBox = document.getElementById("stickersControlsBox");
const stickerPresetSelect = document.getElementById("stickerPresetSelect");
const stickerSizeSlider = document.getElementById("stickerSizeSlider");
const stickerSizeValLbl = document.getElementById("stickerSizeValLbl");
const stickerOpacitySlider = document.getElementById("stickerOpacitySlider");
const stickerOpacityValLbl = document.getElementById("stickerOpacityValLbl");
const stickerPositionSelect = document.getElementById("stickerPositionSelect");
const customStickerFileInput = document.getElementById("customStickerFileInput");
const uploadCustomStickerBtn = document.getElementById("uploadCustomStickerBtn");
const resetStickerBtn = document.getElementById("resetStickerBtn");

const customFontNameInput = document.getElementById("customFontNameInput");
const applyCustomFontNameBtn = document.getElementById("applyCustomFontNameBtn");
const customFontFileInput = document.getElementById("customFontFileInput");
const uploadCustomFontFileBtn = document.getElementById("uploadCustomFontFileBtn");

const customTextColorEnabledToggle = document.getElementById("customTextColorEnabledToggle");
const customTextColorPickersRow = document.getElementById("customTextColorPickersRow");
const customTextMainColorPicker = document.getElementById("customTextMainColorPicker");
const customTextSubColorPicker = document.getElementById("customTextSubColorPicker");

const soundPresetSelect = document.getElementById("soundPresetSelect");
const soundVolumeSlider = document.getElementById("soundVolumeSlider");
const soundVolumeValLbl = document.getElementById("soundVolumeValLbl");
const customSoundFileInput = document.getElementById("customSoundFileInput");
const uploadCustomSoundBtn = document.getElementById("uploadCustomSoundBtn");
const resetSoundBtn = document.getElementById("resetSoundBtn");

let loadedPopupFontDataUrl = "";

function applyV23ExtendedVisuals() {
  const theme = currentSettings.theme || "salmon_ocean";

  // 1. Плотность/прозрачность блоков за текстом (чтобы видеть картинку на заднем фоне)
  const cardAlpha = Math.max(0, Math.min(100, Number(currentSettings.cardBgOpacity ?? 48)));
  document.documentElement.style.setProperty("--card-bg-opacity", `${cardAlpha}%`);
  if (cardBgOpacitySlider) cardBgOpacitySlider.value = String(cardAlpha);
  if (cardBgOpacityValLbl) cardBgOpacityValLbl.textContent = `${cardAlpha}%`;

  // 2. Кастомный шрифт (по имени / Google Fonts или файл .ttf/.woff2)
  if (customFontNameInput) customFontNameInput.value = currentSettings.customFontName || "";
  if (currentSettings.customFontName) {
    let gLink = document.getElementById("vt-popup-gfont");
    if (!gLink) {
      gLink = document.createElement("link");
      gLink.id = "vt-popup-gfont";
      gLink.rel = "stylesheet";
      document.head.appendChild(gLink);
    }
    gLink.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(currentSettings.customFontName.trim())}:wght@400;600;700;800&display=swap`;
  }
  if (currentSettings.customFontDataUrl && currentSettings.customFontDataUrl !== loadedPopupFontDataUrl && window.FontFace) {
    loadedPopupFontDataUrl = currentSettings.customFontDataUrl;
    const ff = new FontFace("VTGuardUserFont", `url(${currentSettings.customFontDataUrl})`);
    ff.load().then((loaded) => {
      document.fonts.add(loaded);
    }).catch(() => {});
  }
  if (currentSettings.customFontFamily === "custom_name" && currentSettings.customFontName) {
    document.documentElement.style.setProperty("--custom-font", `"${currentSettings.customFontName.trim()}", ${POPUP_FONT_STACKS.system}`);
  } else if (currentSettings.customFontFamily === "custom_file" && currentSettings.customFontDataUrl) {
    document.documentElement.style.setProperty("--custom-font", `"VTGuardUserFont", ${POPUP_FONT_STACKS.system}`);
  }

  // 3. Свой цвет текста
  const txtColOn = Boolean(currentSettings.customTextColorEnabled);
  if (customTextColorEnabledToggle) customTextColorEnabledToggle.checked = txtColOn;
  if (customTextColorPickersRow) {
    customTextColorPickersRow.style.opacity = txtColOn ? "1" : "0.45";
    customTextColorPickersRow.style.pointerEvents = txtColOn ? "auto" : "none";
  }
  if (customTextMainColorPicker) customTextMainColorPicker.value = currentSettings.customTextMainColor || "#f0f9ff";
  if (customTextSubColorPicker) customTextSubColorPicker.value = currentSettings.customTextSubColor || "#7dd3fc";

  if (txtColOn) {
    document.body.style.setProperty("--text-main", currentSettings.customTextMainColor || "#f0f9ff");
    document.body.style.setProperty("--text-sub", currentSettings.customTextSubColor || "#7dd3fc");
  } else {
    document.body.style.removeProperty("--text-main");
    document.body.style.removeProperty("--text-sub");
  }

  // 4. Стикеры / Маскоты поверх фона
  const stOn = currentSettings.stickersEnabled !== false;
  const stPreset = currentSettings.stickerPreset || "auto_theme";
  const stSize = Math.max(35, Math.min(200, Number(currentSettings.stickerSize || 78)));
  const stOp = Math.max(15, Math.min(100, Number(currentSettings.stickerOpacity ?? 85)));
  const stPos = currentSettings.stickerPosition || "bottom-right";

  if (stickersEnabledToggle) stickersEnabledToggle.checked = stOn;
  if (quickStickerToggleBtn) {
    quickStickerToggleBtn.style.opacity = stOn ? "1" : "0.45";
    quickStickerToggleBtn.title = stOn ? "Стикер поверх фона ВКЛЮЧЁН (нажмите, чтобы скрыть)" : "Стикер поверх фона ВЫКЛЮЧЕН (нажмите, чтобы включить)";
  }
  if (stickersControlsBox) {
    stickersControlsBox.style.opacity = stOn ? "1" : "0.45";
    stickersControlsBox.style.pointerEvents = stOn ? "auto" : "none";
  }
  if (stickerPresetSelect) stickerPresetSelect.value = stPreset;
  if (stickerSizeSlider) stickerSizeSlider.value = String(stSize);
  if (stickerSizeValLbl) stickerSizeValLbl.textContent = `${stSize}px`;
  if (stickerOpacitySlider) stickerOpacitySlider.value = String(stOp);
  if (stickerOpacityValLbl) stickerOpacityValLbl.textContent = `${stOp}%`;
  if (stickerPositionSelect) stickerPositionSelect.value = stPos;

  if (popupStickerOverlay) {
    if (!stOn) {
      popupStickerOverlay.style.display = "none";
    } else {
      let stSrc = "";
      if (stPreset === "custom" && currentSettings.customStickerDataUrl) {
        stSrc = currentSettings.customStickerDataUrl;
      } else {
        const sKey = stPreset === "auto_theme" ? (POPUP_THEME_TO_STICKER[theme] || "salmon") : stPreset;
        stSrc = `stickers/sticker_${sKey}.png`;
      }
      const stLocked = currentSettings.stickerLockClickThrough !== false;
      const stLockEl = document.getElementById("stickerLockClickThroughToggle");
      if (stLockEl) stLockEl.checked = stLocked;
      popupStickerOverlay.src = stSrc;
      popupStickerOverlay.style.display = "block";
      popupStickerOverlay.style.width = `${stSize}px`;
      popupStickerOverlay.style.height = `${stSize}px`;
      popupStickerOverlay.style.opacity = String(stOp / 100);
      popupStickerOverlay.style.pointerEvents = stLocked ? "none" : "auto";
      popupStickerOverlay.style.cursor = stLocked ? "default" : "grab";

      popupStickerOverlay.style.top = "";
      popupStickerOverlay.style.bottom = "";
      popupStickerOverlay.style.left = "";
      popupStickerOverlay.style.right = "";

      if (stPos === "top-right") {
        popupStickerOverlay.style.top = "52px";
        popupStickerOverlay.style.right = "14px";
      } else if (stPos === "bottom-left") {
        popupStickerOverlay.style.bottom = "14px";
        popupStickerOverlay.style.left = "14px";
      } else if (stPos === "center") {
        popupStickerOverlay.style.top = "45%";
        popupStickerOverlay.style.left = "50%";
        popupStickerOverlay.style.transform = "translate(-50%, -50%)";
      } else if (stPos === "custom_xy") {
        popupStickerOverlay.style.left = `${Number(currentSettings.stickerCustomX ?? 80)}%`;
        popupStickerOverlay.style.top = `${Number(currentSettings.stickerCustomY ?? 75)}%`;
        popupStickerOverlay.style.transform = "translate(-50%, -50%)";
      } else {
        popupStickerOverlay.style.bottom = "14px";
        popupStickerOverlay.style.right = "14px";
        popupStickerOverlay.style.transform = "";
      }
    }
  }

  // 5. Настройки звука
  if (soundPresetSelect) soundPresetSelect.value = currentSettings.soundPreset || "auto_theme";
  const sVol = Math.max(5, Math.min(100, Number(currentSettings.soundVolume ?? 70)));
  if (soundVolumeSlider) soundVolumeSlider.value = String(sVol);
  if (soundVolumeValLbl) soundVolumeValLbl.textContent = `${sVol}%`;
}

// Перетаскивание стикера мышкой прямо по окну расширения (Drag & Drop)
const stickerLockClickThroughToggle = document.getElementById("stickerLockClickThroughToggle");
if (stickerLockClickThroughToggle) {
  stickerLockClickThroughToggle.addEventListener("change", () => {
    currentSettings.stickerLockClickThrough = stickerLockClickThroughToggle.checked;
    applyV23ExtendedVisuals();
    saveSettings();
    flashSaved(
      stickerLockClickThroughToggle.checked
        ? (currentSettings.uiLang === "en" ? "🔒 Sticker locked (click-through enabled)" : "🔒 Стикер зафиксирован (нажатия проходят сквозь него)")
        : (currentSettings.uiLang === "en" ? "🖐️ Sticker dragging enabled" : "🖐️ Перетаскивание стикера мышкой включено")
    );
  });
}

if (popupStickerOverlay) {
  let isDraggingSticker = false;
  popupStickerOverlay.addEventListener("mousedown", (e) => {
    if (currentSettings.stickerLockClickThrough !== false) return;
    e.preventDefault();
    isDraggingSticker = true;
  });
  window.addEventListener("mousemove", (e) => {
    if (!isDraggingSticker) return;
    const xPct = Math.max(8, Math.min(92, Math.round((e.clientX / window.innerWidth) * 100)));
    const yPct = Math.max(8, Math.min(92, Math.round((e.clientY / window.innerHeight) * 100)));
    currentSettings.stickerPosition = "custom_xy";
    currentSettings.stickerCustomX = xPct;
    currentSettings.stickerCustomY = yPct;
    applyV23ExtendedVisuals();
  });
  window.addEventListener("mouseup", () => {
    if (isDraggingSticker) {
      isDraggingSticker = false;
      saveSettings();
      flashSaved("🖐️ Позиция стикера сохранена!");
    }
  });
}

if (cardBgOpacitySlider) {
  cardBgOpacitySlider.addEventListener("input", () => {
    currentSettings.cardBgOpacity = Number(cardBgOpacitySlider.value ?? 48);
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

if (quickStickerToggleBtn) {
  quickStickerToggleBtn.addEventListener("click", () => {
    currentSettings.stickersEnabled = !(currentSettings.stickersEnabled !== false);
    applyV23ExtendedVisuals();
    saveSettings();
    flashSaved(currentSettings.stickersEnabled ? "✨ Стикер темы ВКЛЮЧЁН" : "✨ Стикер темы СКРЫТ");
  });
}

if (stickersEnabledToggle) {
  stickersEnabledToggle.addEventListener("change", () => {
    currentSettings.stickersEnabled = stickersEnabledToggle.checked;
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

if (stickerPresetSelect) {
  stickerPresetSelect.addEventListener("change", () => {
    currentSettings.stickerPreset = stickerPresetSelect.value;
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

if (stickerSizeSlider) {
  stickerSizeSlider.addEventListener("input", () => {
    currentSettings.stickerSize = Number(stickerSizeSlider.value) || 78;
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

if (stickerOpacitySlider) {
  stickerOpacitySlider.addEventListener("input", () => {
    currentSettings.stickerOpacity = Number(stickerOpacitySlider.value ?? 85);
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

if (stickerPositionSelect) {
  stickerPositionSelect.addEventListener("change", () => {
    currentSettings.stickerPosition = stickerPositionSelect.value;
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

if (uploadCustomStickerBtn && customStickerFileInput) {
  uploadCustomStickerBtn.addEventListener("click", () => customStickerFileInput.click());
  customStickerFileInput.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      flashSaved("❌ Выберите стикер до 3 МБ");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      currentSettings.customStickerDataUrl = String(reader.result || "");
      currentSettings.stickerPreset = "custom";
      currentSettings.stickersEnabled = true;
      applyV23ExtendedVisuals();
      saveSettings();
      flashSaved("✨ Ваш собственный стикер установлен!");
    };
    reader.readAsDataURL(file);
  });
}

if (resetStickerBtn) {
  resetStickerBtn.addEventListener("click", () => {
    currentSettings.stickerPreset = "auto_theme";
    currentSettings.customStickerDataUrl = "";
    currentSettings.stickersEnabled = true;
    currentSettings.stickerSize = 78;
    currentSettings.stickerOpacity = 85;
    currentSettings.stickerPosition = "bottom-right";
    applyV23ExtendedVisuals();
    saveSettings();
    flashSaved("✓ Восстановлен фирменный стикер темы");
  });
}

if (applyCustomFontNameBtn && customFontNameInput) {
  applyCustomFontNameBtn.addEventListener("click", () => {
    const name = customFontNameInput.value.trim();
    if (!name) return;
    currentSettings.customFontName = name;
    currentSettings.customFontFamily = "custom_name";
    applyV22CustomVisuals();
    applyV23ExtendedVisuals();
    saveSettings();
    flashSaved(`🔤 Подключён шрифт: ${name}`);
  });
}

if (uploadCustomFontFileBtn && customFontFileInput) {
  uploadCustomFontFileBtn.addEventListener("click", () => customFontFileInput.click());
  customFontFileInput.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      flashSaved("❌ Файл шрифта должен быть до 3 МБ");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      currentSettings.customFontDataUrl = String(reader.result || "");
      currentSettings.customFontFamily = "custom_file";
      applyV22CustomVisuals();
      applyV23ExtendedVisuals();
      saveSettings();
      flashSaved(`🔤 Загружен свой шрифт: ${file.name}`);
    };
    reader.readAsDataURL(file);
  });
}

if (customTextColorEnabledToggle) {
  customTextColorEnabledToggle.addEventListener("change", () => {
    currentSettings.customTextColorEnabled = customTextColorEnabledToggle.checked;
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

[
  [customTextMainColorPicker, "customTextMainColor"],
  [customTextSubColorPicker, "customTextSubColor"]
].forEach(([picker, key]) => {
  if (picker) {
    picker.addEventListener("input", () => {
      currentSettings[key] = picker.value;
      currentSettings.customTextColorEnabled = true;
      applyV23ExtendedVisuals();
      saveSettings();
    });
  }
});

if (soundPresetSelect) {
  soundPresetSelect.addEventListener("change", () => {
    currentSettings.soundPreset = soundPresetSelect.value;
    saveSettings();
    playPopupDemoSound();
  });
}

if (soundVolumeSlider) {
  soundVolumeSlider.addEventListener("input", () => {
    currentSettings.soundVolume = Number(soundVolumeSlider.value ?? 70);
    applyV23ExtendedVisuals();
    saveSettings();
  });
}

if (uploadCustomSoundBtn && customSoundFileInput) {
  uploadCustomSoundBtn.addEventListener("click", () => customSoundFileInput.click());
  customSoundFileInput.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2.5 * 1024 * 1024) {
      flashSaved("❌ Выберите аудиофайл до 2.5 МБ");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      currentSettings.customSoundDataUrl = String(reader.result || "");
      currentSettings.soundPreset = "custom_audio";
      currentSettings.soundAlertsEnabled = true;
      applyV23ExtendedVisuals();
      saveSettings();
      playPopupDemoSound();
      flashSaved(`🎵 Загружен свой звук: ${file.name}`);
    };
    reader.readAsDataURL(file);
  });
}

if (resetSoundBtn) {
  resetSoundBtn.addEventListener("click", () => {
    currentSettings.soundPreset = "auto_theme";
    currentSettings.customSoundDataUrl = "";
    currentSettings.soundVolume = 70;
    applyV23ExtendedVisuals();
    saveSettings();
    playPopupDemoSound();
    flashSaved("✓ Восстановлена фирменная мелодия темы");
  });
}


// ==================== v1.0: ПРЕСЕТЫ ЗАЩИТЫ, КОМБО-ПРЕСЕТЫ СКИНОВ, СВОИ ПРЕСЕТЫ И 6 МОДУЛЕЙ ЗАЩИТЫ ====================
const clickFixShieldEnabled = document.getElementById("clickFixShieldEnabled");
const clipboardHelperEnabled = document.getElementById("clipboardHelperEnabled");
const peSignatureCheckEnabled = document.getElementById("peSignatureCheckEnabled");
const archiveLnkInspectEnabled = document.getElementById("archiveLnkInspectEnabled");
const domainAgeCheckEnabled = document.getElementById("domainAgeCheckEnabled");
const trustScoreEnabled = document.getElementById("trustScoreEnabled");
const smartSummaryEnabled = document.getElementById("smartSummaryEnabled");

const activeSecPresetBadge = document.getElementById("activeSecPresetBadge");
const userSavedPresetsChips = document.getElementById("userSavedPresetsChips");
const newPresetNameInput = document.getElementById("newPresetNameInput");
const saveCustomPresetBtn = document.getElementById("saveCustomPresetBtn");

const SECURITY_PRESETS = {
  comfort: {
    label: "⚡ Комфорт",
    filterMode: "all",
    autoDownloadSafe: true,
  keepScanOnTabClose: true,
    autoBlockEnabled: true,
    falsePositiveMode: "smart",
    autoBlockThreshold: 1,
    strictBlockLock: false,
    hoverBadgeEnabled: false,
    hoverTriggerMode: "alt_only",
  uiLang: "ru",
  tutorialCompleted: false,
    selectionPopupEnabled: true,
    unshortenLinksEnabled: true,
    antiPhishingEnabled: true,
    clickFixShieldEnabled: true,
    clipboardHelperEnabled: true,
    peSignatureCheckEnabled: true,
    archiveLnkInspectEnabled: true,
    domainAgeCheckEnabled: true,
    trustScoreEnabled: true,
    soundAlertsEnabled: true,
    autoCloseSafeSec: 8
  },
  paranoid: {
    label: "🏰 Паранойя",
    filterMode: "all",
    autoDownloadSafe: false,
    autoBlockEnabled: true,
    falsePositiveMode: "all",
    autoBlockThreshold: 1,
    autoBlockIncludeSuspicious: true,
    strictBlockLock: true,
    hoverBadgeEnabled: false,
    hoverTriggerMode: "alt_only",
  uiLang: "ru",
  tutorialCompleted: false,
    selectionPopupEnabled: true,
    unshortenLinksEnabled: true,
    antiPhishingEnabled: true,
    clickFixShieldEnabled: true,
    clipboardHelperEnabled: true,
    peSignatureCheckEnabled: true,
    archiveLnkInspectEnabled: true,
    domainAgeCheckEnabled: true,
    trustScoreEnabled: true,
    soundAlertsEnabled: true,
    autoCloseSafeSec: 0
  },
  gamer: {
    label: "🎮 Геймер",
    filterMode: "all",
    autoDownloadSafe: true,
  keepScanOnTabClose: true,
    autoBlockEnabled: true,
    falsePositiveMode: "trusted_only",
    autoBlockThreshold: 2,
    strictBlockLock: false,
    hoverBadgeEnabled: false,
    hoverTriggerMode: "alt_only",
    selectionPopupEnabled: false,
    unshortenLinksEnabled: true,
    antiPhishingEnabled: true,
    clickFixShieldEnabled: true,
    clipboardHelperEnabled: false,
    peSignatureCheckEnabled: true,
    archiveLnkInspectEnabled: true,
    domainAgeCheckEnabled: false,
    trustScoreEnabled: true,
    soundAlertsEnabled: false,
    autoCloseSafeSec: 4
  },
  light: {
    label: "🍃 Лёгкий",
    filterMode: "all",
    autoDownloadSafe: true,
  keepScanOnTabClose: true,
    autoBlockEnabled: true,
    falsePositiveMode: "smart",
    autoBlockThreshold: 1,
    sizeLimitEnabled: false,
    maxFileSizeMB: 150,
    maxHeavyCategoryMB: 80,
    glassBlurEnabled: false,
    hoverBadgeEnabled: false,
    selectionPopupEnabled: false,
    clipboardHelperEnabled: false,
    clickFixShieldEnabled: true,
    peSignatureCheckEnabled: true,
    archiveLnkInspectEnabled: true,
    domainAgeCheckEnabled: false,
    trustScoreEnabled: true,
    autoCloseSafeSec: 5
  }
};

const SKIN_COMBO_PRESETS = {
  salmon_pro: {
    name: "🐟 Лосось Glass Pro",
    theme: "salmon_ocean",
    iconStyle: "salmon",
    bgImageEnabled: true,
    bgOpacity: 40,
    cardBgOpacity: 42,
    glassBlurEnabled: true,
    stickersEnabled: true,
  stickerLockClickThrough: true,
    stickerPreset: "salmon",
    stickerSize: 84,
    stickerOpacity: 88,
    customFontFamily: "rounded",
    customBorderRadius: 12,
    soundPreset: "salmon_wave",
    customColorsEnabled: false,
    customTextColorEnabled: false
  },
  helldivers_pro: {
    name: "💀 Helldivers 2 Tactical",
    theme: "helldivers2",
    iconStyle: "helldivers",
    bgImageEnabled: true,
    bgOpacity: 38,
    cardBgOpacity: 50,
    glassBlurEnabled: false,
    stickersEnabled: true,
  stickerLockClickThrough: true,
    stickerPreset: "helldivers",
    stickerSize: 82,
    stickerOpacity: 90,
    customFontFamily: "cyber",
    customBorderRadius: 3,
    soundPreset: "helldivers_stratagem",
    customColorsEnabled: false,
    customTextColorEnabled: false
  },
  ozen_pro: {
    name: "⛓️ Бездна Relic",
    theme: "ozen_abyss",
    iconStyle: "ozen",
    bgImageEnabled: true,
    bgOpacity: 42,
    cardBgOpacity: 44,
    glassBlurEnabled: true,
    stickersEnabled: true,
  stickerLockClickThrough: true,
    stickerPreset: "ozen",
    stickerSize: 80,
    stickerOpacity: 85,
    customFontFamily: "serif",
    customBorderRadius: 8,
    soundPreset: "ozen_abyss_bell",
    customColorsEnabled: false,
    customTextColorEnabled: false
  },
  teto_pro: {
    name: "🥖 Kasane Teto 0401",
    theme: "vocaloid_teto",
    iconStyle: "teto",
    bgImageEnabled: true,
    bgOpacity: 40,
    cardBgOpacity: 44,
    glassBlurEnabled: true,
    stickersEnabled: true,
  stickerLockClickThrough: true,
    stickerPreset: "teto",
    stickerSize: 84,
    stickerOpacity: 88,
    customFontFamily: "rounded",
    customBorderRadius: 14,
    soundPreset: "teto_pop",
    customColorsEnabled: false,
    customTextColorEnabled: false
  },
  miku_pro: {
    name: "🎵 Hatsune Miku CV01",
    theme: "vocaloid_miku",
    iconStyle: "miku",
    bgImageEnabled: true,
    bgOpacity: 40,
    cardBgOpacity: 44,
    glassBlurEnabled: true,
    stickersEnabled: true,
  stickerLockClickThrough: true,
    stickerPreset: "miku",
    stickerSize: 84,
    stickerOpacity: 88,
    customFontFamily: "system",
    customBorderRadius: 12,
    soundPreset: "miku_cyber",
    customColorsEnabled: false,
    customTextColorEnabled: false
  }
};

function renderUserSavedPresets() {
  if (!userSavedPresetsChips) return;
  const list = Array.isArray(currentSettings.userCustomPresets) ? currentSettings.userCustomPresets : [];
  if (list.length === 0) {
    userSavedPresetsChips.style.display = "none";
    return;
  }
  userSavedPresetsChips.style.display = "flex";
  userSavedPresetsChips.textContent = "";
  list.forEach((p, idx) => {
    const chip = document.createElement("div");
    chip.className = "chip active";
    setSafeHtml(chip, `<span>⭐ ${p.name}</span> <span data-del="${idx}" title="Удалить пресет" style="margin-left:4px;color:#f87171;">×</span>`);
    chip.addEventListener("click", (e) => {
      if (e.target?.dataset?.del !== undefined) {
        e.stopPropagation();
        const delIdx = Number(e.target.dataset.del);
        currentSettings.userCustomPresets.splice(delIdx, 1);
        renderUserSavedPresets();
        saveSettings();
        flashSaved("🗑️ Пресет удалён");
        return;
      }
      Object.assign(currentSettings, p.data || {});
      applyThemeAndIconUI();
      syncV20FeatureUIs();
      applyV22CustomVisuals();
      applyV23ExtendedVisuals();
      syncV24ModulesUI();
      saveSettings();
      flashSaved(`🌟 Применён ваш пресет: ${p.name}`);
    });
    userSavedPresetsChips.appendChild(chip);
  });
}

function syncV24ModulesUI() {
  if (clickFixShieldEnabled) clickFixShieldEnabled.checked = currentSettings.clickFixShieldEnabled !== false;
  if (clipboardHelperEnabled) clipboardHelperEnabled.checked = currentSettings.clipboardHelperEnabled !== false;
  if (peSignatureCheckEnabled) peSignatureCheckEnabled.checked = currentSettings.peSignatureCheckEnabled !== false;
  if (archiveLnkInspectEnabled) archiveLnkInspectEnabled.checked = currentSettings.archiveLnkInspectEnabled !== false;
  if (domainAgeCheckEnabled) domainAgeCheckEnabled.checked = currentSettings.domainAgeCheckEnabled !== false;
  if (trustScoreEnabled) trustScoreEnabled.checked = currentSettings.trustScoreEnabled !== false;
  if (smartSummaryEnabled) smartSummaryEnabled.checked = currentSettings.smartSummaryEnabled !== false;

  const activePreset = currentSettings.activeSecurityPreset || "comfort";
  if (activeSecPresetBadge) {
    activeSecPresetBadge.textContent = SECURITY_PRESETS[activePreset]?.label || "⚙️ Свой";
  }
  document.querySelectorAll(".sec-preset-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.preset === activePreset);
  });

  renderUserSavedPresets();
  if (currentSettings.uiLang === "en" && typeof applyPopupLanguage === "function") applyPopupLanguage("en");
}

[
  [clickFixShieldEnabled, "clickFixShieldEnabled"],
  [clipboardHelperEnabled, "clipboardHelperEnabled"],
  [peSignatureCheckEnabled, "peSignatureCheckEnabled"],
  [archiveLnkInspectEnabled, "archiveLnkInspectEnabled"],
  [domainAgeCheckEnabled, "domainAgeCheckEnabled"],
  [trustScoreEnabled, "trustScoreEnabled"],
  [smartSummaryEnabled, "smartSummaryEnabled"]
].forEach(([el, key]) => {
  if (el) {
    el.addEventListener("change", () => {
      currentSettings[key] = el.checked;
      currentSettings.activeSecurityPreset = "custom";
      syncV24ModulesUI();
      saveSettings();
    });
  }
});

document.querySelectorAll(".sec-preset-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const pKey = btn.dataset.preset;
    const cfg = SECURITY_PRESETS[pKey];
    if (!cfg) return;
    const { label, ...settingsPatch } = cfg;
    Object.assign(currentSettings, settingsPatch);
    currentSettings.activeSecurityPreset = pKey;

    autoDownloadSafe.checked = Boolean(currentSettings.autoDownloadSafe);
    autoBlockEnabled.checked = Boolean(currentSettings.autoBlockEnabled);
    falsePositiveMode.value = currentSettings.falsePositiveMode || "smart";
    autoBlockSlider.value = String(Math.min(30, currentSettings.autoBlockThreshold || 1));
    autoBlockInput.value = String(currentSettings.autoBlockThreshold || 1);
    autoBlockIncludeSuspicious.checked = Boolean(currentSettings.autoBlockIncludeSuspicious);
    strictBlockLock.checked = Boolean(currentSettings.strictBlockLock);
    modeAll.checked = currentSettings.filterMode === "all";
    modeSelected.checked = currentSettings.filterMode !== "all";

    updateToggleDependentUIs();
    renderCategoryTabs();
    renderChips();
    applyThemeAndIconUI();
    syncV20FeatureUIs();
    applyV22CustomVisuals();
    applyV23ExtendedVisuals();
    syncV24ModulesUI();
    saveSettings();
    flashSaved(`🎚️ Включён пресет защиты: ${label}`);
  });
});

document.querySelectorAll(".skin-combo-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const cKey = btn.dataset.combo;
    const combo = SKIN_COMBO_PRESETS[cKey];
    if (!combo) return;
    const { name, ...visualPatch } = combo;
    Object.assign(currentSettings, visualPatch);
    applyThemeAndIconUI();
    syncV20FeatureUIs();
    applyV22CustomVisuals();
    applyV23ExtendedVisuals();
    syncV24ModulesUI();
    saveSettings();
    playPopupDemoSound();
    flashSaved(`✨ Применён комбо-скин: ${name}`);
  });
});

if (saveCustomPresetBtn && newPresetNameInput) {
  saveCustomPresetBtn.addEventListener("click", () => {
    const name = newPresetNameInput.value.trim() || `Мой пресет #${(currentSettings.userCustomPresets?.length || 0) + 1}`;
    const snapshot = {
      theme: currentSettings.theme,
      iconStyle: currentSettings.iconStyle,
      bgImageEnabled: currentSettings.bgImageEnabled,
      bgOpacity: currentSettings.bgOpacity,
      cardBgOpacity: currentSettings.cardBgOpacity,
      glassBlurEnabled: currentSettings.glassBlurEnabled,
      stickersEnabled: currentSettings.stickersEnabled,
      stickerPreset: currentSettings.stickerPreset,
      stickerSize: currentSettings.stickerSize,
      stickerOpacity: currentSettings.stickerOpacity,
      stickerPosition: currentSettings.stickerPosition,
      customFontFamily: currentSettings.customFontFamily,
      customFontName: currentSettings.customFontName,
      customFontScale: currentSettings.customFontScale,
      customBorderRadius: currentSettings.customBorderRadius,
      customColorsEnabled: currentSettings.customColorsEnabled,
      customBgColor: currentSettings.customBgColor,
      customCardColor: currentSettings.customCardColor,
      customAccentColor: currentSettings.customAccentColor,
      customTextColorEnabled: currentSettings.customTextColorEnabled,
      customTextMainColor: currentSettings.customTextMainColor,
      customTextSubColor: currentSettings.customTextSubColor,
      soundPreset: currentSettings.soundPreset,
      soundVolume: currentSettings.soundVolume
    };
    if (!Array.isArray(currentSettings.userCustomPresets)) currentSettings.userCustomPresets = [];
    currentSettings.userCustomPresets.push({ name, data: snapshot });
    newPresetNameInput.value = "";
    renderUserSavedPresets();
    saveSettings();
    flashSaved(`💾 Пресет «${name}» сохранён!`);
  });
}


// ==================== v1.0: ОБМЕН КОДОМ ТЕМЫ ЧЕРЕЗ БУФЕР ОБМЕНА ====================
const copySkinCodeBtn = document.getElementById("copySkinCodeBtn");
const pasteSkinCodeBtn = document.getElementById("pasteSkinCodeBtn");

if (copySkinCodeBtn) {
  copySkinCodeBtn.addEventListener("click", () => {
    const skinPayload = {
      vtGuardSkinV26: true,
      theme: currentSettings.theme,
      iconStyle: currentSettings.iconStyle,
      bgImageEnabled: currentSettings.bgImageEnabled,
      bgOpacity: currentSettings.bgOpacity,
      cardBgOpacity: currentSettings.cardBgOpacity,
      glassBlurEnabled: currentSettings.glassBlurEnabled,
      stickersEnabled: currentSettings.stickersEnabled,
      stickerPreset: currentSettings.stickerPreset === "custom" ? "auto_theme" : currentSettings.stickerPreset,
      stickerSize: currentSettings.stickerSize,
      stickerOpacity: currentSettings.stickerOpacity,
      stickerPosition: currentSettings.stickerPosition,
      customFontFamily: currentSettings.customFontFamily === "custom_file" ? "system" : currentSettings.customFontFamily,
      customFontName: currentSettings.customFontName,
      customFontScale: currentSettings.customFontScale,
      customBorderRadius: currentSettings.customBorderRadius,
      customColorsEnabled: currentSettings.customColorsEnabled,
      customBgColor: currentSettings.customBgColor,
      customCardColor: currentSettings.customCardColor,
      customAccentColor: currentSettings.customAccentColor,
      customTextColorEnabled: currentSettings.customTextColorEnabled,
      customTextMainColor: currentSettings.customTextMainColor,
      customTextSubColor: currentSettings.customTextSubColor,
      soundPreset: currentSettings.soundPreset === "custom_audio" ? "auto_theme" : currentSettings.soundPreset,
      soundVolume: currentSettings.soundVolume
    };
    const encoded = "VTSKIN:" + btoa(unescape(encodeURIComponent(JSON.stringify(skinPayload))));
    navigator.clipboard.writeText(encoded);
    flashSaved("📋 Код вашего оформления скопирован в буфер обмена!");
  });
}

if (pasteSkinCodeBtn) {
  pasteSkinCodeBtn.addEventListener("click", async () => {
    try {
      const raw = (await navigator.clipboard.readText()).trim();
      const jsonStr = raw.startsWith("VTSKIN:")
        ? decodeURIComponent(escape(atob(raw.slice(7).trim())))
        : raw;
      const parsed = JSON.parse(jsonStr);
      if (!parsed || typeof parsed !== "object" || (!parsed.vtGuardSkinV26 && !parsed.theme)) {
        flashSaved("❌ В буфере обмена нет кода темы VT Guard");
        return;
      }
      delete parsed.vtGuardSkinV26;
      Object.assign(currentSettings, parsed);
      applyThemeAndIconUI();
      syncV20FeatureUIs();
      applyV22CustomVisuals();
      applyV23ExtendedVisuals();
      syncV24ModulesUI();
      saveSettings();
      flashSaved("🎨 Оформление из буфера обмена успешно применено!");
    } catch (_) {
      flashSaved("❌ Не удалось прочитать код темы из буфера обмена");
    }
  });
}


// ==================== v1.0: ДВИЖОК ЖИВЫХ ЧАСТИЦ ТЕМ (LIVE PARTICLES FX), НЕОН, МИНИ-КАПСУЛА HUD И РЕНТГЕН ====================
const popupParticlesCanvas = document.getElementById("popupParticlesCanvas");
const quickParticlesToggleBtn = document.getElementById("quickParticlesToggleBtn");
const liveParticlesEnabledToggle = document.getElementById("liveParticlesEnabledToggle");
const neonGlowSlider = document.getElementById("neonGlowSlider");
const neonGlowValLbl = document.getElementById("neonGlowValLbl");
const cardAnimStyleSelect = document.getElementById("cardAnimStyleSelect");
const miniPillModeEnabledToggle = document.getElementById("miniPillModeEnabledToggle");

const xrayRadarEnabled = document.getElementById("xrayRadarEnabled");
const encryptedArchiveDetectEnabled = document.getElementById("encryptedArchiveDetectEnabled");
const htmlSmugglingProtectionEnabled = document.getElementById("htmlSmugglingProtectionEnabled");
const clipperGuardEnabled = document.getElementById("clipperGuardEnabled");

let particlesAnimId = null;
const particlesPool = [];

function ensureParticlesPool() {
  if (particlesPool.length > 0) return;
  for (let i = 0; i < 28; i++) {
    particlesPool.push({
      x: Math.random() * 480,
      y: Math.random() * 640,
      r: 1.8 + Math.random() * 3.8,
      vx: (Math.random() - 0.5) * 0.45,
      vy: 0.4 + Math.random() * 0.9,
      phase: Math.random() * Math.PI * 2
    });
  }
}

function renderParticlesFrame() {
  if (!popupParticlesCanvas || currentSettings.liveParticlesEnabled === false) {
    particlesAnimId = null;
    return;
  }
  const ctx = popupParticlesCanvas.getContext("2d");
  if (!ctx) return;
  const W = (popupParticlesCanvas.width = window.innerWidth || 450);
  const H = (popupParticlesCanvas.height = window.innerHeight || 600);
  ctx.clearRect(0, 0, W, H);

  ensureParticlesPool();
  const theme = currentSettings.theme || "salmon_ocean";
  const tNow = performance.now() * 0.002;

  if (theme === "vocaloid_miku" || theme === "vocaloid_teto") {
    // Живой эквалайзер внизу экрана + неоновые ноты/искры
    const barColor = theme === "vocaloid_miku" ? "rgba(57, 197, 187, 0.22)" : "rgba(255, 51, 102, 0.22)";
    ctx.fillStyle = barColor;
    const barCount = 24;
    const bw = W / barCount;
    for (let i = 0; i < barCount; i++) {
      const bh = 12 + Math.abs(Math.sin(tNow * 2.2 + i * 0.55)) * 42;
      ctx.fillRect(i * bw + 2, H - bh, bw - 4, bh);
    }
  }

  for (const p of particlesPool) {
    if (theme === "salmon_ocean") {
      // Пузырьки воздуха, плавно плывущие вверх
      p.y -= p.vy * 0.85;
      p.x += Math.sin(tNow + p.phase) * 0.35;
      if (p.y < -10) { p.y = H + 10; p.x = Math.random() * W; }
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(125, 211, 252, 0.38)";
      ctx.lineWidth = 1.2;
      ctx.stroke();
    } else if (theme === "helldivers2") {
      // Падающие сверху вниз золотые искры орбитального сброса
      p.y += p.vy * 1.65;
      if (p.y > H + 10) { p.y = -10; p.x = Math.random() * W; }
      ctx.fillStyle = "rgba(255, 230, 0, 0.42)";
      ctx.fillRect(p.x, p.y, 2, p.r * 3.2);
    } else if (theme === "ozen_abyss") {
      // Восходящие мистические огоньки Светового Поля Бездны
      p.y -= p.vy * 0.55;
      p.x += Math.cos(tNow * 0.8 + p.phase) * 0.25;
      if (p.y < -10) { p.y = H + 10; p.x = Math.random() * W; }
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * 0.9, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(199, 210, 254, 0.35)";
      ctx.fill();
    } else if (theme === "oled_matrix") {
      // Изумрудные цифровые капли Матрицы
      p.y += p.vy * 1.4;
      if (p.y > H + 10) { p.y = -10; p.x = Math.random() * W; }
      ctx.fillStyle = "rgba(16, 185, 129, 0.35)";
      ctx.fillRect(p.x, p.y, 3, 7);
    } else {
      // Мягкие неоновые частицы
      p.y -= p.vy * 0.6;
      if (p.y < -10) { p.y = H + 10; p.x = Math.random() * W; }
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * 0.8, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(148, 163, 184, 0.28)";
      ctx.fill();
    }
  }

  particlesAnimId = requestAnimationFrame(renderParticlesFrame);
}

function applyV27VisualsAndModules() {
  const fxOn = currentSettings.liveParticlesEnabled !== false;
  if (liveParticlesEnabledToggle) liveParticlesEnabledToggle.checked = fxOn;
  if (quickParticlesToggleBtn) {
    quickParticlesToggleBtn.style.opacity = fxOn ? "1" : "0.45";
    quickParticlesToggleBtn.title = fxOn
      ? "Живые частицы темы ВКЛЮЧЕНЫ (нажмите, чтобы выключить)"
      : "Живые частицы темы ВЫКЛЮЧЕНЫ (нажмите, чтобы включить)";
  }
  if (popupParticlesCanvas) {
    popupParticlesCanvas.style.display = fxOn ? "block" : "none";
    if (fxOn && !particlesAnimId) {
      particlesAnimId = requestAnimationFrame(renderParticlesFrame);
    }
  }

  const glowPct = Math.max(0, Math.min(100, Number(currentSettings.neonGlowIntensity ?? 35)));
  if (neonGlowSlider) neonGlowSlider.value = String(glowPct);
  if (neonGlowValLbl) neonGlowValLbl.textContent = `${glowPct}%`;
  if (glowPct > 0) {
    const blurPx = Math.round(glowPct * 0.22);
    document.documentElement.style.setProperty("--neon-card-shadow", `0 0 ${blurPx}px color-mix(in srgb, var(--accent-color) ${glowPct}%, transparent)`);
  } else {
    document.documentElement.style.setProperty("--neon-card-shadow", "none");
  }

  if (cardAnimStyleSelect) cardAnimStyleSelect.value = currentSettings.cardAnimStyle || "slide";
  if (miniPillModeEnabledToggle) miniPillModeEnabledToggle.checked = Boolean(currentSettings.miniPillModeEnabled);

  if (xrayRadarEnabled) xrayRadarEnabled.checked = currentSettings.xrayRadarEnabled !== false;
  if (encryptedArchiveDetectEnabled) encryptedArchiveDetectEnabled.checked = currentSettings.encryptedArchiveDetectEnabled !== false;
  if (htmlSmugglingProtectionEnabled) htmlSmugglingProtectionEnabled.checked = currentSettings.htmlSmugglingProtectionEnabled !== false;
  if (clipperGuardEnabled) clipperGuardEnabled.checked = currentSettings.clipperGuardEnabled !== false;
}

if (quickParticlesToggleBtn) {
  quickParticlesToggleBtn.addEventListener("click", () => {
    currentSettings.liveParticlesEnabled = !(currentSettings.liveParticlesEnabled !== false);
    applyV27VisualsAndModules();
    saveSettings();
    flashSaved(currentSettings.liveParticlesEnabled ? "🌟 Живые частицы темы ВКЛЮЧЕНЫ" : "🌟 Живые частицы темы ВЫКЛЮЧЕНЫ");
  });
}

if (liveParticlesEnabledToggle) {
  liveParticlesEnabledToggle.addEventListener("change", () => {
    currentSettings.liveParticlesEnabled = liveParticlesEnabledToggle.checked;
    applyV27VisualsAndModules();
    saveSettings();
  });
}

if (neonGlowSlider) {
  neonGlowSlider.addEventListener("input", () => {
    currentSettings.neonGlowIntensity = Number(neonGlowSlider.value ?? 35);
    applyV27VisualsAndModules();
    saveSettings();
  });
}

if (cardAnimStyleSelect) {
  cardAnimStyleSelect.addEventListener("change", () => {
    currentSettings.cardAnimStyle = cardAnimStyleSelect.value;
    saveSettings();
  });
}

if (miniPillModeEnabledToggle) {
  miniPillModeEnabledToggle.addEventListener("change", () => {
    currentSettings.miniPillModeEnabled = miniPillModeEnabledToggle.checked;
    saveSettings();
  });
}

[
  [xrayRadarEnabled, "xrayRadarEnabled"],
  [encryptedArchiveDetectEnabled, "encryptedArchiveDetectEnabled"],
  [htmlSmugglingProtectionEnabled, "htmlSmugglingProtectionEnabled"],
  [clipperGuardEnabled, "clipperGuardEnabled"]
].forEach(([el, key]) => {
  if (el) {
    el.addEventListener("change", () => {
      currentSettings[key] = el.checked;
      saveSettings();
    });
  }
});


function applyAllCustomVisualsUnified() {
  if (typeof applyV22CustomVisuals === "function") applyV22CustomVisuals();
  if (typeof applyV23ExtendedVisuals === "function") applyV23ExtendedVisuals();
  if (typeof syncV24ModulesUI === "function") syncV24ModulesUI();
  if (typeof applyV27VisualsAndModules === "function") applyV27VisualsAndModules();
}

init();


// ==================== МОДУЛЬ v1.0: ВЫБОР ЯЗЫКА (RU / EN) И ПОШАГОВОЕ ОБУЧЕНИЕ ====================
const TUTORIAL_STEPS_DATA = {
  ru: [
    {
      tab: "tabSettings",
      badge: "🔑 Шаг 1 из 6 • API-ключ VirusTotal",
      title: "1. Зачем нужен API-ключ VirusTotal и как всё работает?",
      bodyHtml: `
        <div>Во вкладке <b>«🛡️ Защита и API»</b> в самом верху находится поле <b>API-ключ VirusTotal (v3)</b>.</div>
        <div>• <b>С бесплатным ключом:</b> расширение проверяет скачиваемые файлы по всем <b>72 антивирусам</b> напрямую через облако VirusTotal и умеет отправлять новые неизвестные файлы на полную проверку.</div>
        <div>• <b>Где взять ключ бесплатно за 30 секунд:</b> нажмите ссылку <i>«Получить бесплатный ключ ↗»</i> над полем ввода, зарегистрируйтесь на официальном сайте <code>virustotal.com</code> и скопируйте 64-значный ключ из раздела <i>API Key</i>.</div>
        <div>• <b>А если ключа нет?</b> Расширение отлично работает и <b>БЕЗ ключа</b> (Бесключевой режим): проверяет структуру файла локально, сверяет SHA-256 с базами угроз <i>MalwareBazaar / CIRCL</i> и считывает вердикт с веб-страницы VT!</div>
      `,
      highlight: "💡 Важно (v1.3): При скачивании файлов расширение всегда проверяет САМ ФАЙЛ (его SHA-256 и структуру), а не ссылку сайта!"
    },
    {
      tab: "tabSettings",
      badge: "☁️ Шаг 2 из 6 • Прокси Cloudflare Worker",
      title: "2. Прокси Cloudflare Worker (72 АВ без ключа + Глобальный кэш)",
      bodyHtml: `
        <div>Сразу под настройкой бесключевого режима находится поле <b>«☁️ Общий облачный прокси (Cloudflare Worker URL)»</b>.</div>
        <div>• <b>Что это даёт:</b> если вы (или автор сборки) развернёте бесплатный скрипт <code>cloudflare_worker_proxy.js</code> (он лежит в папке расширения) на Cloudflare Workers и вставите туда 1–5 своих бесплатных ключей VT, вы получите ссылку вида <code>https://vt-proxy.name.workers.dev</code>.</div>
        <div>• <b>Преимущество:</b> прокси автоматически чередует ключи (умножая лимит запросов) и кэширует ответы на серверах Cloudflare на <b>7 дней</b>. Если один пользователь уже проверил файл, остальные получат полный отчёт из 72 антивирусов за <b>10 миллисекунд</b> без расхода лимитов!</div>
      `,
      highlight: "💡 Если вы используете личный API-ключ в первом поле, поле Cloudflare Worker заполнять не обязательно."
    },
    {
      tab: "tabMain",
      badge: "🛡️ Шаг 3 из 6 • Пресеты защиты и Автоблокировка",
      title: "3. Готовые пресеты защиты и Умный фильтр ложных тревог",
      bodyHtml: `
        <div>На вкладке <b>«🏠 Главное»</b> вы можете в 1 клик выбрать один из <b>4 режимов работы</b>:</div>
        <div>• <b>🛡️ Комфорт (Рекомендуется):</b> баланс защиты и удобства — игнорирует одиночные ложные срабатывания малоизвестных движков.</div>
        <div>• <b>🔒 Параноик:</b> строгая блокировка при любой жалобе + глубокий рентген архивов и цифровых подписей.</div>
        <div>• <b>🎮 Геймер / Репаки:</b> лоялен к игровым фиксам (<code>OnlineFix</code>, <code>Steam_api</code>, модам и трейнерам), но мгновенно блокирует реальные стиллеры, трояны и майнеры!</div>
        <div>• <b>⚡ Лайт:</b> проверяет только программы и архивы в компактном режиме.</div>
      `,
      highlight: "💡 Вы также можете создать и сохранить свой собственный пресет кнопкой «💾 Сохранить свой»!"
    },
    {
      tab: "tabSettings",
      badge: "🧠 Шаг 4 из 6 • Умная сводка, Доверие и Ползунок",
      title: "4. Умная сводка угроз, Индекс доверия (0–100%) и прокрутка",
      bodyHtml: `
        <div>Когда вы скачиваете файл, в углу экрана появляется плашка проверки <b>VT Salmon Ocean Guard</b>:</div>
        <div>• <b>📊 Уровень доверия (0–100%):</b> автоматически подстраивается под то, <i>на что именно жалуются антивирусы</i>. Если жалуются на <code>Trojan/Stealer/RAT</code> — доверие падает до минимума. Если это игровой фикс (<code>HackTool/GameHack</code>) без кражи паролей — расширение честно предупредит об этом.</div>
        <div>• <b>📡 Радар рисков и Рентген:</b> показывает 5 шкал опасности (Пароли, Память/Фикс, Сеть, Автозагрузка, Майнинг), возраст домена (RDAP) и энтропию упаковки.</div>
        <div>• <b>🖱️ Ползунок прокрутки справа:</b> если отчёт большой, справа на плашке и в окне расширения всегда есть удобный ползунок, чтобы прокрутить вниз до кнопок!</div>
      `,
      highlight: "💡 Кнопки «Скачать файл» и «Заблокировать» закреплены внизу плашки — вы всегда достанете до них."
    },
    {
      tab: "tabFormats",
      badge: "📂 Шаг 5 из 6 • Ручной сканер и 288+ Форматов",
      title: "5. Ручная проверка файлов/ссылок и фильтр форматов",
      bodyHtml: `
        <div>• <b>Ручной сканер (на вкладке «🏠 Главное»):</b> перетащите любой файл с компьютера в зону <i>Drag & Drop</i> или вставьте ссылку / SHA-256 хеш — расширение проверит его за долю секунды без повторной загрузки.</div>
        <div>• <b>Вкладка «📂 Форматы»:</b> здесь собрано более <b>288 форматов файлов</b> по 8 категориям (Программы, Архивы, Документы, Фото, Аудио/Видео, Код, Данные, Торренты). Веб-страницы (<code>.php</code>, <code>.html</code>) исключены из перехвата, чтобы сайты не вызывали ложных срабатываний.</div>
        <div>• <b>Белый список сайтов:</b> во вкладке «🛡️ Защита и API» можно добавить доверенные домены (например, <code>github.com</code>), с которых файлы скачиваются без задержки.</div>
      `,
      highlight: "💡 Также работают горячие клавиши: Alt+Shift+V (пауза защиты), Alt+Shift+S (проверить выделенное), Alt+Shift+C (закрыть плашки)."
    },
    {
      tab: "tabCustom",
      badge: "🎨 Шаг 6 из 6 • Кастомизация, Темы, Стикеры и Звук",
      title: "6. Полная кастомизация: 10 тем, прозрачность, стикеры и свой шрифт",
      bodyHtml: `
        <div>Во вкладке <b>«🎨 Кастомизация»</b> вы можете настроить внешний вид под себя:</div>
        <div>• <b>10 уникальных тем с фоновыми артами:</b> Лососевый Океан, Helldivers 2, Бездна (Abyss), Касане Тето, Хацуне Мику, Неоновый Киберпанк и другие.</div>
        <div>• <b>Прозрачность фона за текстом:</b> ползунок прозрачности плашек позволяет видеть красивый арт темы сквозь текст!</div>
        <div>• <b>Перетаскиваемые стикеры поверх фона:</b> включайте стикеры тем, загружайте свои PNG/GIF, меняйте их размер и перетаскивайте мышкой в любое место окна!</div>
        <div>• <b>Свой шрифт и звук:</b> загружайте любые шрифты (<code>.ttf/.woff2</code>), меняйте цвет текста и выбирайте звуковые эффекты тем (или загрузите свой <code>.mp3/.wav</code>).</div>
      `,
      highlight: "🎉 Обучение завершено! Вы в любой момент можете повторить его кнопкой «🎓 Повторить обучение» в самом низу окна."
    }
  ],
  en: [
    {
      tab: "tabSettings",
      badge: "🔑 Step 1 of 6 • VirusTotal API Key",
      title: "1. How the VirusTotal API Key & Zero-Key Mode Work",
      bodyHtml: `
        <div>At the top of the <b>"🛡️ Protection & API"</b> tab, you will find the <b>VirusTotal API Key (v3)</b> field.</div>
        <div>• <b>With a Free API Key:</b> the extension scans downloaded files across all <b>72 antivirus engines</b> directly via VirusTotal Cloud and can upload new unknown files for deep analysis.</div>
        <div>• <b>How to get a free key in 30 seconds:</b> click <i>"Get free API key ↗"</i> above the input box, sign in at <code>virustotal.com</code>, and copy your 64-character hex key from your profile's <i>API Key</i> page.</div>
        <div>• <b>No API key? No problem!</b> In <b>Zero-Key Mode</b>, the extension inspects file headers/ZIPs locally, queries <i>MalwareBazaar / CIRCL</i> threat feeds by SHA-256, and syncs verdicts from the VT web page!</div>
      `,
      highlight: "💡 Important (v1.3): When downloading a file, the extension always checks the FILE ITSELF (its SHA-256 & binary structure), never replacing file checks with URL checks!"
    },
    {
      tab: "tabSettings",
      badge: "☁️ Step 2 of 6 • Cloudflare Worker Proxy",
      title: "2. Cloudflare Worker Proxy (Shared 72-AV Cloud & 7-Day Cache)",
      bodyHtml: `
        <div>Right below the Zero-Key selector is the <b>"☁️ Shared Cloud Proxy (Cloudflare Worker URL)"</b> field.</div>
        <div>• <b>What it does:</b> by deploying the included <code>cloudflare_worker_proxy.js</code> script to a free Cloudflare Worker with 1–5 free VT keys, you get a proxy URL like <code>https://vt-proxy.name.workers.dev</code>.</div>
        <div>• <b>Why it's awesome:</b> the Worker automatically rotates API keys (multiplying rate limits) and caches SHA-256 reports at Cloudflare's global edge for <b>7 days</b>. Repeat file checks return full 72-AV results in <b>10 ms</b> using zero API quota!</div>
      `,
      highlight: "💡 If you already entered your personal VirusTotal API key in Step 1, you can leave the Cloudflare Worker field blank."
    },
    {
      tab: "tabMain",
      badge: "🛡️ Step 3 of 6 • Security Presets & Auto-Block",
      title: "3. One-Click Security Presets & Smart False-Positive Filter",
      bodyHtml: `
        <div>On the <b>"🏠 Main"</b> tab, you can switch between <b>4 built-in security presets</b> in one click:</div>
        <div>• <b>🛡️ Comfort (Recommended):</b> balanced protection that ignores single false positives from unknown engines unless a trusted AV flags the file.</div>
        <div>• <b>🔒 Paranoid:</b> strict quarantine on any detection + full PE signature & archive inspection.</div>
        <div>• <b>🎮 Gamer / Repacks:</b> recognizes multiplayer fixes (<code>OnlineFix</code>, <code>Steam_api</code>, trainers/mods) while strictly blocking real password stealers, RATs, and miners!</div>
        <div>• <b>⚡ Light:</b> scans only executables & archives using a compact HUD pill.</div>
      `,
      highlight: "💡 You can also save your own custom preset anytime using the '💾 Save Custom' button!"
    },
    {
      tab: "tabSettings",
      badge: "🧠 Step 4 of 6 • Smart Summary, Trust Score & Scrollbar",
      title: "4. Smart Threat Summary, Adaptive Trust Score & Right Scrollbar",
      bodyHtml: `
        <div>Whenever a file is intercepted, the floating <b>VT Salmon Ocean Guard</b> card appears on screen:</div>
        <div>• <b>📊 Adaptive Trust Score (0–100%):</b> dynamically adapts to the <i>Complaint Classifier</i> — distinguishing dangerous stealers/trojans from harmless game fixes or unsigned utilities.</div>
        <div>• <b>📡 5-Axis Risk Radar & X-Ray:</b> visualizes risk across 5 vectors (Passwords/Sessions, Memory/Game Fix, Network, Autorun, GPU Miner), domain age (RDAP), and PE section entropy.</div>
        <div>• <b>🖱️ Right-Hand Scrollbar:</b> both the floating card and this popup feature a clear right-hand scrollbar so you can always scroll down to read long reports and click action buttons!</div>
      `,
      highlight: "💡 Action buttons ('Download File', 'Block', 'Scan Downloaded File') stay pinned at the bottom of the card."
    },
    {
      tab: "tabFormats",
      badge: "📂 Step 5 of 6 • Manual Scanner & 288+ File Formats",
      title: "5. Drag & Drop Manual Scanner and File Format Filters",
      bodyHtml: `
        <div>• <b>Manual Scanner ("🏠 Main" tab):</b> drag & drop any local file or paste a URL / SHA-256 hash to inspect it instantly without re-downloading.</div>
        <div>• <b>"📂 Formats" Tab:</b> toggle over <b>288 file extensions</b> across 8 categories (Executables, Archives, Documents, Images, Media, Code, Data, System/Torrents). Web scripts (<code>.php</code>, <code>.html</code>) are excluded so redirect pages never trigger false cards.</div>
        <div>• <b>Domain Whitelist:</b> in "🛡️ Protection & API", add trusted domains (like <code>github.com</code>) to skip interception on safe sites.</div>
      `,
      highlight: "💡 Global hotkeys: Alt+Shift+V (toggle guard), Alt+Shift+S (scan selection), Alt+Shift+C (close all cards)."
    },
    {
      tab: "tabCustom",
      badge: "🎨 Step 6 of 6 • Customization: 10 Themes, Stickers & Sounds",
      title: "6. Deep Customization: 10 Themes, Transparency, Stickers & Fonts",
      bodyHtml: `
        <div>In the dedicated <b>"🎨 Customization"</b> tab, personalize every detail of your guard:</div>
        <div>• <b>10 Built-in Themes with Art:</b> Salmon Ocean, Helldivers 2, Abyss (Бездна), Kasane Teto, Hatsune Miku, Cyberpunk Neon, and more.</div>
        <div>• <b>Text-Box Background Transparency:</b> adjust card opacity so your background artwork shines through!</div>
        <div>• <b>Draggable Stickers:</b> enable theme stickers, upload custom PNG/GIFs, resize them, and drag them anywhere with your mouse.</div>
        <div>• <b>Custom Fonts & Sounds:</b> load your own <code>.ttf/.woff2</code> fonts, customize text colors, and pick theme sound effects (or upload your own <code>.mp3/.wav</code>).</div>
      `,
      highlight: "🎉 Tutorial complete! You can replay this guide anytime via the '🎓 Replay Tutorial' button at the very bottom."
    }
  ]
};

let currentOnboardingStep = 0; // 0 = экран выбора языка, 1..6 = шаги обучения

// ==================== ПОЛНЫЙ СЛОВАРЬ ПЕРЕВОДА ВСЕГО ИНТЕРФЕЙСА (RU <-> EN) ====================
const POPUP_RU_TO_EN_EXACT = {
  "Донат": "Donate",
  "🔏 ЭЦП ✓": "🔏 Sign ✓",
  "🔏 Сертификат подлинности (ЭЦП Автора)": "🔏 Certificate of Authenticity (Author Signature)",
  "Официальный автор:": "Official Author:",
  "(второй ник:": "(second handle:",
  "Отпечаток ключа ЭЦП:": "ECDSA Key Fingerprint:",
  "Закреплённый ID:": "Pinned Extension ID:",
  "👑 Доказательство владения (только для создателя):": "👑 Proof of Ownership (for creator only):",
  "👑 Маскот Кибер-Лосось: Классика (Корона)": "👑 Cyber-Salmon Mascot: Classic (Crown)",
  "🛡️ Маскот Кибер-Лосось: Изумрудный Щит": "🛡️ Cyber-Salmon Mascot: Emerald Shield",
  "☁️ Маскот Кибер-Лосось: Хакер Облака": "☁️ Cyber-Salmon Mascot: Cloud Hacker",
  "🔎 Маскот Кибер-Лосось: Детектив с лупой": "🔎 Cyber-Salmon Mascot: Detective Lens",
  "🧠 Маскот Кибер-Лосось: ИИ-Радар (Эврика!)": "🧠 Cyber-Salmon Mascot: AI Radar (Eureka!)",
  "🎉 Маскот Кибер-Лосось: Праздничный": "🎉 Cyber-Salmon Mascot: Celebration",

  "VT Download Guard — Настройки": "VT Download Guard — Settings",
  "🛡️ Автономный антивирус расширения (Встроенное ядро YARA/PE + Облако MalwareBazaar/URLhaus/CIRCL + Антивирус ПК — работает даже БЕЗ антивируса на ПК!)": "🛡️ Built-in Autonomous Extension Antivirus (Embedded YARA/PE Core + MalwareBazaar/URLhaus/CIRCL Cloud + PC AV — works even WITHOUT any PC Antivirus!)",
  "Работает без ключа VT и даже если на ПК вообще нет антивируса (встроенное ядро + облачные базы)": "Works without a VT key and even if your PC has NO antivirus installed at all (Embedded AV Core + Cloud Feeds)",
  "Проверка по 72+ облачным антивирусам VirusTotal (можно включать вместе с Антивирусом ПК)": "Scan with 72+ VirusTotal cloud engines (can be enabled alongside PC Antivirus)",
  "Работает без ключа VT или совместно с API-ключом (двойная защита: Антивирус ПК + Облако)": "Works without a VT key or alongside your API key (Dual Shield: PC Antivirus + Cloud)",
  "Как проверять файлы в режиме БЕЗ ключа (или совместно с ключом):": "How to scan files in Zero-Key mode (or alongside your API key):",
  "использовать защиту Windows (Windows Defender / Kaspersky / Dr.Web / ESET) и локальный сигнатурный движок": "use Windows security (Windows Defender / Kaspersky / Dr.Web / ESET) & local signature engine",
  "✓ Активен режим Антивирус ПК + Zero-Key (работает как без ключа, так и совместно с API-ключом VT).": "✓ PC Antivirus + Zero-Key Mode Active (works both without a key and alongside your VT API key).",
  "🚀 Режим работы БЕЗ API-ключа (Антивирус ПК + Zero-Key)": "🚀 Zero-Key Mode (Local PC Antivirus + Cloud Feeds)",
  "💻 Встроенный / Установленный антивирус ПК по умолчанию (Windows Defender / Системный АВ) + Локальный щит": "💻 Default Installed PC Antivirus (Windows Defender / System AV) + Local Shield",
  "🛡️ Гибридный без ключа: Локальный анализатор + базы MalwareBazaar/CIRCL + кнопка страницы VT": "🛡️ Hybrid Zero-Key: Local Deep Inspector + MalwareBazaar/CIRCL + VT Page button",
  "🪟 Сразу открывать мини-окно страницы VirusTotal по SHA-256 скачиваемого файла": "🪟 Auto-open VirusTotal mini popup window by SHA-256",
  "🌐 Сразу открывать вкладку VirusTotal + авто-чтение вердикта со страницы": "🌐 Auto-open VirusTotal tab + auto-sync verdict from page",
  "Проверять встроенным / выбранным по умолчанию антивирусом на ПК:": "Scan with built-in / default installed PC Antivirus:",
  "использовать защиту Windows (Windows Defender / Kaspersky / Dr.Web / ESET) и локальный сигнатурный движок без ключа VT": "use your PC's default antivirus (Windows Defender / Kaspersky / Dr.Web / ESET) & local signature engine without a VT key",
  "✓ Активен режим БЕЗ API-ключа (Встроенный антивирус ПК по умолчанию + локальный инспектор + базы угроз).": "✓ Zero-Key Mode Active (Default PC Antivirus + Local Deep Inspector + Threat Feeds).",
  "Зафиксировать стикер (клик сквозь него):": "Lock sticker (click through it):",
  "стикер не двигается мышкой и позволяет нажимать кнопки прямо сквозь него": "disable mouse dragging and allow clicking buttons right through the sticker",
  "🔒 Стикер зафиксирован (нажатия проходят сквозь него)": "🔒 Sticker locked (click-through enabled)",
  "🖐️ Перетаскивание стикера мышкой включено": "🖐️ Sticker mouse dragging enabled",
  "Лимиты: 0/4 в мин | 0/500 сегодня": "Limits: 0/4 min | 0/500 today",
  "🌐 Шаг 0 из 6 • Выбор языка": "🌐 Step 0 of 6 • Language Selection",
  "🐟 SALMON & LOSOS OCEAN // БЕРЕГОВАЯ ОХРАНА ФАЙЛОВ 🌊": "🐟 SALMON & LOSOS OCEAN // COASTAL FILE GUARD 🌊",
  "💀 ЗА СУПЕР-ЗЕМЛЮ И ДЕМОКРАТИЮ // ОРБИТАЛЬНЫЙ СКАНЕР ФАЙЛОВ Stratagem ⬆️➡️⬇️⬇️⬇️": "💀 FOR SUPER EARTH & DEMOCRACY // ORBITAL FILE SCANNER Stratagem ⬆️➡️⬇️⬇️⬇️",
  "⛓️ НЕПОКОЛЕБИМЫЙ БЕЛЫЙ СВИСТОК // ГЛУБИННЫЙ ДОСМОТР АРТЕФАКТОВ БЕЗДНЫ 🧭": "⛓️ THE UNMOVABLE SOVEREIGN // DEEP ABYSS ARTIFACT INSPECTOR 🧭",
  "🥖 KASANE TETO 0401 // UTAU & SYNTHV TWIN-DRILL ЗАЩИТА 🎤": "🥖 KASANE TETO 0401 // UTAU & SYNTHV TWIN-DRILL GUARD 🎤",
  "🎵 HATSUNE MIKU CV01 // ЦИФРОВОЙ БИРЮЗОВЫЙ ЩИТ СЦЕНЫ 葱": "🎵 HATSUNE MIKU CV01 // DIGITAL CYAN STAGE SHIELD 葱",
  "Проверка файлов • Интерактивное обучение • RU / EN": "Direct File Check • Interactive Guide • RU / EN",
  "🏠 Главное": "🏠 Main",
  "📂 Форматы": "📂 Formats",
  "🛡️ Защита и API": "🛡️ Protection & API",
  "🎨 Кастомизация": "🎨 Customize",
  "🛡️ Проверено": "🛡️ Scanned",
  "🚨 Угроз отражено": "🚨 Threats Blocked",
  "⚡ Из кэша (0 мс)": "⚡ From Cache (0 ms)",
  "🎚️ Пресеты режима защиты (в 1 клик)": "🎚️ Security Mode Presets (1-Click)",
  "⚡ Комфорт": "⚡ Comfort",
  "🏰 Паранойя": "🏰 Paranoid",
  "🎮 Геймер": "🎮 Gamer",
  "🍃 Лёгкий": "🍃 Light",
  "⚙️ Свой": "⚙️ Custom",
  "⚡ Быстрое управление": "⚡ Quick Controls",
  "Автоматически сохранять файл, если всё чисто": "Auto-save file when completely clean",
  "Если 0 антивирусов нашли угрозы, файл сразу сохраняется без нажатия кнопки «Скачать»": "If 0 antivirus engines find threats, save the file automatically without clicking 'Download'",
  "📌 Оставлять окно проверки при закрытии вкладки": "📌 Keep scan window open when tab closes",
  "Если вкладка скачивания закрылась — переносить окно проверки на текущую вкладку или в отдельное окно (выкл = автозакрытие с вкладкой)": "If the download tab closes, move the scan card to the active tab or a standalone window (off = auto-close with tab)",
  "Показывать детальную таблицу всех антивирусов": "Show detailed table of all antivirus engines",
  "Полный список 60–72 вендоров (★ Kaspersky, DrWeb, ESET, Microsoft и др.) как в VirusTotal": "Full list of 60–72 security vendors (★ Kaspersky, DrWeb, ESET, Microsoft, etc.) like on VirusTotal",
  "Режим показа таблицы антивирусов:": "Antivirus table display mode:",
  "Внутри плашки + кнопка полного окна как в VirusTotal": "Inside card + full-screen VirusTotal modal button",
  "Сразу открывать большое окно отчёта со всеми антивирусами": "Immediately open full report window with all vendors",
  "Только по нажатию кнопки «Все антивирусы как в VT»": "Compact (only when clicking 'Vendors' button)",
  "🛡️ Быстрая проверка ссылок на скачивание": "🛡️ Quick download link hover badge",
  "Кнопка «Проверить в VT» при наведении на ссылки (.exe, .zip, .apk, короткие ссылки)": "'Scan Link in VT' badge when hovering links (.exe, .zip, .apk, short links)",
  "🔎 Проверка выделенного текста (хеша / ссылки)": "🔎 Selected text scanner (hash / URL)",
  "Всплывающая кнопка проверки при выделении мышкой SHA-256, MD5 или URL на сайте": "Popup scan button when highlighting a SHA-256, MD5, or URL on any webpage",
  "⌨️ Горячие клавиши и Анти-Фишинг доменов": "⌨️ Hotkeys & Domain Anti-Phishing",
  "Вкл/Выкл: Alt+Shift+V • Проверка: Alt+Shift+S • Сброс: Alt+Shift+C": "Toggle: Alt+Shift+V • Scan: Alt+Shift+S • Close All: Alt+Shift+C",
  "⏱️ Временная пауза защиты:": "⏱️ Temporary guard snooze:",
  "15 мин": "15 min",
  "30 мин": "30 min",
  "1 час": "1 hr",
  "▶ Включить": "▶ Resume",
  "Своё время паузы (в минутах):": "Custom snooze duration (minutes):",
  "⏸️ Пауза": "⏸️ Snooze",
  "🔎 Ручная проверка файла / ссылки / хеша (без ключа)": "🔎 Manual File / URL / Hash Scanner (Full Card)",
  "📄 Перетащите файл сюда или": "📄 Drag & drop a file here or",
  "выберите на ПК": "browse on PC",
  "Мгновенный SHA-256 + проверка ZIP/энтропии + переход на страницу VT": "Full download-style scan card + SHA-256 + Smart Summary + VT Lookup",
  "Проверить ↗": "Scan ↗",
  "Проверить": "Verify",
  "🕒 Последние проверенные файлы и ссылки": "🕒 Recent Scanned Files & Links",
  "Все": "All",
  "Только угрозы": "Threats Only",
  "🗑️ Очистить": "🗑️ Clear",
  "Очистить": "Clear",
  "Пока нет проверенных объектов": "No scanned items yet",
  "Угроз в истории не обнаружено": "No threats found in history",
  "📂 Форматы файлов для проверки": "📂 Monitored File Formats",
  "0 выбрано": "0 selected",
  "Абсолютно любые файлы": "All files",
  "(независимо от расширения)": "(regardless of file extension)",
  "Выбранные форматы": "Selected formats",
  "(каталог по 8 категориям без дубликатов)": "(catalog across 8 categories with no duplicates)",
  "Выбрать все (296)": "Select All",
  "Снять все": "Clear All",
  "Только опасные": "Dangerous Only",
  "Вкл/выкл категорию": "Toggle Category",
  "+ Добавить": "+ Add",
  "📏 Ограничение по размеру файла": "📏 File Size Limit",
  "Пропускать гигантские файлы (.mp4, .iso), чтобы не нагружать браузер расчётом хеша": "Skip huge files (.mp4, .iso) to avoid heavy browser hashing",
  "Пропускать любые файлы крупнее (МБ):": "Skip any files larger than (MB):",
  "Лимит для Видео/Аудио и Архивов/ISO (МБ):": "Limit for Video/Audio & Archives/ISO (MB):",
  "🚀 Режим работы БЕЗ API-ключа (Zero-Key Mode)": "🚀 Zero-Key Mode (No API Key Required)",
  "Как проверять файлы, если пользователь не ввёл ключ VT:": "How to scan files when no personal VT API key is entered:",
  "Гибридный без ключа: Локальный анализатор + базы MalwareBazaar/CIRCL + кнопка страницы VT": "Hybrid Zero-Key: Local Deep Inspector + MalwareBazaar/CIRCL feeds + VT Page button",
  "Сразу открывать мини-окно страницы VirusTotal по SHA-256 скачиваемого файла": "Auto-open VirusTotal mini popup window by SHA-256",
  "Сразу открывать вкладку VirusTotal + авто-чтение вердикта со страницы": "Auto-open VirusTotal tab + auto-sync verdict from page",
  "☁️ URL вашего Cloudflare Worker прокси (опционально, раздаёт 72 АВ всем без ключа):": "☁️ Your Cloudflare Worker Proxy URL (optional, gives 72 AVs without a key):",
  "🛡️ Модули глубокой защиты и Умный анализатор": "🛡️ Deep Protection Modules & Smart Analyzer",
  "Умная сводка поведения файла:": "Smart Behavioral Summary:",
  "объяснять, на что жалуется VT (стилер / кряк / ложная тревога) и что делает файл": "explain what VT flags (stealer / crack / false positive), what the file could be, and what it does",
  "Адаптивный Индекс доверия (0–100%):": "Adaptive Trust Score (0–100%):",
  "автоматически подстраивать процент доверия под классификатор жалоб АВ": "automatically adjust trust percentage based on the AV complaint classifier",
  "🛑 Защита буфера обмена от фейковых капч": "🛑 Clipboard Shield against fake CAPTCHAs",
  "(блокировка скрытых команд Win+R / PowerShell)": "(blocks hidden Win+R / PowerShell ClickFix commands)",
  "Анти-Клиппер (Clipper Guard):": "Anti-Clipper (Clipper Guard):",
  "предупреждать при подмене в буфере обмена Steam Trade ссылок и кошельков": "warn if Steam Trade URLs or crypto wallet addresses are swapped in clipboard",
  "📋 Помощник буфера обмена (предлагать проверку при копировании Ctrl+C ссылки или SHA-256)": "📋 Clipboard Helper (offer scan when copying a link or SHA-256 with Ctrl+C)",
  "🔏 Проверка цифровой подписи": "🔏 Digital Signature Check",
  "внутри скачиваемых .exe / .dll": "inside downloaded .exe / .dll files",
  "📦 Глубокий осмотр": "📦 Deep Inspection of",
  "без распаковки и скрытых команд в ярлыках": "without unpacking & hidden commands inside",
  "🌐 Проверка возраста домена через": "🌐 Domain Age Check via",
  "(предупреждать о сайтах-однодневках младше 30 дней)": "(warn about newly registered domains younger than 30 days)",
  "Визуальный Рентген файла и 5-шкальный Радар рисков": "Visual File X-Ray & 5-Axis Risk Radar",
  "внутри карточки отчёта": "inside the scan report card",
  "Детектор запароленных архивов (.ZIP/.RAR)": "Password-Protected Archive Detector (.ZIP/.RAR)",
  "и инспекция прав внутри": "& permissions inspection inside",
  "плагинов": "browser add-ons",
  "🕸️ Защита от": "🕸️ Protection against",
  "(проверять файлы, собранные скриптами сайта через": "(inspect files assembled in-browser via",
  "🎣 Анти-фишинг (защита от Punycode xn--, .zip-доменов и клонов популярных сайтов)": "🎣 Anti-Phishing Shield (blocks Punycode xn--, .zip domains & brand lookalikes)",
  "🛡️ Кнопка «Проверить ссылку в VT» при наведении на ссылки файлов": "🛡️ Show 'Scan Link in VT' button when hovering file links",
  "Когда показывать кнопку над ссылкой:": "When to show hover button on links:",
  "Только при зажатой клавише Alt (рекомендуется)": "Only while holding Alt key (recommended)",
  "Всегда при наведении на ссылку": "Always when hovering a link",
  "Сразу при наведении мыши": "Immediately on mouse hover",
  "Только при зажатой клавише Alt": "Only while holding Alt key",
  "🔎 Кнопка «Проверить выделенное» при выделении мышкой хеша / URL на странице": "🔎 Show 'Scan Selection' button when highlighting a hash or URL",
  "🔗 Раскрывать короткие ссылки (bit.ly, clck.ru, vk.cc, t.co) перед проверкой": "🔗 Unshorten short URLs (bit.ly, clck.ru, vk.cc, t.co) before scanning",
  "⌨️ Горячие клавиши управления (кликните по полю, чтобы назначить свои):": "⌨️ Custom Control Hotkeys (click any field to rebind):",
  "🛡️ Вкл / Выкл защиту:": "🛡️ Toggle Guard On / Off:",
  "🔎 Проверить выделенное / ссылку:": "🔎 Scan Selection / Hovered Link:",
  "✕ Закрыть все плашки на сайте:": "✕ Close All Cards on Page:",
  "🛡️ Автоблокировка при превышении порога угроз": "🛡️ Auto-Block When Threat Threshold Is Reached",
  "Блокировать сохранение при срабатывании антивирусов": "Automatically block dangerous downloads when antivirus engines trigger",
  "Защита от ложных срабатываний (Белый список АВ):": "False Positive Protection (Trusted AV Whitelist):",
  "Умный фильтр: 1 авторитетный АВ (Kaspersky, DrWeb, ESET, MS) или 3+ малоизвестных": "Smart Filter: 1 Trusted AV (Kaspersky, DrWeb, ESET, MS) or 3+ unknown engines",
  "Учитывать только авторитетных вендоров (★ Белый список АВ)": "Trusted Vendors Only (★ 26 Top Antivirus Engines)",
  "Учитывать все движки подряд по общему порогу ниже": "Count All Engines Equally by Threshold Below",
  "Порог срабатываний антивирусов:": "Antivirus detection threshold:",
  "Учитывать подозрительные (`Suspicious`) срабатывания в пороге": "Include 'Suspicious' flags in auto-block threshold",
  "Строгий карантин (сразу удалять файл с диска при тревоге)": "Strict Quarantine (immediately remove blocked file from disk)",
  "🔑 API-ключ VirusTotal (опционально)": "🔑 VirusTotal API Key (Optional)",
  "Получить ключ ↗": "Get Free Key ↗",
  "Очередь запросов (Queue) активна": "Request Queue Active",
  "🔒 Приватность, Кэш SHA-256 и Доверенные файлы": "🔒 Privacy, SHA-256 Cache & Trusted Files",
  "Отправлять неизвестные файлы на сервер VirusTotal:": "Upload unknown files to VirusTotal cloud:",
  "Только с согласия (сначала проверять SHA-256 хеш, спрашивать перед загрузкой)": "Ask Permission First (check SHA-256 hash first, ask before uploading file)",
  "Автоматически (загружать новые файлы сразу, если их нет в базе)": "Automatically (upload unknown files immediately if not in VT database)",
  "Никогда — проверять строго по SHA-256 хешу (макс. приватность для документов)": "Never — Hash-Only Lookup (maximum privacy for personal documents)",
  "Хранить кэш проверенных SHA-256 (дней):": "Keep verified SHA-256 cache (days):",
  "🗑️ Кэш (": "🗑️ Cache (",
  "⭐ Доверенные (": "⭐ Trusted (",
  "🌐 Белый список доменов (Whitelist)": "🌐 Trusted Domain Whitelist",
  "Не тратить квоту API на доверенные сайты (github.com, microsoft.com, 192.168.*)": "Skip interception on trusted domains (github.com, microsoft.com, 192.168.*)",
  "+ Домен": "+ Domain",
  "🌟 Пресеты скинов, Тема и Иконка": "🌟 Skin Presets, Theme & Toolbar Icon",
  "👁️ Тест плашки на сайте": "👁️ Test Card on Page",
  "Готовые комбо-пресеты (Тема + Фон + Прозрачность + Стикер + Шрифт + Звук):": "1-Click Skin Combo Presets (Theme + Art + Opacity + Sticker + Font + Sound):",
  "🐟 Лосось Glass": "🐟 Salmon Glass",
  "⛓️ Бездна": "⛓️ Abyss",
  "🥖 Тето 0401": "🥖 Teto 0401",
  "🎵 Мику CV01": "🎵 Miku CV01",
  "💾 Сохранить": "💾 Save",
  "📋 Скопировать код темы": "📋 Copy Theme Code",
  "📥 Вставить код темы": "📥 Paste Theme Code",
  "Тема интерфейса и плашек (10 тем):": "Interface & Floating Card Theme (10 Themes):",
  "🐟 Лососевый Океан (Salmon & Losos)": "🐟 Salmon Ocean (Salmon & Losos)",
  "💀 Helldivers 2 (Super Earth Tactical)": "💀 Helldivers 2 (Super Earth Tactical)",
  "⛓️ Бездна (Made in Abyss)": "⛓️ Abyss (Made in Abyss)",
  "🥖 Kasane Teto (0401 Twin-Drill)": "🥖 Kasane Teto (0401 Twin-Drill)",
  "🎵 Hatsune Miku (CV01 Digital Cyan)": "🎵 Hatsune Miku (CV01 Digital Cyan)",
  "🌌 Cyber Blue (Тёмно-синяя)": "🌌 Cyber Blue (Dark Blue)",
  "🟢 OLED Matrix (Чёрно-изумрудная)": "🟢 OLED Matrix (Black Emerald)",
  "🟣 Neon Purple (Киберпанк)": "🟣 Neon Purple (Cyberpunk)",
  "🔴 Crimson ROG (Рубиновая)": "🔴 Crimson ROG (Ruby Dark)",
  "☀️ Light Clean (Светлая дневная)": "☀️ Light Clean (Daylight)",
  "Стиль иконки в браузере (11 вариантов):": "Browser Toolbar Icon Style (11 Styles):",
  "✨ Авто": "✨ Auto",
  "Лосось": "Salmon",
  "Бездна": "Abyss",
  "Тето": "Teto",
  "Мику": "Miku",
  "Синий": "Blue",
  "Изумруд": "Emerald",
  "Неон": "Neon",
  "Рубин": "Ruby",
  "Золото": "Gold",
  "🖼️ Фоновая картинка (Арт) и Прозрачность за текстом": "🖼️ Background Artwork & Text-Box Transparency",
  "Уникальный арт для каждой из 10 тем + настройка видимости фона сквозь карточки": "Custom artwork for all 10 themes + adjustable glass transparency behind text",
  "Яркость задней картинки (": "Background art brightness (",
  "💧 Плотность фона за текстом (": "💧 Text-box background opacity (",
  "✨ Матовое стекло за текстом (выключите для 100% чёткости картинки)": "✨ Frosted glass blur behind text (uncheck for 100% crisp artwork)",
  "Живые анимированные частицы темы (Live FX):": "Live Animated Theme Particles (Live FX):",
  "пузырьки Лосося, десант HD2, огоньки Бездны, эквалайзер Мику/Тето": "Salmon bubbles, HD2 drop pods, Abyss orbs, Miku/Teto equalizer",
  "💫 Неоновое свечение рамок (": "💫 Border neon glow (",
  "📂 Загрузить свой фон (Фото/GIF)": "📂 Upload Custom Background (Image/GIF)",
  "🔄 Родной арт темы": "🔄 Default Theme Art",
  "✨ Стикеры / Маскоты поверх фона": "✨ Stickers & Mascots Overlay",
  "Встроенные стикеры тем (Лосось, Helldivers 2, Бездна, Тето, Мику) + свои стикеры и перетаскивание мышью": "Built-in theme stickers (Salmon, HD2, Abyss, Teto, Miku) + custom stickers & mouse dragging",
  "Выбор стикера:": "Sticker preset:",
  "✨ Авто (Свой стикер у каждой темы)": "✨ Auto (Match active theme sticker)",
  "🐟 Коронованный Лосось (Salmon & Losos)": "🐟 Crowned Salmon (Salmon & Losos)",
  "💀 Череп Супер-Земли (Helldivers 2)": "💀 Super Earth Skull (Helldivers 2)",
  "⛓️ Белый Свисток Бездны (Abyss)": "⛓️ White Whistle of the Abyss",
  "🥖 Двойные локоны Касане Тето (0401)": "🥖 Kasane Teto Twin-Drills (0401)",
  "🎵 Твинтейлы Хацуне Мику (CV01)": "🎵 Hatsune Miku Twintails (CV01)",
  "🛡️ Голографический Кибер-Щит": "🛡️ Holographic Cyber Shield",
  "🟢 Изумрудное Ядро Матрицы": "🟢 Matrix Emerald Core",
  "🌆 Ретро-Солнце Синтвейв": "🌆 Synthwave Retro Sun",
  "⚔️ Рубиновый Герб ROG": "⚔️ Crimson ROG Crest",
  "⭐ Золотая Звезда Стража": "⭐ Golden Guardian Star",
  "📂 Свой загруженный стикер (PNG/GIF)": "📂 Custom Uploaded Sticker (PNG/GIF)",
  "Размер стикера (": "Sticker size (",
  "Прозрачность стикера (": "Sticker opacity (",
  "Позиция (или перетащите стикер мышкой):": "Position (or drag sticker with mouse):",
  "↘ Справа снизу": "↘ Bottom-Right",
  "↗ Справа сверху": "↗ Top-Right",
  "↙ Слева снизу": "↙ Bottom-Left",
  "🎯 По центру": "🎯 Center",
  "🖐️ Своя (перетаскивание мышью)": "🖐️ Custom (Drag with mouse)",
  "📂 Добавить свой стикер (PNG/GIF/WebP)": "📂 Upload Custom Sticker (PNG/GIF/WebP)",
  "🔄 Авто-стикер": "🔄 Auto Sticker",
  "🛠️ Шрифт, Размер, Цвета и Позиция плашки": "🛠️ Font, Scale, Colors & Card Position",
  "🔄 Сброс": "🔄 Reset",
  "Шрифт текста:": "Typography / Font:",
  "🔤 Системный (Segoe UI / Inter)": "🔤 System Default (Segoe UI / Inter)",
  "💻 Хакерский Моно (JetBrains / Consolas)": "💻 Hacker Monospace (JetBrains / Consolas)",
  "⚡ Тактический широкий (Helldivers / Tech)": "⚡ Tactical Wide (Helldivers / Tech)",
  "🫧 Мягкий округлый (Nunito / Trebuchet)": "🫧 Soft Rounded (Nunito / Trebuchet)",
  "📖 Книжный с засечками (Georgia / Бездна)": "📖 Classic Serif (Georgia / Abyss)",
  "🔥 Брутальный (Impact / Заголовочный)": "🔥 Heavy Display (Impact)",
  "🎈 Неформальный (Comic Sans MS)": "🎈 Casual (Comic Sans MS)",
  "📟 Ретро-Терминал (Courier / Lucida)": "📟 Retro Terminal (Courier / Lucida)",
  "🌐 Свой шрифт по имени / Google Fonts": "🌐 Custom Font by Name / Google Fonts",
  "📂 Свой загруженный файл шрифта (.ttf/.woff2)": "📂 Custom Uploaded Font File (.ttf/.woff2)",
  "Применить": "Apply",
  "Размер шрифта и масштаб (": "Font size & UI scale (",
  "Скругление углов карточек (": "Card corner radius (",
  "Ширина окна расширения (": "Popup window width (",
  "🎬 Анимация появления плашки:": "🎬 Card entrance animation:",
  "🌊 Плавный слайд (Классика)": "🌊 Smooth Slide (Classic)",
  "🏀 Пружинный отскок (Bounce)": "🏀 Spring Bounce",
  "⚡ Кибер-Глитч (Cyberpunk)": "⚡ Cyber Glitch",
  "🔍 Мягкий зум (Zoom In)": "🔍 Smooth Zoom In",
  "Режим мини-капсулы (HUD) для чистых файлов:": "Mini-Pill HUD Mode for clean files:",
  "показывать маленькую таблетку, разворачивающуюся по клику": "show a compact HUD pill that expands on click",
  "Позиция плашки на сайтах:": "Floating card position on websites:",
  "↗ Сверху справа": "↗ Top-Right",
  "↘ Снизу справа": "↘ Bottom-Right",
  "↖ Сверху слева": "↖ Top-Left",
  "↙ Снизу слева": "↙ Bottom-Left",
  "Автоскрытие чистой плашки (сек., 0 = выкл):": "Auto-close clean card (sec, 0 = off):",
  "5с": "5s",
  "15с": "15s",
  "Выкл": "Off",
  "🎨 Использовать свою палитру цветов поверх темы:": "🎨 Use custom color palette over theme:",
  "Фон": "Background",
  "Карточки": "Cards",
  "Акцент": "Accent",
  "🖍️ Свой цвет текста (заголовков и подписей):": "🖍️ Custom text color (headings & labels):",
  "Основной текст": "Primary Text",
  "Второстепенный текст": "Secondary Text",
  "🔊 Звуковые сигналы и мелодии тем": "🔊 Sound Alerts & Theme Melodies",
  "🎵 Прослушать": "🎵 Test Sound",
  "Включить звуковое оповещение по завершении проверки файла": "Enable sound alert when file scan completes",
  "Вариация звука:": "Sound preset:",
  "✨ Авто (У каждой темы своя мелодия)": "✨ Auto (Each theme plays its own melody)",
  "🐟 Морской перелив (Лососевый Океан)": "🐟 Ocean Chime (Salmon Ocean)",
  "💀 Ввод стратагемы (Helldivers 2)": "💀 Stratagem Input (Helldivers 2)",
  "⛓️ Резонанс Бездны (Made in Abyss)": "⛓️ Abyss Resonance (Made in Abyss)",
  "🥖 SynthV Драйв (Kasane Teto 0401)": "🥖 SynthV Drive (Kasane Teto 0401)",
  "🎵 Цифровой аккорд (Hatsune Miku CV01)": "🎵 Digital Chord (Hatsune Miku CV01)",
  "👾 8-bit Аркада (Retro Coin)": "👾 8-Bit Arcade (Retro Coin)",
  "📡 Глубоководный Сонар": "📡 Deep Sea Sonar Ping",
  "🔔 Хрустальный перезвон": "🔔 Crystal Chime",
  "🌌 Кибер-Импульс": "🌌 Cyber Pulse",
  "📂 Свой загруженный звук (.mp3/.wav/.ogg)": "📂 Custom Uploaded Audio (.mp3/.wav/.ogg)",
  "Громкость звука (": "Sound volume (",
  "📂 Загрузить свой звук (.mp3 / .wav / .ogg)": "📂 Upload Custom Sound (.mp3 / .wav / .ogg)",
  "🔄 Сброс звука": "🔄 Reset Sound",
  "📤 Экспорт настроек (JSON)": "📤 Export Settings (JSON)",
  "📥 Импорт настроек (JSON)": "📥 Import Settings (JSON)",
  "Все изменения сохраняются автоматически": "All changes are saved automatically",
  "🎓 Повторить обучение (Как всё устроено)": "🎓 Replay Tutorial (How Everything Works)",
  "⏭️ Пропустить обучение": "⏭️ Skip Tutorial",
  "👋 Добро пожаловать в VT Download Guard v1.3!": "👋 Welcome to VT Download Guard v1.3!",
  "Выберите язык интерфейса и короткого обучения. Вы сможете пропустить обучение прямо сейчас или пройти его за 1 минуту:": "Choose your interface & tutorial language below. You can skip the tutorial right away or complete it in 1 minute:",
  "Полный перевод и обучение": "Full Russian UI & Guide",
  "⏭️ Сразу скипнуть обучение": "⏭️ Skip Tutorial Now",
  "🚀 Начать обучение →": "🚀 Start Tutorial →",
  "← Назад": "← Back",
  "⏭️ Скинуть": "⏭️ Skip",
  "Далее →": "Next →"
};

const POPUP_ATTR_RU_TO_EN = {
  "Зажмите мышкой, чтобы перетащить стикер в любое место окна!": "Hold mouse button to drag the sticker anywhere in the window!",
  "Нажмите, чтобы быстро сменить стиль иконки щита": "Click to cycle toolbar shield icon style",
  "Включить / выключить живые анимированные частицы темы (Live FX)": "Toggle live animated theme particles (Live FX)",
  "Включить / выключить стикер темы поверх фона": "Toggle theme sticker overlay",
  "Включить / выключить фоновую картинку темы": "Toggle theme background artwork",
  "Быстро переключить тему оформления (10 тем)": "Quickly switch theme (10 themes)",
  "Включить или выключить перехват файлов": "Enable or disable file download interception",
  "Оптимальный баланс: автосохранение чистых, умный фильтр АВ, защита ClickFix и осмотр архивов": "Balanced protection: auto-save clean files, smart AV filter, ClickFix shield & archive inspection",
  "Максимальная защита: перехват всех форматов, строгий карантин от 1 угрозы, проверка возраста доменов и подписи PE": "Maximum security: intercept all formats, strict quarantine on 1+ threat, RDAP domain age & PE signature check",
  "Тихий игровой режим: без звуков, автоскрытие за 4 сек, кнопка на ссылках только по Alt": "Silent gaming mode: muted sounds, 4s auto-close, hover badge only with Alt key",
  "Лёгкий режим для слабых ПК: без тяжёлых эффектов стекла, пропуск файлов > 150 МБ": "Lightweight mode for low-end PCs: disables heavy blur effects, skips files > 150 MB",
  "Лимиты бесплатного публичного ключа VirusTotal (4 запроса в минуту и 500 в день)": "Free VirusTotal public API limits (4 requests/min and 500/day)",
  "Нажмите или перетащите сюда любой файл для мгновенного расчёта SHA-256 и открытия отчёта на VirusTotal": "Click or drag & drop any file here for a full scan card + SHA-256 + VirusTotal report",
  "Или вставьте SHA-256 хеш / URL-ссылку...": "Or paste a SHA-256 hash / URL link...",
  "Очистить журнал проверок": "Clear scan history log",
  "🔍 Поиск в истории по имени файла или SHA-256...": "🔍 Search history by filename or SHA-256...",
  "🔍 Поиск формата (например: torrent, exe, png, apk, zip)...": "🔍 Search extension (e.g. torrent, exe, png, apk, zip)...",
  "Добавить свой формат (через запятую)...": "Add custom extension (comma-separated)...",
  "https://vt-proxy.ваш-домен.workers.dev": "https://vt-proxy.your-domain.workers.dev",
  "Кликните и нажмите нужные клавиши": "Click and press your desired shortcut keys",
  "Вставьте 64-значный API-ключ с virustotal.com...": "Paste your 64-character hex API key from virustotal.com...",
  "Показать/скрыть ключ": "Show / hide API key",
  "Проверить работу ключа": "Test API key connection",
  "Очистить кэш проверенных SHA-256": "Clear verified SHA-256 hash cache",
  "Очистить белый список доверенных файлов": "Clear trusted files whitelist",
  "Добавить домен (напр. github.com, 192.168.*)...": "Add domain (e.g. github.com, 192.168.*)...",
  "Показать тестовую плашку с вашей темой, фоном, стикером и шрифтом на открытой странице": "Show a demo floating card with your theme, art, sticker & font on the active webpage",
  "Название вашего пресета (напр. Мой стиль)...": "Custom preset name (e.g. My Style)...",
  "Скопировать код вашей темы в буфер обмена, чтобы скинуть другу": "Copy your theme config code to clipboard to share with friends",
  "Применить код темы из буфера обмена": "Apply theme config code from clipboard",
  "🔥 Специальные и Аниме / Игровые темы": "🔥 Featured Anime & Gaming Themes",
  "🎨 Классические темы": "🎨 Classic Themes",
  "Автоматически под выбранную тему": "Automatically match active theme",
  "Лососевый щит (Salmon & Losos)": "Salmon Shield (Salmon & Losos)",
  "Тактический щит Helldivers 2": "Helldivers 2 Tactical Shield",
  "Щит Бездны (Made in Abyss)": "Abyss Shield (Made in Abyss)",
  "Синий щит": "Blue Shield",
  "Изумрудный щит": "Emerald Shield",
  "Фиолетовый щит": "Purple Neon Shield",
  "Рубиновый щит": "Crimson Shield",
  "Золотой VIP-щит": "Gold VIP Shield",
  "Уменьшите, чтобы карточки за текстом стали прозрачными и открыли заднюю картинку": "Lower this value to make cards transparent so the background art shines through",
  "Вернуть родной арт выбранной темы": "Restore default artwork of the active theme",
  "Сбросить шрифт, размер и цвета к стандартным": "Reset font, scale, and colors to defaults",
  "Имя шрифта Windows или Google Fonts (напр. Rubik, Montserrat, Russo One)...": "Windows or Google Font name (e.g. Rubik, Montserrat, Russo One)...",
  "Загрузить свой файл шрифта .ttf / .otf / .woff2 с компьютера": "Upload a local .ttf / .otf / .woff2 font file from PC",
  "Введите своё время в секундах (0 — не закрывать автоматически)": "Enter custom time in seconds (0 = never auto-close)",
  "Закрыть и пропустить обучение": "Close and skip tutorial"
};

const THEME_FLAVOR_TEXT_EN = {
  salmon_ocean: "🐟 SALMON & LOSOS OCEAN // COASTAL FILE GUARD 🌊",
  helldivers2: "💀 FOR SUPER EARTH & DEMOCRACY // ORBITAL FILE SCANNER Stratagem ⬆️➡️⬇️⬇️⬇️",
  ozen_abyss: "⛓️ THE UNMOVABLE SOVEREIGN // DEEP ABYSS ARTIFACT INSPECTOR 🧭",
  vocaloid_teto: "🥖 KASANE TETO 0401 // UTAU & SYNTHV TWIN-DRILL GUARD 🎤",
  vocaloid_miku: "🎵 HATSUNE MIKU CV01 // DIGITAL CYAN STAGE SHIELD 葱"
};

const CATEGORY_LABELS_EN = {
  all: "All Formats",
  exec: "⚙️ Executables & APK",
  arch: "📦 Archives & ISO",
  docs: "📄 Office & Docs",
  img: "🖼️ Images, Art & 3D",
  media: "🎬 Audio & Video",
  code: "💻 Code & Scripts",
  data: "🗄️ Data & Certs",
  sys: "🔧 System & Torrents",
  custom: "✨ Custom"
};

function translateDynamicRuToEn(rawStr) {
  if (!rawStr) return rawStr;
  let s = String(rawStr);
  const trimmed = s.trim();
  if (POPUP_RU_TO_EN_EXACT[trimmed]) {
    const lead = s.match(/^\s*/)?.[0] || "";
    const trail = s.match(/\s*$/)?.[0] || "";
    return lead + POPUP_RU_TO_EN_EXACT[trimmed] + trail;
  }
  const dynPairs = [
        ["⚙️ Программы и APK", "⚙️ Executables & APK"],
    ["📦 Архивы и ISO", "📦 Archives & ISO"],
    ["📄 Документы и Офис", "📄 Office & Docs"],
    ["🖼️ Фото, Графика и 3D", "🖼️ Images, Art & 3D"],
    ["🎬 Аудио и Видео", "🎬 Audio & Video"],
    ["💻 Код и Скрипты", "💻 Code & Scripts"],
    ["🗄️ Данные и Сертификаты", "🗄️ Data & Certs"],
    ["🔧 Системные и Торренты", "🔧 System & Torrents"],
    ["✨ Свои", "✨ Custom"],
    ["Лимиты: ", "Limits: "],
    [" в мин | ", "/min | "],
    [" сегодня", " today"],
    [" | Очередь: ", " | Queue: "],
    [" из ", " of "],
    [" выбрано", " selected"],
    ["Выбрать все (", "Select All ("],
    ["Все форматы (", "All Formats ("],
    ["Все форматы", "All Formats"],
    ["Вкл/Выкл: ", "Toggle: "],
    [" • Проверка: ", " • Scan: "],
    [" • Сброс: ", " • Close: "],
    ["✓ Активен режим БЕЗ API-ключа (Встроенный антивирус ПК по умолчанию + локальный инспектор + базы угроз).", "✓ Zero-Key Mode Active (Default PC Antivirus + Local Deep Inspector + Threat Feeds)."],
    ["✓ Формат ключа корректен (64 hex-символа). Нажмите «Проверить» для теста связи.", "✓ Key format is valid (64 hex chars). Click 'Verify' to test connection."],
    ["❌ Неверный формат ключа (сейчас символов: ", "❌ Invalid key length (current: "],
    [", нужно 64 символа 0-9, a-f).", ", required: 64 hex chars 0-9, a-f)."],
    ["✅ Ключ активен! VirusTotal API v3 успешно отвечает.", "✅ API Key is active! VirusTotal API v3 responded successfully."],
    ["⏸️ На паузе (включится через ~", "⏸️ Snoozed (resumes in ~"],
    [" мин.)", " min)"],
    ["⏱️ Временная пауза защиты:", "⏱️ Temporary guard snooze:"],
    ["Белый список доменов пуст", "Domain whitelist is empty"],
    ["Форматы не найдены. Добавьте свой формат ниже.", "No formats found. Add a custom extension below."],
    ["Пока нет проверенных объектов", "No scanned items yet"],
    ["Угроз в истории не обнаружено", "No threats found in history"],
    ["📋 Хеш", "📋 Hash"],
    ["Скопировать SHA-256: ", "Copy SHA-256: "],
    ["Открыть отчёт на сайте VirusTotal", "Open report on VirusTotal"],
        ["✓ Настройки сохранены", "✓ Settings saved"],
    ["Все изменения сохраняются автоматически", "All changes are saved automatically"],
    ["✓ Локальный кэш SHA-256 очищен", "✓ Local SHA-256 cache cleared"],
    ["✓ Белый список доверенных файлов очищен", "✓ Trusted files whitelist cleared"],
    ["✓ История и предупреждения очищены", "✓ Scan history and alerts cleared"],
    ["✓ Все настройки и темы экспортированы в JSON", "✓ All settings & themes exported to JSON"],
    ["✓ Настройки успешно импортированы!", "✓ Settings imported successfully!"],
    ["❌ Ошибка чтения JSON-файла настроек", "❌ Failed to parse settings JSON file"],
    ["✓ Восстановлен родной арт выбранной темы", "✓ Restored default theme artwork"],
    ["✓ Восстановлен фирменный стикер темы", "✓ Restored default theme sticker"],
    ["✓ Восстановлена фирменная мелодия темы", "✓ Restored default theme melody"],
    ["✓ Шрифт, размер и пропорции сброшены по умолчанию", "✓ Font, scale, and layout reset to defaults"],
    ["✨ Ваш собственный стикер установлен!", "✨ Custom sticker applied!"],
    ["✨ Стикер темы ВКЛЮЧЁН", "✨ Theme sticker ENABLED"],
    ["✨ Стикер темы СКРЫТ", "✨ Theme sticker HIDDEN"],
    ["🖼️ Фоновый арт темы ВКЛЮЧЁН", "🖼️ Theme background art ENABLED"],
    ["🖼️ Фоновый арт темы СКРЫТ", "🖼️ Theme background art HIDDEN"],
    ["🖼️ Свой пользовательский фон установлен!", "🖼️ Custom background image applied!"],
    ["🌟 Живые частицы темы ВКЛЮЧЕНЫ", "🌟 Live theme particles ENABLED"],
    ["🌟 Живые частицы темы ВЫКЛЮЧЕНЫ", "🌟 Live theme particles DISABLED"],
    ["🎵 Звуковое оповещение активно!", "🎵 Sound alert is active!"],
    ["🎵 Загружен свой звук: ", "🎵 Custom sound loaded: "],
    ["🔤 Загружен свой шрифт: ", "🔤 Custom font loaded: "],
    ["🔤 Подключён шрифт: ", "🔤 Font applied: "],
    ["🖐️ Позиция стикера сохранена!", "🖐️ Sticker position saved!"],
    ["📋 Код вашего оформления скопирован в буфер обмена!", "📋 Theme code copied to clipboard!"],
    ["🎨 Оформление из буфера обмена успешно применено!", "🎨 Theme from clipboard applied!"],
    ["❌ В буфере обмена нет кода темы VT Guard", "❌ No VT Guard theme code found in clipboard"],
    ["❌ Не удалось прочитать код темы из буфера обмена", "❌ Could not read theme code from clipboard"],
    ["👁️ Демо-плашка показана на открытой вкладке сайта!", "👁️ Demo card displayed on active webpage!"],
    ["🛡️ Защита снова включена!", "🛡️ Guard resumed!"],
    ["⏸️ Защита поставлена на паузу на ", "⏸️ Guard snoozed for "],
    ["🎚️ Включён пресет защиты: ", "🎚️ Security preset applied: "],
    ["✨ Применён комбо-скин: ", "✨ Skin combo applied: "],
    ["🌟 Применён ваш пресет: ", "🌟 Custom preset applied: "],
    ["💾 Пресет «", "💾 Preset '"],
    ["» сохранён!", "' saved!"],
    ["🗑️ Пресет удалён", "🗑️ Preset deleted"],
    ["🎨 Тема изменена: ", "🎨 Theme changed: "],
    ["🛡️ Стиль иконки: ", "🛡️ Icon style: "],
    ["⏱️ Автоскрытие плашки отключено", "⏱️ Auto-close disabled"],
    ["⏱️ Автоскрытие чистой плашки: через ", "⏱️ Auto-close clean card in "],
    [" сек.", " sec"],
    ["✓ Срок хранения кэша SHA-256: ", "✓ SHA-256 cache retention: "],
    [" дн.", " days"],
    ["⌨️ Назначена комбинация: ", "⌨️ Shortcut assigned: "],
    ["Нажмите клавиши...", "Press shortcut keys..."],
    ["Проверка...", "Verifying..."],
    ["✓ SHA-256 скопирован в буфер обмена", "✓ SHA-256 copied to clipboard"],
    ["✓ SHA-256 скопирован!", "✓ SHA-256 copied!"],
  ];
  for (const [ru, en] of dynPairs) {
    if (s.includes(ru)) s = s.split(ru).join(en);
  }
  return s;
}

let isApplyingLanguagePass = false;
function applyPopupLanguage(lang) {
  if (isApplyingLanguagePass) return;
  isApplyingLanguagePass = true;
  try {
    const isEn = lang === "en";
    currentSettings.uiLang = isEn ? "en" : "ru";

    const quickLangBtn = document.getElementById("quickLangToggleBtn");
    if (quickLangBtn) {
      quickLangBtn.textContent = isEn ? "🇬🇧 EN" : "🇷🇺 RU";
      quickLangBtn.title = isEn ? "Switch language to Russian (Русский)" : "Переключить язык на английский (English)";
    }

    // 1. Быстрый однопроходный перевод текстовых узлов без MutationObserver-зависаний
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let node;
    while ((node = walker.nextNode())) {
      const parentEl = node.parentElement;
      if (!parentEl) continue;
      const parentTag = parentEl.tagName;
      if (parentTag === "SCRIPT" || parentTag === "STYLE") continue;
      if (parentEl.id === "chooseLangRuBtn" || parentEl.id === "chooseLangEnBtn" || parentEl.id === "quickLangToggleBtn") continue;

      const curVal = node.nodeValue || "";
      if (node.__origRu === undefined || /[а-яА-ЯёЁ]/.test(curVal)) {
        node.__origRu = curVal;
      }
      const baseRu = node.__origRu;
      if (!baseRu || !baseRu.trim()) continue;

      let targetVal = baseRu;
      if (isEn) {
        const norm = baseRu.replace(/\s+/g, " ").trim();
        if (POPUP_RU_TO_EN_EXACT[norm]) {
          const lead = baseRu.match(/^\s*/)?.[0] || "";
          const trail = baseRu.match(/\s*$/)?.[0] || "";
          targetVal = lead + POPUP_RU_TO_EN_EXACT[norm] + trail;
        } else {
          targetVal = translateDynamicRuToEn(baseRu);
        }
      }
      if (node.nodeValue !== targetVal) {
        node.nodeValue = targetVal;
      }
    }

    // 2. Перевод атрибутов placeholder, title, label
    document.querySelectorAll("[placeholder], [title], optgroup[label]").forEach((el) => {
      if (el.id === "quickLangToggleBtn") return;
      for (const attr of ["placeholder", "title", "label"]) {
        if (!el.hasAttribute(attr)) continue;
        const propKey = `__origAttr_${attr}`;
        if (el[propKey] === undefined) {
          el[propKey] = el.getAttribute(attr);
        }
        const origVal = el[propKey];
        if (!origVal) continue;
        let nextAttrVal = origVal;
        if (isEn) {
          const norm = origVal.replace(/\s+/g, " ").trim();
          if (POPUP_ATTR_RU_TO_EN[norm]) {
            nextAttrVal = POPUP_ATTR_RU_TO_EN[norm];
          } else if (POPUP_RU_TO_EN_EXACT[norm]) {
            nextAttrVal = POPUP_RU_TO_EN_EXACT[norm];
          } else {
            nextAttrVal = translateDynamicRuToEn(origVal);
          }
        }
        if (el.getAttribute(attr) !== nextAttrVal) {
          el.setAttribute(attr, nextAttrVal);
        }
      }
    });

    // 3. Обновляем подсказки режимов
    updateKeyHint(currentSettings.apiKey);

    const onboardingHintEl = document.getElementById("onboardingLangHintBox");
    if (onboardingHintEl) {
      setSafeHtml(onboardingHintEl, isEn
        ? "💡 <b>In this guide we'll cover step by step:</b> 1) VirusTotal API Key & Autonomous Zero-Key AV Engine; 2) Cloudflare Worker Proxy; 3) Security Presets & Auto-Block; 4) Smart Summary, Adaptive Trust Score & Right Scrollbar; 5) Drag & Drop Scanner & 288+ Formats; 6) Customization (10 themes, stickers, fonts & sounds)."
        : "💡 <b>В обучении мы разберём по порядку:</b> 1) Зачем нужен API-ключ VirusTotal и как работает встроенный автономный антивирус без ключа; 2) Прокси Cloudflare Worker; 3) Пресеты защиты и автоблокировку; 4) Умную сводку, Индекс доверия и правый ползунок прокрутки; 5) Ручной сканер и 288+ форматов; 6) Кастомизацию (10 тем, стикеры, шрифты и звук).");
    }

    const ruBtn = document.getElementById("chooseLangRuBtn");
    const enBtn = document.getElementById("chooseLangEnBtn");
    if (ruBtn && enBtn) {
      ruBtn.classList.toggle("active", !isEn);
      enBtn.classList.toggle("active", isEn);
    }

    const donateTxtEl = document.getElementById("authorDonateText");
    if (donateTxtEl) donateTxtEl.textContent = isEn ? "Donate" : "Донат";
    const donateLinkEl = document.getElementById("authorDonateLink");
    if (donateLinkEl) donateLinkEl.title = isEn ? "Support the developer (DonationAlerts)" : "Поддержать разработчика (DonationAlerts)";
    const certBtnEl = document.getElementById("openAuthorCertModalBtn");
    if (certBtnEl && !certBtnEl.textContent.includes("🚨")) {
      certBtnEl.textContent = isEn ? "🔏 Sign ✓" : "🔏 ЭЦП ✓";
      certBtnEl.title = isEn
        ? "Verify Author's ECDSA P-256 Digital Signature & Build Authenticity"
        : "Проверить криптографическую ЭЦП автора (ECDSA P-256) и подлинность сборки";
    }
    const secretInp = document.getElementById("ownerSecretKeyInput");
    if (secretInp) {
      secretInp.placeholder = isEn
        ? "Paste owner secret key (SP1-LOSOS-OWNER-)..."
        : "Вставьте секретный ключ владельца (SP1-LOSOS-OWNER-)...";
    }
    if (typeof verifyAuthorEcdsaSignature === "function") {
      verifyAuthorEcdsaSignature();
    }

    renderOnboardingStep();
  } finally {
    isApplyingLanguagePass = false;
  }
}


// ==================== MASCOT 6-EXPRESSION SPRITE ENGINE & VISUAL NOVEL TOUR ====================
let vnTypewriterTimer = null;
let vnFullCurrentText = "";
let vnIsTyping = false;
let vnTourIsOpen = false;
const VN_MOOD_ORDER = ["key", "shield", "cloud", "scanner", "radar", "custom"];

const VN_ACCENT_COLORS = {
  key: { hex: "#fbbf24", glow: "rgba(251, 191, 36, 0.38)", icon: "🔑", img: "icons/mascot_key.png" },
  shield: { hex: "#34d399", glow: "rgba(52, 211, 153, 0.38)", icon: "🛡️", img: "icons/mascot_shield.png" },
  cloud: { hex: "#38bdf8", glow: "rgba(56, 189, 248, 0.38)", icon: "☁️", img: "icons/mascot_cloud.png" },
  scanner: { hex: "#c084fc", glow: "rgba(192, 132, 252, 0.38)", icon: "🔎", img: "icons/mascot_scanner.png" },
  radar: { hex: "#f472b6", glow: "rgba(244, 114, 182, 0.38)", icon: "🧠", img: "icons/mascot_radar.png" },
  custom: { hex: "#fb7185", glow: "rgba(251, 113, 133, 0.42)", icon: "🎉", img: "icons/mascot_custom.png" }
};

function getMascotSvgByMood(mood) {
  const info = VN_ACCENT_COLORS[mood] || VN_ACCENT_COLORS.key;
  return `<div style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;border-radius:11px;overflow:hidden;box-shadow:inset 0 0 12px ${info.hex};">
    <img src="${info.img}" alt="Cyber-Salmon Mascot (${mood})" style="width:100%;height:100%;object-fit:cover;display:block;border-radius:11px;" />
    <span style="position:absolute;right:3px;bottom:3px;width:22px;height:22px;border-radius:999px;background:#091326;border:1.5px solid ${info.hex};display:flex;align-items:center;justify-content:center;font-size:12px;box-shadow:0 2px 6px rgba(0,0,0,0.8);">${info.icon}</span>
  </div>`;
}

const VN_TOUR_META = {
  ru: [
    {
      tab: "tabSettings",
      targetSelector: "#vtApiKeyControlsBox",
      focusSelector: "#apiKeyInput",
      mood: "key",
      moodTag: "🔑 КЛЮЧ VT",
      title: "1. Куда вставлять API-ключ VirusTotal?",
      pointerText: "СЮДА: Поле для 64-значного API-ключа VirusTotal (или нажмите «Получить ключ ↗»)",
      actionBtnText: "🔑 Фокус на ключ",
      speech: "Привет! Я Кибер-Лосось, твой гид от автора SalmonPlay1 (LososKiler). Прямо под оранжевой стрелкой — поле для бесплатного ключа с virustotal.com (для проверки по 72 антивирусам). А если ключа нет — расширение отлично работает и БЕЗ него!",
      hint: "💡 Вставь ключ прямо сейчас или нажми «Далее ▶» (или клавишу →)."
    },
    {
      tab: "tabSettings",
      targetSelector: "#zeroKeyControlsBox",
      focusSelector: "#verifyZeroKeyModeBtn",
      mood: "shield",
      moodTag: "🛡️ ЗАЩИТНИК",
      title: "2. Защита БЕЗ ключа и БЕЗ антивируса на ПК",
      pointerText: "СЮДА: Встроенный 6-модульный антивирус (работает без ключа и без АВ на ПК)",
      actionBtnText: "⚡ Тест защиты",
      speech: "Перехожу в боевой режим щита! Даже без API-ключа и без установленного антивируса на ПК наше 6-модульное ядро само проверяет заголовки .exe/.dll, энтропию, архивы .zip/.rar без распаковки и сверяет SHA-256 по базам MalwareBazaar, URLhaus и CIRCL!",
      hint: "💡 Оба режима (API-ключ + Автономный антивирус) работают одновременно!"
    },
    {
      tab: "tabSettings",
      targetSelector: "#proxyUrlInput",
      focusSelector: "#proxyUrlInput",
      mood: "cloud",
      moodTag: "☁️ ОБЛАКО",
      title: "3. Облачный прокси Cloudflare Worker (опционально)",
      pointerText: "СЮДА: Поле Cloudflare Worker URL (общий кэш 72 антивирусов на 7 дней)",
      actionBtnText: "☁️ Фокус на поле",
      speech: "Подключаю облачный терминал! Поле «Cloudflare Worker прокси» нужно, если захочешь развернуть скрипт cloudflare_worker_proxy.js. Прокси чередует ключи и кэширует ответы 72 антивирусов на 7 суток, выдавая результат за 10 мс!",
      hint: "💡 Если используешь личный ключ или автономный режим — оставь поле пустым."
    },
    {
      tab: "tabMain",
      targetSelector: "#securityPresetsRow",
      focusSelector: "#dropZoneBox",
      mood: "scanner",
      moodTag: "🔎 ДЕТЕКТИВ",
      title: "4. Ручной сканер файлов и 4 пресета в 1 клик",
      pointerText: "СЮДА: Выбери режим защиты («Комфорт», «Паранойя», «Геймер» или «Лёгкий»)",
      actionBtnText: "🔎 К сканеру",
      speech: "Вооружаюсь лупой детектива! На главной вкладке можно перетащить любой файл в ручной сканер сверху или выбрать пресет в 1 клик. Режим «🎮 Геймер» не ругается на безопасные игровые фиксы (OnlineFix, Steam_api, моды), но блокирует настоящие стиллеры!",
      hint: "💡 Во время проверки файла также доступна кнопка «⚡ Отменить проверку и сохранить»."
    },
    {
      tab: "tabSettings",
      targetSelector: "#smartSummaryEnabled",
      focusSelector: "#smartSummaryEnabled",
      mood: "radar",
      moodTag: "🧠 ИИ-ГЕНИЙ",
      title: "5. Умная сводка поведения, Доверие и Радар рисков",
      pointerText: "СЮДА: Модули Умной сводки поведения, Индекса доверия (0–100%) и анти-ClickFix",
      actionBtnText: "🧠 Показать",
      speech: "Эврика! Умная сводка простым языком объясняет, на что жалуются антивирусы (опасный стилер паролей или безобидный фикс), считает Индекс доверия 0–100%, строит 5-лучевой Радар рисков и защищает буфер обмена от подмены кошельков и ClickFix!",
      hint: "💡 Загрузки из приложения Discord автоматически перехватываются в мини-окне."
    },
    {
      tab: "tabCustom",
      targetSelector: "#authorCreditsBar",
      focusSelector: "#openAuthorCertModalBtn",
      mood: "custom",
      moodTag: "🎉 ФИНАЛ!",
      title: "6. Кастомизация (10 тем, 6 эмоций маскота) и ссылки автора",
      pointerText: "СЮДА: Подпись автора SalmonPlay1 (LososKiler), кнопка Доната и ЭЦП!",
      actionBtnText: "🔏 Открыть ЭЦП",
      speech: "Ура, мы на финише! Во вкладке «🎨 Кастомизация» тебя ждут 10 тем, мои 6 стикеров-эмоций, звуки и приоритет окон! А в самом низу — подпись автора «by SalmonPlay1 / by LososKiler», кнопка «❤️ Донат» (DonationAlerts) и сертификат «🔏 ЭЦП ✓»!",
      hint: "🎉 Нажми на мой портрет для смены эмоции или нажми «✅ Готово»!"
    }
  ],
  en: [
    {
      tab: "tabSettings",
      targetSelector: "#vtApiKeyControlsBox",
      focusSelector: "#apiKeyInput",
      mood: "key",
      moodTag: "🔑 VT KEY",
      title: "1. Where to paste your VirusTotal API Key",
      pointerText: "HERE: Paste your 64-character VirusTotal API key (or click 'Get key ↗')",
      actionBtnText: "🔑 Focus Key",
      speech: "Hi! I'm Cyber-Salmon, your guide created by author SalmonPlay1 (LososKiler). Right below the orange callout is the box for your free VirusTotal API key (to scan across 72+ cloud engines) — or use our built-in Zero-Key mode without any key!",
      hint: "💡 Paste your key right now or click 'Next ▶' (or press →)."
    },
    {
      tab: "tabSettings",
      targetSelector: "#zeroKeyControlsBox",
      focusSelector: "#verifyZeroKeyModeBtn",
      mood: "shield",
      moodTag: "🛡️ GUARDIAN",
      title: "2. Protection WITHOUT an API Key or PC Antivirus",
      pointerText: "HERE: Built-in 6-Core Antivirus (works without an API key or PC AV)",
      actionBtnText: "⚡ Test Shield",
      speech: " Engaging Guardian Shield mode! Even without a VirusTotal key and even if your PC has NO antivirus installed, our embedded 6-module engine inspects PE headers, entropy, and .zip/.rar archives without unpacking, and checks MalwareBazaar, URLhaus, and CIRCL!",
      hint: "💡 Both modes (VT API Key + Autonomous Core) work great together!"
    },
    {
      tab: "tabSettings",
      targetSelector: "#proxyUrlInput",
      focusSelector: "#proxyUrlInput",
      mood: "cloud",
      moodTag: "☁️ CLOUD",
      title: "3. Cloudflare Worker Shared Proxy (Optional)",
      pointerText: "HERE: Optional Cloudflare Worker URL (7-day global edge cache)",
      actionBtnText: "☁️ Focus Proxy",
      speech: "Connecting to Cloud HUD! Deploy the included cloudflare_worker_proxy.js script to Cloudflare Workers to rotate API keys automatically and cache 72-AV reports at the edge for 7 days — delivering instant 10 ms results!",
      hint: "💡 Leave this blank if you use your personal API key or Autonomous mode."
    },
    {
      tab: "tabMain",
      targetSelector: "#securityPresetsRow",
      focusSelector: "#dropZoneBox",
      mood: "scanner",
      moodTag: "🔎 DETECTIVE",
      title: "4. Manual File Scanner & 1-Click Security Presets",
      pointerText: "HERE: Pick a security preset ('Comfort', 'Paranoid', 'Gamer', or 'Light')",
      actionBtnText: "🔎 To Scanner",
      speech: "Detective lens activated! On the '🏠 Main' tab, drag & drop any file to scan it or pick a 1-click preset. '🎮 Gamer' mode recognizes safe multiplayer fixes (OnlineFix, Steam_api, mods) while strictly blocking real password stealers!",
      hint: "💡 During any active scan, you can also click '⚡ Cancel Scan & Save'."
    },
    {
      tab: "tabSettings",
      targetSelector: "#smartSummaryEnabled",
      focusSelector: "#smartSummaryEnabled",
      mood: "radar",
      moodTag: "🧠 AI GENIUS",
      title: "5. Smart Behavioral Summary, Trust Score & Risk Radar",
      pointerText: "HERE: Smart Summary, 0–100% Trust Score & ClickFix Clipboard Shield",
      actionBtnText: "🧠 Show Modules",
      speech: "Eureka! Smart Summary explains in plain language what antivirus engines flag (a dangerous stealer vs. a harmless game fix), computes a 0–100% Trust Score, draws a 5-Axis Risk Radar, and protects your clipboard from ClickFix and wallet swappers!",
      hint: "💡 Discord desktop app downloads are also intercepted automatically."
    },
    {
      tab: "tabCustom",
      targetSelector: "#authorCreditsBar",
      focusSelector: "#openAuthorCertModalBtn",
      mood: "custom",
      moodTag: "🎉 FINALE!",
      title: "6. Customization (10 Themes, 6 Mascot Poses) & Author Links",
      pointerText: "HERE: Official Author SalmonPlay1 (LososKiler), Donate & Digital Signature!",
      actionBtnText: "🔏 Author Cert",
      speech: "We made it! In '🎨 Customize', personalize 10 animated themes, my 6 mascot expression stickers, sounds, and window priority! At the bottom are the official author badges ('by SalmonPlay1 / by LososKiler'), '❤️ Donate', & '🔏 Sign ✓'!",
      hint: "🎉 Click my portrait to cycle expressions or click '✅ Done'!"
    }
  ]
};

function clearVnSpotlight() {
  document.body.classList.remove("vn-tour-active");
  document.querySelectorAll(".vn-spotlight-target").forEach(el => el.classList.remove("vn-spotlight-target"));
  document.querySelectorAll(".vn-spotlight-subtarget").forEach(el => el.classList.remove("vn-spotlight-subtarget"));
  document.querySelectorAll(".vn-inline-callout").forEach(el => el.remove());
  const vnOverlay = document.getElementById("vnTourOverlay");
  if (vnOverlay) vnOverlay.style.display = "none";
  const avatarBox = document.getElementById("vnMascotAvatarBox");
  if (avatarBox) avatarBox.classList.remove("vn-mascot-talking");
  if (vnTypewriterTimer) {
    clearInterval(vnTypewriterTimer);
    vnTypewriterTimer = null;
  }
}

function startVnTypewriter(text) {
  const txtEl = document.getElementById("vnTypewriterText");
  const curEl = document.getElementById("vnTypewriterCursor");
  const avatarBox = document.getElementById("vnMascotAvatarBox");
  if (!txtEl) return;
  if (vnTypewriterTimer) {
    clearInterval(vnTypewriterTimer);
    vnTypewriterTimer = null;
  }
  vnFullCurrentText = text;
  vnIsTyping = true;
  txtEl.textContent = "";
  if (curEl) curEl.style.display = "inline-block";
  if (avatarBox) avatarBox.classList.add("vn-mascot-talking");

  let pos = 0;
  vnTypewriterTimer = setInterval(() => {
    if (pos < vnFullCurrentText.length) {
      txtEl.textContent += vnFullCurrentText.charAt(pos);
      pos++;
    } else {
      clearInterval(vnTypewriterTimer);
      vnTypewriterTimer = null;
      vnIsTyping = false;
      if (avatarBox) avatarBox.classList.remove("vn-mascot-talking");
    }
  }, 11);
}

function finishVnTypewriterImmediately() {
  if (!vnIsTyping) return false;
  if (vnTypewriterTimer) {
    clearInterval(vnTypewriterTimer);
    vnTypewriterTimer = null;
  }
  vnIsTyping = false;
  const txtEl = document.getElementById("vnTypewriterText");
  if (txtEl) txtEl.textContent = vnFullCurrentText;
  const avatarBox = document.getElementById("vnMascotAvatarBox");
  if (avatarBox) avatarBox.classList.remove("vn-mascot-talking");
  return true;
}

function insertInlineCalloutAndScroll(targetEl, spotCard, pointerText) {
  document.querySelectorAll(".vn-inline-callout").forEach(el => el.remove());
  if (!targetEl) return;

  let insertAnchor = targetEl;
  let highlightTarget = targetEl;
  if (targetEl.id === "vtApiKeyControlsBox" && spotCard) {
    insertAnchor = spotCard.firstElementChild || targetEl;
    highlightTarget = document.getElementById("apiKeyInput") || targetEl;
  } else if (targetEl.id === "zeroKeyControlsBox" && spotCard) {
    insertAnchor = spotCard.firstElementChild || targetEl;
    highlightTarget = targetEl;
  } else if (targetEl.id === "securityPresetsRow" && spotCard) {
    insertAnchor = spotCard.firstElementChild || targetEl;
    highlightTarget = targetEl;
  } else if (targetEl.id === "smartSummaryEnabled" && targetEl.closest("label")) {
    insertAnchor = (spotCard && spotCard.firstElementChild) ? spotCard.firstElementChild : targetEl.closest("label");
    highlightTarget = targetEl.closest("label");
  } else if (targetEl.id === "proxyUrlInput" && targetEl.parentElement) {
    insertAnchor = targetEl.parentElement;
    highlightTarget = targetEl;
  }

  const callout = document.createElement("div");
  callout.className = "vn-inline-callout";
  const arrowSpan = document.createElement("span");
  arrowSpan.className = "vn-inline-callout-arrow";
  arrowSpan.textContent = "👇";
  const textSpan = document.createElement("span");
  textSpan.textContent = pointerText;
  callout.appendChild(arrowSpan);
  callout.appendChild(textSpan);

  if (insertAnchor.parentNode) {
    insertAnchor.parentNode.insertBefore(callout, insertAnchor);
  }

  if (highlightTarget) {
    highlightTarget.classList.add("vn-spotlight-subtarget");
  }

  setTimeout(() => {
    callout.scrollIntoView({ behavior: "smooth", block: "start" });
  }, 35);
}

function renderOnboardingStep() {
  const modal = document.getElementById("onboardingModal");
  const vnOverlay = document.getElementById("vnTourOverlay");
  const isEn = currentSettings.uiLang === "en";
  const vnSteps = VN_TOUR_META[isEn ? "en" : "ru"];
  const langScreen = document.getElementById("onboardingLangScreen");
  const stepsScreen = document.getElementById("onboardingStepsScreen");
  const badgeEl = document.getElementById("onboardingStepBadge");

  // Step 0: Language Selection Screen with bilingual Mascot greeting
  if (currentOnboardingStep <= 0) {
    clearVnSpotlight();
    if (!modal || modal.style.display === "none") return;
    if (langScreen) langScreen.style.display = "block";
    if (stepsScreen) stepsScreen.style.display = "none";
    if (badgeEl) badgeEl.textContent = isEn ? "🌐 Language Selection • Visual Novel Guide" : "🌐 Выбор языка • Обучение с Маскотом";
    const welcomeTitle = document.getElementById("onboardingWelcomeTitle");
    if (welcomeTitle) {
      let wrap = welcomeTitle.parentNode.querySelector(".vn-welcome-mascot");
      if (!wrap) {
        wrap = document.createElement("div");
        wrap.className = "vn-welcome-mascot";
        wrap.style.cssText = "display:flex;align-items:center;gap:10px;margin-bottom:8px;padding:7px 10px;border-radius:10px;background:linear-gradient(135deg,rgba(2,132,199,0.18),rgba(15,23,42,0.9));border:1px solid rgba(56,189,248,0.45);";
        welcomeTitle.parentNode.insertBefore(wrap, welcomeTitle);
      }
      const mascotIntroTitle = isEn
        ? "🐟 Cyber-Salmon (6 Dynamic Expressions • Author SalmonPlay1 / LososKiler):"
        : "🐟 Кибер-Лосось (6 живых эмоций • Гид от автора SalmonPlay1 / LososKiler):";
      const mascotIntroSub = isEn
        ? "“Hi! Pick your language below — I'll change my pose on every step and point directly to the API Key box and controls!”"
        : "«Привет! Выбери язык ниже — на каждом шаге я буду менять позу и эмоцию и прямо в окне покажу, куда вставлять ключ!»";
      setSafeHtml(wrap, `<div style="width:56px;height:56px;flex-shrink:0;">${getMascotSvgByMood("key")}</div><div style="font-size:11px;line-height:1.35;color:#e2e8f0;"><b>${mascotIntroTitle}</b><br/>${mascotIntroSub}</div>`);
    }
    return;
  }

  // Steps 1..6: Zero-Overlap Visual Novel Spotlight over live extension UI
  // Only render if the tutorial is actively open (prevents language switch button from reopening the last step after finishing!)
  if (!vnTourIsOpen) {
    clearVnSpotlight();
    return;
  }
  if (modal) modal.style.display = "none";
  if (!vnOverlay) return;
  vnOverlay.style.display = "block";
  document.body.classList.add("vn-tour-active");

  const idx = Math.min(vnSteps.length - 1, Math.max(0, currentOnboardingStep - 1));
  const vnObj = vnSteps[idx] || vnSteps[0];
  const accentInfo = VN_ACCENT_COLORS[vnObj.mood] || VN_ACCENT_COLORS.key;

  // Apply dynamic mood color to the Visual Novel Dock
  vnOverlay.style.setProperty("--vn-accent", accentInfo.hex);
  vnOverlay.style.setProperty("--vn-accent-glow", accentInfo.glow);

  const progBar = document.getElementById("vnTopProgressBar");
  if (progBar) {
    progBar.style.width = `${Math.round(((idx + 1) / vnSteps.length) * 100)}%`;
  }

  // 1. Switch to target tab
  if (vnObj.tab) {
    document.querySelectorAll(".main-tab-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.tab === vnObj.tab);
    });
    document.querySelectorAll(".tab-pane").forEach(p => {
      p.classList.toggle("active", p.id === vnObj.tab);
    });
  }

  // 2. Highlight target card & insert inline non-overlapping callout banner right above the target element
  document.querySelectorAll(".vn-spotlight-target").forEach(el => el.classList.remove("vn-spotlight-target"));
  document.querySelectorAll(".vn-spotlight-subtarget").forEach(el => el.classList.remove("vn-spotlight-subtarget"));

  const targetEl = document.querySelector(vnObj.targetSelector);
  const focusEl = document.querySelector(vnObj.focusSelector) || targetEl;
  const spotCard = targetEl ? (targetEl.closest("section.card") || targetEl.closest("footer") || targetEl) : null;

  if (spotCard) {
    spotCard.classList.add("vn-spotlight-target");
  }

  insertInlineCalloutAndScroll(targetEl, spotCard, vnObj.pointerText);

  // 3. Populate Visual Novel UI with unique Mascot Expression Sprite & pop animation
  const moodTagEl = document.getElementById("vnMascotMoodTag");
  if (moodTagEl) moodTagEl.textContent = vnObj.moodTag;

  const avatarBox = document.getElementById("vnMascotAvatarBox");
  if (avatarBox) {
    avatarBox.dataset.currentMood = vnObj.mood;
    setSafeHtml(avatarBox, getMascotSvgByMood(vnObj.mood));
    avatarBox.classList.remove("vn-mascot-pop");
    void avatarBox.offsetWidth;
    avatarBox.classList.add("vn-mascot-pop");
  }

  const speakerEl = document.getElementById("vnSpeakerName");
  if (speakerEl) {
    speakerEl.textContent = isEn
      ? "🐟 Cyber-Salmon • Guide by SalmonPlay1 (LososKiler)"
      : "🐟 Кибер-Лосось • Гид SalmonPlay1 (LososKiler)";
  }

  const counterEl = document.getElementById("vnStepCounter");
  if (counterEl) {
    counterEl.textContent = isEn
      ? `Step ${idx + 1} / ${vnSteps.length}`
      : `Шаг ${idx + 1} / ${vnSteps.length}`;
  }

  const titleBox = document.getElementById("vnStepTitleBox");
  if (titleBox) titleBox.textContent = vnObj.title;

  const hintChip = document.getElementById("vnHintChip");
  if (hintChip) hintChip.textContent = vnObj.hint;

  startVnTypewriter(vnObj.speech);

  const dotsRow = document.getElementById("vnDotsRow");
  if (dotsRow) {
    setSafeHtml(dotsRow, vnSteps.map((_, i) => `<span class="onboarding-dot ${i === idx ? "active" : ""}"></span>`).join(""));
  }

  const actionBtn = document.getElementById("vnActionFocusBtn");
  if (actionBtn) {
    actionBtn.style.display = "inline-block";
    actionBtn.textContent = vnObj.actionBtnText;
    actionBtn.onclick = () => {
      if (idx === 5) {
        const certBtn = document.getElementById("openAuthorCertModalBtn");
        if (certBtn) certBtn.click();
        const modalEl = document.getElementById("authorCertModal");
        if (modalEl) setTimeout(() => modalEl.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
      } else if (idx === 1) {
        const verifyBtn = document.getElementById("verifyZeroKeyModeBtn");
        if (verifyBtn) verifyBtn.click();
      } else if (focusEl) {
        const calloutEl = document.querySelector(".vn-inline-callout") || focusEl;
        calloutEl.scrollIntoView({ behavior: "smooth", block: "start" });
        if (typeof focusEl.focus === "function") focusEl.focus();
      }
    };
  }

  const nextBtn = document.getElementById("vnNextStepBtn");
  if (nextBtn) {
    nextBtn.textContent = idx === vnSteps.length - 1
      ? (isEn ? "✅ Done" : "✅ Готово")
      : (isEn ? "Next ▶" : "Далее ▶");
  }
  const prevBtn = document.getElementById("vnPrevStepBtn");
  if (prevBtn) {
    prevBtn.textContent = isEn ? "◀ Back" : "◀ Назад";
  }
  const skipBtn = document.getElementById("vnSkipTourBtn");
  if (skipBtn) {
    skipBtn.textContent = isEn ? "✕ Skip" : "✕ Скип";
  }
}

function openOnboardingModal(startAtLangScreen = true) {
  const modal = document.getElementById("onboardingModal");
  if (!modal) return;
  clearVnSpotlight();
  currentOnboardingStep = startAtLangScreen ? 0 : 1;
  vnTourIsOpen = !startAtLangScreen;
  if (currentOnboardingStep === 0) {
    modal.style.display = "flex";
  }
  applyPopupLanguage(currentSettings.uiLang || "ru");
  renderOnboardingStep();
}

function closeAndCompleteOnboarding() {
  vnTourIsOpen = false;
  currentOnboardingStep = 0;
  clearVnSpotlight();
  const modal = document.getElementById("onboardingModal");
  if (modal) modal.style.display = "none";
  currentSettings.tutorialCompleted = true;
  saveSettings();
  flashSaved(currentSettings.uiLang === "en" ? "✓ Guide completed! You can replay it anytime at the bottom." : "✓ Обучение с Кибер-Лососем завершено — можно повторить кнопкой внизу!");
}

function initV30LanguageAndTutorial() {






  const hybMainToggle = document.getElementById("hybridProtectionMainToggle");
  const hybSettingsToggle = document.getElementById("hybridProtectionEnabled");
  const autoNoAvMainToggle = document.getElementById("autonomousNoAvMainToggle");
  const autoNoAvSettingsToggle = document.getElementById("autonomousNoAvCoreEnabled");
  const verifyHybridBtnEl = document.getElementById("verifyHybridBtn");

  const applyHybridChange = async (checkedVal) => {
    const isEn = currentSettings.uiLang === "en";
    currentSettings.hybridProtectionEnabled = Boolean(checkedVal);
    if (currentSettings.hybridProtectionEnabled) {
      currentSettings.vtApiKeyModeEnabled = true;
      currentSettings.zeroKeyAndPcAvModeEnabled = true;
      currentSettings.autonomousNoAvCoreEnabled = true;
      const vtEl = document.getElementById("vtApiKeyModeEnabled");
      const zkEl = document.getElementById("zeroKeyAndPcAvModeEnabled");
      if (vtEl) vtEl.checked = true;
      if (zkEl) zkEl.checked = true;
    }
    updateKeyHint(currentSettings.apiKey);
    await safeStorageSet({
      hybridProtectionEnabled: currentSettings.hybridProtectionEnabled,
      vtApiKeyModeEnabled: currentSettings.vtApiKeyModeEnabled,
      zeroKeyAndPcAvModeEnabled: currentSettings.zeroKeyAndPcAvModeEnabled,
      autonomousNoAvCoreEnabled: currentSettings.autonomousNoAvCoreEnabled
    });
    saveSettingsImmediate();
    flashSaved(
      currentSettings.hybridProtectionEnabled
        ? (isEn ? "⚡ Hybrid Protection (API + Autonomous No-PC-AV) ENABLED" : "⚡ Гибридная защита (API-ключ + Автономная без АВ на ПК) ВКЛЮЧЕНА")
        : (isEn ? "⏸️ Hybrid Protection DISABLED" : "⏸️ Гибридная защита ВЫКЛЮЧЕНА")
    );
  };

  if (hybMainToggle && !hybMainToggle.__vtBound) {
    hybMainToggle.__vtBound = true;
    hybMainToggle.checked = currentSettings.hybridProtectionEnabled !== false;
    hybMainToggle.addEventListener("change", () => applyHybridChange(hybMainToggle.checked));
  }
  if (hybSettingsToggle && !hybSettingsToggle.__vtBound) {
    hybSettingsToggle.__vtBound = true;
    hybSettingsToggle.checked = currentSettings.hybridProtectionEnabled !== false;
    hybSettingsToggle.addEventListener("change", () => applyHybridChange(hybSettingsToggle.checked));
  }

  const applyAutoNoAvChange = async (checkedVal) => {
    const isEn = currentSettings.uiLang === "en";
    currentSettings.autonomousNoAvCoreEnabled = Boolean(checkedVal);
    if (currentSettings.autonomousNoAvCoreEnabled) {
      currentSettings.zeroKeyAndPcAvModeEnabled = true;
      const zkEl = document.getElementById("zeroKeyAndPcAvModeEnabled");
      if (zkEl) zkEl.checked = true;
    }
    updateKeyHint(currentSettings.apiKey);
    await safeStorageSet({
      autonomousNoAvCoreEnabled: currentSettings.autonomousNoAvCoreEnabled,
      zeroKeyAndPcAvModeEnabled: currentSettings.zeroKeyAndPcAvModeEnabled
    });
    saveSettingsImmediate();
    flashSaved(
      currentSettings.autonomousNoAvCoreEnabled
        ? (isEn ? "🧬 Autonomous Scan (No API key & No PC AV) ENABLED" : "🧬 Автономная проверка (без API-ключа и без антивируса на ПК) ВКЛЮЧЕНА")
        : (isEn ? "⏸️ Autonomous No-PC-AV Core DISABLED" : "⏸️ Автономная проверка без антивируса на ПК ВЫКЛЮЧЕНА")
    );
  };

  if (autoNoAvMainToggle && !autoNoAvMainToggle.__vtBound) {
    autoNoAvMainToggle.__vtBound = true;
    autoNoAvMainToggle.checked = currentSettings.autonomousNoAvCoreEnabled !== false;
    autoNoAvMainToggle.addEventListener("change", () => applyAutoNoAvChange(autoNoAvMainToggle.checked));
  }
  if (autoNoAvSettingsToggle && !autoNoAvSettingsToggle.__vtBound) {
    autoNoAvSettingsToggle.__vtBound = true;
    autoNoAvSettingsToggle.checked = currentSettings.autonomousNoAvCoreEnabled !== false;
    autoNoAvSettingsToggle.addEventListener("change", () => applyAutoNoAvChange(autoNoAvSettingsToggle.checked));
  }

  if (verifyHybridBtnEl && !verifyHybridBtnEl.__vtBound) {
    verifyHybridBtnEl.__vtBound = true;
    verifyHybridBtnEl.addEventListener("click", () => {
      const isEn = currentSettings.uiLang === "en";
      verifyHybridBtnEl.disabled = true;
      verifyHybridBtnEl.textContent = isEn ? "Testing..." : "Тест...";
      chrome.runtime.sendMessage({ type: "VT_VERIFY_HYBRID_PROTECTION" }, (res) => {
        verifyHybridBtnEl.disabled = false;
        verifyHybridBtnEl.textContent = isEn ? "Test" : "Тест";
        const hybMsg = document.getElementById("hybridValidationMsg");
        if (hybMsg && res) {
          hybMsg.className = "key-msg ok";
          hybMsg.style.color = "";
          hybMsg.textContent = isEn ? (res.messageEn || res.message) : (res.message || "✓ Гибридная защита работает исправно!");
        }
        flashSaved(isEn ? "✓ Hybrid Protection verified!" : "✓ Гибридная защита (API + Автономное ядро без АВ) проверена!");
      });
    });
  }

  const vtApiKeyModeToggle = document.getElementById("vtApiKeyModeEnabled");
  if (vtApiKeyModeToggle) {
    vtApiKeyModeToggle.checked = currentSettings.vtApiKeyModeEnabled !== false;
    vtApiKeyModeToggle.addEventListener("change", async () => {
      currentSettings.vtApiKeyModeEnabled = Boolean(vtApiKeyModeToggle.checked);
      updateKeyHint(currentSettings.apiKey);
      await safeStorageSet({ vtApiKeyModeEnabled: currentSettings.vtApiKeyModeEnabled });
      saveSettingsImmediate();
      flashSaved(
        vtApiKeyModeToggle.checked
          ? (currentSettings.uiLang === "en" ? "🔑 VirusTotal API Key mode ENABLED" : "🔑 Проверка по API-ключу VirusTotal ВКЛЮЧЕНА")
          : (currentSettings.uiLang === "en" ? "⏸️ VirusTotal API Key mode DISABLED" : "⏸️ Проверка по API-ключу VirusTotal ВЫКЛЮЧЕНА")
      );
    });
  }

  const zeroKeyModeToggle = document.getElementById("zeroKeyAndPcAvModeEnabled");
  if (zeroKeyModeToggle) {
    zeroKeyModeToggle.checked = currentSettings.zeroKeyAndPcAvModeEnabled !== false;
    zeroKeyModeToggle.addEventListener("change", async () => {
      currentSettings.zeroKeyAndPcAvModeEnabled = Boolean(zeroKeyModeToggle.checked);
      updateKeyHint(currentSettings.apiKey);
      await safeStorageSet({ zeroKeyAndPcAvModeEnabled: currentSettings.zeroKeyAndPcAvModeEnabled });
      saveSettingsImmediate();
      flashSaved(
        zeroKeyModeToggle.checked
          ? (currentSettings.uiLang === "en" ? "🚀 Zero-Key & PC Antivirus mode ENABLED" : "🚀 Режим БЕЗ API-ключа (Антивирус ПК + Zero-Key) ВКЛЮЧЁН")
          : (currentSettings.uiLang === "en" ? "⏸️ Zero-Key & PC Antivirus mode DISABLED" : "⏸️ Режим БЕЗ API-ключа (Антивирус ПК + Zero-Key) ВЫКЛЮЧЕН")
      );
    });
  }

  const verifyZeroKeyBtn = document.getElementById("verifyZeroKeyModeBtn");
  const zeroKeyValidationMsg = document.getElementById("zeroKeyValidationMsg");
  if (verifyZeroKeyBtn && zeroKeyValidationMsg) {
    verifyZeroKeyBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const isEn = currentSettings.uiLang === "en";
      verifyZeroKeyBtn.disabled = true;
      verifyZeroKeyBtn.textContent = isEn ? "Testing..." : "Проверка...";
      chrome.runtime.sendMessage({ type: "VT_VERIFY_ZERO_KEY_PC_AV" }, (res) => {
        verifyZeroKeyBtn.disabled = false;
        verifyZeroKeyBtn.textContent = isEn ? "Verify" : "Проверить";
        if (res && res.ok) {
          zeroKeyValidationMsg.className = "key-msg ok";
          const dualNote = (currentSettings.vtApiKeyModeEnabled !== false && /^[a-f0-9]{64}$/i.test(currentSettings.apiKey || ""))
            ? (isEn ? " + Combined with VT API Key!" : " + Работает совместно с вашим ключом VT!")
            : "";
          zeroKeyValidationMsg.textContent = isEn
            ? `✅ Verified! ${res.avName} + Local Signature Shield + MalwareBazaar/CIRCL feeds are active (${res.latencyMs} ms)${dualNote}`
            : `✅ Проверка успешна! ${res.avName} + Локальный сигнатурный щит + базы MalwareBazaar/CIRCL активны (${res.latencyMs} мс)${dualNote}`;
        } else {
          zeroKeyValidationMsg.className = "key-msg err";
          zeroKeyValidationMsg.textContent = isEn
            ? "❌ Verification failed."
            : "❌ Ошибка самопроверки модуля.";
        }
      });
    });
  }

const localPcAntivirusEnabledEl = document.getElementById("localPcAntivirusEnabled");
if (localPcAntivirusEnabledEl) {
  localPcAntivirusEnabledEl.checked = currentSettings.localPcAntivirusEnabled !== false;
  localPcAntivirusEnabledEl.addEventListener("change", () => {
    currentSettings.localPcAntivirusEnabled = Boolean(localPcAntivirusEnabledEl.checked);
    safeStorageSet({ localPcAntivirusEnabled: currentSettings.localPcAntivirusEnabled });
    saveSettingsImmediate();
    flashSaved(
      localPcAntivirusEnabledEl.checked
        ? (currentSettings.uiLang === "en" ? "💻 Local PC Antivirus scan ENABLED" : "💻 Проверка встроенным антивирусом ПК ВКЛЮЧЕНА")
        : (currentSettings.uiLang === "en" ? "💻 Local PC Antivirus scan DISABLED" : "💻 Проверка встроенным антивирусом ПК ВЫКЛЮЧЕНА")
    );
  });
}

  const keepScanToggle = document.getElementById("keepScanOnTabCloseToggle");
  if (keepScanToggle) {
    keepScanToggle.checked = currentSettings.keepScanOnTabClose !== false;
    keepScanToggle.addEventListener("change", () => {
      currentSettings.keepScanOnTabClose = keepScanToggle.checked;
      saveSettings();
      flashSaved(
        keepScanToggle.checked
          ? (currentSettings.uiLang === "en" ? "📌 Scan window will stay open when tab closes" : "📌 Окно проверки будет оставаться при закрытии вкладки")
          : (currentSettings.uiLang === "en" ? "✕ Scan window will auto-close with tab" : "✕ Включено автозакрытие окна проверки вместе с вкладкой")
      );
    });
  }

  // Если окно открыто как автономное окно проверки после закрытия вкладки (?standalone_scan=...)
  const urlParams = new URLSearchParams(window.location.search);
  const standaloneScanId = urlParams.get("standalone_scan");
  const standaloneViewParam = urlParams.get("view");
  if (standaloneScanId) {
    const onboardingEl = document.getElementById("onboardingModal");
    if (onboardingEl) onboardingEl.style.display = "none";
    document.querySelectorAll(".main-tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === "tabMain"));
    document.querySelectorAll(".tab-pane").forEach(p => p.classList.toggle("active", p.id === "tabMain"));

    // Если в Кастомизации выбрано «Само окно вывода проверки поверх» (card_on_top), скрываем лишние вкладки настроек и показываем ТОЛЬКО чистую карточку проверки (с кнопкой «⚙️ Открыть расширение»)!
    const preferCardOnly = (standaloneViewParam === "card") || (currentSettings.scanWindowDisplayMode || "card_on_top") === "card_on_top";
    if (preferCardOnly) {
      document.title = "VT Download Guard — Вывод проверки";
      const toHide = document.querySelectorAll(".header, .main-tabs, .lifetime-stats-bar, .footer, #tabMain > section.card");
      toHide.forEach((el) => {
        if (manualResultBox && el.contains(manualResultBox)) {
          Array.from(el.children).forEach(ch => {
            if (ch !== manualResultBox) ch.style.display = "none";
          });
          el.style.padding = "0";
          el.style.border = "none";
          el.style.background = "transparent";
        } else {
          el.style.display = "none";
        }
      });
      const switchBar = document.createElement("div");
      switchBar.style.cssText = "display:flex;justify-content:flex-end;margin-bottom:6px;";
      const showExtBtn = document.createElement("button");
      showExtBtn.type = "button";
      showExtBtn.className = "mini-btn accent";
      showExtBtn.textContent = currentSettings.uiLang === "en" ? "🛡️ Show Full Extension UI" : "🛡️ Показать окно с расширением";
      showExtBtn.addEventListener("click", () => {
        toHide.forEach((el) => {
          el.style.display = "";
          if (manualResultBox && el.contains(manualResultBox)) {
            Array.from(el.children).forEach(ch => { ch.style.display = ""; });
            el.style.padding = "";
            el.style.border = "";
            el.style.background = "";
          }
        });
        switchBar.remove();
      });
      switchBar.appendChild(showExtBtn);
      if (manualResultBox && manualResultBox.parentNode) {
        manualResultBox.parentNode.insertBefore(switchBar, manualResultBox);
      }
    }
    if (manualResultBox) {
      manualResultBox.style.display = "block";
      manualResultBox.scrollIntoView({ behavior: "smooth", block: "start" });
      chrome.runtime.sendMessage({ type: "VT_GET_STANDALONE_SCAN", scanId: standaloneScanId }, (res) => {
        if (res && res.ok && res.payload) {
          renderFullScanCardInPopup(manualResultBox, res.payload, true);
        }
      });
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg?.type === "VT_STANDALONE_SCAN_UPDATE" && msg.payload?.scanId === standaloneScanId) {
          renderFullScanCardInPopup(manualResultBox, msg.payload, true);
        }
      });
    }
  }

  applyPopupLanguage(currentSettings.uiLang || "ru");
  setTimeout(() => {
    if (currentSettings.uiLang === "en") applyPopupLanguage("en");
  }, 150);

  const chooseRu = document.getElementById("chooseLangRuBtn");
  const chooseEn = document.getElementById("chooseLangEnBtn");
  if (chooseRu) {
    chooseRu.addEventListener("click", () => {
      applyPopupLanguage("ru");
      saveSettings();
    });
  }
  if (chooseEn) {
    chooseEn.addEventListener("click", () => {
      applyPopupLanguage("en");
      saveSettings();
    });
  }

  const quickLangBtn = document.getElementById("quickLangToggleBtn");
  if (quickLangBtn) {
    quickLangBtn.addEventListener("click", () => {
      const nextLang = currentSettings.uiLang === "en" ? "ru" : "en";
      applyPopupLanguage(nextLang);
      saveSettings();
      flashSaved(nextLang === "en" ? "🇬🇧 Language switched to English" : "🇷🇺 Язык переключён на Русский");
    });
  }

  const footerLangBtn = document.getElementById("footerLangSwitchBtn");
  if (footerLangBtn) {
    footerLangBtn.addEventListener("click", () => {
      openOnboardingModal(true);
    });
  }

  const replayBtn = document.getElementById("replayTutorialBtn");
  if (replayBtn) {
    replayBtn.addEventListener("click", () => {
      openOnboardingModal(true);
    });
  }

  const skipTopBtn = document.getElementById("onboardingSkipTopBtn");
  const skipStartBtn = document.getElementById("onboardingSkipStartBtn");
  const skipBottomBtn = document.getElementById("onboardingSkipBottomBtn");
  [skipTopBtn, skipStartBtn, skipBottomBtn].forEach(btn => {
    if (btn) btn.addEventListener("click", closeAndCompleteOnboarding);
  });

  const startGuideBtn = document.getElementById("onboardingStartGuideBtn");
  if (startGuideBtn) {
    startGuideBtn.addEventListener("click", () => {
      vnTourIsOpen = true;
      currentOnboardingStep = 1;
      renderOnboardingStep();
    });
  }

  const prevBtn = document.getElementById("onboardingPrevBtn");
  if (prevBtn) {
    prevBtn.addEventListener("click", () => {
      currentOnboardingStep = Math.max(0, currentOnboardingStep - 1);
      renderOnboardingStep();
    });
  }

  const nextBtn = document.getElementById("onboardingNextBtn");
  if (nextBtn) {
    nextBtn.addEventListener("click", () => {
      const totalSteps = TUTORIAL_STEPS_DATA.ru.length;
      if (currentOnboardingStep >= totalSteps) {
        // Возвращаем на главную вкладку после завершения
        document.querySelectorAll(".main-tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === "tabMain"));
        document.querySelectorAll(".tab-pane").forEach(p => p.classList.toggle("active", p.id === "tabMain"));
        closeAndCompleteOnboarding();
      } else {
        currentOnboardingStep++;
        renderOnboardingStep();
      }
    });
  }

  const vnPrevBtn = document.getElementById("vnPrevStepBtn");
  if (vnPrevBtn && !vnPrevBtn.__vtBound) {
    vnPrevBtn.__vtBound = true;
    vnPrevBtn.addEventListener("click", () => {
      if (currentOnboardingStep <= 1) {
        openOnboardingModal(true);
      } else {
        currentOnboardingStep--;
        renderOnboardingStep();
      }
    });
  }

  const vnNextBtn = document.getElementById("vnNextStepBtn");
  if (vnNextBtn && !vnNextBtn.__vtBound) {
    vnNextBtn.__vtBound = true;
    vnNextBtn.addEventListener("click", () => {
      if (finishVnTypewriterImmediately()) return;
      const totalSteps = VN_TOUR_META.ru.length;
      if (currentOnboardingStep >= totalSteps) {
        document.querySelectorAll(".main-tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === "tabMain"));
        document.querySelectorAll(".tab-pane").forEach(p => p.classList.toggle("active", p.id === "tabMain"));
        closeAndCompleteOnboarding();
      } else {
        currentOnboardingStep++;
        renderOnboardingStep();
      }
    });
  }

  const vnSkipBtn = document.getElementById("vnSkipTourBtn");
  if (vnSkipBtn && !vnSkipBtn.__vtBound) {
    vnSkipBtn.__vtBound = true;
    vnSkipBtn.addEventListener("click", closeAndCompleteOnboarding);
  }

    const vnAvatarEl = document.getElementById("vnMascotAvatarBox");
  if (vnAvatarEl && !vnAvatarEl.__vtBound) {
    vnAvatarEl.__vtBound = true;
    vnAvatarEl.addEventListener("click", () => {
      const curMood = vnAvatarEl.dataset.currentMood || "key";
      const nextMood = VN_MOOD_ORDER[(VN_MOOD_ORDER.indexOf(curMood) + 1) % VN_MOOD_ORDER.length];
      vnAvatarEl.dataset.currentMood = nextMood;
      const info = VN_ACCENT_COLORS[nextMood] || VN_ACCENT_COLORS.key;
      const vnOverlay = document.getElementById("vnTourOverlay");
      if (vnOverlay) {
        vnOverlay.style.setProperty("--vn-accent", info.hex);
        vnOverlay.style.setProperty("--vn-accent-glow", info.glow);
      }
      setSafeHtml(vnAvatarEl, getMascotSvgByMood(nextMood));
      vnAvatarEl.classList.remove("vn-mascot-pop");
      void vnAvatarEl.offsetWidth;
      vnAvatarEl.classList.add("vn-mascot-pop");
    });
  }

  if (!window.__vtVnKeyNavBound) {
    window.__vtVnKeyNavBound = true;
    window.addEventListener("keydown", (e) => {
      const vnOverlay = document.getElementById("vnTourOverlay");
      if (!vnOverlay || vnOverlay.style.display === "none") return;
      if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) return;
      if (e.key === "ArrowRight" || e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        if (vnNextBtn) vnNextBtn.click();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        if (vnPrevBtn) vnPrevBtn.click();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeAndCompleteOnboarding();
      }
    });
  }

  const vnTypeBox = document.getElementById("vnTypewriterBox");
  if (vnTypeBox && !vnTypeBox.__vtBound) {
    vnTypeBox.__vtBound = true;
    vnTypeBox.addEventListener("click", () => {
      if (!finishVnTypewriterImmediately()) {
        if (vnNextBtn) vnNextBtn.click();
      }
    });
  }

  // Если пользователь открыл расширение впервые (tutorialCompleted === false) — сразу показываем выбор языка и обучение!
  if (!currentSettings.tutorialCompleted) {
    openOnboardingModal(true);
  }
}


// ==================== 🔏 КРИПТОГРАФИЧЕСКАЯ ЭЦП АВТОРА И ЗАЩИТА ОТ ПОДДЕЛКИ (ECDSA P-256) ====================
const VT_AUTHOR_CRYPTO_CERT = {
  authors: "SalmonPlay1 & LososKiler",
  leftCredit: "by SalmonPlay1",
  rightCredit: "by LososKiler",
  donateUrl: "https://www.donationalerts.com/r/salmonplay1",
  geckoId: "vt-download-guard@salmonplay1.lososkiler",
  fingerprint: "SP1-LK-0810-4BFB-3631-A818-6228-82C2-8C9A-1C4D",
  publicKeySpkiB64: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE0kjpd0ZOrQDe2dfbzaRS1GQTqgP5wXTkT1xn83C3e/j3wpXA/Y9xs8bzvFou5kB9bxcD3cFKfEOKMhC+8MrFxg==",
  signatureB64: "ZBH5iPuNse5MmtYOQMfd7GSKuwDstsCjHE+WvI/XV0YkLT/n2Sn1KmVSbih04alFrzCowNObxjHqPRVgiSL46g==",
  ownerSecretSha256: "7aa860fd92af31b707023e5851d720a42df2f66e2b1ad3eb37ea0f0a19a6bd95"
};

function b64ToUint8Array(b64) {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}

async function verifyAuthorEcdsaSignature() {
  try {
    const leftEl = document.getElementById("authorCreditLeft");
    const rightEl = document.getElementById("authorCreditRight");
    const donateEl = document.getElementById("authorDonateLink");
    const donateTxtEl = document.getElementById("authorDonateText");
    if (donateTxtEl) {
      donateTxtEl.textContent = currentSettings?.uiLang === "en" ? "Donate" : "Донат";
    }
    const leftTxt = (leftEl ? leftEl.textContent : "").trim();
    const rightTxt = (rightEl ? rightEl.textContent : "").trim();
    const donateHref = donateEl ? (donateEl.getAttribute("href") || "").trim() : "";
    const manifestObj = chrome.runtime?.getManifest ? chrome.runtime.getManifest() : { author: "SalmonPlay1 & LososKiler" };
    const manifestAuthor = String(manifestObj.author || "SalmonPlay1 & LososKiler").trim();

    if (leftEl) { leftEl.style.display = "inline-flex"; leftEl.style.visibility = "visible"; leftEl.style.opacity = "1"; }
    if (rightEl) { rightEl.style.display = "inline-flex"; rightEl.style.visibility = "visible"; rightEl.style.opacity = "1"; }
    if (donateEl) { donateEl.style.display = "inline-flex"; donateEl.style.visibility = "visible"; donateEl.style.opacity = "1"; }

    const reconstructedPayload = `VT_DOWNLOAD_GUARD_V1.0::AUTHORS=${manifestAuthor}::LEFT=${leftTxt}::RIGHT=${rightTxt}::DONATE_URL=${donateHref}::GECKO=vt-download-guard@salmonplay1.lososkiler`;

    const pubKey = await crypto.subtle.importKey(
      "spki",
      b64ToUint8Array(VT_AUTHOR_CRYPTO_CERT.publicKeySpkiB64),
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["verify"]
    );
    const isValid = await crypto.subtle.verify(
      { name: "ECDSA", hash: { name: "SHA-256" } },
      pubKey,
      b64ToUint8Array(VT_AUTHOR_CRYPTO_CERT.signatureB64),
      new TextEncoder().encode(reconstructedPayload)
    );

    const certBtn = document.getElementById("openAuthorCertModalBtn");
    const statusBox = document.getElementById("authorCertStatusBox");
    if (!isValid) {
      if (leftEl) leftEl.textContent = VT_AUTHOR_CRYPTO_CERT.leftCredit;
      if (rightEl) rightEl.textContent = VT_AUTHOR_CRYPTO_CERT.rightCredit;
      if (donateEl) donateEl.setAttribute("href", VT_AUTHOR_CRYPTO_CERT.donateUrl);
      if (certBtn) {
        certBtn.textContent = "🚨 ЭЦП НАРУШЕНА!";
        certBtn.style.color = "#f87171";
      }
      if (statusBox) {
        statusBox.style.background = "rgba(239,68,68,0.2)";
        statusBox.style.color = "#fca5a5";
        statusBox.textContent = "🚨 ВНИМАНИЕ: Обнаружена попытка подделки авторства! Настоящий автор: SalmonPlay1 (LososKiler).";
      }
      return false;
    }
    if (certBtn) {
      certBtn.textContent = currentSettings?.uiLang === "en" ? "🔏 Sign ✓" : "🔏 ЭЦП ✓";
    }
    if (statusBox) {
      statusBox.style.background = "rgba(16,185,129,0.14)";
      statusBox.style.color = "#34d399";
      statusBox.textContent = currentSettings?.uiLang === "en"
        ? "✅ Authentic Build verified by ECDSA P-256 digital signature (SalmonPlay1 / LososKiler)!"
        : "✅ Подлинная авторская сборка подтверждена ЭЦП ECDSA P-256 (SalmonPlay1 / LososKiler).";
    }
    return true;
  } catch (_) {
    return true;
  }
}

function bindExternalAuthorLink(el, targetUrl) {
  if (!el || el.__vtLinkBound) return;
  el.__vtLinkBound = true;
  el.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (chrome?.tabs?.create) {
      chrome.tabs.create({ url: targetUrl, active: true });
    } else {
      window.open(targetUrl, "_blank", "noopener,noreferrer");
    }
  });
}

function initAuthorCertificateModal() {
  const openBtn = document.getElementById("openAuthorCertModalBtn");
  const closeBtn = document.getElementById("closeAuthorCertModalBtn");
  const modal = document.getElementById("authorCertModal");
  const secretInput = document.getElementById("ownerSecretKeyInput");
  const verifyBtn = document.getElementById("verifyOwnerSecretBtn");
  const resultMsg = document.getElementById("ownerProofResultMsg");

  bindExternalAuthorLink(document.getElementById("authorDonateLink"), VT_AUTHOR_CRYPTO_CERT.donateUrl);

  verifyAuthorEcdsaSignature();

  if (openBtn && modal && !openBtn.__vtCertBound) {
    openBtn.__vtCertBound = true;
    openBtn.addEventListener("click", async () => {
      const show = modal.style.display === "none";
      modal.style.display = show ? "block" : "none";
      if (show) {
        await verifyAuthorEcdsaSignature();
        modal.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }
    });
  }
  if (closeBtn && modal && !closeBtn.__vtCertBound) {
    closeBtn.__vtCertBound = true;
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }
  if (verifyBtn && secretInput && resultMsg && !verifyBtn.__vtCertBound) {
    verifyBtn.__vtCertBound = true;
    verifyBtn.addEventListener("click", async () => {
      const isEn = currentSettings?.uiLang === "en";
      const val = (secretInput.value || "").trim();
      if (!val) return;
      const digestBuf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("VT_OWNER_SALT::" + val));
      const hex = Array.from(new Uint8Array(digestBuf)).map(b => b.toString(16).padStart(2, "0")).join("");
      if (hex === VT_AUTHOR_CRYPTO_CERT.ownerSecretSha256) {
        resultMsg.style.color = "#34d399";
        resultMsg.textContent = isEn
          ? "👑 OWNER VERIFIED! Cryptographic proof confirmed: You are the true creator (SalmonPlay1 / LososKiler)!"
          : "👑 ВЛАДЕЛЕЦ ПОДТВЕРЖДЁН! Криптографический ключ совпал: Вы — настоящий создатель расширения (SalmonPlay1 / LososKiler)!";
      } else {
        resultMsg.style.color = "#f87171";
        resultMsg.textContent = isEn
          ? "❌ Invalid Owner Key! Only the true author (SalmonPlay1 / LososKiler) holds the private master key."
          : "❌ Неверный секретный ключ! Только настоящий автор (SalmonPlay1 / LososKiler) владеет этим ключом.";
      }
    });
  }
}

setTimeout(initAuthorCertificateModal, 60);
