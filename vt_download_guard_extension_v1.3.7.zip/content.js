// VT Download Guard v1.0 — Content Script
// Включает кастомные тёмные скроллбары, кнопку согласия на отправку неизвестного файла (Privacy Consent), отметки авторитетных антивирусов (★) и полное окно отчёта VirusTotal.

(() => {
  function setSafeHtml(el, htmlStr) {
    if (!el) return;
    el.textContent = "";
    if (!htmlStr) return;
    const parser = new DOMParser();
    const doc = parser.parseFromString(String(htmlStr), "text/html");
    while (doc.body.firstChild) {
      el.appendChild(doc.body.firstChild);
    }
  }
  
  try {
    if (window.__vtDownloadGuardAliveCheck && window.__vtDownloadGuardAliveCheck()) {
      return;
    }
  } catch (_) {}
  window.__vtDownloadGuardAliveCheck = () => Boolean(chrome?.runtime?.id);
  try {
    const staleHost = document.getElementById("vt-download-guard-host");
    if (staleHost) staleHost.remove();
  } catch (_) {}

  let hostEl = null;
  let shadowRoot = null;
  let containerEl = null;
  let modalBackdropEl = null;
  const cards = new Map();

  function escHtml(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // Zero-Copy кэш пользовательских ассетов (фон, стикер, звук, шрифт) — читается 1 раз из storage без пересылки по IPC!
  const localCustomAssets = {
    customBgDataUrl: "",
    customStickerDataUrl: "",
    customSoundDataUrl: "",
    customFontDataUrl: ""
  };

  function syncLocalCustomAssets() {
    try {
      chrome.storage?.local?.get(localCustomAssets, (res) => {
        if (res) Object.assign(localCustomAssets, res);
      });
    } catch (_) {}
  }
  syncLocalCustomAssets();


  // ==================== v1.8.0: ВСТРОЕННЫЙ WEB AUDIO СИНТЕЗАТОР ЗВУКОВ И ТЕМЫ ОФОРМЛЕНИЯ ====================
  const playedSoundForScan = new Set();

  const SOUND_MELODIES = {
    salmon_wave:          { wave: "sine",     notes: [493.88, 659.25, 783.99, 987.77], step: 0.065 },
    helldivers_stratagem: { wave: "triangle", notes: [440, 440, 587.33, 659.25, 880],  step: 0.06  },
    ozen_abyss_bell:      { wave: "sine",     notes: [293.66, 440, 587.33],            step: 0.095 },
    teto_pop:             { wave: "square",   notes: [587.33, 739.99, 880, 1174.66],   step: 0.055 },
    miku_cyber:           { wave: "sine",     notes: [523.25, 659.25, 783.99, 1046.5], step: 0.06  },
    retro_coin:           { wave: "square",   notes: [987.77, 1318.51],                step: 0.075 },
    sonar_ping:           { wave: "sine",     notes: [880, 1760],                      step: 0.09  },
    crystal_chime:        { wave: "sine",     notes: [783.99, 987.77, 1174.66, 1567.98], step: 0.055 },
    cyber_sonar:          { wave: "triangle", notes: [587.33, 880],                    step: 0.07  }
  };

  const THEME_TO_SOUND_MAP = {
    salmon_ocean: "salmon_wave",
    helldivers2: "helldivers_stratagem",
    ozen_abyss: "ozen_abyss_bell",
    vocaloid_teto: "teto_pop",
    vocaloid_miku: "miku_cyber",
    oled_matrix: "retro_coin",
    purple_synth: "crystal_chime",
    crimson_guard: "helldivers_stratagem",
    dark_cyber: "cyber_sonar",
    light_clean: "crystal_chime"
  };

  function playAlertSound(type, data = {}) {
    try {
      const vol = Math.max(0.02, Math.min(1, (Number(data.soundVolume ?? 70)) / 100));
      const preset = data.soundPreset || "auto_theme";

      if (preset === "custom_audio" && (data.customSoundDataUrl || localCustomAssets.customSoundDataUrl)) {
        const audio = new Audio((data.customSoundDataUrl || localCustomAssets.customSoundDataUrl));
        audio.volume = vol;
        audio.play().catch(() => {});
        return;
      }

      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      if (type === "danger") {
        [0, 0.16, 0.32].forEach((offset, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = "sawtooth";
          osc.frequency.setValueAtTime(idx % 2 === 0 ? 520 : 390, now + offset);
          gain.gain.setValueAtTime(0.12 * vol, now + offset);
          gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.13);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + offset);
          osc.stop(now + offset + 0.14);
        });
      } else {
        const resolvedKey = preset === "auto_theme"
          ? (THEME_TO_SOUND_MAP[data.theme || "salmon_ocean"] || "salmon_wave")
          : (SOUND_MELODIES[preset] ? preset : "salmon_wave");
        const cfg = SOUND_MELODIES[resolvedKey] || SOUND_MELODIES.salmon_wave;
        cfg.notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = cfg.wave;
          osc.frequency.setValueAtTime(freq, now + idx * cfg.step);
          gain.gain.setValueAtTime(0.09 * vol, now + idx * cfg.step);
          gain.gain.exponentialRampToValueAtTime(0.001, now + idx * cfg.step + 0.16);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + idx * cfg.step);
          osc.stop(now + idx * cfg.step + 0.17);
        });
      }
      setTimeout(() => {
        try { ctx.close(); } catch (_) {}
      }, 800);
    } catch (_) {}
  }

  let currentScanWindowDisplayMode = "card_on_top";
  let isToolbarPopupOpen = false;
  let inPageExtPanelEl = null;

  function ensureInPageExtensionPanel(show) {
    ensureContainer();
    if (!show) {
      if (inPageExtPanelEl) {
        inPageExtPanelEl.remove();
        inPageExtPanelEl = null;
      }
      return null;
    }
    if (!inPageExtPanelEl || !shadowRoot.contains(inPageExtPanelEl)) {
      inPageExtPanelEl = document.createElement("div");
      inPageExtPanelEl.className = "vt-inpage-ext-panel";
      const extUrl = chrome.runtime.getURL("popup.html?inpage_panel=1");
      setSafeHtml(inPageExtPanelEl, `
        <div class="vt-inpage-ext-bar" title="Зажмите мышкой для перемещения окна расширения">
          <span>🛡️ VT Download Guard — Окно расширения</span>
          <button type="button" class="vt-inpage-ext-close" title="Закрыть окно расширения">✕</button>
        </div>
        <iframe src="${extUrl}" class="vt-inpage-ext-iframe" allow="clipboard-read; clipboard-write"></iframe>
      `);
      const closeBtn = inPageExtPanelEl.querySelector(".vt-inpage-ext-close");
      if (closeBtn) {
        closeBtn.addEventListener("click", () => {
          ensureInPageExtensionPanel(false);
          applyHostPosition(contentPrefs.bannerPosition || "top-right", currentScanWindowDisplayMode);
        });
      }
      // Перетаскивание окна расширения за верхнюю панель
      const dragBar = inPageExtPanelEl.querySelector(".vt-inpage-ext-bar");
      if (dragBar) {
        let dragging = false, startX = 0, startY = 0, origRight = 95, origTop = 14;
        dragBar.addEventListener("mousedown", (e) => {
          if (e.target === closeBtn) return;
          dragging = true;
          startX = e.clientX;
          startY = e.clientY;
          origRight = parseInt(inPageExtPanelEl.style.right || "95", 10) || 95;
          origTop = parseInt(inPageExtPanelEl.style.top || "14", 10) || 14;
          e.preventDefault();
        });
        window.addEventListener("mousemove", (e) => {
          if (!dragging || !inPageExtPanelEl) return;
          const dx = e.clientX - startX;
          const dy = e.clientY - startY;
          inPageExtPanelEl.style.right = Math.max(10, origRight - dx) + "px";
          inPageExtPanelEl.style.top = Math.max(10, origTop + dy) + "px";
        });
        window.addEventListener("mouseup", () => { dragging = false; });
      }
      shadowRoot.appendChild(inPageExtPanelEl);
    }
    return inPageExtPanelEl;
  }

  function applyHostPosition(pos, winMode) {
    if (!hostEl) return;
    if (winMode) currentScanWindowDisplayMode = winMode;
    hostEl.style.top = "";
    hostEl.style.bottom = "";
    hostEl.style.left = "";
    hostEl.style.right = "";

    const anyExtOpen = isToolbarPopupOpen || Boolean(inPageExtPanelEl && shadowRoot?.contains(inPageExtPanelEl));
    // В Яндекс Браузере / Chrome иконка расширения находится ~130px от правого края, а ширина окна расширения ~465px (итого 130+465 = 595px).
    // Поэтому сдвиг 625px гарантирует, что в режиме «🔄 Оба окна рядом» плашка проверки стоит слева от окна расширения вообще БЕЗ перекрытия!
    let rightOffset = "20px";
    if (currentScanWindowDisplayMode === "both_windows" && anyExtOpen) {
      rightOffset = window.innerWidth >= 1020 ? "625px" : "560px";
    } else if (currentScanWindowDisplayMode === "card_on_top" && inPageExtPanelEl) {
      // В режиме «📊 Само окно вывода проверки поверх» карточка проверки перекрывает окно расширения сверху (со сдвигом, чтобы оба окна были видны и карточка проверки была НА ПЕРЕДНЕМ ПЛАНЕ поверх окна расширения!)
      rightOffset = "265px";
    }

    if (pos === "bottom-right") {
      hostEl.style.bottom = "20px";
      hostEl.style.right = rightOffset;
    } else if (pos === "top-left") {
      hostEl.style.top = "20px";
      hostEl.style.left = "20px";
    } else if (pos === "bottom-left") {
      hostEl.style.bottom = "20px";
      hostEl.style.left = "20px";
    } else {
      hostEl.style.top = "20px";
      hostEl.style.right = rightOffset;
    }

    // Управляем Z-Index слоями между окном проверки (containerEl) и окном расширения (inPageExtPanelEl):
    if (containerEl) {
      containerEl.style.position = "relative";
      containerEl.style.zIndex = currentScanWindowDisplayMode === "extension_on_top" ? "100" : "300";
    }
    if (inPageExtPanelEl) {
      inPageExtPanelEl.style.zIndex = currentScanWindowDisplayMode === "extension_on_top" ? "400" : "150";
      if (currentScanWindowDisplayMode === "both_windows") {
        inPageExtPanelEl.style.right = "95px";
      }
    }
  }


  function ensureContainer() {
    if (containerEl && hostEl && document.documentElement && document.documentElement.contains(hostEl)) return containerEl;
    if (containerEl && hostEl && (document.body || document.documentElement)) {
      try {
        (document.body || document.documentElement).appendChild(hostEl);
        return containerEl;
      } catch (_) {}
    }

    hostEl = document.createElement("div");
    hostEl.id = "vt-download-guard-host";
    hostEl.style.all = "initial";
    hostEl.style.position = "fixed";
    hostEl.style.top = "20px";
    hostEl.style.right = "20px";
    hostEl.style.zIndex = "2147483647";
    hostEl.style.pointerEvents = "none";

    shadowRoot = hostEl.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      * {
        box-sizing: border-box;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, Arial, sans-serif;
      }
      /* Удобный заметный ползунок прокрутки справа для карточек и таблиц (v1.0) */
      ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
      }
      ::-webkit-scrollbar-track {
        background: rgba(15, 23, 42, 0.75);
        border-radius: 8px;
      }
      ::-webkit-scrollbar-thumb {
        background: #38bdf8;
        border-radius: 8px;
        border: 1.5px solid #0f172a;
      }
      ::-webkit-scrollbar-thumb:hover {
        background: #60a5fa;
      }

      .vt-inpage-ext-panel {
        pointer-events: auto;
        position: fixed;
        top: 14px;
        right: 95px;
        width: 465px;
        height: 615px;
        max-height: calc(100vh - 28px);
        background: #0a1929;
        border: 2px solid #38bdf8;
        border-radius: 14px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        z-index: 150;
      }
      .vt-inpage-ext-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 6px 12px;
        background: linear-gradient(90deg, #0f172a, #1e293b);
        border-bottom: 1px solid rgba(56, 189, 248, 0.35);
        color: #7dd3fc;
        font-size: 11.5px;
        font-weight: 800;
        cursor: move;
        user-select: none;
      }
      .vt-inpage-ext-close {
        background: rgba(239, 68, 68, 0.2);
        color: #fca5a5;
        border: 1px solid rgba(248, 113, 113, 0.4);
        border-radius: 6px;
        padding: 1px 7px;
        font-size: 12px;
        font-weight: 800;
        cursor: pointer;
      }
      .vt-inpage-ext-close:hover {
        background: #ef4444;
        color: #fff;
      }
      .vt-inpage-ext-iframe {
        width: 100%;
        height: 100%;
        border: none;
        flex: 1;
        background: #0f172a;
      }
      .vt-stack {
        pointer-events: auto;
        display: flex;
        flex-direction: column;
        gap: 12px;
        width: 445px;
        max-width: calc(100vw - 28px);
        max-height: calc(100vh - 32px);
        overflow-y: auto;
        overflow-x: hidden;
        padding-right: 4px;
      }
      .vt-stack-toolbar {
        pointer-events: auto;
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        background: rgba(15, 23, 42, 0.94);
        border: 1px solid rgba(56, 189, 248, 0.45);
        border-radius: 10px;
        padding: 7px 11px;
        color: #e0f2fe;
        font-size: 11.5px;
        font-weight: 700;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.55);
        backdrop-filter: blur(10px);
      }
      .vt-stack-toolbar-btns {
        display: flex;
        align-items: center;
        gap: 5px;
      }
      .vt-stack-btn {
        background: rgba(30, 41, 59, 0.9);
        color: #bae6fd;
        border: 1px solid rgba(125, 211, 252, 0.35);
        border-radius: 6px;
        padding: 3px 7px;
        font-size: 10.5px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.15s ease;
      }
      .vt-stack-btn:hover {
        background: rgba(56, 189, 248, 0.25);
        color: #ffffff;
      }
      .vt-stack-btn-danger {
        color: #fca5a5;
        border-color: rgba(248, 113, 113, 0.4);
      }
      .vt-stack-btn-danger:hover {
        background: rgba(239, 68, 68, 0.28);
        color: #ffffff;
      }
      .vt-collapse-btn {
        background: rgba(30, 41, 59, 0.85);
        color: #7dd3fc;
        border: 1px solid rgba(56, 189, 248, 0.4);
        border-radius: 6px;
        padding: 2px 7px;
        font-size: 10.5px;
        font-weight: 800;
        cursor: pointer;
        line-height: 1.2;
        transition: all 0.15s ease;
      }
      .vt-collapse-btn:hover {
        background: rgba(56, 189, 248, 0.25);
        color: #fff;
      }
      .vt-card {
        pointer-events: auto;
        flex-shrink: 0 !important;
        background: #0f172a;
        color: #f8fafc;
        border: 1px solid #334155;
        border-radius: 14px;
        padding: 15px;
        max-height: calc(100vh - 64px);
        overflow-y: auto;
        overflow-x: hidden;
      }
      .vt-card.vt-card-collapsed {
        padding: 10px 14px !important;
        max-height: none !important;
        overflow: hidden !important;
        cursor: pointer;
      }
      .vt-card.vt-card-collapsed .vt-status-box,
      .vt-card.vt-card-collapsed .vt-credits-row,
      .vt-card.vt-card-collapsed .vt-autosave-banner,
      .vt-card.vt-card-collapsed .vt-autoblock-banner {
        display: none !important;
      }
      .vt-card.vt-card-collapsed .vt-filename {
        margin-bottom: 0 !important;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.65), 0 8px 10px -6px rgba(0, 0, 0, 0.5);
        animation: vtSlideIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        transition: border-color 0.2s ease;
      }
      .vt-card.vt-safe { border-left: 5px solid #10b981; }
      .vt-card.vt-warning { border-left: 5px solid #f59e0b; }
      .vt-card.vt-danger { border-left: 5px solid #ef4444; }
      .vt-card.vt-scanning { border-left: 5px solid #38bdf8; }
      .vt-card.vt-error { border-left: 5px solid #f97316; }

      /* Темы оформления v1.8.0 для карточек и модального окна */

      /* 5 новых фирменных тем v1.0 для плашек на сайтах */
      .vt-card.theme-salmon_ocean {
        background: linear-gradient(160deg, #061a29 0%, #0b293f 100%);
        border-color: #ff7e67;
        box-shadow: 0 20px 28px rgba(4, 18, 30, 0.8);
      }
      .vt-card.theme-salmon_ocean .vt-status-box { background: rgba(6, 22, 35, 0.85); border: 1px solid rgba(56, 189, 248, 0.25); }
      .vt-card.theme-salmon_ocean .vt-brand { color: #ff8a73; }
      .vt-card.theme-salmon_ocean .vt-btn-primary { background: #ff7e67; color: #051622; }

      .vt-card.theme-helldivers2 {
        background: #11110e;
        border: 2px solid #ffe600;
        border-radius: 6px;
        box-shadow: 0 0 22px rgba(255, 230, 0, 0.18), 0 18px 25px rgba(0, 0, 0, 0.85);
      }
      .vt-card.theme-helldivers2 .vt-status-box { background: #1b1b16; border-left: 3px solid #ffe600; border-radius: 4px; color: #fef08a; }
      .vt-card.theme-helldivers2 .vt-brand { color: #ffe600; text-transform: uppercase; letter-spacing: 0.06em; }
      .vt-card.theme-helldivers2 .vt-btn-primary { background: #ffe600; color: #0d0d0b; font-weight: 800; text-transform: uppercase; }

      .vt-card.theme-ozen_abyss {
        background: radial-gradient(circle at top right, #1e2238 0%, #090a10 85%);
        border-color: #cbd5e1;
        box-shadow: 0 20px 30px rgba(0, 0, 0, 0.9);
      }
      .vt-card.theme-ozen_abyss .vt-status-box { background: #121420; border: 1px solid #334155; color: #e2e8f0; }
      .vt-card.theme-ozen_abyss .vt-brand { color: #e2e8f0; letter-spacing: 0.04em; }
      .vt-card.theme-ozen_abyss .vt-btn-primary { background: #818cf8; color: #090a10; }

      .vt-card.theme-vocaloid_teto {
        background: linear-gradient(155deg, #1a0b13 0%, #2b1120 100%);
        border-color: #ff3366;
      }
      .vt-card.theme-vocaloid_teto .vt-status-box { background: #14080e; border: 1px solid rgba(255, 51, 102, 0.3); }
      .vt-card.theme-vocaloid_teto .vt-brand { color: #ff4d79; }
      .vt-card.theme-vocaloid_teto .vt-btn-primary { background: #ff3366; color: #ffffff; }

      .vt-card.theme-vocaloid_miku {
        background: linear-gradient(155deg, #07161b 0%, #0e2932 100%);
        border-color: #39c5bb;
      }
      .vt-card.theme-vocaloid_miku .vt-status-box { background: #061115; border: 1px solid rgba(57, 197, 187, 0.35); }
      .vt-card.theme-vocaloid_miku .vt-brand { color: #39c5bb; }
      .vt-card.theme-vocaloid_miku .vt-btn-primary { background: #39c5bb; color: #041014; }

      .vt-card.theme-oled_matrix .vt-status-box { background: #0b1410; }

      /* 5 новых фирменных тем v1.0 для плашек на сайтах */
      .vt-card.theme-salmon_ocean {
        background: linear-gradient(160deg, #061a29 0%, #0b293f 100%);
        border-color: #ff7e67;
        box-shadow: 0 20px 28px rgba(4, 18, 30, 0.8);
      }
      .vt-card.theme-salmon_ocean .vt-status-box { background: rgba(6, 22, 35, 0.85); border: 1px solid rgba(56, 189, 248, 0.25); }
      .vt-card.theme-salmon_ocean .vt-brand { color: #ff8a73; }
      .vt-card.theme-salmon_ocean .vt-btn-primary { background: #ff7e67; color: #051622; }

      .vt-card.theme-helldivers2 {
        background: #11110e;
        border: 2px solid #ffe600;
        border-radius: 6px;
        box-shadow: 0 0 22px rgba(255, 230, 0, 0.18), 0 18px 25px rgba(0, 0, 0, 0.85);
      }
      .vt-card.theme-helldivers2 .vt-status-box { background: #1b1b16; border-left: 3px solid #ffe600; border-radius: 4px; color: #fef08a; }
      .vt-card.theme-helldivers2 .vt-brand { color: #ffe600; text-transform: uppercase; letter-spacing: 0.06em; }
      .vt-card.theme-helldivers2 .vt-btn-primary { background: #ffe600; color: #0d0d0b; font-weight: 800; text-transform: uppercase; }

      .vt-card.theme-ozen_abyss {
        background: radial-gradient(circle at top right, #1e2238 0%, #090a10 85%);
        border-color: #cbd5e1;
        box-shadow: 0 20px 30px rgba(0, 0, 0, 0.9);
      }
      .vt-card.theme-ozen_abyss .vt-status-box { background: #121420; border: 1px solid #334155; color: #e2e8f0; }
      .vt-card.theme-ozen_abyss .vt-brand { color: #e2e8f0; letter-spacing: 0.04em; }
      .vt-card.theme-ozen_abyss .vt-btn-primary { background: #818cf8; color: #090a10; }

      .vt-card.theme-vocaloid_teto {
        background: linear-gradient(155deg, #1a0b13 0%, #2b1120 100%);
        border-color: #ff3366;
      }
      .vt-card.theme-vocaloid_teto .vt-status-box { background: #14080e; border: 1px solid rgba(255, 51, 102, 0.3); }
      .vt-card.theme-vocaloid_teto .vt-brand { color: #ff4d79; }
      .vt-card.theme-vocaloid_teto .vt-btn-primary { background: #ff3366; color: #ffffff; }

      .vt-card.theme-vocaloid_miku {
        background: linear-gradient(155deg, #07161b 0%, #0e2932 100%);
        border-color: #39c5bb;
      }
      .vt-card.theme-vocaloid_miku .vt-status-box { background: #061115; border: 1px solid rgba(57, 197, 187, 0.35); }
      .vt-card.theme-vocaloid_miku .vt-brand { color: #39c5bb; }
      .vt-card.theme-vocaloid_miku .vt-btn-primary { background: #39c5bb; color: #041014; }

      .vt-card.theme-oled_matrix .vt-brand { color: #10b981; }

      .vt-card.theme-purple_synth { background: #130d26; border-color: #581c87; }
      .vt-card.theme-purple_synth .vt-status-box { background: #1e1438; }
      .vt-card.theme-purple_synth .vt-brand { color: #c084fc; }

      .vt-card.theme-crimson_guard { background: #180a0d; border-color: #881337; }
      .vt-card.theme-crimson_guard .vt-status-box { background: #261016; }
      .vt-card.theme-crimson_guard .vt-brand { color: #fb7185; }

      .vt-card.theme-light_clean { background: #ffffff; color: #0f172a; border-color: #cbd5e1; box-shadow: 0 15px 30px rgba(15, 23, 42, 0.18); }
      .vt-card.theme-light_clean .vt-filename { color: #0f172a; }
      .vt-card.theme-light_clean .vt-status-box { background: #f1f5f9; color: #334155; }
      .vt-card.theme-light_clean .vt-stat-pill { background: #ffffff; border-color: #cbd5e1; }
      .vt-card.theme-light_clean .vt-inline-vendors-grid { background: #ffffff; border-color: #cbd5e1; }
      .vt-card.theme-light_clean .vt-vendor-name { color: #1e293b; }
      .vt-card.theme-light_clean .vt-brand { color: #2563eb; }
      .vt-card.theme-light_clean .vt-ext-badge { background: #e2e8f0; color: #334155; border-color: #cbd5e1; }


      @keyframes vtBounceIn {
        0% { opacity: 0; transform: translateY(-28px) scale(0.88); }
        65% { opacity: 1; transform: translateY(5px) scale(1.02); }
        100% { opacity: 1; transform: translateY(0) scale(1); }
      }
      @keyframes vtCyberGlitch {
        0% { opacity: 0; transform: translateX(24px) skewX(-12deg); filter: hue-rotate(90deg); }
        45% { opacity: 1; transform: translateX(-6px) skewX(6deg); }
        75% { transform: translateX(3px) skewX(-2deg); }
        100% { opacity: 1; transform: translateX(0) skewX(0); filter: none; }
      }
      @keyframes vtZoomIn {
        from { opacity: 0; transform: scale(0.78); }
        to { opacity: 1; transform: scale(1); }
      }
      .vt-card.anim-bounce { animation: vtBounceIn 0.36s cubic-bezier(0.22, 1, 0.36, 1); }
      .vt-card.anim-cyber_glitch { animation: vtCyberGlitch 0.32s ease-out; }
      .vt-card.anim-zoom { animation: vtZoomIn 0.22s ease-out; }

      .vt-mini-pill-hud {
        pointer-events: auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        background: rgba(15, 23, 42, 0.92);
        border: 1.5px solid #10b981;
        border-radius: 999px;
        padding: 8px 14px;
        color: #f8fafc;
        font-size: 12px;
        font-weight: 700;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.65);
        cursor: pointer;
        backdrop-filter: blur(6px);
        animation: vtSlideIn 0.22s ease;
      }
      .vt-mini-pill-hud:hover {
        border-color: #38bdf8;
        transform: translateY(-1px);
      }

      @keyframes vtSlideIn {
        from { opacity: 0; transform: translateY(-12px) scale(0.97); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }
      
      .vt-card > *:not(.vt-bg-decor-layer) { position: relative; z-index: 1; text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75); }
      .vt-card.theme-light_clean > *:not(.vt-bg-decor-layer) { text-shadow: none; }
      .vt-card .vt-status-box,
      .vt-card .vt-stat-pill,
      .vt-card .vt-inline-vendors-grid {
        background: color-mix(in srgb, #0f172a var(--vt-panel-alpha, 48%), transparent) !important;
        backdrop-filter: blur(2px);
      }
      .vt-card.theme-light_clean .vt-status-box,
      .vt-card.theme-light_clean .vt-stat-pill,
      .vt-card.theme-light_clean .vt-inline-vendors-grid {
        background: color-mix(in srgb, #ffffff var(--vt-panel-alpha, 65%), transparent) !important;
      }
      .vt-card[style*="--vt-custom-text-main"] .vt-filename,
      .vt-card[style*="--vt-custom-text-main"] .vt-status-box,
      .vt-card[style*="--vt-custom-text-main"] .vt-vendor-name {
        color: var(--vt-custom-text-main) !important;
      }
      .vt-card[style*="--vt-custom-text-sub"] .vt-stat-label,
      .vt-card[style*="--vt-custom-text-sub"] .vt-inline-vendors-header,
      .vt-card[style*="--vt-custom-text-sub"] .vt-link {
        color: var(--vt-custom-text-sub) !important;
      }

      .vt-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 10px;
      }
      .vt-brand {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13.5px;
        font-weight: 700;
        color: #38bdf8;
        letter-spacing: 0.02em;
      }
      .vt-ext-badge {
        background: #1e293b;
        color: #94a3b8;
        border: 1px solid #334155;
        font-size: 11px;
        font-weight: 700;
        padding: 2px 7px;
        border-radius: 6px;
        text-transform: uppercase;
      }
      .vt-close {
        background: transparent;
        border: none;
        color: #94a3b8;
        cursor: pointer;
        font-size: 18px;
        line-height: 1;
        padding: 2px 6px;
        border-radius: 6px;
      }
      .vt-close:hover {
        background: #1e293b;
        color: #f8fafc;
      }
      .vt-filename {
        font-size: 14px;
        font-weight: 600;
        color: #f1f5f9;
        word-break: break-all;
        margin-bottom: 8px;
      }
      .vt-autoblock-banner {
        background: rgba(239, 68, 68, 0.18);
        border: 1px solid #ef4444;
        color: #fecaca;
        border-radius: 8px;
        padding: 7px 10px;
        font-size: 12px;
        font-weight: 700;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .vt-autosave-banner {
        background: rgba(16, 185, 129, 0.16);
        border: 1px solid #10b981;
        color: #a7f3d0;
        border-radius: 8px;
        padding: 7px 10px;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }
      .vt-folder-btn {
        background: #065f46;
        color: #ecfdf5;
        border: 1px solid #10b981;
        border-radius: 6px;
        padding: 3px 8px;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        white-space: nowrap;
      }
      .vt-folder-btn:hover {
        background: #047857;
      }
      .vt-status-box {
        background: #1e293b;
        border-radius: 10px;
        padding: 10px 12px;
        font-size: 12.5px;
        line-height: 1.45;
        color: #cbd5e1;
        margin-bottom: 10px;
      }
      .vt-spinner-row {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .vt-spinner {
        width: 18px;
        height: 18px;
        border: 2.5px solid #334155;
        border-top-color: #38bdf8;
        border-radius: 50%;
        animation: vtSpin 0.8s linear infinite;
        flex-shrink: 0;
      }
      @keyframes vtSpin {
        to { transform: rotate(360deg); }
      }
      .vt-stats-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        margin-top: 10px;
      }
      .vt-stat-pill {
        background: #0f172a;
        border: 1px solid #334155;
        border-radius: 8px;
        padding: 6px 8px;
        text-align: center;
      }
      .vt-stat-num {
        font-size: 15px;
        font-weight: 700;
        display: block;
      }
      .vt-stat-label {
        font-size: 10px;
        color: #94a3b8;
        text-transform: uppercase;
      }
      .vt-num-danger { color: #f87171; }
      .vt-num-warn { color: #fbbf24; }
      .vt-num-safe { color: #34d399; }


      .vt-smart-summary-box {
        margin-top: 9px;
        padding: 9px 11px;
        border-radius: 8px;
        background: color-mix(in srgb, #0f172a var(--vt-panel-alpha, 48%), transparent);
        border: 1px solid #334155;
        font-size: 11.5px;
        line-height: 1.42;
      }
      .vt-smart-risk-title {
        font-weight: 800;
        font-size: 12px;
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .vt-smart-complains {
        color: #e2e8f0;
        margin-bottom: 6px;
      }
      .vt-smart-caps-list {
        margin: 0;
        padding-left: 16px;
        color: #cbd5e1;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .vt-smart-rec {
        margin-top: 6px;
        padding-top: 5px;
        border-top: 1px dashed rgba(148, 163, 184, 0.3);
        font-weight: 700;
        color: #f8fafc;
      }

      .vt-inline-vendors-wrap {
        margin-top: 10px;
        border-top: 1px solid #334155;
        padding-top: 8px;
      }
      .vt-inline-vendors-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 11.5px;
        font-weight: 600;
        color: #94a3b8;
        margin-bottom: 6px;
      }
      .vt-inline-vendors-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4px 10px;
        max-height: 160px;
        overflow-y: auto;
        background: #0f172a;
        border: 1px solid #334155;
        border-radius: 8px;
        padding: 6px 8px;
      }
      .vt-vendor-cell {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 11px;
        padding: 3px 0;
        border-bottom: 1px solid #1e293b;
        gap: 6px;
      }
      .vt-vendor-name {
        color: #e2e8f0;
        font-weight: 500;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .vt-trusted-star {
        color: #38bdf8;
        font-size: 10px;
        margin-left: 3px;
      }
      .vt-vendor-state {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        white-space: nowrap;
        font-weight: 600;
      }
      .vt-v-clean { color: #10b981; }
      .vt-v-malicious { color: #ef4444; }
      .vt-v-suspicious { color: #f59e0b; }
      .vt-v-other { color: #64748b; }

      .vt-actions {
        background: rgba(15, 23, 42, 0.78);
        backdrop-filter: blur(6px);
        padding: 8px;
        margin: 6px 0 8px 0;
        border: 1px solid rgba(148, 163, 184, 0.2);
        border-radius: 9px;
        display: flex;
        align-items: stretch;
        justify-content: space-between;
        gap: 6px;
        flex-wrap: wrap;
        z-index: 5;
      }
      .vt-actions > .vt-btn,
      .vt-actions > .vt-link {
        flex: 1 1 calc(50% - 6px);
        justify-content: center;
        text-align: center;
        box-sizing: border-box;
        margin: 0 !important;
        white-space: nowrap;
      }
      .vt-btn {
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: opacity 0.15s ease, transform 0.1s ease;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
      }
      .vt-btn:hover { opacity: 0.92; }
      .vt-btn:active { transform: scale(0.98); }
      .vt-btn-primary {
        background: #10b981;
        color: #052e16;
      }
      .vt-btn-upload {
        background: #2563eb;
        color: #ffffff;
      }
      .vt-btn-danger-outline {
        background: #1e293b;
        color: #fca5a5;
        border: 1px solid #ef4444;
      }
      .vt-btn-secondary {
        background: #334155;
        color: #f8fafc;
      }
      .vt-btn-vt-view {
        background: rgba(56, 189, 248, 0.15);
        color: #38bdf8;
        border: 1px solid #0284c7;
      }
      .vt-locked-tag {
        font-size: 12px;
        color: #f87171;
        font-weight: 600;
      }
      .vt-link {
        color: #94a3b8;
        font-size: 11.5px;
        font-weight: 500;
        text-decoration: none;
      }
      .vt-link:hover {
        color: #38bdf8;
        text-decoration: underline;
      }
      .vt-credits-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 10px;
        padding-top: 7px;
        border-top: 1px solid #1e293b;
        font-size: 10.5px;
        font-weight: 700;
      }
      .vt-modal-credits {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 20px;
        background: #1d2433;
        border-top: 1px solid #2a3246;
        font-size: 11.5px;
        font-weight: 700;
      }
      .vt-credit-left, .vt-credit-right, .vt-credit-donate {
        text-decoration: none;
        cursor: pointer;
        padding: 2px 6px;
        border-radius: 5px;
        transition: all 0.15s ease;
        display: inline-flex;
        align-items: center;
        gap: 3px;
      }
      .vt-credit-left {
        color: #38bdf8;
        background: rgba(56, 189, 248, 0.08);
        border: 1px solid rgba(56, 189, 248, 0.25);
      }
      .vt-credit-left:hover {
        color: #fca5a5;
        background: rgba(239, 68, 68, 0.18);
        border-color: #f87171;
        transform: translateY(-1px);
      }
      .vt-credit-right {
        color: #a78bfa;
        background: rgba(167, 139, 250, 0.08);
        border: 1px solid rgba(167, 139, 250, 0.25);
      }
      .vt-credit-right:hover {
        color: #e9d5ff;
        background: rgba(168, 85, 247, 0.22);
        border-color: #c084fc;
        transform: translateY(-1px);
      }
      .vt-credit-donate {
        color: #fbbf24;
        background: linear-gradient(135deg, rgba(245, 158, 11, 0.18), rgba(234, 88, 12, 0.22));
        border: 1px solid rgba(251, 191, 36, 0.5);
        font-weight: 800;
        font-size: 10px;
      }
      .vt-credit-donate:hover {
        color: #ffffff;
        background: linear-gradient(135deg, #f59e0b, #ea580c);
        border-color: #fde047;
        transform: translateY(-1px);
      }

      /* МОДАЛЬНОЕ ОКНО ПОЛНОГО ОТЧЁТА VIRUSTOTAL */
      .vt-modal-backdrop {
        pointer-events: auto;
        position: fixed;
        inset: 0;
        background: rgba(9, 13, 24, 0.82);
        backdrop-filter: blur(4px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 24px;
        z-index: 2147483647;
        animation: vtFadeIn 0.18s ease;
      }
      @keyframes vtFadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      .vt-modal-window {
        width: 980px;
        max-width: 96vw;
        max-height: 90vh;
        background: #161b26;
        color: #e2e8f0;
        border: 1px solid #2a3246;
        border-radius: 12px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85);
      }
      .vt-modal-topbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 20px;
        background: #1d2433;
        border-bottom: 1px solid #2a3246;
      }
      .vt-modal-title {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 14px;
        font-weight: 700;
        color: #60a5fa;
      }
      .vt-modal-close {
        background: #2a3246;
        color: #cbd5e1;
        border: none;
        border-radius: 6px;
        padding: 5px 12px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
      }
      .vt-modal-close:hover {
        background: #3b4661;
        color: #ffffff;
      }
      .vt-hero-row {
        display: flex;
        gap: 14px;
        padding: 18px 20px 12px;
        align-items: stretch;
      }
      .vt-score-box {
        width: 125px;
        flex-shrink: 0;
        background: #1d2433;
        border: 1px solid #2a3246;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 14px 10px;
      }
      .vt-circle-ring {
        width: 78px;
        height: 78px;
        border-radius: 50%;
        border: 6px solid #22c55e;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin-bottom: 8px;
      }
      .vt-circle-ring.danger { border-color: #ef4444; }
      .vt-circle-ring.warn { border-color: #f59e0b; }
      .vt-ring-num {
        font-size: 22px;
        font-weight: 700;
        line-height: 1.05;
        color: #22c55e;
      }
      .vt-circle-ring.danger .vt-ring-num { color: #ef4444; }
      .vt-circle-ring.warn .vt-ring-num { color: #f59e0b; }
      .vt-ring-total {
        font-size: 11px;
        color: #94a3b8;
      }
      .vt-community-label {
        font-size: 10.5px;
        color: #94a3b8;
        text-align: center;
      }
      .vt-summary-panel {
        flex: 1;
        background: #1d2433;
        border: 1px solid #2a3246;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .vt-summary-banner {
        padding: 9px 16px;
        font-size: 13px;
        font-weight: 600;
        background: rgba(34, 197, 94, 0.12);
        color: #4ade80;
        border-bottom: 1px solid #2a3246;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .vt-summary-banner.danger {
        background: rgba(239, 68, 68, 0.15);
        color: #f87171;
      }
      .vt-summary-banner.warn {
        background: rgba(245, 158, 11, 0.15);
        color: #fbbf24;
      }
      .vt-summary-meta-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 16px;
        gap: 16px;
        flex-wrap: wrap;
      }
      .vt-meta-main {
        display: flex;
        flex-direction: column;
        gap: 5px;
        min-width: 0;
        flex: 1;
      }
      .vt-sha256-line {
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        font-size: 12.5px;
        color: #e2e8f0;
        word-break: break-all;
      }
      .vt-file-title-line {
        font-size: 13px;
        color: #cbd5e1;
        font-weight: 500;
        word-break: break-all;
      }
      .vt-type-pill {
        display: inline-block;
        align-self: flex-start;
        background: rgba(45, 212, 191, 0.14);
        color: #2dd4bf;
        font-size: 11px;
        font-weight: 600;
        padding: 2px 8px;
        border-radius: 10px;
        margin-top: 2px;
      }
      .vt-meta-columns {
        display: flex;
        align-items: center;
        gap: 22px;
        flex-shrink: 0;
      }
      .vt-meta-col {
        border-left: 1px solid #2a3246;
        padding-left: 14px;
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .vt-meta-col-label {
        font-size: 11px;
        color: #64748b;
      }
      .vt-meta-col-val {
        font-size: 12.5px;
        font-weight: 600;
        color: #e2e8f0;
      }
      .vt-tabs-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 20px;
        border-bottom: 1px solid #2a3246;
        gap: 16px;
      }
      .vt-tabs-left {
        display: flex;
        gap: 22px;
      }
      .vt-tab-btn {
        background: transparent;
        border: none;
        border-bottom: 2.5px solid transparent;
        color: #94a3b8;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.04em;
        padding: 10px 4px;
        cursor: pointer;
        text-transform: uppercase;
      }
      .vt-tab-btn.active {
        color: #60a5fa;
        border-bottom-color: #60a5fa;
      }
      .vt-vendor-search {
        background: #1d2433;
        border: 1px solid #2a3246;
        color: #f8fafc;
        border-radius: 6px;
        padding: 5px 10px;
        font-size: 12px;
        width: 240px;
        outline: none;
      }
      .vt-vendor-search:focus {
        border-color: #60a5fa;
      }
      .vt-modal-body {
        padding: 14px 20px 20px;
        overflow-y: auto;
        flex: 1;
      }
      .vt-section-heading {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 13px;
        font-weight: 600;
        color: #e2e8f0;
        padding-bottom: 10px;
        border-bottom: 1px solid #2a3246;
        margin-bottom: 4px;
      }
      .vt-vendors-two-col {
        display: grid;
        grid-template-columns: 1fr 1fr;
        column-gap: 32px;
      }
      @media (max-width: 720px) {
        .vt-vendors-two-col {
          grid-template-columns: 1fr;
        }
      }
      .vt-vendor-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 9px 4px;
        border-bottom: 1px solid #22293a;
        font-size: 12.5px;
      }
      .vt-vendor-row-name {
        color: #e2e8f0;
        font-weight: 500;
      }
      .vt-vendor-row-res {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        font-size: 12.5px;
      }
      .vt-icon-circle {
        width: 16px;
        height: 16px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 800;
      }
      .vt-icon-clean { border: 1.5px solid #22c55e; color: #22c55e; }
      .vt-icon-malicious { border: 1.5px solid #ef4444; color: #ef4444; }
      .vt-icon-suspicious { border: 1.5px solid #f59e0b; color: #f59e0b; }
      .vt-icon-other { border: 1.5px solid #64748b; color: #64748b; }
      .vt-details-box {
        background: #1d2433;
        border: 1px solid #2a3246;
        border-radius: 8px;
        padding: 14px 16px;
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .vt-detail-line {
        display: grid;
        grid-template-columns: 180px 1fr;
        gap: 12px;
        font-size: 12.5px;
        border-bottom: 1px solid #262f42;
        padding-bottom: 8px;
      }
      .vt-detail-key {
        color: #94a3b8;
        font-weight: 600;
      }
      .vt-detail-val {
        color: #f1f5f9;
        word-break: break-all;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      }
    `;

    containerEl = document.createElement("div");
    containerEl.className = "vt-stack";

    shadowRoot.appendChild(style);
    shadowRoot.appendChild(containerEl);
    (document.body || document.documentElement).appendChild(hostEl);

    return containerEl;
  }

  function formatVendorBadge(v) {
    if (v.category === "malicious") {
      return {
        cls: "vt-v-malicious",
        iconCls: "vt-icon-malicious",
        icon: "!",
        text: v.result || "Malicious"
      };
    }
    if (v.category === "suspicious") {
      return {
        cls: "vt-v-suspicious",
        iconCls: "vt-icon-suspicious",
        icon: "!",
        text: v.result || "Suspicious"
      };
    }
    if (v.category === "undetected" || v.category === "harmless") {
      return {
        cls: "vt-v-clean",
        iconCls: "vt-icon-clean",
        icon: "✓",
        text: v.category === "harmless" ? "Clean" : "Undetected"
      };
    }
    return {
      cls: "vt-v-other",
      iconCls: "vt-icon-other",
      icon: "–",
      text: "Unable to process"
    };
  }

  function openFullVirusTotalModal(data) {
    ensureContainer();
    if (modalBackdropEl) {
      modalBackdropEl.remove();
      modalBackdropEl = null;
    }

    const malicious = data.stats?.malicious || 0;
    const suspicious = data.stats?.suspicious || 0;
    const total = data.stats?.total || (data.allVendors ? data.allVendors.length : 0);
    const ringState = malicious > 0 ? "danger" : suspicious > 0 ? "warn" : "";
    const meta = data.fileMeta || {};
    const vendors = Array.isArray(data.allVendors) ? data.allVendors : [];

    modalBackdropEl = document.createElement("div");
    modalBackdropEl.className = "vt-modal-backdrop";

    const win = document.createElement("div");
    win.className = "vt-modal-window";

    const topbar = document.createElement("div");
    topbar.className = "vt-modal-topbar";
    setSafeHtml(topbar, `
      <div class="vt-modal-title">
        <span>🛡️ VirusTotal — Security Vendors' Analysis (${contentPrefs.uiLang === "en" ? "★ = Trusted Vendor" : "★ = Авторитетный вендор"})</span>
      </div>
    `);
    const modalRightBtns = document.createElement("div");
    modalRightBtns.style.cssText = "display:flex;gap:8px;align-items:center;";

    const copyReportBtn = document.createElement("button");
    copyReportBtn.className = "vt-modal-close";
    copyReportBtn.style.color = "#38bdf8";
    copyReportBtn.textContent = contentPrefs.uiLang === "en" ? "📋 Copy Report" : "📋 Скопировать сводку";
    copyReportBtn.addEventListener("click", () => {
      const reportText = [
        `🛡️ VT Download Guard v1.3 — Отчёт проверки`,
        `Файл: ${data.filename || "—"}`,
        `SHA-256: ${meta.sha256 || "—"}`,
        `Результат: ${malicious} угроз / ${suspicious} подозрит. из ${total} АВ`,
        `Тип: ${meta.magicDesc || meta.typeTag || data.ext || "—"}`,
        `Ссылка VT: ${data.reportUrl || "—"}`
      ].join("\n");
      navigator.clipboard.writeText(reportText);
      copyReportBtn.textContent = contentPrefs.uiLang === "en" ? "✓ Copied to clipboard!" : "✓ Скопировано в буфер!";
      setTimeout(() => { copyReportBtn.textContent = contentPrefs.uiLang === "en" ? "📋 Copy Report" : "📋 Скопировать сводку"; }, 1800);
    });
    modalRightBtns.appendChild(copyReportBtn);

    const closeModalBtn = document.createElement("button");
    closeModalBtn.className = "vt-modal-close";
    closeModalBtn.textContent = contentPrefs.uiLang === "en" ? "✕ Close Window" : "✕ Закрыть окно";
    closeModalBtn.addEventListener("click", () => {
      modalBackdropEl.remove();
      modalBackdropEl = null;
    });
    modalRightBtns.appendChild(closeModalBtn);
    topbar.appendChild(modalRightBtns);
    win.appendChild(topbar);

    const heroRow = document.createElement("div");
    heroRow.className = "vt-hero-row";

    const bannerText =
      malicious > 0
        ? `🚨 ${malicious} из ${total} антивирусных вендоров пометили этот файл как вредоносный`
        : suspicious > 0
        ? `⚠️ ${suspicious} из ${total} антивирусных вендоров пометили этот файл как подозрительный`
        : `✓ Ни один антивирусный вендор не пометил этот файл как вредоносный (No security vendors flagged this file as malicious)`;

    setSafeHtml(heroRow, `
      <div class="vt-score-box">
        <div class="vt-circle-ring ${ringState}">
          <span class="vt-ring-num">${malicious}</span>
          <span class="vt-ring-total">/ ${total}</span>
        </div>
        <div class="vt-community-label">Community<br/>Score</div>
      </div>
      <div class="vt-summary-panel">
        <div class="vt-summary-banner ${ringState}">
          <span>${bannerText}</span>
          ${
            data.reportUrl
              ? `<a href="${data.reportUrl.replace(/\s+/g, "")}" target="_blank" rel="noopener noreferrer" class="vt-link" style="color:#60a5fa;">Открыть на virustotal.com ↗</a>`
              : ""
          }
        </div>
        <div class="vt-summary-meta-row">
          <div class="vt-meta-main">
            <div class="vt-sha256-line">${meta.sha256 || "SHA-256"}</div>
            <div class="vt-file-title-line">${data.filename || "Файл"}</div>
            <span class="vt-type-pill">${meta.typeTag || data.ext || "file"}</span>
          </div>
          <div class="vt-meta-columns">
            <div class="vt-meta-col">
              <span class="vt-meta-col-label">Size (Размер)</span>
              <span class="vt-meta-col-val">${meta.sizeFormatted || "—"}</span>
            </div>
            <div class="vt-meta-col">
              <span class="vt-meta-col-label">Last Analysis Date</span>
              <span class="vt-meta-col-val">${meta.analysisDate || "Только что"}</span>
            </div>
          </div>
        </div>
      </div>
    `);
    win.appendChild(heroRow);

    const tabsBar = document.createElement("div");
    tabsBar.className = "vt-tabs-bar";

    const tabsLeft = document.createElement("div");
    tabsLeft.className = "vt-tabs-left";

    const tabDetectionBtn = document.createElement("button");
    tabDetectionBtn.className = "vt-tab-btn active";
    tabDetectionBtn.textContent = `DETECTION (${vendors.length})`;

    const tabDetailsBtn = document.createElement("button");
    tabDetailsBtn.className = "vt-tab-btn";
    tabDetailsBtn.textContent = contentPrefs.uiLang === "en" ? "DETAILS" : "DETAILS (ДЕТАЛИ)";

    tabsLeft.appendChild(tabDetectionBtn);
    tabsLeft.appendChild(tabDetailsBtn);

    const searchInput = document.createElement("input");
    searchInput.type = "text";
    searchInput.className = "vt-vendor-search";
    searchInput.placeholder = contentPrefs.uiLang === "en" ? "🔍 Search antivirus (Kaspersky, DrWeb, ESET...)" : "🔍 Поиск антивируса (Kaspersky, DrWeb, Avast...)";

    tabsBar.appendChild(tabsLeft);
    tabsBar.appendChild(searchInput);
    win.appendChild(tabsBar);

    const modalBody = document.createElement("div");
    modalBody.className = "vt-modal-body";
    win.appendChild(modalBody);

    const modalFooter = document.createElement("div");
    modalFooter.className = "vt-modal-credits";
    setSafeHtml(modalFooter, `<span class="vt-credit-left">by SalmonPlay1</span><a href="https://www.donationalerts.com/r/salmonplay1" target="_blank" rel="noopener noreferrer" class="vt-credit-donate" title="Поддержать (DonationAlerts)"><svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0;"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg><span>${isEn ? "Donate" : "Донат"}</span></a><span class="vt-credit-right">by LososKiler</span>`);
    modalFooter.querySelectorAll("a").forEach(a => a.addEventListener("click", e => e.stopPropagation()));
    win.appendChild(modalFooter);

    let currentTab = "detection";

    function renderModalTabContent() {
      modalBody.textContent = "";
      if (currentTab === "detection") {
        searchInput.style.display = "block";
        const heading = document.createElement("div");
        heading.className = "vt-section-heading";
        setSafeHtml(heading, `
          <span>Security vendors' analysis ⓘ</span>
          <span style="font-size:11.5px; color:#94a3b8;">★ — авторитетный вендор | Всего движков: ${vendors.length}</span>
        `);
        modalBody.appendChild(heading);

        const filterRow = document.createElement("div");
        filterRow.style.cssText = "display:flex;gap:6px;margin-bottom:10px;flex-wrap:wrap;";
        const curVFilter = win.__vendorFilterMode || "all";
        const trustedTotal = vendors.filter(v => v.trusted).length;
        const flaggedTotal = vendors.filter(v => v.category === "malicious" || v.category === "suspicious").length;

        [
          { id: "all", label: `Все движки (${vendors.length})` },
          { id: "trusted", label: `★ Авторитетные АВ (${trustedTotal})` },
          { id: "flagged", label: `⚠️ Только сработавшие (${flaggedTotal})` }
        ].forEach((fItem) => {
          const fBtn = document.createElement("button");
          const isAct = curVFilter === fItem.id;
          fBtn.style.cssText = `background:${isAct ? "#2563eb" : "#1d2433"};color:${isAct ? "#fff" : "#94a3b8"};border:1px solid ${isAct ? "#60a5fa" : "#2a3246"};border-radius:6px;padding:4px 10px;font-size:11.5px;font-weight:600;cursor:pointer;`;
          fBtn.textContent = fItem.label;
          fBtn.addEventListener("click", () => {
            win.__vendorFilterMode = fItem.id;
            renderModalTabContent();
          });
          filterRow.appendChild(fBtn);
        });
        modalBody.appendChild(filterRow);

        const q = searchInput.value.trim().toLowerCase();
        let filtered = vendors;
        if (curVFilter === "trusted") {
          filtered = filtered.filter(v => v.trusted);
        } else if (curVFilter === "flagged") {
          filtered = filtered.filter(v => v.category === "malicious" || v.category === "suspicious");
        }
        if (q) {
          filtered = filtered.filter(
            v =>
              v.engine.toLowerCase().includes(q) ||
              (v.result && v.result.toLowerCase().includes(q))
          );
        }

        const grid = document.createElement("div");
        grid.className = "vt-vendors-two-col";

        for (const v of filtered) {
          const b = formatVendorBadge(v);
          const row = document.createElement("div");
          row.className = "vt-vendor-row";

          const leftName = document.createElement("span");
          leftName.className = "vt-vendor-row-name";
          setSafeHtml(leftName, `${v.engine}${v.trusted ? '<span class="vt-trusted-star" title="Авторитетный антивирусный вендор">★</span>' : ""}`);

          const rightRes = document.createElement("span");
          rightRes.className = `vt-vendor-row-res ${b.cls}`;
          setSafeHtml(rightRes, `
            <span class="vt-icon-circle ${b.iconCls}">${b.icon}</span>
            <span>${b.text}</span>
          `);

          row.appendChild(leftName);
          row.appendChild(rightRes);
          grid.appendChild(row);
        }

        modalBody.appendChild(grid);
      } else {
        searchInput.style.display = "none";
        const detailsBox = document.createElement("div");
        detailsBox.className = "vt-details-box";
        setSafeHtml(detailsBox, `
          <div class="vt-detail-line">
            <span class="vt-detail-key">Имя файла</span>
            <span class="vt-detail-val">${data.filename || "—"}</span>
          </div>
          <div class="vt-detail-line">
            <span class="vt-detail-key">SHA-256</span>
            <span class="vt-detail-val">${meta.sha256 || "—"}</span>
          </div>
          ${
            meta.md5
              ? `<div class="vt-detail-line"><span class="vt-detail-key">MD5</span><span class="vt-detail-val">${meta.md5}</span></div>`
              : ""
          }
          ${
            meta.sha1
              ? `<div class="vt-detail-line"><span class="vt-detail-key">SHA-1</span><span class="vt-detail-val">${meta.sha1}</span></div>`
              : ""
          }
          <div class="vt-detail-line">
            <span class="vt-detail-key">Размер файла</span>
            <span class="vt-detail-val">${meta.sizeFormatted || "—"}</span>
          </div>
          <div class="vt-detail-line">
            <span class="vt-detail-key">Тип / Сигнатура</span>
            <span class="vt-detail-val">${meta.magicDesc || meta.typeTag || data.ext || "—"}</span>
          </div>
          ${
            Array.isArray(meta.zipEntries) && meta.zipEntries.length > 0
              ? `<div class="vt-detail-line"><span class="vt-detail-key">Содержимое ZIP (без распаковки)</span><span class="vt-detail-val">${meta.zipEntries.join(", ")}</span></div>`
              : ""
          }
          <div class="vt-detail-line">
            <span class="vt-detail-key">Дата последнего анализа</span>
            <span class="vt-detail-val">${meta.analysisDate || "Только что"}</span>
          </div>
        `);
        modalBody.appendChild(detailsBox);
      }
    }

    tabDetectionBtn.addEventListener("click", () => {
      currentTab = "detection";
      tabDetectionBtn.classList.add("active");
      tabDetailsBtn.classList.remove("active");
      renderModalTabContent();
    });

    tabDetailsBtn.addEventListener("click", () => {
      currentTab = "details";
      tabDetailsBtn.classList.add("active");
      tabDetectionBtn.classList.remove("active");
      renderModalTabContent();
    });

    searchInput.addEventListener("input", () => {
      if (currentTab === "detection") renderModalTabContent();
    });

    modalBackdropEl.addEventListener("click", (e) => {
      if (e.target === modalBackdropEl) {
        modalBackdropEl.remove();
        modalBackdropEl = null;
      }
    });

    renderModalTabContent();
    modalBackdropEl.appendChild(win);
    shadowRoot.appendChild(modalBackdropEl);
  }


  const FONT_STACK_MAP = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, Arial, sans-serif',
    monospace: '"JetBrains Mono", Consolas, "Courier New", monospace',
    cyber: 'Bahnschrift, "Arial Black", Impact, "Segoe UI", sans-serif',
    rounded: '"Trebuchet MS", Nunito, Verdana, sans-serif',
    serif: 'Georgia, "Palatino Linotype", "Times New Roman", serif',
    impact: 'Impact, "Arial Black", sans-serif',
    comic: '"Comic Sans MS", cursive, sans-serif',
    terminal: '"Courier New", Lucida Console, monospace'
  };

  const THEME_TO_STICKER_MAP = {
    salmon_ocean: "salmon",
    helldivers2: "helldivers",
    ozen_abyss: "ozen",
    vocaloid_teto: "teto",
    vocaloid_miku: "miku",
    dark_cyber: "cyber",
    oled_matrix: "matrix",
    purple_synth: "synth",
    crimson_guard: "crimson",
    light_clean: "star"
  };

  let injectedCustomFontUrl = "";

  function ensureCustomFontsLoaded(data) {
    try {
      if (data.customFontName && !document.getElementById("vt-guard-gfont")) {
        const link = document.createElement("link");
        link.id = "vt-guard-gfont";
        link.rel = "stylesheet";
        link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(data.customFontName.trim())}:wght@400;600;700;800&display=swap`;
        document.head?.appendChild(link);
      }
      if ((data.customFontDataUrl || localCustomAssets.customFontDataUrl) && (data.customFontDataUrl || localCustomAssets.customFontDataUrl) !== injectedCustomFontUrl && window.FontFace) {
        injectedCustomFontUrl = (data.customFontDataUrl || localCustomAssets.customFontDataUrl);
        const ff = new FontFace("VTGuardUserFont", `url(${(data.customFontDataUrl || localCustomAssets.customFontDataUrl)})`);
        ff.load().then((loaded) => {
          document.fonts?.add(loaded);
        }).catch(() => {});
      }
    } catch (_) {}
  }

  function applyCardCustomVisuals(card, data) {
    ensureCustomFontsLoaded(data);
    const theme = data.theme || "salmon_ocean";
    const fontKey = data.customFontFamily || "system";
    const scale = Math.max(80, Math.min(125, Number(data.customFontScale) || 100)) / 100;
    const radius = data.customBorderRadius !== undefined ? Number(data.customBorderRadius) : 14;
    const panelAlpha = Math.max(0, Math.min(100, Number(data.cardBgOpacity ?? 48))) / 100;

    let resolvedFont = FONT_STACK_MAP[fontKey] || FONT_STACK_MAP.system;
    if (fontKey === "custom_file" && (data.customFontDataUrl || localCustomAssets.customFontDataUrl)) {
      resolvedFont = '"VTGuardUserFont", ' + FONT_STACK_MAP.system;
    } else if (fontKey === "custom_name" && data.customFontName) {
      resolvedFont = `"${data.customFontName.trim()}", ` + FONT_STACK_MAP.system;
    }

    card.style.position = "relative";
    card.style.overflowY = "auto";
    card.style.overflowX = "hidden";
    card.style.fontFamily = resolvedFont;
    card.style.borderRadius = `${radius}px`;
    card.style.zoom = String(scale);
    const animStyle = data.cardAnimStyle || "slide";
    if (animStyle !== "slide") {
      card.classList.add(`anim-${animStyle}`);
    }
    const glowPct = Math.max(0, Math.min(100, Number(data.neonGlowIntensity ?? 35)));
    if (glowPct > 0) {
      const glowColor = data.verdict === "danger" ? "#ef4444" : data.verdict === "warning" ? "#f59e0b" : (data.customColorsEnabled && data.customAccentColor ? data.customAccentColor : "#38bdf8");
      const blurPx = Math.round(glowPct * 0.32);
      const alphaHex = Math.round((glowPct / 100) * 140).toString(16).padStart(2, "0");
      card.style.boxShadow = `0 0 ${blurPx}px ${glowColor}${alphaHex}, 0 18px 25px -5px rgba(0, 0, 0, 0.65)`;
    }
    card.style.setProperty("--vt-panel-alpha", `${Math.round(panelAlpha * 100)}%`);

    if (data.customColorsEnabled) {
      if (data.customBgColor) card.style.background = data.customBgColor;
      if (data.customAccentColor) card.style.borderColor = data.customAccentColor;
    }

    if (data.customTextColorEnabled) {
      if (data.customTextMainColor) card.style.color = data.customTextMainColor;
      card.style.setProperty("--vt-custom-text-main", data.customTextMainColor || "#f8fafc");
      card.style.setProperty("--vt-custom-text-sub", data.customTextSubColor || "#94a3b8");
    } else {
      card.style.removeProperty("--vt-custom-text-main");
      card.style.removeProperty("--vt-custom-text-sub");
    }

    // 1. Фоновая картинка темы (или пользовательский арт)
    if (data.bgImageEnabled !== false) {
      let bgUrl = "";
      if ((data.customBgDataUrl || localCustomAssets.customBgDataUrl)) {
        bgUrl = (data.customBgDataUrl || localCustomAssets.customBgDataUrl);
      } else {
        try {
          bgUrl = chrome.runtime.getURL(`backgrounds/bg_${theme}.png`);
        } catch (_) {}
      }
      if (bgUrl) {
        const bgLayer = document.createElement("div");
        bgLayer.className = "vt-bg-decor-layer";
        const op = Math.max(5, Math.min(85, Number(data.bgOpacity ?? 36))) / 100;
        bgLayer.style.cssText = `position:absolute;inset:0;background-image:url("${bgUrl}");background-size:cover;background-position:center;opacity:${op};pointer-events:none;z-index:0;`;
        card.appendChild(bgLayer);
      }
    }

    // 2. Стикер / Маскот поверх фона
    if (data.stickersEnabled !== false) {
      const sPreset = data.stickerPreset || "auto_theme";
      let stickerUrl = "";
      if (sPreset === "custom" && (data.customStickerDataUrl || localCustomAssets.customStickerDataUrl)) {
        stickerUrl = (data.customStickerDataUrl || localCustomAssets.customStickerDataUrl);
      } else {
        const sKey = sPreset === "auto_theme" ? (THEME_TO_STICKER_MAP[theme] || "salmon") : sPreset;
        try {
          stickerUrl = chrome.runtime.getURL(`stickers/sticker_${sKey}.png`);
        } catch (_) {}
      }
      if (stickerUrl) {
        const stEl = document.createElement("img");
        stEl.className = "vt-bg-decor-layer";
        stEl.src = stickerUrl;
        const sz = Math.max(30, Math.min(200, Number(data.stickerSize) || 78));
        const op = Math.max(10, Math.min(100, Number(data.stickerOpacity ?? 85))) / 100;
        const pos = data.stickerPosition || "bottom-right";
        let posCss = "bottom:8px;right:10px;";
        if (pos === "top-right") posCss = "top:28px;right:10px;";
        else if (pos === "bottom-left") posCss = "bottom:8px;left:10px;";
        else if (pos === "center") posCss = "top:50%;left:50%;transform:translate(-50%,-50%);";
        else if (pos === "custom_xy") posCss = `left:${Number(data.stickerCustomX ?? 80)}%;top:${Number(data.stickerCustomY ?? 75)}%;transform:translate(-50%,-50%);`;
        stEl.style.cssText = `position:absolute;${posCss}width:${sz}px;height:${sz}px;object-fit:contain;opacity:${op};pointer-events:none;z-index:0;filter:drop-shadow(0 4px 10px rgba(0,0,0,0.65));`;
        card.appendChild(stEl);
      }
    }
  }

  // ==================== v1.0: ПОЛНЫЙ ПЕРЕВОД ПЛАШКИ НА АНГЛИЙСКИЙ (RU <-> EN) ====================
  const CONTENT_RU_EN_EXACT = {
    "Угрозы": "Threats",
    "Подозрит.": "Suspicious",
    "Чисто": "Clean",
    "Проверено": "Scanned",
    "Проверяемый файл": "Scanned File",
    "Закрыть плашку": "Close card",
    "✓ Файл чист и автоматически сохранён!": "✓ File is clean and automatically saved!",
    "📂 Показать в папке": "📂 Show in folder",
    "⭐ Доверять": "⭐ Trust",
    "✓ В белом списке!": "✓ Whitelisted!",
    "🌐 Страница VT ↗": "🌐 VT Page ↗",
    "🌐 Сайт VirusTotal ↗": "🌐 VirusTotal Web ↗",
    "📤 Отправить в VT": "📤 Upload to VT",
    "Отправка...": "Uploading...",
    "🔒 Строгий карантин (файл удалён)": "🔒 Strict Quarantine (file removed)",
    "Удалить файл": "Delete File",
    "Заблокировать": "Block",
    "Разблокировать и скачать": "Unblock & Download",
    "Всё равно скачать": "Download Anyway",
    "Скачать файл": "Download File",
    "Сохранение...": "Saving...",
    "📂 Проверить сам файл": "📂 Scan Downloaded File",
    "⏳ Расчёт SHA-256 файла...": "⏳ Hashing file...",
    "Развернуть во весь экран ⤢": "Expand Full Screen ⤢",
    "📋 Скопировать сводку": "📋 Copy Report",
    "✓ Скопировано!": "✓ Copied!",
    "🛡️ Проверить ссылку в VT": "🛡️ Scan Link in VT",
    "🔎 Проверить выделенное в VT": "🔎 Scan Selection in VT"
  };

  function trCardStr(str, isEn) {
    if (!isEn || !str) return str;
    let s = String(str);
    if (CONTENT_RU_EN_EXACT[s]) return CONTENT_RU_EN_EXACT[s];
    const replacements = [
      ["🟢 БЕЗОПАСНО (Угроз не найдено)", "🟢 SAFE (No threats found)"],
      ["🟢 БЕЗОПАСНО (Проверенный файл)", "🟢 SAFE (Verified file)"],
      ["🟢 БЕЗОПАСНО: Игровой фикс / Мод (Угроз: 0)", "🟢 SAFE: Game Fix / Mod (Threats: 0)"],
      ["🟡 УСЛОВНЫЙ РИСК: Игровой фикс / Кряк / Мод (HackTool)", "🟡 CONDITIONAL RISK: Game Fix / Crack / Mod (HackTool)"],
      ["🟡 НИЗКИЙ РИСК: Вероятно ложная ИИ-эвристика (False Positive)", "🟡 LOW RISK: Likely AI False Positive"],
      ["🟡 ВНИМАНИЕ: Запароленный архив (Содержимое скрыто от АВ)", "🟡 WARNING: Password-Protected Archive (Hidden from AV)"],
      ["🟠 СРЕДНИЙ РИСК: Рекламный установщик (Adware / PUA)", "🟠 MEDIUM RISK: Adware / PUA Installer"],
      ["🟠 ВЫСОКАЯ ОПАСНОСТЬ: Скрытый майнер криптовалюты!", "🟠 HIGH DANGER: Hidden Crypto Miner!"],
      ["🔴 КРИТИЧЕСКАЯ ОПАСНОСТЬ: Стилер паролей и аккаунтов!", "🔴 CRITICAL DANGER: Password & Account Stealer!"],
      ["🔴 КРИТИЧЕСКАЯ ОПАСНОСТЬ: Троян удалённого доступа (RAT)!", "🔴 CRITICAL DANGER: Remote Access Trojan (RAT)!"],
      ["🔴 КРИТИЧЕСКАЯ ОПАСНОСТЬ: Вирус-шифровальщик (Ransomware)!", "🔴 CRITICAL DANGER: Ransomware Encryptor!"],
      ["🔴 ОПАСНЫЙ ФАЙЛ", "🔴 DANGEROUS FILE"],
      ["🟡 ПОДОЗРИТЕЛЬНЫЙ ФАЙЛ", "🟡 SUSPICIOUS FILE"],
      ["Жалоб антивирусов:", "AV Detections:"],
      ["Жалоб:", "Detections:"],
      ["🎯 Чем может являться файл:", "🎯 What this file could be:"],
      ["Игровой сетевой фикс (Online-Fix / FreeTP), кряк (Crack / HackTool), трейнер или модификация для запуска игры и кооператива по сети", "Multiplayer Game Fix (Online-Fix / FreeTP), Crack / HackTool, Trainer, or DRM modification for online co-op"],
      ["Троян-стилер паролей и аккаунтов (Infostealer / PWS), замаскированный под программу, кряк или установщик", "Password & Account Stealer Trojan (Infostealer / PWS) disguised as a program, crack, or installer"],
      ["Троян удалённого доступа и скрытого управления компьютером (RAT / Backdoor) под видом обычного файла", "Remote Access Trojan (RAT / Backdoor) disguised as a regular file"],
      ["Вирус-шифровальщик файлов (Ransomware / Вымогатель).", "Ransomware File Encryptor."],
      ["Скрытый майнер криптовалюты (CoinMiner / XMRig), встроенный в установщик или репак", "Hidden Cryptocurrency Miner (CoinMiner / XMRig) bundled inside an installer or repack"],
      ["Рекламный установщик (Adware / PUA / Bundle), который вместе с основной программой пытается установить партнёрское ПО или рекламу.", "Adware / PUA Bundle Installer that attempts to install sponsored software or ads."],
      ["Обычная программа или установщик", "Regular program or installer"],
      ["сжатый упаковщиком кода (UPX / NSIS / InnoSetup), на который ложно среагировала ИИ-эвристика малоизвестного АВ.", "packed with a standard compressor (UPX / NSIS / InnoSetup) that triggered a false positive from a minor AI engine."],
      ["Подозрительный исполняемый файл, модифицированный установщик или потенциальный троян-загрузчик", "Suspicious executable, modified installer, or potential trojan downloader"],
      ["Легитимный установщик программы или обновление для Windows", "Legitimate program installer or Windows update"],
      ["Безопасная исполняемая программа или портативное приложение для Windows", "Safe executable program or portable Windows application"],
      ["Сжатый архив или образ диска", "Compressed archive or disk image"],
      ["с файлами программы, мода или документами.", "containing program files, mod assets, or documents."],
      ["Торрент-файл раздачи BitTorrent (.torrent) со списком скачиваемых файлов и адресом трекера.", "BitTorrent distribution file (.torrent) containing file list metadata and tracker URL."],
      ["Установочный пакет приложения для Android", "Android Application Package"],
      ["Динамическая библиотека или системный модуль", "Dynamic Link Library or system module"],
      ["Проверенный безопасный файл формата", "Verified safe file of type"],
      ["угроз не выявлено", "no threats detected"],
      ["Официально подписанная программа или установщик для Windows (.exe).", "Officially signed Windows program or installer (.exe)."],
      ["Ни один антивирусный движок и локальный инспектор не предъявили претензий к этому файлу.", "No antivirus engine or local inspector flagged any issues with this file."],
      ["Ни один из 72 антивирусов не предъявил претензий. Локальный инспектор подтвердил целостность структуры.", "None of the 72 antivirus engines found any issues. Local inspector confirmed structural integrity."],
      ["Все проверки пройдены, жалоб антивирусов нет", "All checks passed, 0 antivirus complaints"],
      ["Файл можно безопасно открывать и использовать.", "This file is safe to open and use."],
      ["✅ Файл полностью безопасен для запуска.", "✅ This file is completely safe to run."],
      ["Антивирусы и анализатор жалуются на код кражи паролей из браузеров, куки-файлов и сессий Steam / Discord / Telegram (Stealer / PWS).", "Antivirus engines & analyzer flagged code that steals browser passwords, cookies, and Steam / Discord / Telegram sessions (Stealer / PWS)."],
      ["⛔ КАТЕГОРИЧЕСКИ НЕ ЗАПУСКАТЬ! Удалите этот файл, иначе ваши аккаунты могут быть угнаны.", "⛔ DO NOT RUN! Delete this file immediately to protect your accounts from theft."],
      ["⛔ КАТЕГОРИЧЕСКИ НЕ ЗАПУСКАТЬ! Немедленно удалите файл.", "⛔ DO NOT RUN! Delete this file immediately."],
      ["⛔ НЕМЕДЛЕННО УДАЛИТЬ ФАЙЛ!", "⛔ DELETE THIS FILE IMMEDIATELY!"],
      ["жалуются на обход лицензионной защиты игры (HackTool / Crack / OnlineFix / модификация steam_api), а не на боевой троян.", "flagged game DRM bypass code (HackTool / Crack / OnlineFix / steam_api modification), not a destructive trojan."],
      ["Антивирусы (", "Antivirus engines ("],
      [" шт.) ", " total) "],
      ["ℹ️ Если вы сами скачивали пиратский сетевой фикс, кряк или трейнер с проверенного источника — такая реакция антивирусов ожидаема.", "ℹ️ If you intentionally downloaded a multiplayer fix, crack, or trainer from a trusted source, this antivirus reaction is expected."],
      ["🎮 Игровой модуль / Сетевой фикс", "🎮 Game Module / Online Fix"],
      ["обращается к Steam API / мультиплееру игры", "interacts with Steam API / game multiplayer"],
      ["модифицирует или подменяет файлы защиты игры (steam_api.dll / OnlineFix64.dll) для эмуляции лицензии", "modifies or emulates game DRM libraries (steam_api.dll / OnlineFix64.dll)"],
      ["💉 Инъекция в память процесса: внедряется в запущенный процесс игры (Hook / Inject) для разблокировки сетевого режима, DLC или функций трейнера", "💉 Process Memory Injection: hooks into the running game process to unlock multiplayer, DLC, or trainer features"],
      ["💉 Инъекция в память: умеет встраиваться в другие запущенные программы или менять память игры", "💉 Memory Injection: can inject into running processes or modify game memory"],
      ["💉 Модификация процесса / DRM: перехватывает вызовы лицензии (steam_api / OnlineFix) для работы кооператива или фикса", "💉 Process / DRM Modification: intercepts license calls (steam_api / OnlineFix) for co-op or fix functionality"],
      ["🌐 Сетевой доступ: подключается к серверам Steam / Epic Games / EOS для соединения игроков в мультиплеере", "🌐 Network Access: connects to Steam / Epic Games / EOS servers for multiplayer matchmaking"],
      ["🌐 Сетевой доступ: умеет подключаться к интернету и передавать/скачивать данные", "🌐 Network Access: can connect to the internet and send/download data"],
      ["🌐 Сетевой доступ: умеет подключаться к игровым серверам для синхронизации по сети", "🌐 Network Access: connects to game servers for network synchronization"],
      ["🌐 Сетевой доступ: используется только для проверки обновлений", "🌐 Network Access: used only for update checks"],
      ["🛡️ Проверка на шпионаж: сигнатур кражи паролей браузера, куки-файлов и угона сессий (Stealer / RAT) не обнаружено", "🛡️ Spyware Check: no signatures of browser password theft, cookies, or session hijacking (Stealer / RAT) found"],
      ["🛡️ Скрытых стилеров, майнеров или команд автозагрузки не обнаружено", "🛡️ No hidden stealers, miners, or autorun persistence commands detected"],
      ["🔓 Чтение паролей и сессий: пытается скрытно извлечь пароли и куки из браузеров, сессии Steam, Discord, Telegram (tdata) и криптокошельки", "🔓 Password & Session Theft: attempts to extract browser passwords/cookies, Steam, Discord, Telegram (tdata), and crypto wallets"],
      ["🔓 Чтение паролей и сессий: пытается расшифровать данные браузеров (DPAPI) или папку tdata", "🔓 Password & Session Theft: attempts to decrypt browser credentials (DPAPI) or Telegram tdata"],
      ["🌐 Скрытая пересылка данных: отправляет собранные данные пользователя на удалённый сервер злоумышленника (C2 / Telegram-бот)", "🌐 Covert Exfiltration: sends stolen credentials to a remote attacker server (C2 / Telegram bot)"],
      ["⚙️ Изменение системы: может менять ключи реестра Windows или добавляться в автозагрузку", "⚙️ System Modification: can modify Windows Registry keys or add autorun persistence"],
      ["⚙️ Установка приложения: распаковывает файлы программы в выбранную папку, создаёт ярлыки и выполняет штатную настройку", "⚙️ Application Installer: unpacks program files, creates shortcuts, and performs standard setup"],
      ["⚙️ Штатный запуск приложения: выполняет функции программы в рамках прав пользователя без скрытых вредоносных инструкций", "⚙️ Standard Application Execution: runs normal program functions within user permissions with no hidden malicious code"],
      ["📦 Архивный контейнер: хранит сжатые файлы для распаковки на диск (сам архив без запуска вложенных файлов код не выполняет)", "📦 Archive Container: stores compressed files for extraction (does not execute code by itself)"],
      ["📄 Формат объекта: Исполняемый модуль Windows PE (.exe) — проверен по облачной базе антивирусов VirusTotal", "📄 Object Format: Windows PE Executable (.exe) — verified against VirusTotal cloud database"],
      ["🔏 Цифровая подпись:", "🔏 Digital Signature:"],
      ["(файл официально подписан)", "(officially signed file)"],
      ["⚠️ Цифровая подпись отсутствует: создатель .exe файла официально не подтверждён", "⚠️ No Digital Signature: the publisher of this .exe file is not officially verified"],
      ["📦 Содержимое архива (", "📦 Archive Contents ("],
      [" файлов):", " files):"],
      ["🧲 Файлы внутри торрент-раздачи:", "🧲 Files inside torrent:"],
      ["🌐 Возраст домена ", "🌐 Domain age of "],
      ["🔓 Кража паролей / Сессий", "🔓 Password / Session Theft"],
      ["💉 Память / Игровой фикс", "💉 Memory / Game Fix"],
      ["🌐 Сетевая активность", "🌐 Network Activity"],
      ["⚙️ Автозагрузка / Система", "⚙️ Autorun / System"],
      ["⛏️ Нагрузка GPU / Майнинг", "⛏️ GPU Load / Mining"],
      ["Угроз не обнаружено (0 из ", "No threats detected (0 of "],
      [" антивирусов)", " antivirus engines)"],
      [" анализаторов)", " analyzers)"],
      ["АВТОБЛОКИРОВКА! Сработало антивирусов: ", "AUTO-BLOCKED! Antivirus detections: "],
      ["Обнаружена угроза: сработало ", "Threat detected: triggered "],
      ["Обнаружена угроза: ", "Threat detected: "],
      ["Подозрительный файл: предупреждений ", "Suspicious file: warnings "],
      ["Подозрительный объект: ", "Suspicious object: "],
      ["Возможна ложная тревога (False Positive): сработало ", "Possible False Positive: triggered "],
      ["Потоковый расчёт SHA-256 чанками и проверка сигнатур / ZIP / полиглотов...", "Streaming SHA-256 calculation & inspecting signatures / ZIP / polyglots..."],
      ["Приватный запрос по SHA-256", "Private SHA-256 lookup"],
      ["в базу VirusTotal без отправки файла...", "in VirusTotal database without uploading the file..."],
      ["Анализ файла", "Analyzing file"],
      ["и сигнатур безопасности в облаке VirusTotal...", "and security signatures in VirusTotal cloud..."],
      ["Бесключевой режим: проверка SHA-256 по открытым базам (MalwareBazaar / CIRCL) и локальному инспектору...", "Zero-Key Mode: checking SHA-256 against open threat feeds (MalwareBazaar / CIRCL) & local inspector..."],
      ["АВ реагируют на игровой фикс / обход DRM", "AVs reacted to game fix / DRM bypass"],
      ["жалоб:", "detections:"],
      ["а не на стилер", "not a stealer"],
      ["0 угроз в базах АВ (но у .exe отсутствует цифровая подпись издателя)", "0 threats in AV databases (unsigned .exe publisher)"],
      ["0 угроз + подтверждённая цифровая подпись разработчика (PE Authenticode)", "0 threats + verified developer digital signature (PE Authenticode)"],
      ["Демо-предпросмотр плашки: 0 из 72 антивирусов (Ваша тема, фоновый арт и умная сводка применены!)", "Demo Card Preview: 0 of 72 antivirus engines (Your theme, background art & smart summary applied!)"],
      ["Только что", "Just now"]
    ];
    for (const [ru, en] of replacements) {
      if (s.includes(ru)) s = s.split(ru).join(en);
    }
    return s;
  }

  function renderCard(data) {
    const stack = ensureContainer();
    applyHostPosition(data.bannerPosition || "top-right", data.scanWindowDisplayMode || "card_on_top");
    const isEn = (data.uiLang || contentPrefs.uiLang) === "en";
    if (isEn) {
      if (data.summaryText) data.summaryText = trCardStr(data.summaryText, true);
      if (data.stepText) data.stepText = trCardStr(data.stepText, true);
      if (data.smartSummary) {
        const sm = data.smartSummary;
        sm.riskBadge = trCardStr(sm.riskBadge, true);
        sm.trustReason = trCardStr(sm.trustReason, true);
        sm.whatFileCouldBe = trCardStr(sm.whatFileCouldBe, true);
        sm.whatComplains = trCardStr(sm.whatComplains, true);
        sm.recommendation = trCardStr(sm.recommendation, true);
        if (Array.isArray(sm.capabilities)) {
          sm.capabilities = sm.capabilities.map(c => trCardStr(c, true));
        }
        if (Array.isArray(sm.radarMetrics)) {
          sm.radarMetrics = sm.radarMetrics.map(m => ({ ...m, label: trCardStr(m.label, true) }));
        }
      }
    }
    let card = cards.get(data.scanId);
    if (card && data.state === "scanning" && card.classList.contains("vt-scanning")) {
      const existingStepEl = card.querySelector(".vt-step-text");
      if (existingStepEl) {
        existingStepEl.textContent = data.stepText || (isEn ? "Scanning in VirusTotal..." : "Проверка в VirusTotal...");
        return;
      }
    }
    if (!card) {
      card = document.createElement("div");
      // Если уже открыты другие карточки, автоматически сворачиваем старые завершённые карточки, чтобы новое окно было полностью открыто, а старые можно было развернуть в 1 клик!
      for (const [oldId, oldEl] of cards.entries()) {
        if (oldId !== data.scanId && !oldEl.classList.contains("vt-scanning")) {
          oldEl.classList.add("vt-card-collapsed");
          const btn = oldEl.querySelector(".vt-collapse-btn");
          if (btn) btn.textContent = isEn ? "▾ Expand" : "▾ Развернуть";
        }
      }
      cards.set(data.scanId, card);
      const toolbarEl = stack.querySelector(".vt-stack-toolbar");
      if (toolbarEl && toolbarEl.nextSibling) {
        stack.insertBefore(card, toolbarEl.nextSibling);
      } else if (toolbarEl) {
        stack.appendChild(card);
      } else {
        stack.prepend(card);
      }
    }

    const stateClass =
      data.state === "scanning"
        ? "vt-scanning"
        : data.state === "error" || data.state === "consent_required"
        ? "vt-warning"
        : data.verdict === "danger"
        ? "vt-danger"
        : data.verdict === "warning"
        ? "vt-warning"
        : "vt-safe";

    if (data.miniPillModeEnabled && data.state === "completed" && data.verdict === "safe" && !data.__forceExpanded) {
      card.className = "vt-mini-pill-hud";
      setSafeHtml(card, `
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:230px;">🛡️ ${data.filename || "Файл"}</span>
        <span style="color:#34d399;">✓ ${isEn ? "Clean" : "Чисто"} (${data.trustScore ?? 96}%)</span>
        <span style="color:#38bdf8;font-size:11px;" title="Развернуть полный отчёт">⤢</span>
        <button type="button" class="vt-pill-close" style="background:none;border:none;color:#94a3b8;cursor:pointer;font-size:15px;line-height:1;">×</button>
      `);
      card.onclick = (e) => {
        if (e.target?.classList?.contains("vt-pill-close")) {
          e.stopPropagation();
          chrome.runtime.sendMessage({ type: "VT_DISMISS_CARD", scanId: data.scanId }).catch(() => {});
          card.remove();
          cards.delete(data.scanId);
          return;
        }
        data.__forceExpanded = true;
        renderCard(data);
      };
      return;
    }

    const themeCls = `theme-${data.theme || 'salmon_ocean'}`;
    card.className = `vt-card ${stateClass} ${themeCls}`;
    card.textContent = "";
    applyCardCustomVisuals(card, data);
    if (!card.__vtBadgeClearBound) {
      card.__vtBadgeClearBound = true;
      card.addEventListener("mouseenter", () => {
        if (data.state === "completed" || data.state === "error" || data.state === "consent_required") {
          chrome.runtime.sendMessage({ type: "VT_CLEAR_BADGE" }).catch(() => {});
        }
      });
      card.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "VT_CLEAR_BADGE" }).catch(() => {});
      });
    }

    const header = document.createElement("div");
    header.className = "vt-header";

    const THEME_BRAND_TITLES = {
      salmon_ocean: "🐟 VT Salmon Ocean Guard",
      helldivers2: "💀 SUPER EARTH // VT STRATAGEM",
      ozen_abyss: "⛓️ VT Abyss Guard // Бездна",
      vocaloid_teto: "🥖 VT Guard // Teto 0401",
      vocaloid_miku: "🎵 VT Guard // Miku CV01"
    };
    const brand = document.createElement("div");
    brand.className = "vt-brand";
    brand.textContent = THEME_BRAND_TITLES[data.theme] || "🛡️ VirusTotal Guard";

    const rightHeader = document.createElement("div");
    rightHeader.style.display = "flex";
    rightHeader.style.alignItems = "center";
    rightHeader.style.gap = "6px";

    if (data.trustScore !== undefined && data.trustScore !== null && data.state === "completed") {
      const tsBadge = document.createElement("span");
      const ts = Number(data.trustScore);
      const tsColor = ts >= 80 ? "#34d399" : ts >= 50 ? "#fbbf24" : "#f87171";
      tsBadge.style.cssText = `background:rgba(15,23,42,0.75);color:${tsColor};border:1px solid ${tsColor};font-size:10.5px;font-weight:800;padding:2px 7px;border-radius:6px;`;
      tsBadge.title = "Индекс доверия файлу (0–100%) на основе АВ, подписи PE, структуры архива и репутации";
      tsBadge.textContent = isEn ? `📊 Trust: ${ts}%` : `📊 Доверие: ${ts}%`;
      rightHeader.appendChild(tsBadge);
    }

    const extBadge = document.createElement("span");
    extBadge.className = "vt-ext-badge";
    extBadge.textContent = `.${data.ext || "file"}`;

    const collapseBtn = document.createElement("button");
    collapseBtn.type = "button";
    collapseBtn.className = "vt-collapse-btn";
    collapseBtn.title = isEn ? "Collapse / Expand window" : "Свернуть / Развернуть окно проверки";
    const updateCollapseLabel = () => {
      const isCol = card.classList.contains("vt-card-collapsed");
      collapseBtn.textContent = isCol ? (isEn ? "▾ Expand" : "▾ Развернуть") : (isEn ? "▴ Collapse" : "▴ Свернуть");
    };
    updateCollapseLabel();
    collapseBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      card.classList.toggle("vt-card-collapsed");
      updateCollapseLabel();
    });

    const closeBtn = document.createElement("button");
    closeBtn.className = "vt-close";
    closeBtn.title = "Закрыть плашку";
    closeBtn.textContent = "×";
    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({ type: "VT_DISMISS_CARD", scanId: data.scanId }).catch(() => {});
      card.remove();
      cards.delete(data.scanId);
      syncStackToolbar(stack, isEn);
    });

    header.style.cursor = "pointer";
    header.title = isEn ? "Click to expand/collapse window" : "Нажмите, чтобы развернуть или свернуть окно";
    header.addEventListener("click", (e) => {
      if (e.target === closeBtn || e.target === collapseBtn) return;
      if (card.classList.contains("vt-card-collapsed") || cards.size > 1) {
        card.classList.toggle("vt-card-collapsed");
        updateCollapseLabel();
      }
    });

    rightHeader.appendChild(extBadge);
    rightHeader.appendChild(collapseBtn);
    rightHeader.appendChild(closeBtn);
    header.appendChild(brand);
    header.appendChild(rightHeader);
    card.appendChild(header);

    const fileEl = document.createElement("div");
    fileEl.className = "vt-filename";
    fileEl.textContent = data.filename || "Проверяемый файл";
    fileEl.addEventListener("click", () => {
      if (card.classList.contains("vt-card-collapsed")) {
        card.classList.remove("vt-card-collapsed");
        const cBtn = card.querySelector(".vt-collapse-btn");
        if (cBtn) cBtn.textContent = isEn ? "▴ Collapse" : "▴ Свернуть";
      }
    });
    card.appendChild(fileEl);

    if (data.autoBlocked) {
      const blockBanner = document.createElement("div");
      blockBanner.className = "vt-autoblock-banner";
      blockBanner.textContent = isEn ? `🛑 Download blocked (triggered ${data.triggeredCount} ≥ threshold ${data.blockThreshold})` : `🛑 Загрузка заблокирована (сработало ${data.triggeredCount} ≥ порога ${data.blockThreshold})`;
      card.appendChild(blockBanner);
    } else if (data.autoDownloaded) {
      const saveBanner = document.createElement("div");
      saveBanner.className = "vt-autosave-banner";
      const leftTxt = document.createElement("span");
      leftTxt.textContent = isEn ? "✓ File is clean and automatically saved!" : "✓ Файл чист и автоматически сохранён!";
      saveBanner.appendChild(leftTxt);

      if (data.downloadId !== null && data.downloadId !== undefined) {
        const showFolderBtn = document.createElement("button");
        showFolderBtn.className = "vt-folder-btn";
        showFolderBtn.textContent = isEn ? "📂 Show in folder" : "📂 Показать в папке";
        showFolderBtn.addEventListener("click", () => {
          chrome.runtime.sendMessage({ type: "VT_SHOW_IN_FOLDER", downloadId: data.downloadId });
        });
        saveBanner.appendChild(showFolderBtn);
      }
      card.appendChild(saveBanner);
    }

    const statusBox = document.createElement("div");
    statusBox.className = "vt-status-box";

    if (data.state === "scanning") {
      const row = document.createElement("div");
      row.className = "vt-spinner-row";
      const spinner = document.createElement("div");
      spinner.className = "vt-spinner";
      const text = document.createElement("div");
      text.className = "vt-step-text";
      text.textContent = data.stepText || (isEn ? "Scanning in VirusTotal..." : "Проверка в VirusTotal...");
      row.appendChild(spinner);
      row.appendChild(text);
      statusBox.appendChild(row);

      const scanActionsRow = document.createElement("div");
      scanActionsRow.className = "vt-actions";
      scanActionsRow.style.cssText = "margin-top:10px;padding-top:8px;border-top:1px solid rgba(148,163,184,0.18);display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end;";

      const skipAndSaveBtn = document.createElement("button");
      skipAndSaveBtn.type = "button";
      skipAndSaveBtn.className = "vt-btn vt-btn-primary";
      skipAndSaveBtn.style.cssText = "flex:1;min-width:190px;justify-content:center;font-weight:800;";
      skipAndSaveBtn.title = isEn
        ? "Stop waiting for scan and immediately save/download the file"
        : "Не ждать окончания проверки, сразу снять файл с паузы и сохранить (скачать)";
      skipAndSaveBtn.textContent = isEn
        ? "⚡ Cancel Scan & Save (Download)"
        : "⚡ Отменить проверку и скачать (сохранить)";
      skipAndSaveBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        skipAndSaveBtn.disabled = true;
        skipAndSaveBtn.textContent = isEn ? "✓ Saving file..." : "✓ Сохранение файла...";
        chrome.runtime.sendMessage(
          { type: "VT_SKIP_SCAN_AND_SAVE", scanId: data.scanId, filename: data.filename },
          () => {
            card.remove();
            cards.delete(data.scanId);
            syncStackToolbar(stack, isEn);
          }
        );
      });
      scanActionsRow.appendChild(skipAndSaveBtn);

      const abortDelBtn = document.createElement("button");
      abortDelBtn.type = "button";
      abortDelBtn.className = "vt-btn vt-btn-secondary";
      abortDelBtn.title = isEn ? "Cancel scan and delete paused download" : "Отменить проверку и удалить загрузку";
      abortDelBtn.textContent = isEn ? "✕ Cancel & Delete" : "✕ Удалить";
      abortDelBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        abortDelBtn.disabled = true;
        chrome.runtime.sendMessage(
          { type: "VT_CANCEL_DOWNLOAD", scanId: data.scanId },
          () => {
            card.remove();
            cards.delete(data.scanId);
            syncStackToolbar(stack, isEn);
          }
        );
      });
      scanActionsRow.appendChild(abortDelBtn);

      statusBox.appendChild(scanActionsRow);
    } else if (data.state === "error" || data.state === "consent_required") {
      statusBox.textContent = data.summaryText;
    } else if (data.state === "completed") {
      const summary = document.createElement("div");
      summary.style.fontWeight = "600";
      summary.textContent =
        data.verdict === "danger"
          ? `🚨 ${data.summaryText}`
          : data.verdict === "warning"
          ? `⚠️ ${data.summaryText}`
          : `✅ ${data.summaryText}`;
      statusBox.appendChild(summary);

      if (data.stats) {
        const grid = document.createElement("div");
        grid.className = "vt-stats-grid";
        setSafeHtml(grid, `
          <div class="vt-stat-pill">
            <span class="vt-stat-num vt-num-danger">${data.stats.malicious}</span>
            <span class="vt-stat-label">${isEn ? "Threats" : "Угрозы"}</span>
          </div>
          <div class="vt-stat-pill">
            <span class="vt-stat-num vt-num-warn">${data.stats.suspicious}</span>
            <span class="vt-stat-label">${isEn ? "Suspicious" : "Подозрит."}</span>
          </div>
          <div class="vt-stat-pill">
            <span class="vt-stat-num vt-num-safe">${data.stats.harmless}</span>
            <span class="vt-stat-label">${isEn ? "Clean" : "Чисто"}</span>
          </div>
        `);
        statusBox.appendChild(grid);
      }

      if (data.smartSummary) {
        const sm = data.smartSummary;
        const smBox = document.createElement("div");
        smBox.className = "vt-smart-summary-box";
        smBox.style.borderColor = sm.riskColor || "#38bdf8";

        const capsHtml = Array.isArray(sm.capabilities) && sm.capabilities.length > 0
          ? `<div style="font-weight:700;color:#94a3b8;margin-bottom:2px;">${isEn ? "🔍 Inside & What the file can do:" : "🔍 Что внутри и что может делать файл:"}</div>
             <ul class="vt-smart-caps-list">${sm.capabilities.map(c => `<li>${c}</li>`).join("")}</ul>`
          : "";

        const tScore = data.trustScore !== undefined && data.trustScore !== null ? Number(data.trustScore) : (sm.trustScore ?? 90);
        const tBarColor = tScore >= 80 ? "#10b981" : tScore >= 55 ? "#fbbf24" : "#ef4444";
        const trustMeterHtml = `
          <div style="margin-bottom:7px;padding:6px 8px;border-radius:6px;background:rgba(15,23,42,0.55);border:1px solid rgba(148,163,184,0.2);">
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;font-weight:700;margin-bottom:4px;">
              <span>${isEn ? "📊 Trust Score (by complaint classifier):" : "📊 Уровень доверия (по классификатору жалоб):"}</span>
              <span style="color:${tBarColor};font-size:12px;">${tScore}% / 100%</span>
            </div>
            <div style="width:100%;height:6px;background:#1e293b;border-radius:4px;overflow:hidden;">
              <div style="width:${tScore}%;height:100%;background:${tBarColor};transition:width 0.3s ease;"></div>
            </div>
            ${sm.trustReason ? `<div style="font-size:10.5px;color:#94a3b8;margin-top:3px;">${isEn ? "↳ Score basis:" : "↳ Основание оценки:"} ${sm.trustReason}</div>` : ""}
          </div>
        `;

        let xrayAndRadarHtml = "";
        if (data.xrayRadarEnabled !== false) {
          if (Array.isArray(sm.radarMetrics) && sm.radarMetrics.length > 0) {
            const barsHtml = sm.radarMetrics.map(m => {
              const pct = Math.min(100, Math.max(4, (m.score || 0) * 10));
              const col = m.score >= 7 ? "#ef4444" : m.score >= 4 ? "#fbbf24" : "#34d399";
              return `
                <div style="display:grid;grid-template-columns:145px 1fr 28px;align-items:center;gap:6px;font-size:10px;">
                  <span style="color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${m.label}</span>
                  <div style="height:4.5px;background:#1e293b;border-radius:3px;overflow:hidden;">
                    <div style="width:${pct}%;height:100%;background:${col};"></div>
                  </div>
                  <span style="text-align:right;color:${col};font-weight:700;">${m.score}/10</span>
                </div>
              `;
            }).join("");
            xrayAndRadarHtml += `
              <div style="margin:6px 0;padding:6px 8px;border-radius:6px;background:rgba(15,23,42,0.45);border:1px solid rgba(148,163,184,0.16);display:flex;flex-direction:column;gap:3px;">
                <div style="font-size:10px;font-weight:700;color:#94a3b8;margin-bottom:2px;">${isEn ? "📡 Risk Factor Radar (0–10):" : "📡 Радар факторов риска (0–10):"}</div>
                ${barsHtml}
              </div>
            `;
          }
          if (sm.xrayBreakdown) {
            const xb = sm.xrayBreakdown;
            xrayAndRadarHtml += `
              <div style="margin:5px 0;padding:5px 8px;border-radius:6px;background:rgba(15,23,42,0.45);border:1px solid rgba(148,163,184,0.16);">
                <div style="display:flex;justify-content:space-between;font-size:10px;color:#94a3b8;margin-bottom:3px;">
                  <span>${isEn ? "🔬 File Structure X-Ray (Entropy:" : "🔬 Рентген структуры файла (Энтропия:"} ${xb.entropy}/8.0)</span>
                  <span>${xb.certPct > 0 ? (isEn ? "🔏 Signed" : "🔏 Подписан") : (isEn ? "Unsigned" : "Без ЭЦП")}</span>
                </div>
                <div style="display:flex;width:100%;height:6px;border-radius:3px;overflow:hidden;gap:1px;">
                  <div style="width:${xb.headerPct}%;background:#38bdf8;" title="Заголовок (${xb.headerPct}%)"></div>
                  <div style="width:${xb.codePct}%;background:#10b981;" title="Код и секции (${xb.codePct}%)"></div>
                  <div style="width:${xb.packedPct}%;background:#a855f7;" title="Сжатые данные / Архив (${xb.packedPct}%)"></div>
                  ${xb.certPct > 0 ? `<div style="width:${xb.certPct}%;background:#facc15;" title="Цифровая подпись (${xb.certPct}%)"></div>` : ""}
                </div>
              </div>
            `;
          }
        }

        const whatCouldBeHtml = sm.whatFileCouldBe
          ? `<div class="vt-smart-complains" style="margin-bottom:5px;padding:5px 8px;border-radius:6px;background:rgba(56,189,248,0.11);border-left:3px solid ${sm.riskColor || '#38bdf8'};"><strong>${isEn ? "🎯 What this file could be:" : "🎯 Чем может являться файл:"}</strong> ${sm.whatFileCouldBe}</div>`
          : "";

        setSafeHtml(smBox, `
          <div class="vt-smart-risk-title" style="color:${sm.riskColor || '#34d399'};">
            <span>🧠 ${sm.riskBadge}</span>
          </div>
          ${trustMeterHtml}
          ${whatCouldBeHtml}
          <div class="vt-smart-complains"><strong>${isEn ? "What AVs flag:" : "На что жалуются АВ:"}</strong> ${sm.whatComplains}</div>
          ${capsHtml}
          ${xrayAndRadarHtml}
          <div class="vt-smart-rec">${sm.recommendation || ""}</div>
        `);
        statusBox.appendChild(smBox);
      }

      const vendorsList = Array.isArray(data.allVendors) ? data.allVendors : [];
      if (vendorsList.length > 0 && data.showDetailedVendors && data.vendorDisplayMode !== "compact") {
        const wrap = document.createElement("div");
        wrap.className = "vt-inline-vendors-wrap";

        const vHeader = document.createElement("div");
        vHeader.className = "vt-inline-vendors-header";
        setSafeHtml(vHeader, `
          <span>Security vendors' analysis (${vendorsList.length})</span>
          <span style="color:#38bdf8; cursor:pointer;" class="vt-expand-trigger">${isEn ? "Expand Full Screen ⤢" : "Развернуть во весь экран ⤢"}</span>
        `);
        vHeader.querySelector(".vt-expand-trigger").addEventListener("click", () => {
          openFullVirusTotalModal(data);
        });
        wrap.appendChild(vHeader);

        const vGrid = document.createElement("div");
        vGrid.className = "vt-inline-vendors-grid";
        const vFrag = document.createDocumentFragment();

        for (const v of vendorsList) {
          const b = formatVendorBadge(v);
          const cell = document.createElement("div");
          cell.className = "vt-vendor-cell";
          setSafeHtml(cell, `
            <span class="vt-vendor-name" title="${v.engine}">${v.engine}${v.trusted ? '<span class="vt-trusted-star">★</span>' : ""}</span>
            <span class="vt-vendor-state ${b.cls}">${b.icon} ${b.text}</span>
          `);
          vFrag.appendChild(cell);
        }

        vGrid.appendChild(vFrag);
        wrap.appendChild(vGrid);
        statusBox.appendChild(wrap);
      }
    }

    const actions = document.createElement("div");
    actions.className = "vt-actions vt-actions-top";

    if (data.fileMeta?.oneTimeStreamNeedsFile) {
      const pickFileInput = document.createElement("input");
      pickFileInput.type = "file";
      pickFileInput.style.display = "none";
      const pickFileBtn = document.createElement("button");
      pickFileBtn.className = "vt-btn vt-btn-upload";
      pickFileBtn.title = "Выбрать скачанный файл с диска для полной проверки самого файла (SHA-256 + 72 антивируса)";
      pickFileBtn.textContent = (data.uiLang === "en" || contentPrefs.uiLang === "en") ? "📂 Scan Downloaded File" : "📂 Проверить сам файл";
      pickFileBtn.addEventListener("click", () => pickFileInput.click());
      pickFileInput.addEventListener("change", async () => {
        const f = pickFileInput.files && pickFileInput.files[0];
        if (!f) return;
        pickFileBtn.disabled = true;
        pickFileBtn.textContent = (data.uiLang === "en" || contentPrefs.uiLang === "en") ? "⏳ Hashing file..." : "⏳ Расчёт SHA-256 файла...";
        try {
          const buf = await f.arrayBuffer();
          const u8 = new Uint8Array(buf);
          const hashBuf = await crypto.subtle.digest("SHA-256", u8);
          const hashHex = Array.from(new Uint8Array(hashBuf)).map(b => b.toString(16).padStart(2, "0")).join("");
          const headArr = Array.from(u8.subarray(0, Math.min(32768, u8.byteLength)));
          const tailArr = Array.from(u8.subarray(Math.max(0, u8.byteLength - 65536), u8.byteLength));
          chrome.runtime.sendMessage({
            type: "VT_INLINE_CARD_FILE_SCAN",
            scanId: data.scanId,
            sha256: hashHex,
            filename: f.name,
            fileSize: f.size,
            headBytes: headArr,
            tailBytes: tailArr
          });
        } catch (_) {
          pickFileBtn.disabled = false;
          pickFileBtn.textContent = "📂 Проверить сам файл";
        }
      });
      actions.appendChild(pickFileInput);
      actions.appendChild(pickFileBtn);
    }

    if (data.state === "completed" && /^[a-f0-9]{64}$/i.test(data.fileMeta?.sha256 || "")) {
      const trustBtn = document.createElement("button");
      trustBtn.className = "vt-btn vt-btn-secondary";
      trustBtn.title = "Добавить SHA-256 этого файла в белый список доверенных (больше не задерживать при скачивании)";
      trustBtn.textContent = isEn ? "⭐ Trust" : "⭐ Доверять";
      trustBtn.addEventListener("click", () => {
        trustBtn.textContent = "✓ В белом списке!";
        trustBtn.disabled = true;
        chrome.runtime.sendMessage({
          type: "VT_TRUST_HASH",
          sha256: data.fileMeta.sha256,
          scanId: data.scanId
        }, () => {
          setTimeout(() => {
            card.remove();
            cards.delete(data.scanId);
          }, 600);
        });
      });
      actions.appendChild(trustBtn);
    }

    if (data.state === "completed" && Array.isArray(data.allVendors) && data.allVendors.length > 0) {
      const fullViewBtn = document.createElement("button");
      fullViewBtn.className = "vt-btn vt-btn-vt-view";
      fullViewBtn.textContent = data.fileMeta?.noKeyModeUsed
        ? `📊 Детали проверки (${data.allVendors.length})`
        : `📊 Все антивирусы (${data.allVendors.length}) как в VT`;
      fullViewBtn.addEventListener("click", () => {
        openFullVirusTotalModal(data);
      });
      actions.appendChild(fullViewBtn);

      if (data.reportUrl && data.fileMeta?.noKeyModeUsed) {
        const vtPopupBtn = document.createElement("button");
        vtPopupBtn.className = "vt-btn vt-btn-secondary";
        vtPopupBtn.title = "Открыть официальную страницу этого файла на VirusTotal в мини-окне (без API-ключа)";
        vtPopupBtn.textContent = isEn ? "🌐 VT Page ↗" : "🌐 Страница VT ↗";
        vtPopupBtn.addEventListener("click", () => {
          const cleanUrl = data.reportUrl.replace(/\s+/g, "");
          const bridgeUrl = cleanUrl.includes("?")
            ? `${cleanUrl}&vtguard_scan=${encodeURIComponent(data.scanId)}`
            : `${cleanUrl}?vtguard_scan=${encodeURIComponent(data.scanId)}`;
          chrome.runtime.sendMessage({ type: "VT_OPEN_OWN_MINI_WINDOW", scanId: data.scanId, payload: data, viewType: "card" });
        });
        actions.appendChild(vtPopupBtn);
      }
    } else if (data.reportUrl) {
      const reportLink = document.createElement("a");
      reportLink.className = "vt-link";
      reportLink.href = data.reportUrl.replace(/\s+/g, "");
      reportLink.target = "_blank";
      reportLink.rel = "noopener noreferrer";
      
      reportLink.textContent = isEn ? "🌐 VirusTotal Web ↗" : "🌐 Сайт VirusTotal ↗";
      actions.appendChild(reportLink);
    }

    // Если требуется согласие пользователя на отправку нового файла в облако VirusTotal (Privacy Consent)
    if (data.state === "consent_required" && data.canUploadConsent) {
      const uploadConsentBtn = document.createElement("button");
      uploadConsentBtn.className = "vt-btn vt-btn-upload";
      uploadConsentBtn.textContent = isEn ? "📤 Upload to VT" : "📤 Отправить в VT";
      uploadConsentBtn.addEventListener("click", () => {
        uploadConsentBtn.disabled = true;
        uploadConsentBtn.textContent = "Отправка...";
        chrome.runtime.sendMessage({ type: "VT_CONSENT_UPLOAD", scanId: data.scanId });
      });
      actions.appendChild(uploadConsentBtn);
    }

    if (data.state === "completed" || data.canDownloadAnyway || data.state === "consent_required") {
      if (data.strictBlockLock) {
        const lockTag = document.createElement("span");
        lockTag.className = "vt-locked-tag";
        lockTag.textContent = "🔒 Строгий карантин (файл удалён)";
        actions.appendChild(lockTag);
      } else {
        const cancelBtn = document.createElement("button");
        cancelBtn.className = "vt-btn vt-btn-secondary";
        cancelBtn.textContent = isEn ? "🗑️ Delete File" : "🗑️ Удалить файл";
        cancelBtn.addEventListener("click", () => {
          chrome.runtime.sendMessage({ type: "VT_CANCEL_DOWNLOAD", scanId: data.scanId });
          card.remove();
          cards.delete(data.scanId);
        });

        const downloadBtn = document.createElement("button");
        downloadBtn.className =
          data.verdict === "danger" || data.verdict === "warning"
            ? "vt-btn vt-btn-danger-outline"
            : "vt-btn vt-btn-primary";
        downloadBtn.textContent = data.autoBlocked
          ? (isEn ? "📥 Unblock & Save File" : "📥 Разблокировать и сохранить")
          : data.verdict === "danger" || data.verdict === "warning"
          ? (isEn ? "📥 Save File Anyway" : "📥 Всё равно сохранить (скачать)")
          : (isEn ? "📥 Save (Download) File" : "📥 Сохранить (скачать) файл");

        downloadBtn.addEventListener("click", () => {
          downloadBtn.disabled = true;
          downloadBtn.textContent = isEn ? "⏳ Saving..." : "⏳ Сохранение...";
          chrome.runtime.sendMessage({
            type: "VT_FORCE_DOWNLOAD_ITEM",
            scanId: data.scanId,
            downloadId: data.downloadId,
            fileUrl: data.fileUrl,
            filename: data.filename
          }, () => {
            downloadBtn.textContent = isEn ? "✅ File Saved!" : "✅ Файл сохранён!";
            setTimeout(() => {
              card.remove();
              cards.delete(data.scanId);
              syncStackToolbar(stack, isEn);
            }, 450);
          });
        });

        actions.appendChild(cancelBtn);
        actions.appendChild(downloadBtn);
      }
    }

    // Размещаем кнопки управления (📂 Проверить сам файл, 📊 Все антивирусы, Удалить файл, Разблокировать и скачать) НАВЕРХУ плашки!
    const topGridEl = statusBox.querySelector(".vt-stats-grid");
    if (topGridEl && topGridEl.parentNode === statusBox) {
      topGridEl.insertAdjacentElement("afterend", actions);
    } else {
      statusBox.insertBefore(actions, statusBox.firstChild);
    }
    card.appendChild(statusBox);

    const cardCredits = document.createElement("div");
    cardCredits.className = "vt-credits-row";
    cardCredits.title = "🔏 Защищено криптографической ЭЦП автора: SalmonPlay1 / LososKiler (Отпечаток ECDSA P-256: SP1-LK-0810-4BFB-3631-A818-6228-82C2-8C9A-1C4D)";
    setSafeHtml(cardCredits, `<span class="vt-credit-left">by SalmonPlay1</span><a href="https://www.donationalerts.com/r/salmonplay1" target="_blank" rel="noopener noreferrer" class="vt-credit-donate" title="Поддержать разработчика (DonationAlerts)"><svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" style="flex-shrink:0;"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg><span>${isEn ? "Donate" : "Донат"}</span></a><span style="font-size:9px;color:#38bdf8;opacity:0.9;">${isEn ? "🔏 Sign" : "🔏 ЭЦП"}</span><span class="vt-credit-right">by LososKiler</span>`);
    cardCredits.querySelectorAll("a").forEach(a => a.addEventListener("click", e => e.stopPropagation()));
    card.appendChild(cardCredits);

    if (data.state === "completed" && data.soundAlertsEnabled !== false && !playedSoundForScan.has(data.scanId)) {
      playedSoundForScan.add(data.scanId);
      if (data.verdict === "danger" || data.verdict === "warning") {
        playAlertSound("danger", data);
      } else if (data.verdict === "safe") {
        playAlertSound("safe", data);
      }
    }

    // Автозакрытие плашки для чистых файлов (если включено в настройках и пользователь не навёл курсор)
    const autoSec = Number(data.autoCloseSafeSec) || 0;
    if (data.state === "completed" && data.verdict === "safe" && autoSec > 0 && !card.__vtAutoCloseTimer) {
      card.__vtAutoCloseTimer = setTimeout(() => {
        if (card.matches(":hover")) return;
        card.style.transition = "opacity 0.25s ease, transform 0.25s ease";
        card.style.opacity = "0";
        card.style.transform = "translateY(-8px)";
        setTimeout(() => {
          chrome.runtime.sendMessage({ type: "VT_DISMISS_CARD", scanId: data.scanId }).catch(() => {});
          card.remove();
          cards.delete(data.scanId);
          syncStackToolbar(stack, isEn);
        }, 260);
      }, autoSec * 1000);
    }
    syncStackToolbar(stack, isEn);

    if (
      data.state === "completed" &&
      data.showDetailedVendors &&
      data.vendorDisplayMode === "auto_modal" &&
      Array.isArray(data.allVendors) &&
      data.allVendors.length > 0
    ) {
      openFullVirusTotalModal(data);
    }
  }

  function syncStackToolbar(stack, isEn) {
    if (!stack) return;
    let tb = stack.querySelector(".vt-stack-toolbar");
    if (cards.size < 2) {
      if (tb) tb.remove();
      return;
    }
    if (!tb) {
      tb = document.createElement("div");
      tb.className = "vt-stack-toolbar";
      stack.prepend(tb);
    }
    tb.textContent = "";
    const countSpan = document.createElement("span");
    countSpan.textContent = isEn ? `🗂️ Windows: ${cards.size}` : `🗂️ Окон проверок: ${cards.size}`;

    const btnGroup = document.createElement("div");
    btnGroup.className = "vt-stack-toolbar-btns";

    const expandAllBtn = document.createElement("button");
    expandAllBtn.type = "button";
    expandAllBtn.className = "vt-stack-btn";
    expandAllBtn.textContent = isEn ? "▾ Expand all" : "▾ Развернуть все";
    expandAllBtn.addEventListener("click", () => {
      for (const [, cEl] of cards.entries()) {
        cEl.classList.remove("vt-card-collapsed");
        const b = cEl.querySelector(".vt-collapse-btn");
        if (b) b.textContent = isEn ? "▴ Collapse" : "▴ Свернуть";
      }
    });

    const collapseAllBtn = document.createElement("button");
    collapseAllBtn.type = "button";
    collapseAllBtn.className = "vt-stack-btn";
    collapseAllBtn.textContent = isEn ? "▴ Collapse all" : "▴ Свернуть все";
    collapseAllBtn.addEventListener("click", () => {
      for (const [, cEl] of cards.entries()) {
        cEl.classList.add("vt-card-collapsed");
        const b = cEl.querySelector(".vt-collapse-btn");
        if (b) b.textContent = isEn ? "▾ Expand" : "▾ Развернуть";
      }
    });

    const closeAllBtn = document.createElement("button");
    closeAllBtn.type = "button";
    closeAllBtn.className = "vt-stack-btn vt-stack-btn-danger";
    closeAllBtn.textContent = isEn ? "✕ Close all" : "✕ Закрыть все";
    closeAllBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "VT_DISMISS_CARD", scanId: "__ALL__" }).catch(() => {});
      for (const [, cEl] of cards.entries()) {
        cEl.remove();
      }
      cards.clear();
      tb.remove();
    });

    btnGroup.appendChild(expandAllBtn);
    btnGroup.appendChild(collapseAllBtn);
    btnGroup.appendChild(closeAllBtn);
    tb.appendChild(countSpan);
    tb.appendChild(btnGroup);
  }

  window.__vtGuardRenderCardDirect = (payload) => {
    try {
      renderCard(payload);
      return true;
    } catch (_) {
      return false;
    }
  };

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === "VT_TRIGGER_INPAGE_DOWNLOAD" && msg.targetUrl) {
      try {
        const a = document.createElement("a");
        a.href = msg.targetUrl;
        if (msg.filename) a.download = msg.filename;
        a.rel = "noopener";
        a.style.display = "none";
        (document.body || document.documentElement).appendChild(a);
        a.click();
        setTimeout(() => { try { a.remove(); } catch (_) {} }, 2500);
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return true;
    }
    if (msg?.type === "VT_FETCH_STREAM_IN_TAB" && msg.targetUrl) {
      (async () => {
        try {
          const ctrl = new AbortController();
          const tId = setTimeout(() => ctrl.abort(), 6500);
          const resp = await fetch(msg.targetUrl, {
            credentials: "include",
            redirect: "follow",
            signal: ctrl.signal
          });
          clearTimeout(tId);
          if (!resp.ok) {
            sendResponse({ ok: false, status: resp.status });
            return;
          }
          const cType = resp.headers.get("content-type") || "application/octet-stream";
          if (/text\/html|application\/xhtml/i.test(cType)) {
            sendResponse({ ok: false, isHtml: true });
            return;
          }
          const buf = await resp.arrayBuffer();
          if (!buf || buf.byteLength === 0 || buf.byteLength > 35 * 1024 * 1024) {
            sendResponse({ ok: false, byteLength: buf ? buf.byteLength : 0 });
            return;
          }
          const bytes = new Uint8Array(buf);
          let binary = "";
          const chunk = 0x8000;
          for (let i = 0; i < bytes.length; i += chunk) {
            binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
          }
          sendResponse({
            ok: true,
            base64Data: btoa(binary),
            mimeType: cType,
            byteLength: bytes.length
          });
        } catch (e) {
          sendResponse({ ok: false, error: String(e) });
        }
      })();
      return true;
    }
    if (msg?.type === "VT_READ_BLOB_URL" && msg.blobUrl) {
      (async () => {
        try {
          const resp = await fetch(msg.blobUrl);
          if (!resp.ok) {
            sendResponse({ ok: false });
            return;
          }
          const buf = await resp.arrayBuffer();
          if (buf.byteLength > 35 * 1024 * 1024) {
            sendResponse({ ok: false, tooLarge: true, byteLength: buf.byteLength });
            return;
          }
          const bytes = new Uint8Array(buf);
          let binary = "";
          const chunk = 0x8000;
          for (let i = 0; i < bytes.length; i += chunk) {
            binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
          }
          sendResponse({
            ok: true,
            base64Data: btoa(binary),
            mimeType: resp.headers.get("content-type") || "application/octet-stream",
            byteLength: bytes.length
          });
        } catch (e) {
          sendResponse({ ok: false, error: String(e) });
        }
      })();
      return true;
    }
    if (msg?.type === "VT_BANNER_UPDATE" && msg.payload) {
      if (window !== window.top) return false;
      try {
        renderCard(msg.payload);
        sendResponse({ ok: true, rendered: true });
      } catch (err) {
        sendResponse({ ok: false, rendered: false, error: String(err) });
      }
      return true;
    } else if (msg?.type === "VT_WINDOW_MODE_CHANGED") {
      currentScanWindowDisplayMode = msg.scanWindowDisplayMode || "card_on_top";
      if (hostEl) {
        hostEl.style.display = "block";
        applyHostPosition(contentPrefs.bannerPosition || "top-right", currentScanWindowDisplayMode);
      }
      sendResponse({ ok: true });
      return true;
    } else if (msg?.type === "VT_POPUP_OPEN_STATE") {
      isToolbarPopupOpen = Boolean(msg.open);
      if (msg.scanWindowDisplayMode) {
        currentScanWindowDisplayMode = msg.scanWindowDisplayMode;
      }
      if (hostEl) {
        hostEl.style.display = "block";
        applyHostPosition(contentPrefs.bannerPosition || "top-right", currentScanWindowDisplayMode);
      }
      sendResponse({ ok: true, hasCards: cards.size > 0 });
      return true;
    } else if (msg?.type === "VT_CHECK_AND_OPEN_INPAGE_EXT") {
      if (window !== window.top) return false;
      currentScanWindowDisplayMode = msg.scanWindowDisplayMode || "card_on_top";
      if (cards.size > 0 && currentScanWindowDisplayMode === "card_on_top") {
        ensureInPageExtensionPanel(true);
        applyHostPosition(contentPrefs.bannerPosition || "top-right", "card_on_top");
        sendResponse({ ok: true, handedOff: true });
      } else {
        sendResponse({ ok: true, handedOff: false });
      }
      return true;
    } else if (msg?.type === "VT_TOAST_MESSAGE" && msg.text) {
      if (window === window.top) showToastBanner(msg.text);
      sendResponse({ ok: true });
      return true;
    }
  });

  // ==================== v1.0: БЫСТРАЯ ПРОВЕРКА ССЫЛОК, ПРОВЕРКА ВЫДЕЛЕННОГО ТЕКСТА, АНТИ-ФИШИНГ И КАСТОМНЫЕ ГОРЯЧИЕ КЛАВИШИ ====================
  let hoverBadgeEl = null;
  let selectionBadgeEl = null;
  let currentHoveredLinkUrl = "";
  let currentSelectedText = "";
  let hideHoverTimer = null;

  let contentPrefs = {
    enabled: true,
    hoverBadgeEnabled: false,
    hoverTriggerMode: "alt_only",
    uiLang: "ru",
    selectionPopupEnabled: true,
    antiPhishingEnabled: true,
    clickFixShieldEnabled: true,
    clipboardHelperEnabled: true,
    clipperGuardEnabled: true,
    hotkeysEnabled: false,
    hotkeyToggle: "Alt+Shift+V",
    hotkeyScan: "Alt+Shift+S",
    hotkeyCloseAll: "Alt+Shift+C"
  };

  function syncContentPrefs() {
    try {
      chrome.storage?.local?.get(contentPrefs, (res) => {
        if (res) contentPrefs = { ...contentPrefs, ...res };
      });
    } catch (_) {}
  }
  syncContentPrefs();

  try {
    chrome.storage?.onChanged?.addListener((changes, area) => {
      if (area === "local") {
        syncContentPrefs();
        if (changes.customBgDataUrl || changes.customStickerDataUrl || changes.customSoundDataUrl || changes.customFontDataUrl) syncLocalCustomAssets();
      }
    });
  } catch (_) {}

  function showToastBanner(text) {
    ensureContainer();
    const toast = document.createElement("div");
    toast.style.cssText =
      "pointer-events:auto;background:#0f172a;color:#f8fafc;border:1.5px solid #38bdf8;border-radius:10px;padding:10px 14px;font-size:12.5px;font-weight:700;box-shadow:0 12px 24px rgba(0,0,0,0.6);margin-bottom:8px;transition:opacity 0.25s ease;";
    toast.textContent = text;
    containerEl.prepend(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 260);
    }, 2400);
  }

  const DOWNLOADABLE_LINK_EXTS = new Set([
    "exe", "msi", "msp", "msix", "apk", "xapk", "dmg", "pkg", "deb", "rpm", "appimage",
    "bat", "cmd", "com", "scr", "ps1", "vbs", "hta", "jar", "zip", "rar", "7z", "tar",
    "gz", "xz", "iso", "img", "vhd", "torrent", "dll", "sys", "lnk", "reg", "crx", "xpi",
    "pdf", "docm", "xlsm", "pptm"
  ]);

  function isDownloadableAnchor(a) {
    if (!a || !a.href || !/^https?:\/\//i.test(a.href)) return false;
    if (location.hostname.endsWith("virustotal.com")) return false;
    if (a.hasAttribute("download")) return true;
    try {
      const u = new URL(a.href);
      const host = u.hostname.toLowerCase().replace(/^www\./, "");
      if (["bit.ly", "clck.ru", "vk.cc", "tinyurl.com", "cutt.ly", "t.co", "goo.su"].includes(host)) return true;
      const lastSeg = decodeURIComponent(u.pathname.split("/").pop() || "").toLowerCase();
      if (lastSeg.includes(".")) {
        const ext = lastSeg.split(".").pop().trim();
        if (DOWNLOADABLE_LINK_EXTS.has(ext)) return true;
      }
      for (const k of ["file", "filename", "download"]) {
        const val = (u.searchParams.get(k) || "").toLowerCase();
        if (val.includes(".")) {
          const ext = val.split(".").pop().trim();
          if (DOWNLOADABLE_LINK_EXTS.has(ext)) return true;
        }
      }
    } catch (_) {}
    return false;
  }

  // Верхняя синяя плашка "🛡️ Проверить ссылку в VT" полностью убрана по запросу пользователя (оставлена только проверка снизу в контекстном меню ПКМ).
  // Дополнительно вычищаем любую старую кнопку с этим текстом, если она осталась в DOM от прежней версии до обновления страницы:
  function purgeLegacyHoverBadges() {
    try {
      if (hoverBadgeEl) {
        hoverBadgeEl.remove();
        hoverBadgeEl = null;
      }
      document.querySelectorAll("button").forEach((btn) => {
        const txt = (btn.textContent || "").trim();
        if (txt === "🛡️ Проверить ссылку в VT" || txt === "🛡️ Scan Link in VT") {
          btn.remove();
        }
      });
    } catch (_) {}
  }
  purgeLegacyHoverBadges();
  document.addEventListener("contextmenu", purgeLegacyHoverBadges, { capture: true, passive: true });
  document.addEventListener("mouseover", (e) => {
    const a = e.target?.closest?.("a[href]");
    if (a && a.href) currentHoveredLinkUrl = a.href;
  }, { capture: true, passive: true });

  // Всплывающая мини-кнопка при выделении текста мышкой (SHA-256, MD5, SHA-1, URL или домена)
  function isScannableSelection(txt) {
    if (!txt || txt.length < 5 || txt.length > 512) return false;
    if (/^[a-fA-F0-9]{32}$|^[a-fA-F0-9]{40}$|^[a-fA-F0-9]{64}$/.test(txt)) return true;
    if (/^https?:\/\//i.test(txt)) return true;
    if (/^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,12}(\/.*)?$/.test(txt) && !txt.includes(" ")) return true;
    return false;
  }

  function ensureSelectionBadge() {
    if (selectionBadgeEl && document.body && document.body.contains(selectionBadgeEl)) return selectionBadgeEl;
    selectionBadgeEl = document.createElement("button");
    selectionBadgeEl.type = "button";
    selectionBadgeEl.style.cssText =
      "position:fixed;z-index:2147483646;display:none;align-items:center;gap:5px;background:#1e293b;color:#34d399;border:1.5px solid #10b981;border-radius:8px;padding:5px 10px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:11.5px;font-weight:700;cursor:pointer;box-shadow:0 10px 20px rgba(0,0,0,0.6);";
    setSafeHtml(selectionBadgeEl, contentPrefs.uiLang === "en" ? "🔎 Scan Selection in VT" : "🔎 Проверить выделенное в VT");
    selectionBadgeEl.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!currentSelectedText) return;
      const toScan = currentSelectedText;
      selectionBadgeEl.style.display = "none";
      showToastBanner(`🔎 Проверка выделенного: ${toScan.slice(0, 34)}...`);
      chrome.runtime.sendMessage({ type: "VT_QUICK_SCAN_HOTKEY", text: toScan });
    });
    (document.body || document.documentElement).appendChild(selectionBadgeEl);
    return selectionBadgeEl;
  }

  document.addEventListener("mouseup", (e) => {
    if (!contentPrefs.enabled || !contentPrefs.selectionPopupEnabled) {
      if (selectionBadgeEl) selectionBadgeEl.style.display = "none";
      return;
    }
    setTimeout(() => {
      const sel = (window.getSelection()?.toString() || "").trim();
      if (isScannableSelection(sel)) {
        currentSelectedText = sel;
        const badge = ensureSelectionBadge();
        const top = Math.max(10, Math.min(window.innerHeight - 45, e.clientY - 40));
        const left = Math.max(10, Math.min(window.innerWidth - 210, e.clientX));
        badge.style.top = `${top}px`;
        badge.style.left = `${left}px`;
        setSafeHtml(badge, /^[a-fA-F0-9]{32,64}$/.test(sel)
          ? (contentPrefs.uiLang === "en" ? "🔎 Scan Hash in VT" : "🔎 Проверить хеш в VT")
          : (contentPrefs.uiLang === "en" ? "🔎 Scan URL in VT" : "🔎 Проверить адрес в VT"));
        badge.style.display = "inline-flex";
      } else if (selectionBadgeEl) {
        selectionBadgeEl.style.display = "none";
      }
    }, 30);
  });

  // Универсальное сопоставление комбинаций клавиш (работает и на русской, и на английской раскладке)
  function formatKeyEventCombo(e) {
    const parts = [];
    if (e.ctrlKey || e.metaKey) parts.push("Ctrl");
    if (e.altKey) parts.push("Alt");
    if (e.shiftKey) parts.push("Shift");
    const code = e.code || "";
    let keyName = "";
    if (code.startsWith("Key")) {
      keyName = code.slice(3).toUpperCase();
    } else if (code.startsWith("Digit")) {
      keyName = code.slice(5);
    } else if (/^F([1-9]|1[0-2])$/.test(code)) {
      keyName = code;
    } else if (["Space", "Enter", "Backquote", "Escape"].includes(code)) {
      keyName = code;
    }
    if (!keyName) return "";
    parts.push(keyName);
    return parts.join("+");
  }

  document.addEventListener("keydown", (e) => {
    if (!contentPrefs.hotkeysEnabled) return;
    const pressedCombo = formatKeyEventCombo(e);
    if (!pressedCombo) return;

    const toggleCombo = (contentPrefs.hotkeyToggle || "Alt+Shift+V").toLowerCase();
    const scanCombo = (contentPrefs.hotkeyScan || "Alt+Shift+S").toLowerCase();
    const closeCombo = (contentPrefs.hotkeyCloseAll || "Alt+Shift+C").toLowerCase();
    const currentLower = pressedCombo.toLowerCase();

    if (currentLower === toggleCombo) {
      e.preventDefault();
      chrome.runtime.sendMessage({ type: "VT_TOGGLE_GUARD_HOTKEY" }, (res) => {
        if (res && res.ok) {
          showToastBanner(
            res.enabled
              ? `🛡️ Защита VT Download Guard ВКЛЮЧЕНА (${contentPrefs.hotkeyToggle})`
              : `⏸️ Защита VT Download Guard НА ПАУЗЕ (${contentPrefs.hotkeyToggle})`
          );
        }
      });
    } else if (currentLower === scanCombo) {
      const targetText = (window.getSelection()?.toString() || "").trim() || currentHoveredLinkUrl || location.href;
      if (targetText) {
        e.preventDefault();
        showToastBanner(`🔎 Проверка (${contentPrefs.hotkeyScan}): ${targetText.slice(0, 36)}...`);
        chrome.runtime.sendMessage({ type: "VT_QUICK_SCAN_HOTKEY", text: targetText });
      }
    } else if (currentLower === closeCombo) {
      if (cards.size > 0 || modalBackdropEl) {
        e.preventDefault();
        for (const [sId, cEl] of cards.entries()) {
          chrome.runtime.sendMessage({ type: "VT_DISMISS_CARD", scanId: sId }).catch(() => {});
          cEl.remove();
        }
        cards.clear();
        if (modalBackdropEl) {
          modalBackdropEl.remove();
          modalBackdropEl = null;
        }
        showToastBanner("✓ Все плашки VT Download Guard закрыты");
      }
    }
  });

  // Анти-фишинг проверка текущего сайта при открытии страницы
  function checkCurrentPagePhishing() {
    if (!/^https?:\/\//i.test(location.href)) return;
    chrome.runtime.sendMessage({ type: "VT_CHECK_PAGE_PHISHING", url: location.href }, (res) => {
      if (res && res.suspicious && res.reason) {
        renderCard({
          scanId: "vt_phishing_" + location.hostname,
          filename: `Внимание: ${location.hostname}`,
          ext: "ФИШИНГ?",
          state: "completed",
          verdict: "danger",
          summaryText: res.reason,
          stats: { malicious: 1, suspicious: 1, harmless: 0, total: 1 },
          allVendors: [
            { engine: "VT Guard Anti-Phishing Shield", category: "malicious", result: res.reason, trusted: true }
          ],
          fileMeta: {
            sha256: location.href,
            sizeFormatted: "Веб-страница",
            typeTag: "anti-phishing",
            magicDesc: res.reason,
            analysisDate: "Только что"
          },
          reportUrl: `https://www.virustotal.com/gui/domain/${encodeURIComponent(location.hostname)}`,
          hasDownloadableTarget: false
        });
      }
    });
  }
  checkCurrentPagePhishing();

  // ==================== v1.0: ПОМОЩНИК ДЛЯ GOOGLE DRIVE / ЯНДЕКС.ДИСК / MEDIAFIRE ====================
  function initCloudDriveShieldHelper() {
    const host = location.hostname.toLowerCase();
    const isGoogleDriveWarn = (host.includes("drive.google.com") || host.includes("docs.google.com")) &&
      (location.pathname.includes("/uc") || document.body?.textContent?.includes("Virus scan warning") || document.body?.textContent?.includes("Не удалось проверить файл на наличие вирусов"));
    if (isGoogleDriveWarn) {
      showToastBanner("🛡️ VT Download Guard активен: большой файл с Google Диска будет автоматически проверен потоковым инспектором при скачивании!");
    }
  }
  setTimeout(initCloudDriveShieldHelper, 900);


  // ==================== v1.0: ЗАЩИТА БУФЕРА ОБМЕНА ОТ CLICKFIX (WIN+R) И ПРОВЕРКА СКОПИРОВАННЫХ ССЫЛОК ====================
  const CLICKFIX_DANGER_PATTERNS = [
    /powershell[\s\S]{0,40}(-e|-enc|-encodedcommand|-w\s+hidden|-windowstyle\s+hidden|iex|invoke-expression|irm|iwr|downloadstring)/i,
    /mshta(\.exe)?\s+(http|vbscript|javascript)/i,
    /cmd(\.exe)?\s*\/c\s+.*(curl|certutil|bitsadmin|powershell|mshta|regsvr32|rundll32)/i,
    /certutil(\.exe)?\s+-urlcache/i,
    /regsvr32(\.exe)?\s+\/s\s+\/n\s+\/u\s+\/i:/i
  ];

  function detectClickFixCommand(text) {
    if (!text || text.length < 10 || text.length > 4000) return false;
    for (const rx of CLICKFIX_DANGER_PATTERNS) {
      if (rx.test(text)) return true;
    }
    return false;
  }

  document.addEventListener("copy", () => {
    if (!contentPrefs.enabled) return;
    setTimeout(async () => {
      try {
        const copied = (window.getSelection()?.toString() || "").trim();
        let clipText = copied;
        if (!clipText && navigator.clipboard?.readText) {
          clipText = (await navigator.clipboard.readText().catch(() => "")) || "";
        }
        if (!clipText) return;

        // 1. Проверка на скрытую подмену буфера обмена вредоносной командой ClickFix
        if (contentPrefs.clickFixShieldEnabled !== false && detectClickFixCommand(clipText)) {
          try {
            await navigator.clipboard.writeText("[VT Download Guard: Вредоносная команда ClickFix заблокирована и удалена из буфера обмена]");
          } catch (_) {}
          chrome.runtime.sendMessage({
            type: "VT_CLICKFIX_ALERT",
            hostname: location.hostname,
            commandSnippet: clipText.slice(0, 120)
          });
          return;
        }

        // 2. Помощник буфера обмена: если скопирован SHA-256 хеш или прямая ссылка на файл
        if (contentPrefs.clipboardHelperEnabled !== false && isScannableSelection(clipText)) {
          const isHash = /^[a-fA-F0-9]{64}$/.test(clipText);
          const isFileLink = /^https?:\/\//i.test(clipText) && /\.(exe|msi|zip|rar|7z|apk|iso|dmg|torrent|bat|ps1)(\?|$)/i.test(clipText);
          if (isHash || isFileLink) {
            currentSelectedText = clipText;
            const badge = ensureSelectionBadge();
            badge.style.top = "18px";
            badge.style.left = "50%";
            badge.style.transform = "translateX(-50%)";
            setSafeHtml(badge, isHash
              ? "📋 Скопирован SHA-256 — Проверить в VT?"
              : "📋 Скопирована ссылка на файл — Проверить в VT?");
            badge.style.display = "inline-flex";
            setTimeout(() => {
              if (badge) {
                badge.style.display = "none";
                badge.style.transform = "";
              }
            }, 5500);
          }
        }
      } catch (_) {}
    }, 60);
  });


  
  // 3. Защита от троянов-клипперов (подмены скопированных криптокошельков BTC/ETH/TON/USDT и Steam Trade ссылок)
  let lastUserCopiedWalletOrTrade = "";
  const WALLET_OR_TRADE_REGEX = /^(bc1[a-zA-HJ-NP-Z0-9]{25,59}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}|0x[a-fA-F0-9]{40}|T[A-Za-z1-9]{33}|UQ[a-zA-Z0-9_-]{46}|EQ[a-zA-Z0-9_-]{46}|https?:\/\/steamcommunity\.com\/tradeoffer\/new\/\?partner=\d+.*)$/;

  document.addEventListener("copy", () => {
    const sel = (window.getSelection()?.toString() || "").trim();
    if (WALLET_OR_TRADE_REGEX.test(sel)) {
      lastUserCopiedWalletOrTrade = sel;
    }
  }, { capture: true, passive: true });

  document.addEventListener("paste", (e) => {
    if (!contentPrefs.enabled || contentPrefs.clipperGuardEnabled === false || !lastUserCopiedWalletOrTrade) return;
    const pasted = (e.clipboardData?.getData("text") || "").trim();
    if (pasted && WALLET_OR_TRADE_REGEX.test(pasted) && pasted !== lastUserCopiedWalletOrTrade) {
      showToastBanner("🚨 ВНИМАНИЕ (Clipper Guard): Вставляемый кошелёк / Steam-трейд ссылка ОТЛИЧАЕТСЯ от скопированной вами! Возможна подмена буфера обмена!");
    }
  }, { capture: true, passive: true });

  // ==================== МОСТ К ОФИЦИАЛЬНОЙ СТРАНИЦЕ VIRUSTOTAL (РАБОТА БЕЗ API-КЛЮЧА) ====================
  function queryShadowText(root) {
    let text = "";
    if (!root) return text;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null);
    let node = walker.currentNode;
    while (node) {
      if (node.shadowRoot) {
        text += " " + queryShadowText(node.shadowRoot);
      }
      node = walker.nextNode();
    }
    text += " " + (root.textContent || "");
    return text;
  }

  function showVtPageHelperBanner(htmlContent) {
    if (document.getElementById("vt-guard-page-helper")) return;
    const bar = document.createElement("div");
    bar.id = "vt-guard-page-helper";
    bar.style.cssText = "position:fixed;bottom:20px;right:20px;z-index:2147483647;max-width:460px;background:#0f172a;color:#f8fafc;border:1.5px solid #38bdf8;border-radius:12px;padding:14px 16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:13px;line-height:1.45;box-shadow:0 20px 25px -5px rgba(0,0,0,0.7);";
    setSafeHtml(bar, htmlContent);
    (document.body || document.documentElement).appendChild(bar);
  }

  function initVirusTotalPageBridge() {
    if (!location.hostname.endsWith("virustotal.com")) return;
    chrome.runtime.sendMessage({ type: "VT_CLEAR_BADGE" }).catch(() => {});
    const mFile = location.pathname.match(/\/gui\/file\/([a-fA-F0-9]{64})/);
    const mUrl = location.pathname.match(/\/gui\/url\/([a-zA-Z0-9_-]+)/);
    if (!mFile && !mUrl) return;
    const sha256 = mFile ? mFile[1].toLowerCase() : "";
    const urlId = mUrl ? mUrl[1] : "";
    const params = new URLSearchParams(location.search);
    const scanId = params.get("vtguard_scan") || "";
    const sourceDomain = params.get("vtguard_domain") || "";

    let synced = false;
    let attempts = 0;
    const timer = setInterval(() => {
      attempts++;
      if (synced || attempts > 25) {
        clearInterval(timer);
        return;
      }
      try {
        const allText = queryShadowText(document.body);
        const lowerText = allText.toLowerCase();

        // Случай 1: Файла ещё нет в базе VirusTotal ("Item not found" / "No matches found")
        if (lowerText.includes("item not found") || lowerText.includes("no matches found")) {
          synced = true;
          clearInterval(timer);
          const objLabel = sha256 ? `Этого файла (<code>${sha256.slice(0, 12)}...</code>)` : `Этой ссылки на скачивание`;
          showVtPageHelperBanner(`
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
              <strong style="color:#ff856d;">🐟 VT Download Guard — Помощник по VirusTotal</strong>
              <button id="vtGuardHelperClose" style="background:none;border:none;color:#94a3b8;cursor:pointer;font-size:16px;">✕</button>
            </div>
            <div style="color:#cbd5e1;margin-bottom:10px;">
              ${objLabel} ещё <b>нет в базе VirusTotal</b> (надпись <i>Item not found</i> означает, что эту ссылку или новый файл ещё никто не сканировал на сайте VT). Локальная проверка сигнатур расширения угроз не обнаружила!
            </div>
            <div style="display:flex;gap:7px;flex-wrap:wrap;">
              ${sourceDomain ? `<a href="https://www.virustotal.com/gui/domain/${encodeURIComponent(sourceDomain)}" style="background:#10b981;color:#052e16;text-decoration:none;border-radius:7px;padding:7px 11px;font-weight:700;font-size:12px;">🌐 Проверить репутацию домена ${sourceDomain} ↗</a>` : ""}
              <a href="https://www.virustotal.com/gui/home/upload" style="background:#2563eb;color:#fff;text-decoration:none;border-radius:7px;padding:7px 11px;font-weight:600;font-size:12px;">📤 Загрузить сам файл на VT</a>
              ${scanId ? `<button id="vtGuardApproveFromVtBtn" style="background:#334155;color:#f8fafc;border:none;border-radius:7px;padding:7px 11px;font-weight:600;font-size:12px;cursor:pointer;">✅ Сохранить файл</button>` : ""}
            </div>
          `);
          const closeEl = document.getElementById("vtGuardHelperClose");
          if (closeEl) closeEl.onclick = () => document.getElementById("vt-guard-page-helper")?.remove();
          const approveEl = document.getElementById("vtGuardApproveFromVtBtn");
          if (approveEl && scanId) {
            approveEl.onclick = () => {
              approveEl.textContent = "✓ Файл сохранён!";
              approveEl.disabled = true;
              chrome.runtime.sendMessage({ type: "VT_PROCEED_DOWNLOAD", scanId }).catch(() => {});
            };
          }
          return;
        }

        // Случай 2: Ищем паттерн Community Score на странице VT: например "0/72" или "3 / 71" и анализируем, на что жалуется сайт VT!
        const scoreMatch = allText.match(/(\d{1,2})\s*\/\s*(6\d|7\d)\b/);
        if (scoreMatch) {
          const malicious = Number(scoreMatch[1]);
          const total = Number(scoreMatch[2]);
          if (total >= 50 && total <= 85) {
            synced = true;
            clearInterval(timer);

            const foundTags = [];
            const tagPatterns = [
              { rx: /redline|lumma|vidar|raccoon|stealc|infostealer|pws|password/i, label: "🚨 Стилер паролей/аккаунтов", danger: "high" },
              { rx: /asyncrat|njrat|remcos|quasar|backdoor|nanocore|dcrat/i, label: "🚨 Троян удалённого доступа (RAT)", danger: "high" },
              { rx: /ransom|lockbit|wannacry|stopdjvu|cryptor/i, label: "🚨 Шифровальщик-вымогатель", danger: "high" },
              { rx: /xmrig|coinminer|cryptominer/i, label: "⛏️ Скрытый майнер видеокарты", danger: "high" },
              { rx: /hacktool|crack|keygen|gamehack|onlinefix|cheat|trainer/i, label: "🎮 Игровой кряк / Фикс / Трейнер (HackTool)", danger: "medium" },
              { rx: /adware|bundle|puad|potentially unwanted/i, label: "📢 Рекламное ПО (Adware/PUA)", danger: "medium" }
            ];
            for (const tp of tagPatterns) {
              if (tp.rx.test(lowerText)) foundTags.push(tp.label);
            }

            const isFlowsealZapretOnVt =
              /zapret-discord-youtube/i.test(lowerText) &&
              (/windivert/i.test(lowerText) || malicious <= 12);

            let vtExplainText = "";
            let pageTrustScore = 96;
            if (isFlowsealZapretOnVt) {
              pageTrustScore = 100;
              vtExplainText = `🟢 <b>Уровень доверия: 100% (ОФИЦИАЛЬНЫЙ ZAPRET ОТ FLOWSEAL — Вирусов нет!):</b> Это подлинный релиз <code>zapret-discord-youtube</code> от разработчика <b>Flowseal</b>. Срабатывания (${malicious}/${total} АВ) на сайте VT — это известная ложная реакция на официальный подписанный драйвер <code>WinDivert</code> (pua.windivert). Архив полностью безопасен!`;
            } else if (malicious === 0) {
              pageTrustScore = 98;
              vtExplainText = `✅ <b>Уровень доверия: ${pageTrustScore}%</b> — Сайт VirusTotal подтверждает: 0 из ${total} антивирусов нашли угрозы. Файл полностью чист!`;
            } else if (foundTags.some(t => t.startsWith("🚨"))) {
              pageTrustScore = Math.max(0, 5 - Math.min(5, malicious));
              vtExplainText = `⛔ <b>Уровень доверия: ${pageTrustScore}% (КРИТИЧЕСКАЯ УГРОЗА, ${malicious}/${total} АВ):</b> Жалобы на боевой вредонос: <b>${foundTags.join(", ")}</b>. Категорически не запускать!`;
            } else if (foundTags.some(t => t.startsWith("⛏️"))) {
              pageTrustScore = 12;
              vtExplainText = `🟠 <b>Уровень доверия: ${pageTrustScore}% (${malicious}/${total} АВ):</b> Жалобы на <b>${foundTags.join(", ")}</b> (нагрузка видеокарты/процессора).`;
            } else if (foundTags.some(t => t.startsWith("🎮")) && malicious <= 18) {
              pageTrustScore = Math.max(58, 72 - malicious);
              vtExplainText = `🟡 <b>Уровень доверия: ${pageTrustScore}% (Условный риск — Игровой фикс, ${malicious}/${total} АВ):</b> Антивирусы жалуются на <b>${foundTags.join(", ")}</b> (обход DRM / модификация игры, а не стилер).`;
            } else if (malicious <= 2) {
              pageTrustScore = Math.max(78, 86 - malicious * 3);
              vtExplainText = `ℹ️ <b>Уровень доверия: ${pageTrustScore}% (Низкий риск, ${malicious}/${total} АВ):</b> Сработало всего ${malicious} малоизвестных движка (вероятно, ложная ИИ-эвристика на упаковщик).`;
            } else {
              pageTrustScore = Math.max(10, 65 - malicious * 6);
              vtExplainText = `⚠️ <b>Уровень доверия: ${pageTrustScore}% (${malicious}/${total} АВ):</b> Несколько антивирусов пометили объект как вредоносный (${foundTags.join(", ") || "эвристика трояна"}).`;
            }

            showVtPageHelperBanner(`
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                <strong style="color:#ff856d;">🧠 VT Download Guard — Умная сводка страницы VT</strong>
                <button id="vtGuardHelperClose" style="background:none;border:none;color:#94a3b8;cursor:pointer;font-size:16px;">✕</button>
              </div>
              <div style="color:#e2e8f0;margin-bottom:8px;">${vtExplainText}</div>
              ${scanId ? `<div style="display:flex;gap:7px;"><button id="vtGuardApproveFromVtBtn" style="background:#10b981;color:#052e16;border:none;border-radius:7px;padding:6px 11px;font-weight:700;font-size:12px;cursor:pointer;">✅ Разрешить скачивание файла</button></div>` : ""}
            `);
            const closeEl = document.getElementById("vtGuardHelperClose");
            if (closeEl) closeEl.onclick = () => document.getElementById("vt-guard-page-helper")?.remove();
            const approveEl = document.getElementById("vtGuardApproveFromVtBtn");
            if (approveEl && scanId) {
              approveEl.onclick = () => {
                approveEl.textContent = "✓ Файл сохранён!";
                approveEl.disabled = true;
                chrome.runtime.sendMessage({ type: "VT_PROCEED_DOWNLOAD", scanId }).catch(() => {});
              };
            }

            if (sha256) {
              chrome.runtime.sendMessage({
                type: "VT_PAGE_SCRAPED_RESULT",
                payload: {
                  sha256,
                  malicious: isFlowsealZapretOnVt ? 0 : malicious,
                  total,
                  threatLabels: foundTags,
                  filename: document.title.replace(/\s*-\s*VirusTotal.*$/i, "").trim(),
                  scanId,
                  isOfficialFlowsealPage: isFlowsealZapretOnVt
                }
              }).catch(() => {});
            }
          }
        }
      } catch (_) {}
    }, 350);
  }

  initVirusTotalPageBridge();
})();