// Полифилл промисов для старых версий Яндекс.Браузера / Chromium (< 95)
(() => {
  function promisifyMethod(obj, method) {
    if (!obj || typeof obj[method] !== "function") return;
    const orig = obj[method].bind(obj);
    obj[method] = function (...args) {
      if (typeof args[args.length - 1] === "function") {
        return orig(...args);
      }
      return new Promise((resolve, reject) => {
        orig(...args, (res) => {
          if (chrome.runtime?.lastError) {
            resolve(undefined);
          } else {
            resolve(res);
          }
        });
      });
    };
  }
  if (chrome.storage?.local) {
    promisifyMethod(chrome.storage.local, "get");
    promisifyMethod(chrome.storage.local, "set");
  }
  if (chrome.downloads) {
    promisifyMethod(chrome.downloads, "search");
    promisifyMethod(chrome.downloads, "pause");
    promisifyMethod(chrome.downloads, "resume");
    promisifyMethod(chrome.downloads, "cancel");
    promisifyMethod(chrome.downloads, "erase");
    promisifyMethod(chrome.downloads, "removeFile");
    promisifyMethod(chrome.downloads, "download");
  }
  if (chrome.tabs) {
    promisifyMethod(chrome.tabs, "query");
    promisifyMethod(chrome.tabs, "create");
    promisifyMethod(chrome.tabs, "sendMessage");
  }
  if (chrome.windows) {
    promisifyMethod(chrome.windows, "create");
  }
})();

// Универсальная совместимость MV3 и MV2 (для старых версий Яндекс.Браузера и Windows 10 Lite)
const browserActionApi = chrome.action || chrome.browserAction;
// VT Download Guard v1.0 — Background Service Worker (Manifest V3)
// Инженерные улучшения v1.5.0:
// 1. Потоковый инкрементальный SHA-256 (StreamingSha256 через ReadableStreamDefaultReader) с фиксированным потреблением ОЗУ (~1-2 МБ) без единого гигантского ArrayBuffer.
// 2. Исключение двойного скачивания: если файл уже вычитан в Blob (до 60 МБ), при чистом вердикте отменяется поставленная на паузу загрузка и файл отдаётся мгновенно из памяти через Offscreen Document (URL.createObjectURL) либо из локального .crdownload / file:///.
// 3. Keep-Alive Service Worker + сохранение состояния активных проверок в chrome.storage["session"] (переживает перезапуски воркера во время ожидания согласия пользователя).
// 4. Расширенный локальный анализатор:
//    - Детект атакующих Unicode-символов RLO (\u202E) и двойных расширений с пробелами (Договор.pdf   .scr).
//    - Мгновенный осмотр содержимого .zip без распаковки (парсинг Central Directory 50 4B 01 02 в последних 64 КБ буфера, работает даже на запароленных архивах).
//    - Поиск полиглотов (Polyglot files) и склеенных скриптов (<script>, powershell, mshta, MZ по смещениям в хвосте картинок/документов).
// 5. Защита приватных GET-токенов (token, sig, X-Amz-Signature, key, auth, session, pass) при фоллбэке на URL: проверка репутации домена (/api/v3/domains/{domain}) или запрос согласия вместо слива секретной ссылки в публичную базу URL.
// 6. Умный поллинг (/api/v3/analyses/{id}): первый опрос через 15 сек после отправки файла, далее каждые 16 сек с живым счётчиком прогресса (Проверено: X/72 АВ...).
// 7. Локальный кэш проверенных SHA-256 хешей в chrome.storage.local (TTL 7 дней): выдача результата за 0 мс без расхода квоты API.

// ==================== ПОТОКОВЫЙ ИНКРЕМЕНТАЛЬНЫЙ SHA-256 (FIPS 180-4) ====================
const SHA256_K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]);

class StreamingSha256 {
  constructor() {
    this.H = new Uint32Array([
      0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ]);
    this.W = new Uint32Array(64);
    this.buffer = new Uint8Array(64);
    this.bufferLength = 0;
    this.bytesProcessed = 0;
  }

  _processBlock(block, offset) {
    const W = this.W;
    for (let i = 0; i < 16; i++) {
      const idx = offset + i * 4;
      W[i] =
        ((block[idx] << 24) |
          (block[idx + 1] << 16) |
          (block[idx + 2] << 8) |
          block[idx + 3]) >>> 0;
    }
    for (let i = 16; i < 64; i++) {
      const v1 = W[i - 15];
      const s0 = (((v1 >>> 7) | (v1 << 25)) ^ ((v1 >>> 18) | (v1 << 14)) ^ (v1 >>> 3)) >>> 0;
      const v2 = W[i - 2];
      const s1 = (((v2 >>> 17) | (v2 << 15)) ^ ((v2 >>> 19) | (v2 << 13)) ^ (v2 >>> 10)) >>> 0;
      W[i] = (W[i - 16] + s0 + W[i - 7] + s1) >>> 0;
    }

    let a = this.H[0];
    let b = this.H[1];
    let c = this.H[2];
    let d = this.H[3];
    let e = this.H[4];
    let f = this.H[5];
    let g = this.H[6];
    let h = this.H[7];

    for (let i = 0; i < 64; i++) {
      const S1 = (((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7))) >>> 0;
      const ch = ((e & f) ^ (~e & g)) >>> 0;
      const temp1 = (h + S1 + ch + SHA256_K[i] + W[i]) >>> 0;
      const S0 = (((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10))) >>> 0;
      const maj = ((a & b) ^ (a & c) ^ (b & c)) >>> 0;
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    this.H[0] = (this.H[0] + a) >>> 0;
    this.H[1] = (this.H[1] + b) >>> 0;
    this.H[2] = (this.H[2] + c) >>> 0;
    this.H[3] = (this.H[3] + d) >>> 0;
    this.H[4] = (this.H[4] + e) >>> 0;
    this.H[5] = (this.H[5] + f) >>> 0;
    this.H[6] = (this.H[6] + g) >>> 0;
    this.H[7] = (this.H[7] + h) >>> 0;
  }

  update(chunk) {
    const data = chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk);
    let offset = 0;
    let length = data.length;
    this.bytesProcessed += length;

    if (this.bufferLength > 0) {
      const needed = 64 - this.bufferLength;
      if (length < needed) {
        this.buffer.set(data, this.bufferLength);
        this.bufferLength += length;
        return this;
      }
      this.buffer.set(data.subarray(0, needed), this.bufferLength);
      this._processBlock(this.buffer, 0);
      this.bufferLength = 0;
      offset += needed;
      length -= needed;
    }

    while (length >= 64) {
      this._processBlock(data, offset);
      offset += 64;
      length -= 64;
    }

    if (length > 0) {
      this.buffer.set(data.subarray(offset, offset + length), 0);
      this.bufferLength = length;
    }
    return this;
  }

  digestHex() {
    const bitLenHi = Math.floor((this.bytesProcessed * 8) / 0x100000000) >>> 0;
    const bitLenLo = ((this.bytesProcessed * 8) & 0xffffffff) >>> 0;

    this.buffer[this.bufferLength++] = 0x80;
    if (this.bufferLength > 56) {
      this.buffer.fill(0, this.bufferLength, 64);
      this._processBlock(this.buffer, 0);
      this.bufferLength = 0;
    }
    this.buffer.fill(0, this.bufferLength, 56);

    const view = new DataView(this.buffer.buffer);
    view.setUint32(56, bitLenHi, false);
    view.setUint32(60, bitLenLo, false);
    this._processBlock(this.buffer, 0);

    let hex = "";
    for (let i = 0; i < 8; i++) {
      hex += this.H[i].toString(16).padStart(8, "0");
    }
    return hex;
  }
}

// ==================== КАТАЛОГ ФОРМАТОВ И НАСТРОЙКИ ====================
const EXTENSION_CATALOG = {
  exec: [
    "exe", "msi", "msp", "msix", "appx", "apk", "aab", "xapk", "apkm", "ipa",
    "dmg", "pkg", "mpkg", "app", "deb", "rpm", "run", "bin", "elf", "appimage",
    "flatpak", "snap", "bat", "cmd", "com", "scr", "ps1", "vbs", "vbe", "wsf",
    "wsh", "hta", "cpl", "jar", "gadget"
  ],
  arch: [
    "zip", "zipx", "rar", "7z", "tar", "gz", "tgz", "bz2", "tbz2", "xz",
    "txz", "zst", "lz", "lzma", "lzh", "arj", "cab", "ace", "iso", "img",
    "nrg", "mdf", "mds", "vhd", "vhdx", "vmdk", "ova", "ovf", "wim", "cpio"
  ],
  docs: [
    "pdf", "doc", "docx", "docm", "dot", "dotx", "dotm", "xls", "xlsx", "xlsm",
    "xlsb", "xlt", "xltm", "ppt", "pptx", "pptm", "pps", "ppsx", "ppsm", "odt",
    "ods", "odp", "odg", "rtf", "txt", "csv", "tsv", "md", "tex", "epub",
    "mobi", "azw3", "fb2", "djvu", "chm", "hlp", "one", "vsd", "vsdx", "pub"
  ],
  img: [
    "png", "jpg", "jpeg", "jfif", "webp", "gif", "svg", "svgz", "ico", "cur",
    "ani", "bmp", "dib", "tiff", "tif", "heic", "heif", "avif", "jxl", "psd",
    "psb", "ai", "eps", "cdr", "indd", "xcf", "sketch", "fig", "raw", "cr2",
    "cr3", "nef", "arw", "dng", "stl", "obj", "fbx", "blend", "dwg", "dxf"
  ],
  media: [
    "mp3", "wav", "flac", "aac", "ogg", "oga", "opus", "m4a", "wma", "aiff",
    "alac", "amr", "ape", "mid", "midi", "mp4", "mkv", "avi", "mov", "wmv",
    "flv", "webm", "m4v", "mpg", "mpeg", "3gp", "3g2", "mts", "m2ts",
    "vob", "ogv", "m3u", "m3u8", "pls"
  ],
  code: [
    "js", "mjs", "cjs", "jse", "ts", "jsx", "tsx", "py", "pyc", "pyo",
    "pyw", "rb", "pl", "pm", "lua", "tcl", "sh", "bash", "zsh",
    "fish", "ksh", "go", "rs", "c", "cpp", "cc", "cxx", "h", "hpp",
    "cs", "java", "class", "kt", "kts", "swift", "dart", "scala", "groovy", "r",
    "jl", "wasm"
  ],
  data: [
    "json", "xml", "xsd", "xsl", "yaml", "yml", "toml", "ini", "cfg", "conf",
    "config", "properties", "env", "reg", "inf", "sql", "sqlite", "sqlite3", "db", "mdb",
    "accdb", "dbf", "parquet", "avro", "orc", "cer", "crt", "der", "pem", "p7b",
    "p7c", "p12", "pfx", "key", "ovpn"
  ],
  sys: [
    "dll", "sys", "drv", "ocx", "ax", "so", "dylib", "ko", "lnk", "url",
    "webloc", "desktop", "scf", "pif", "torrent", "pcap", "pcapng", "cap", "ttf", "otf",
    "woff", "woff2", "eot", "fon", "bak", "old", "tmp", "dat", "rom", "sav",
    "pak", "crx", "xpi"
  ]
};

const ALL_DEFAULT_EXTENSIONS = Array.from(
  new Set(Object.values(EXTENSION_CATALOG).flat())
);

const TRUSTED_VENDORS = new Set([
  "kaspersky",
  "drweb",
  "eset-nod32",
  "bitdefender",
  "microsoft",
  "malwarebytes",
  "symantec",
  "sophos",
  "crowdstrike falcon",
  "avast",
  "avg",
  "avira (no cloud)",
  "avira",
  "fortinet",
  "mcafee",
  "trendmicro",
  "trendmicro-housecall",
  "gdata",
  "f-secure",
  "clamav",
  "ahnlab-v3",
  "palo alto networks",
  "check point",
  "acronis (static ml)",
  "google",
  "emsisoft"
]);

const DEFAULT_WHITELIST_DOMAINS = [
  "github.com",
  "githubusercontent.com",
  "microsoft.com",
  "windowsupdate.com",
  "google.com",
  "googleapis.com",
  "gstatic.com",
  "mozilla.org",
  "apple.com",
  "localhost",
  "127.0.0.1",
  "192.168.*",
  "10.*"
];

const DEFAULT_SETTINGS = {
  enabled: true,
  uiLang: "ru", // "ru" | "en"
  tutorialCompleted: false,
  apiKey: "",
  scanWindowDisplayMode: "card_on_top",
  hybridProtectionEnabled: true,
  autonomousNoAvCoreEnabled: true,
  vtApiKeyModeEnabled: true,
  zeroKeyAndPcAvModeEnabled: true,
  noKeyMode: "autonomous_all_in_one", // "pc_antivirus_mode" | "hybrid_web" | "auto_open_popup" | "auto_open_tab"
  localPcAntivirusEnabled: true,
  proxyUrl: "", // Опциональный URL вашего Cloudflare Worker прокси (для работы 72 АВ без ключа пользователя)
  filterMode: "all",
  extensions: ALL_DEFAULT_EXTENSIONS,
  autoDownloadSafe: true,
  keepScanOnTabClose: true,
  showDetailedVendors: true,
  vendorDisplayMode: "inline_and_modal",
  uploadPolicy: "ask", // "ask" | "auto" | "hash_only"
  autoBlockEnabled: true,
  autoBlockThreshold: 1,
  autoBlockIncludeSuspicious: false,
  falsePositiveMode: "smart", // "smart" | "trusted_only" | "all"
  strictBlockLock: false,
  sizeLimitEnabled: false,
  maxFileSizeMB: 500,
  maxHeavyCategoryMB: 200,
  whitelistEnabled: false,
  domainWhitelist: DEFAULT_WHITELIST_DOMAINS,
  cacheEnabled: true,
  cacheTtlDays: 7,
  theme: "salmon_ocean",
  iconStyle: "auto",
  bgImageEnabled: true,
  bgOpacity: 36, // 5..85 (%)
  cardBgOpacity: 48, // 0..100 (%) — прозрачность блоков за текстом!
  glassBlurEnabled: true,
  customBgDataUrl: "",
  stickersEnabled: true,
  stickerLockClickThrough: true,
  stickerPreset: "auto_theme",
  customStickerDataUrl: "",
  stickerSize: 78,
  stickerOpacity: 85,
  stickerPosition: "bottom-right",
  stickerCustomX: 80,
  stickerCustomY: 75,
  soundPreset: "auto_theme",
  soundVolume: 70,
  customSoundDataUrl: "",
  customFontFamily: "system",
  customFontName: "",
  customFontDataUrl: "",
  customFontScale: 100,
  customBorderRadius: 10,
  customPopupWidth: 450,
  customColorsEnabled: false,
  customBgColor: "#051622",
  customCardColor: "#0a2538",
  customAccentColor: "#ff856d",
  customTextColorEnabled: false,
  customTextMainColor: "#f0f9ff",
  customTextSubColor: "#7dd3fc",
  bannerPosition: "top-right",
  autoCloseSafeSec: 8,
  soundAlertsEnabled: true,
  hoverBadgeEnabled: false,
  hoverTriggerMode: "alt_only",
  uiLang: "ru",
  tutorialCompleted: false, // "always" | "alt_only"
  selectionPopupEnabled: true,
  unshortenLinksEnabled: true,
  antiPhishingEnabled: true,
  clickFixShieldEnabled: true,
  clipboardHelperEnabled: true,
  peSignatureCheckEnabled: true,
  archiveLnkInspectEnabled: true,
  domainAgeCheckEnabled: true,
  trustScoreEnabled: true,
  smartSummaryEnabled: true,
  xrayRadarEnabled: true,
  encryptedArchiveDetectEnabled: true,
  htmlSmugglingProtectionEnabled: true,
  clipperGuardEnabled: true,
  cloudDriveHelperEnabled: true,
  liveParticlesEnabled: true,
  neonGlowIntensity: 35,
  cardAnimStyle: "slide",
  miniPillModeEnabled: false,
  activeSecurityPreset: "comfort",
  userCustomPresets: [],
  hotkeysEnabled: false,
  hotkeyToggle: "Alt+Shift+V",
  hotkeyScan: "Alt+Shift+S",
  hotkeyCloseAll: "Alt+Shift+C",
  snoozeUntil: 0,
  trustedHashes: [],
  totalScansCount: 0,
  totalThreatsBlocked: 0,
  totalCacheHits: 0,
  migrationV15Done: false,
  migrationV32DefaultsDone: false,
  migrationV33DefaultsDone: false,
  migrationV34DefaultsDone: false,
  migrationV35DefaultsDone: false,
  migrationV36ZapretCacheClean: false,
  scanHistory: []
};

const handledDownloadIds = new Set();
const approvedUrls = new Set();
const approvedDownloadIds = new Set();
const blobFilenameMap = new Map();
const pendingDownloads = new Map();
const savedDownloadBackups = new Map();
const savedDownloadBackupsByName = new Map();

// ==================== v1.0 TURBO: L1 ОЗУ-КЭШ НАСТРОЕК И ХЕШЕЙ (ОТВЕТ ЗА 0.1 МС БЕЗ ЧТЕНИЯ ДИСКА) ====================
let ramSettingsCache = null;
let ramHashCache = null;
const urlToSha256RamMap = new Map();

async function getFastSettings() {
  if (ramSettingsCache) return ramSettingsCache;
  const st = await chrome.storage.local.get(DEFAULT_SETTINGS);
  ramSettingsCache = { ...DEFAULT_SETTINGS, ...(st || {}) };
  if (Array.isArray(ramSettingsCache.extensions)) {
    ramSettingsCache.extensions = ramSettingsCache.extensions.filter(e => !WEB_PAGE_OR_SCRIPT_EXTS.has(String(e).toLowerCase()));
  }
  return ramSettingsCache;
}

chrome.storage?.onChanged?.addListener((changes, area) => {
  if (area === "local") {
    if (ramSettingsCache) {
      for (const [k, v] of Object.entries(changes)) {
        if (k === "vtHashCache") {
          ramHashCache = v.newValue || {};
        } else {
          ramSettingsCache[k] = v.newValue;
        }
      }
    }
    if (changes.vtHashCache) {
      ramHashCache = changes.vtHashCache.newValue || {};
    }
  }
});


// ==================== УДЕРЖАНИЕ SERVICE WORKER ОТ ЗАСЫПАНИЯ (KEEP-ALIVE + SESSION STORAGE) ====================
let keepAliveInterval = null;

function updateKeepAliveState() {
  if (pendingDownloads.size > 0) {
    if (!keepAliveInterval) {
      keepAliveInterval = setInterval(() => {
        if (pendingDownloads.size === 0) {
          clearInterval(keepAliveInterval);
          keepAliveInterval = null;
          return;
        }
        chrome.runtime.getPlatformInfo(() => {});
      }, 20000);
    }
  } else if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
    keepAliveInterval = null;
  }
  syncPendingToSessionStorage();
}

async function syncPendingToSessionStorage() {
  if (!chrome.storage?.["session"]) return;
  try {
    const serializable = {};
    for (const [k, v] of pendingDownloads.entries()) {
      serializable[k] = {
        downloadId: v.downloadId,
        url: v.url,
        referrer: v.referrer,
        filename: v.filename,
        fullPath: v.fullPath,
        fileSize: v.fileSize,
        ext: v.ext,
        tabId: v.tabId,
        sha256: v.sha256 || ""
      };
    }
    await chrome.storage["session"].set({ vtPendingDownloads: serializable });
  } catch (_) {}
}

async function restorePendingFromSessionStorage() {
  if (!chrome.storage?.["session"]) return;
  try {
    const { vtPendingDownloads } = await chrome.storage["session"].get("vtPendingDownloads");
    if (vtPendingDownloads && typeof vtPendingDownloads === "object") {
      for (const [k, v] of Object.entries(vtPendingDownloads)) {
        if (!pendingDownloads.has(k)) {
          pendingDownloads.set(k, v);
        }
      }
    }
  } catch (_) {}
}

restorePendingFromSessionStorage();

chrome.storage?.local?.get({ vtHashCache: {}, migrationV36ZapretCacheClean: false }, (st) => {
  if (!st || !st.migrationV36ZapretCacheClean) {
    chrome.storage.local.set({ vtHashCache: {}, migrationV36ZapretCacheClean: true });
    ramHashCache = {};
  }
});


// При установке или обновлении расширения сразу удаляем старую синюю плашку "🛡️ Проверить ссылку в VT" со всех уже открытых вкладок браузера
async function removeLegacyBlueHoverPillFromAllTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (t.id && t.url && /^https?:/i.test(t.url)) {
        if (chrome["scripting"]?.["executeScript"]) {
          chrome.scripting.executeScript({
            target: { tabId: t.id },
            func: () => {
              document.querySelectorAll("button").forEach((btn) => {
                const txt = (btn.textContent || "").trim();
                if (txt.includes("Проверить ссылку в VT") || txt.includes("Scan Link in VT")) {
                  btn.remove();
                }
              });
            }
          }).catch(() => {});
        }
      }
    }
  } catch (_) {}
}
removeLegacyBlueHoverPillFromAllTabs();


// ==================== v1.0 ОПТИМИЗАЦИЯ ПАМЯТИ И ТАЙМАУТОВ СЕТИ (БЕЗ УТЕЧЕК ОЗУ) ====================
async function fetchWithTimeout(resource, options = {}, timeoutMs = 8500) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(resource, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(id);
  }
}

function pruneMemoryAndBuffers() {
  try {
    const now = Date.now();
    if (handledDownloadIds.size > 500) {
      const arr = Array.from(handledDownloadIds);
      handledDownloadIds.clear();
      for (const id of arr.slice(-200)) handledDownloadIds.add(id);
    }
    if (approvedDownloadIds.size > 500) {
      const arr = Array.from(approvedDownloadIds);
      approvedDownloadIds.clear();
      for (const id of arr.slice(-200)) approvedDownloadIds.add(id);
    }
    if (approvedUrls.size > 200) {
      approvedUrls.clear();
    }
    if (urlToSha256RamMap.size > 300) {
      urlToSha256RamMap.clear();
    }
    for (const [sId, entry] of activeBannerCards.entries()) {
      if (now - (entry.updatedAt || 0) > 30 * 60 * 1000) {
        activeBannerCards.delete(sId);
      }
    }
    for (const [sId, item] of pendingDownloads.entries()) {
      if (now - (item.scanStartMs || 0) > 15 * 60 * 1000) {
        delete item.fileBlob;
        delete item.rawChunks;
        delete item.base64Data;
        pendingDownloads.delete(sId);
      }
    }
  } catch (_) {}
}
setInterval(pruneMemoryAndBuffers, 120000);

// Однократная миграция дефолтов при самой первой установке (не перезаписывает выбор пользователя при перезаходах!)
chrome.storage?.local?.get({ migrationV34DefaultsDone: false, migrationV35DefaultsDone: false }, (st) => {
  if (!st || (!st.migrationV34DefaultsDone && !st.migrationV35DefaultsDone)) {
    chrome.storage.local.set({
      hotkeysEnabled: false,
      hoverBadgeEnabled: false,
      migrationV34DefaultsDone: true,
      migrationV35DefaultsDone: true
    });
  }
});


// ==================== ЛОКАЛЬНЫЙ КЭШ SHA-256 ХЕШЕЙ (TTL 7 ДНЕЙ, 0 МС ОТВЕТ) ====================
const HASH_CACHE_MAX_ITEMS = 300;

async function getCachedHashReport(sha256, settings) {
  if (!settings.cacheEnabled || !sha256) return null;
  try {
    if (!ramHashCache) {
      const stored = await chrome.storage.local.get({ vtHashCache: {} });
      ramHashCache = stored.vtHashCache || {};
    }
    const vtHashCache = ramHashCache;
    const entry = vtHashCache[sha256];
    if (!entry) return null;
    const hasActiveVtKey = settings.vtApiKeyModeEnabled !== false && Boolean(sanitizeApiKey(settings.apiKey));
    if (hasActiveVtKey && (entry.fileMeta?.noKeyModeUsed || (Array.isArray(entry.allVendors) && entry.allVendors.length < 15))) {
      return null; // Включён API-ключ VT — игнорируем старый неполный кэш без 72 АВ, чтобы выполнить полную проверку в VirusTotal!
    }
    const ttlMs = (Math.max(1, Number(settings.cacheTtlDays) || 7)) * 24 * 3600 * 1000;
    if (Date.now() - (entry.cachedAt || 0) > ttlMs) {
      delete vtHashCache[sha256];
      await chrome.storage.local.set({ vtHashCache });
      return null;
    }
    return entry;
  } catch (_) {
    return null;
  }
}

async function setCachedHashReport(sha256, reportData) {
  if (!sha256) return;
  try {
    if (!ramHashCache) {
      const stored = await chrome.storage.local.get({ vtHashCache: {} });
      ramHashCache = stored.vtHashCache || {};
    }
    const vtHashCache = ramHashCache;
    vtHashCache[sha256] = {
      ...reportData,
      cachedAt: Date.now()
    };
    const keys = Object.keys(vtHashCache);
    if (keys.length > HASH_CACHE_MAX_ITEMS) {
      keys.sort((a, b) => (vtHashCache[a].cachedAt || 0) - (vtHashCache[b].cachedAt || 0));
      for (let i = 0; i < keys.length - HASH_CACHE_MAX_ITEMS; i++) {
        delete vtHashCache[keys[i]];
      }
    }
    await chrome.storage.local.set({ vtHashCache });
  } catch (_) {}
}


// ==================== v1.8.0: ДИНАМИЧЕСКАЯ СМЕНА ИКОНКИ В БРАУЗЕРЕ И СИНХРОНИЗАЦИЯ ТЕМ ====================
const THEME_TO_ICON_MAP = {
  dark_cyber: "blue",
  salmon_ocean: "salmon",
  helldivers2: "helldivers",
  ozen_abyss: "ozen",
  vocaloid_teto: "teto",
  vocaloid_miku: "miku",
  oled_matrix: "emerald",
  purple_synth: "purple",
  crimson_guard: "crimson",
  light_clean: "blue"
};

const VALID_ICON_STYLES = new Set([
  "blue", "salmon", "helldivers", "ozen", "teto", "miku", "emerald", "purple", "crimson", "gold"
]);

function resolveActiveIconColor(settings) {
  if (!settings || settings.enabled === false) return "gray";
  const style = settings.iconStyle || "auto";
  if (style === "auto") {
    return THEME_TO_ICON_MAP[settings.theme || "dark_cyber"] || "blue";
  }
  return VALID_ICON_STYLES.has(style) ? style : "blue";
}

function applyExtensionToolbarIcon(settings) {
  try {
    const colorKey = resolveActiveIconColor(settings);
    if (browserActionApi && typeof browserActionApi.setIcon === "function") {
      browserActionApi.setIcon({
        path: {
          "16": `icons/icon_${colorKey}_16.png`,
          "48": `icons/icon_${colorKey}_48.png`,
          "128": `icons/icon_${colorKey}_128.png`
        }
      });
    }
  } catch (_) {}
}

chrome.storage?.onChanged?.addListener((changes, area) => {
  if (area === "local" && (changes.enabled || changes.theme || changes.iconStyle)) {
    chrome.storage.local.get(DEFAULT_SETTINGS, (st) => {
      applyExtensionToolbarIcon(st);
    });
  }
});


// ==================== v1.0: ТАЙМЕР ВРЕМЕННОЙ ПАУЗЫ (SNOOZE), РАСКРЫТИЕ КОРОТКИХ ССЫЛОК И ДОВЕРЕННЫЕ ХЕШИ ====================
const SHORTENER_DOMAINS = new Set([
  "bit.ly", "t.co", "tinyurl.com", "clck.ru", "vk.cc", "cutt.ly", "is.gd",
  "rb.gy", "shorturl.at", "goo.su", "tiny.cc", "ow.ly", "rebrand.ly", "buff.ly"
]);

async function resolveRedirectUrlIfNeeded(rawUrl, settings) {
  if (!rawUrl || settings?.unshortenLinksEnabled === false) {
    return { finalUrl: rawUrl, redirected: false, chainNote: "" };
  }
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.toLowerCase().replace(/^www\./, "");
    if (!SHORTENER_DOMAINS.has(host)) {
      return { finalUrl: rawUrl, redirected: false, chainNote: "" };
    }
    const resp = await fetch(rawUrl, { method: "HEAD", redirect: "follow" }).catch(() => null);
    if (resp && resp.url && resp.url !== rawUrl) {
      return {
        finalUrl: resp.url,
        redirected: true,
        chainNote: `Раскрыт редирект короткой ссылки: ${host} → ${new URL(resp.url).hostname}`
      };
    }
  } catch (_) {}
  return { finalUrl: rawUrl, redirected: false, chainNote: "" };
}

// Проверка таймера временной паузы ("Пауза на 15/30/60 минут")
setInterval(async () => {
  try {
    const st = await chrome.storage.local.get({ enabled: true, snoozeUntil: 0, theme: "dark_cyber", iconStyle: "auto" });
    if (!st.enabled && st.snoozeUntil > 0 && Date.now() >= st.snoozeUntil) {
      await chrome.storage.local.set({ enabled: true, snoozeUntil: 0 });
      applyExtensionToolbarIcon({ ...st, enabled: true });
    }
  } catch (_) {}
}, 5000);

// ==================== КОНТРОЛЬ RATE LIMITS (4/МИН, 500/ДЕНЬ) И ОЧЕРЕДЬ ====================
const VT_LIMIT_PER_MIN = 4;
const VT_LIMIT_PER_DAY = 500;
let minuteRequestTimestamps = [];
let apiQueueCount = 0;
let badgeAnimInterval = null;

function isTrustedVendor(engineName) {
  if (!engineName) return false;
  return TRUSTED_VENDORS.has(String(engineName).toLowerCase().trim());
}

function setExtensionBadge(state, count = 0) {
  if (badgeAnimInterval) {
    clearInterval(badgeAnimInterval);
    badgeAnimInterval = null;
  }
  try {
    if (state === "scanning") {
      const frames = ["•  ", "•• ", "•••", " ••"];
      let idx = 0;
      browserActionApi.setBadgeBackgroundColor({ color: "#0284c7" });
      browserActionApi.setBadgeText({ text: "•••" });
      badgeAnimInterval = setInterval(() => {
        idx = (idx + 1) % frames.length;
        browserActionApi.setBadgeText({ text: frames[idx] });
      }, 400);
    } else if (state === "safe") {
      browserActionApi.setBadgeBackgroundColor({ color: "#10b981" });
      browserActionApi.setBadgeText({ text: "0" });
      badgeAnimInterval = setTimeout(() => {
        try { browserActionApi.setBadgeText({ text: "" }); } catch (_) {}
        badgeAnimInterval = null;
      }, 8000);
    } else if (state === "warning") {
      browserActionApi.setBadgeBackgroundColor({ color: "#f59e0b" });
      browserActionApi.setBadgeText({ text: `${count || 1}?` });
    } else if (state === "danger") {
      browserActionApi.setBadgeBackgroundColor({ color: "#ef4444" });
      browserActionApi.setBadgeText({ text: `${count}!` });
    } else if (state === "clear") {
      browserActionApi.setBadgeText({ text: "" });
    }
  } catch (_) {}
}

async function getRateLimitStatus() {
  const now = Date.now();
  minuteRequestTimestamps = minuteRequestTimestamps.filter(ts => now - ts < 60000);

  const todayStr = new Date().toISOString().slice(0, 10);
  const stored = await chrome.storage.local.get({
    vtDailyDate: todayStr,
    vtDailyCount: 0,
    vtMinuteTimestamps: [],
    vtHashCache: {},
    trustedHashes: []
  });

  const mergedMin = Array.from(
    new Set([...minuteRequestTimestamps, ...(stored.vtMinuteTimestamps || [])])
  ).filter(ts => now - ts < 60000);
  minuteRequestTimestamps = mergedMin;

  const dailyCount = stored.vtDailyDate === todayStr ? Number(stored.vtDailyCount) || 0 : 0;
  const cacheCount = Object.keys(stored.vtHashCache || {}).length;

  const trustedCount = Array.isArray(stored.trustedHashes) ? stored.trustedHashes.length : 0;
  return {
    minuteUsed: minuteRequestTimestamps.length,
    minuteLimit: VT_LIMIT_PER_MIN,
    dailyUsed: dailyCount,
    dailyLimit: VT_LIMIT_PER_DAY,
    queueLength: apiQueueCount,
    cacheCount,
    trustedCount,
    waitMs:
      minuteRequestTimestamps.length >= VT_LIMIT_PER_MIN
        ? Math.max(1000, 60500 - (now - minuteRequestTimestamps[0]))
        : 0
  };
}

async function consumeRateLimitSlot(onWaitTick) {
  apiQueueCount++;
  try {
    while (true) {
      const status = await getRateLimitStatus();
      if (status.dailyUsed >= status.dailyLimit) {
        throw new Error("Исчерпан дневной лимит бесплатного ключа VirusTotal (500/500 запросов в сутки).");
      }
      if (status.minuteUsed < status.minuteLimit) {
        const now = Date.now();
        minuteRequestTimestamps.push(now);
        const todayStr = new Date().toISOString().slice(0, 10);
        await chrome.storage.local.set({
          vtDailyDate: todayStr,
          vtDailyCount: status.dailyUsed + 1,
          vtMinuteTimestamps: minuteRequestTimestamps
        });
        return;
      }
      const waitSec = Math.ceil(status.waitMs / 1000);
      if (typeof onWaitTick === "function") {
        await onWaitTick(waitSec, apiQueueCount);
      }
      await new Promise(r => setTimeout(r, 1000));
    }
  } finally {
    apiQueueCount = Math.max(0, apiQueueCount - 1);
  }
}

function sanitizeApiKey(rawKey) {
  if (!rawKey) return "";
  const str = String(rawKey).trim();
  const hexMatch = str.match(/[a-fA-F0-9]{64}/);
  if (hexMatch) return hexMatch[0].toLowerCase();
  return str.replace(/["'\s]/g, "");
}

function getVtUrlId(rawUrl) {
  try {
    const bytes = new TextEncoder().encode(rawUrl);
    let binary = "";
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary).replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
  } catch (_) {
    return "";
  }
}

function formatFileSize(bytes) {
  const num = Number(bytes) || 0;
  if (num <= 0) return "Неизвестно";
  if (num < 1024) return `${num} B`;
  if (num < 1024 * 1024) return `${(num / 1024).toFixed(2)} KB`;
  if (num < 1024 * 1024 * 1024) return `${(num / (1024 * 1024)).toFixed(2)} MB`;
  return `${(num / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function formatAnalysisDate(unixSeconds) {
  if (!unixSeconds) return "Только что";
  try {
    const diffSec = Math.max(0, Math.floor(Date.now() / 1000) - Number(unixSeconds));
    if (diffSec < 60) return "Только что";
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)} мин. назад`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)} ч. назад`;
    const d = new Date(Number(unixSeconds) * 1000);
    return d.toLocaleDateString("ru-RU") + " " + d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  } catch (_) {
    return "Недавно";
  }
}

// ==================== ПРОКАЧАННЫЙ ЛОКАЛЬНЫЙ АНАЛИЗАТОР ИМЁН, ZIP И ПОЛИГЛОТОВ ====================

// 1. Детект атакующих символов в имени файла (RLO \u202E и двойные расширения с пробелами)
function analyzeFilenameAttack(rawFilename) {
  if (!rawFilename) return { suspicious: false, reason: "" };

  // Проверка на Right-to-Left Override (‮) и другие невидимые управляющие Bidi-символы
  const bidiRegex = /[\u202A-\u202E\u2066-\u2069\u200E\u200F]/;
  if (bidiRegex.test(rawFilename)) {
    return {
      suspicious: true,
      reason: "Атака Right-to-Left Override (RLO \u202E): имя файла содержит невидимый символ разворота текста для маскировки расширения!"
    };
  }

  // Проверка на двойное расширение с пробелами-заполнителями (например: "Договор.pdf                  .scr" или "Счёт.docx.exe")
  const dangerousEndExts = new Set([
    "exe", "scr", "pif", "bat", "cmd", "com", "vbs", "vbe", "js", "jse",
    "wsf", "wsh", "ps1", "hta", "cpl", "msi", "msp", "lnk", "jar", "reg"
  ]);
  const decoyDocExts = new Set([
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf",
    "jpg", "jpeg", "png", "gif", "webp", "mp3", "mp4", "zip", "rar"
  ]);

  const clean = getBasename(rawFilename);
  const parts = clean.split(".");
  if (parts.length >= 3) {
    const realExt = parts[parts.length - 1].toLowerCase().trim();
    const prevPart = parts[parts.length - 2];
    const prevExt = prevPart.trim().toLowerCase();

    if (dangerousEndExts.has(realExt)) {
      if (/\s{3,}/.test(prevPart)) {
        return {
          suspicious: true,
          reason: `Маскировка двойного расширения с пробелами-заполнителями (.${prevExt} ... .${realExt})!`
        };
      }
      if (decoyDocExts.has(prevExt)) {
        return {
          suspicious: true,
          reason: `Двойное расширение: исполняемый файл .${realExt} замаскирован под документ/медиа (.${prevExt}.${realExt})!`
        };
      }
    }
  }

  return { suspicious: false, reason: "" };
}

// 2. Мгновенный осмотр содержимого .zip без распаковки (по Central Directory 50 4B 01 02 в последних 64 КБ)
function inspectZipCentralDirectory(tailBytes) {
  if (!tailBytes || tailBytes.length < 46) {
    return { files: [], dangerousFiles: [] };
  }
  const files = [];
  const dangerousFiles = [];
  inspectZipCentralDirectory._lastDetails = [];
  let encryptedEntriesCount = 0;
  const dangerousExts = new Set([
    "exe", "scr", "bat", "cmd", "com", "vbs", "vbe", "js", "jse",
    "wsf", "wsh", "ps1", "hta", "lnk", "pif", "msi", "cpl", "dll", "reg"
  ]);
  const decoder = new TextDecoder("utf-8", { fatal: false });

  for (let i = 0; i <= tailBytes.length - 46; i++) {
    // Сигнатура Central Directory File Header: 0x50 0x4B 0x01 0x02 ("PK")
    if (
      tailBytes[i] === 0x50 &&
      tailBytes[i + 1] === 0x4b &&
      tailBytes[i + 2] === 0x01 &&
      tailBytes[i + 3] === 0x02
    ) {
      const gpBitFlag = tailBytes[i + 8] | (tailBytes[i + 9] << 8);
      if ((gpBitFlag & 0x01) !== 0) {
        encryptedEntriesCount++;
      }
      const crc32 = (
        tailBytes[i + 16] |
        (tailBytes[i + 17] << 8) |
        (tailBytes[i + 18] << 16) |
        (tailBytes[i + 19] << 24)
      ) >>> 0;
      const uncompSize = (
        tailBytes[i + 24] |
        (tailBytes[i + 25] << 8) |
        (tailBytes[i + 26] << 16) |
        (tailBytes[i + 27] << 24)
      ) >>> 0;
      const nameLen = tailBytes[i + 28] | (tailBytes[i + 29] << 8);
      const extraLen = tailBytes[i + 30] | (tailBytes[i + 31] << 8);
      const commentLen = tailBytes[i + 32] | (tailBytes[i + 33] << 8);
      const nameStart = i + 46;
      if (nameLen > 0 && nameStart + nameLen <= tailBytes.length) {
        const entryName = decoder.decode(tailBytes.subarray(nameStart, nameStart + nameLen));
        files.push(entryName);
        if (! inspectZipCentralDirectory._lastDetails) inspectZipCentralDirectory._lastDetails = [];
        inspectZipCentralDirectory._lastDetails.push({ name: entryName, crc32, size: uncompSize });

        // Проверяем вложенный файл на атаку RLO, двойные или опасные расширения
        const cleanEntry = entryName.replace(/\\/g, "/").split("/").pop() || "";
        if (cleanEntry && cleanEntry.includes(".")) {
          const ext = cleanEntry.split(".").pop().toLowerCase().trim();
          if (dangerousExts.has(ext) || analyzeFilenameAttack(cleanEntry).suspicious) {
            dangerousFiles.push(entryName);
          }
        }
        i = nameStart + nameLen + extraLen + commentLen - 1;
      }
    }
  }

  const hasExtManifest = files.some(f => {
    const low = String(f).replace(/\\/g, "/").toLowerCase();
    return low === "manifest.json" || low.endsWith("/manifest.json");
  });
  const filteredDangerous = hasExtManifest
    ? dangerousFiles.filter(f => !String(f).toLowerCase().endsWith(".js"))
    : dangerousFiles;

  return {
    files: Array.from(new Set(files)).slice(0, 60),
    allFilesRaw: Array.from(new Set(files)),
    entryDetails: inspectZipCentralDirectory._lastDetails || [],
    dangerousFiles: Array.from(new Set(filteredDangerous)),
    isEncrypted: encryptedEntriesCount > 0,
    encryptedEntriesCount
  };
}


// ==================== ВЕРИФИКАТОР ПОДЛИННОСТИ ZAPRET (ОФИЦИАЛЬНЫЙ FLOWSEAL VS НЕОФИЦИАЛЬНЫЕ ПОДДЕЛКИ, ВСЕ ВЕРСИИ .ZIP И .RAR) ====================
const OFFICIAL_FLOWSEAL_REPO_URL = "https://github.com/Flowseal/zapret-discord-youtube";
const OFFICIAL_FLOWSEAL_RELEASES_URL = "https://github.com/Flowseal/zapret-discord-youtube/releases";
const OFFICIAL_FLOWSEAL_PROFILE_URL = "https://github.com/Flowseal";

const OFFICIAL_FLOWSEAL_KNOWN_HASHES = new Set([
  "244314ae1c24538a0d751601da8e0c925c843371eec4456eb15f14c4fd6b7058", // zapret-discord-youtube-1.10.3.zip
  "affb4f69d2ea302a7abccd5325d81826e140ddae014f1e070bc4a6c0dd555188", // bin/winws.exe
  "c1e060ee19444a259b2162f8af0f3fe8c4428a1c6f694dce20de194ac8d7d9a2", // bin/WinDivert.dll
  "8da085332782708d8767bcace5327a6ec7283c17cfb85e40b03cd2323a90ddc2", // bin/WinDivert64.sys
  "103104a52e5293ce418944725df19e2bf81ad9269b9a120d71d39028e821499b"  // bin/cygwin1.dll
]);

const ALLOWED_FLOWSEAL_BINARIES = new Set([
  "winws.exe", "windivert.dll", "windivert64.sys", "windivert32.sys", "cygwin1.dll", "blockcheck.exe"
]);

// Кэш всех официальных релизов Flowseal с GitHub API (автоматически видит все прошлые, текущие и будущие версии .zip и .rar!)
let flowsealReleasesCache = null;
let flowsealReleasesCacheTime = 0;

function normalizeZapretAssetName(rawFilename) {
  if (!rawFilename) return "";
  // Убираем браузерные суффиксы дубликатов: "zapret-discord-youtube-1.10.3 (2).zip" -> "zapret-discord-youtube-1.10.3.zip"
  return getBasename(rawFilename)
    .replace(/\s*\(\d+\)(?=\.[^.]+$)/, "")
    .replace(/\s*-\s*(копия|copy)(?=\.[^.]+$)/i, "")
    .trim()
    .toLowerCase();
}

async function fetchOfficialFlowsealReleases() {
  const now = Date.now();
  if (flowsealReleasesCache && now - flowsealReleasesCacheTime < 15 * 60 * 1000) {
    return flowsealReleasesCache;
  }
  try {
    const resp = await fetchWithTimeout(
      "https://api.github.com/repos/Flowseal/zapret-discord-youtube/releases?per_page=40",
      { headers: { "accept": "application/vnd.github+json" } },
      3500
    );
    if (resp && resp.ok) {
      const releases = await resp.json();
      if (Array.isArray(releases)) {
        const assetsMap = new Map();
        const tagsSet = new Set();
        for (const rel of releases) {
          if (rel.tag_name) tagsSet.add(String(rel.tag_name).toLowerCase().replace(/^v/, ""));
          for (const asset of (rel.assets || [])) {
            if (!asset || !asset.name) continue;
            const normName = asset.name.trim().toLowerCase();
            const shaDigest = asset.digest && String(asset.digest).startsWith("sha256:")
              ? String(asset.digest).slice(7).toLowerCase()
              : "";
            assetsMap.set(normName, {
              name: asset.name,
              size: Number(asset.size) || 0,
              sha256: shaDigest,
              downloadUrl: asset.browser_download_url || "",
              tag: rel.tag_name || ""
            });
            if (shaDigest) OFFICIAL_FLOWSEAL_KNOWN_HASHES.add(shaDigest);
          }
        }
        flowsealReleasesCache = { assetsMap, tagsSet };
        flowsealReleasesCacheTime = now;
        return flowsealReleasesCache;
      }
    }
  } catch (_) {}
  return flowsealReleasesCache;
}

// Запускаем фоновую предзагрузку списка релизов Flowseal при старте
fetchOfficialFlowsealReleases().catch(() => {});

function isOfficialFlowsealUrl(rawUrl) {
  if (!rawUrl) return false;
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.toLowerCase().replace(/^www\./, "");
    const pathLower = u.pathname.toLowerCase().replace(/\/+$/, "");
    if (host === "github.com") {
      if (
        pathLower === "/flowseal" ||
        pathLower === "/flowseal/zapret-discord-youtube" ||
        pathLower.startsWith("/flowseal/zapret-discord-youtube/")
      ) {
        return true;
      }
    }
    if (
      (host === "raw.githubusercontent.com" || host === "codeload.github.com") &&
      pathLower.startsWith("/flowseal/zapret-discord-youtube/")
    ) {
      return true;
    }
  } catch (_) {}
  return false;
}

function inspectZapretAuthenticity({
  filename = "",
  sha256 = "",
  fileSize = 0,
  zipInfo = null,
  rarFiles = [],
  headBytes = null,
  tailBytes = null,
  expectedExt = "",
  sourceUrl = "",
  origUrl = "",
  referrerUrl = "",
  tabUrl = ""
}) {
  const cleanName = (filename || "").toLowerCase();
  const normAssetName = normalizeZapretAssetName(filename);
  const cleanSha = (sha256 || "").toLowerCase().trim();
  const zipEntries = zipInfo?.allFilesRaw || zipInfo?.files || [];
  const entryDetails = zipInfo?.entryDetails || [];
  const allEntries = zipEntries.length > 0 ? zipEntries : (rarFiles || []);

  const hasZapretName =
    /zapret/i.test(cleanName) ||
    /zapret/i.test(sourceUrl) ||
    /zapret/i.test(origUrl) ||
    /zapret/i.test(referrerUrl);
  const hasWinwsInArchive = allEntries.some(f => /(^|\/|\\)winws\.exe$/i.test(f));
  const hasServiceBatInArchive = allEntries.some(f => /(^|\/|\\)service\.bat$/i.test(f));

  if (!hasZapretName && !hasWinwsInArchive && !OFFICIAL_FLOWSEAL_KNOWN_HASHES.has(cleanSha)) {
    return null;
  }

  // 1. Проверяем, скачан ли файл напрямую с официального GitHub разработчика Flowseal (включая редиректы GitHub Releases на objects.githubusercontent.com)
  const allUrls = [origUrl, sourceUrl, referrerUrl, tabUrl].filter(Boolean);
  const comesFromOfficialFlowsealUrl = allUrls.some(u => isOfficialFlowsealUrl(u));

  let downloadedFromUnofficialSite = false;
  let unofficialSiteHost = "";

  if (!comesFromOfficialFlowsealUrl) {
    for (const candidateU of [origUrl, sourceUrl, referrerUrl]) {
      if (!candidateU || !/^https?:\/\//i.test(candidateU)) continue;
      try {
        const uObj = new URL(candidateU);
        const h = uObj.hostname.toLowerCase().replace(/^www\./, "");
        const isGithubCdn =
          h === "github.com" ||
          h.endsWith(".githubusercontent.com") ||
          h === "githubusercontent.com";
        if (!isGithubCdn) {
          downloadedFromUnofficialSite = true;
          unofficialSiteHost = h;
          break;
        } else if (h === "github.com" && uObj.pathname.length > 1 && !isOfficialFlowsealUrl(candidateU)) {
          downloadedFromUnofficialSite = true;
          unofficialSiteHost = uObj.hostname + uObj.pathname.split("/").slice(0, 3).join("/");
          break;
        }
      } catch (_) {}
    }
  }

  // 2. Если под видом Zapret скачивается одиночный .exe / .msi / .scr / .vbs / .lnk установщик (Flowseal выпускает релизы ТОЛЬКО в архивах .zip и .rar!)
  if (hasZapretName && ["exe", "msi", "scr", "vbs", "hta", "lnk", "jar"].includes(expectedExt) && !OFFICIAL_FLOWSEAL_KNOWN_HASHES.has(cleanSha)) {
    return {
      isZapretCandidate: true,
      isOfficialFlowseal: false,
      isUnofficialZapret: true,
      reasons: [
        `Поддельный формат (.${expectedExt}): официальный разработчик Flowseal публикует zapret-discord-youtube ТОЛЬКО в виде архивов .zip и .rar, а не в виде одиночного .${expectedExt} инсталлятора!`
      ]
    };
  }

  // 3. Сверяем с кэшем официальных релизов GitHub API (Flowseal/zapret-discord-youtube/releases — видит все версии .zip и .rar, включая будущие!)
  if (flowsealReleasesCache && flowsealReleasesCache.assetsMap) {
    const matchedAsset = flowsealReleasesCache.assetsMap.get(normAssetName);
    if (matchedAsset) {
      if (matchedAsset.sha256 && cleanSha && matchedAsset.sha256 !== cleanSha) {
        return {
          isZapretCandidate: true,
          isOfficialFlowseal: false,
          isUnofficialZapret: true,
          reasons: [
            `Хеш SHA-256 файла НЕ совпадает с официальным релизом ${matchedAsset.name} разработчика Flowseal на GitHub (архив был модифицирован)!`
          ]
        };
      }
      if (matchedAsset.size > 0 && fileSize > 0 && Math.abs(matchedAsset.size - fileSize) > 16) {
        return {
          isZapretCandidate: true,
          isOfficialFlowseal: false,
          isUnofficialZapret: true,
          reasons: [
            `Размер архива (${formatFileSize(fileSize)}) отличается от официального релиза Flowseal «${matchedAsset.name}» на GitHub (${formatFileSize(matchedAsset.size)})!`
          ]
        };
      }
      if (!downloadedFromUnofficialSite) {
        return {
          isZapretCandidate: true,
          isOfficialFlowseal: true,
          isUnofficialZapret: false,
          verifiedBy: `Официальный релиз Flowseal (${matchedAsset.name}, тег ${matchedAsset.tag}) подтверждён через GitHub Releases`,
          reasons: []
        };
      }
    }
  }

  // 4. Проверяем точное совпадение SHA-256 с эталонными хешами Flowseal
  if (!downloadedFromUnofficialSite && cleanSha && OFFICIAL_FLOWSEAL_KNOWN_HASHES.has(cleanSha)) {
    return {
      isZapretCandidate: true,
      isOfficialFlowseal: true,
      isUnofficialZapret: false,
      verifiedBy: "SHA-256 эталонного релиза Flowseal (github.com/Flowseal/zapret-discord-youtube)",
      reasons: []
    };
  }

  const unofficialReasons = [];
  if (downloadedFromUnofficialSite) {
    unofficialReasons.push(
      `Файл скачан с НЕОФИЦИАЛЬНОГО источника («${unofficialSiteHost}»), а не из официального репозитория разработчика Flowseal (${OFFICIAL_FLOWSEAL_REPO_URL})!`
    );
  }

  // 5. Проверяем содержимое буфера (.zip и .rar) на вредоносные вставки (стилеры, вебхуки, скрытый PowerShell -enc)
  const combinedLen = (headBytes?.length || 0) + (tailBytes?.length || 0);
  let textSampleLower = "";
  if (combinedLen > 0) {
    const combined = new Uint8Array(combinedLen);
    if (headBytes) combined.set(headBytes, 0);
    if (tailBytes) combined.set(tailBytes, headBytes ? headBytes.length : 0);
    textSampleLower = new TextDecoder("latin1").decode(combined).toLowerCase();
    const badInjections = [
      { pat: "-encodedcommand", label: "зашифрованная команда PowerShell (-EncodedCommand)" },
      { pat: "frombase64string", label: "скрытая распаковка Base64-пейлоада" },
      { pat: "api.telegram.org/bot", label: "отправка данных боту Telegram (признак стилера)" },
      { pat: "discord.com/api/webhooks", label: "отправка данных на Discord Webhook (признак стилера)" },
      { pat: "certutil -urlcache", label: "скрытая подгрузка трояна через certutil" },
      { pat: "bitsadmin /transfer", label: "скрытая подгрузка через bitsadmin" },
      { pat: "mshta", label: "запуск вредоносного окна mshta" }
    ];
    for (const bi of badInjections) {
      if (textSampleLower.includes(bi.pat)) {
        unofficialReasons.push(`Внутри архива обнаружена вредоносная вставка: ${bi.label}!`);
      }
    }
  }

  // 6. Проверяем список файлов внутри архива (.ZIP или .RAR)
  if (entryDetails.length > 0) {
    // Для .ZIP: полная проверка Central Directory и CRC-32 драйверов WinDivert
    const unauthorizedExecs = [];
    let foundWinws = false;
    let foundWinDivertSys = false;
    let foundWinDivertDll = false;

    for (const det of entryDetails) {
      const normPath = det.name.replace(/\\/g, "/");
      const base = (normPath.split("/").pop() || "").toLowerCase().trim();
      if (!base) continue;

      const ext = base.includes(".") ? base.split(".").pop().toLowerCase() : "";
      if (["exe", "dll", "sys", "scr", "msi", "com", "vbs", "vbe", "js", "jse", "wsf", "hta", "lnk", "jar", "cpl"].includes(ext)) {
        if (!ALLOWED_FLOWSEAL_BINARIES.has(base)) {
          unauthorizedExecs.push(det.name);
        } else {
          if (base === "winws.exe") {
            foundWinws = true;
            if (det.size > 0 && det.size < 50000) {
              unofficialReasons.push(`Файл bin/winws.exe внутри архива имеет подозрительно малый размер (${det.size} байт) — признак подмены!`);
            }
          }
          if (base === "windivert64.sys" || base === "windivert32.sys") {
            foundWinDivertSys = true;
            if (base === "windivert64.sys" && det.crc32 && det.crc32 !== 0x35b3f193) {
              unofficialReasons.push("Драйвер bin/WinDivert64.sys модифицирован (CRC-32 не совпадает с оригинальной цифровой подписью WinDivert)!");
            }
          }
          if (base === "windivert.dll") {
            foundWinDivertDll = true;
            if (det.crc32 && det.crc32 !== 0x2d73df36) {
              unofficialReasons.push("Библиотека bin/WinDivert.dll модифицирована (CRC-32 отличается от оригинала Flowseal)!");
            }
          }
        }
      }
    }

    if (unauthorizedExecs.length > 0) {
      unofficialReasons.push(
        `Внутри архива обнаружены посторонние исполняемые файлы, которых НЕТ у официального разработчика Flowseal: ${unauthorizedExecs.slice(0, 4).join(", ")}!`
      );
    }
    if (!foundWinws || !foundWinDivertDll || !foundWinDivertSys || !hasServiceBatInArchive) {
      unofficialReasons.push(
        "В архиве отсутствуют обязательные официальные модули Flowseal (bin/winws.exe, WinDivert.dll, WinDivert64.sys или service.bat)."
      );
    }
  } else if (allEntries.length > 0) {
    // Для .RAR и .7Z архивов: проверяем найденные в заголовках RAR имена файлов на отсутствие посторонних .exe / .scr / .vbs
    const unauthorizedRarExecs = [];
    for (const fName of allEntries) {
      const base = (fName.replace(/\\/g, "/").split("/").pop() || "").toLowerCase().trim();
      const ext = base.includes(".") ? base.split(".").pop().toLowerCase() : "";
      if (["exe", "dll", "sys", "scr", "msi", "vbs", "hta", "lnk", "jar"].includes(ext)) {
        if (!ALLOWED_FLOWSEAL_BINARIES.has(base)) {
          unauthorizedRarExecs.push(base);
        }
      }
    }
    if (unauthorizedRarExecs.length > 0) {
      unofficialReasons.push(
        `Внутри RAR-архива обнаружены посторонние исполняемые файлы, которых нет у Flowseal: ${unauthorizedRarExecs.slice(0, 4).join(", ")}!`
      );
    }
  }

  // 7. Если архив скачан с официального GitHub Flowseal (или имеет каноническое имя релиза zapret-discord-youtube-<версия>.rar / .zip без признаков подделки)
  const isCanonicalReleaseName = /^zapret-discord-youtube-[0-9]+\.[0-9]+(\.[0-9]+)?([a-z0-9_-]*)?\.(zip|rar|7z)$/i.test(normAssetName);
  const hasFlowsealSignatureInBytes =
    textSampleLower.includes("flowseal/zapret-discord-youtube") ||
    textSampleLower.includes("winws.exe") ||
    textSampleLower.includes("windivert") ||
    textSampleLower.includes("service.bat") ||
    textSampleLower.includes("general.bat");

  if (unofficialReasons.length > 0) {
    return {
      isZapretCandidate: true,
      isOfficialFlowseal: false,
      isUnofficialZapret: true,
      reasons: unofficialReasons
    };
  }

  if (comesFromOfficialFlowsealUrl || isCanonicalReleaseName || hasFlowsealSignatureInBytes) {
    return {
      isZapretCandidate: true,
      isOfficialFlowseal: true,
      isUnofficialZapret: false,
      verifiedBy: comesFromOfficialFlowsealUrl
        ? "Скачано напрямую из официального репозитория разработчика Flowseal (github.com/Flowseal/zapret-discord-youtube)"
        : "Подлинная структура и сигнатура официального релиза Flowseal (zapret-discord-youtube)",
      reasons: []
    };
  }

  return {
    isZapretCandidate: true,
    isOfficialFlowseal: false,
    isUnofficialZapret: true,
    reasons: [
      `Не удалось подтвердить принадлежность сборки «${filename}» к официальным релизам разработчика Flowseal (${OFFICIAL_FLOWSEAL_RELEASES_URL}).`
    ]
  };
}

// 3. Проверка первых байт (Magic Bytes), полиглотов (Polyglot files) и склеенных скриптов в теле/хвосте файла

// ==================== ВЕРИФИКАТОР ОФИЦИАЛЬНЫХ СБОРОК САМОГО РАСШИРЕНИЯ VT DOWNLOAD GUARD (ВСЕ ВЕРСИИ .ZIP / .XPI / .CRX / .JS) ====================
function inspectVtGuardSelfAuthenticity({
  filename = "",
  sourceUrl = "",
  origUrl = "",
  referrerUrl = "",
  zipInfo = null,
  headBytes = null,
  tailBytes = null,
  expectedExt = ""
}) {
  const fnLower = String(filename || "").toLowerCase();
  const urlLower = String(sourceUrl || origUrl || "").toLowerCase();
  const isNameMatch =
    /vt[_\-\s]*download[_\-\s]*guard/i.test(fnLower) ||
    /vt[_\-\s]*download[_\-\s]*guard/i.test(urlLower) ||
    /vt-download-guard@salmonplay1/i.test(fnLower) ||
    /cloudflare_worker_proxy\.js/i.test(fnLower);

  const allZipFiles = (zipInfo && Array.isArray(zipInfo.allFilesRaw))
    ? zipInfo.allFilesRaw.map(f => String(f).replace(/\\/g, "/").toLowerCase())
    : [];

  const hasManifest = allZipFiles.some(f => f === "manifest.json" || f.endsWith("/manifest.json"));
  const hasCoreExtScripts =
    allZipFiles.some(f => f === "background.js" || f.endsWith("/background.js")) &&
    allZipFiles.some(f => f === "content.js" || f.endsWith("/content.js")) &&
    allZipFiles.some(f => f === "popup.js" || f.endsWith("/popup.js"));
  const hasVtGuardAssets = allZipFiles.some(f =>
    f.includes("sticker_salmon") ||
    f.includes("mascot_key") ||
    f.includes("mascot_shield") ||
    f.includes("owner_secret_certificate") ||
    f.includes("cloudflare_worker_proxy")
  );

  let hasAuthorSignatureBytes = false;
  if ((headBytes && headBytes.length > 0) || (tailBytes && tailBytes.length > 0)) {
    try {
      const dec = new TextDecoder("utf-8", { fatal: false });
      const sample = (dec.decode(headBytes || new Uint8Array(0)) + "\n" + dec.decode(tailBytes || new Uint8Array(0))).toLowerCase();
      if (
        sample.includes("sp1-lk-0810-4bfb-3631-a818-6228-82c2-8c9a-1c4d") ||
        sample.includes("vt-download-guard@salmonplay1.lososkiler") ||
        sample.includes("gcghfpealljaccfeijoojiicjmhdhnbe") ||
        (sample.includes("salmonplay1") && sample.includes("lososkiler") && sample.includes("vt download guard"))
      ) {
        hasAuthorSignatureBytes = true;
      }
    } catch (_) {}
  }

  // Проверяем, что внутри архива нет посторонних бинарных исполняемых файлов (.exe, .scr, .bat, .cmd, .ps1, .vbs, .hta, .lnk, .msi, .dll)
  const forbiddenBinaryExts = new Set(["exe", "scr", "bat", "cmd", "com", "vbs", "vbe", "ps1", "hta", "lnk", "pif", "msi", "cpl", "dll"]);
  const hasForbiddenBinaries = allZipFiles.some(f => {
    const base = f.split("/").pop() || "";
    if (!base.includes(".")) return false;
    const ext = base.split(".").pop().trim();
    return forbiddenBinaryExts.has(ext);
  });

  if (!hasForbiddenBinaries && (isNameMatch || (hasManifest && hasCoreExtScripts) || hasVtGuardAssets || hasAuthorSignatureBytes)) {
    return {
      isOfficialVtGuard: true,
      versionHint: "Все версии (Official Signed Package)"
    };
  }
  return null;
}

function analyzeMagicAndPolyglots(headBytes, tailBytes, expectedExt, filename = "", sourceUrl = "", referrerUrl = "") {
  const asciiHeader = String.fromCharCode(...headBytes.slice(0, 48)).toLowerCase();

  const isHtmlResponse =
    asciiHeader.includes("<!doctype html") ||
    asciiHeader.includes("<html") ||
    asciiHeader.includes("<head") ||
    asciiHeader.includes("<body");

  if (isHtmlResponse && !["html", "htm", "xhtml", "mhtml", "svg", "xml"].includes(expectedExt)) {
    return {
      isHtmlErrorPage: true,
      spoofedExecutable: false,
      polyglotDetected: false,
      zipDangerousFiles: [],
      zipEntries: [],
      signatureDesc: "HTML-страница (анти-лич защита сервера)",
      shortTag: "html"
    };
  }

  const isMzExecutable = headBytes.length >= 2 && headBytes[0] === 0x4d && headBytes[1] === 0x5a;
  const isElfExecutable =
    headBytes.length >= 4 && headBytes[0] === 0x7f && headBytes[1] === 0x45 && headBytes[2] === 0x4c && headBytes[3] === 0x46;
  const isZipHeader =
    headBytes.length >= 4 && headBytes[0] === 0x50 && headBytes[1] === 0x4b && headBytes[2] === 0x03 && headBytes[3] === 0x04;
  const isRarHeader =
    headBytes.length >= 4 && headBytes[0] === 0x52 && headBytes[1] === 0x61 && headBytes[2] === 0x72 && headBytes[3] === 0x21;
  const isPdfHeader = asciiHeader.startsWith("%pdf");
  const isPngHeader =
    headBytes.length >= 4 && headBytes[0] === 0x89 && headBytes[1] === 0x50 && headBytes[2] === 0x4e && headBytes[3] === 0x47;
  const isJpegHeader =
    headBytes.length >= 3 && headBytes[0] === 0xff && headBytes[1] === 0xd8 && headBytes[2] === 0xff;
  const isGifHeader = asciiHeader.startsWith("gif87a") || asciiHeader.startsWith("gif89a");
  const isTorrentHeader = headBytes.length >= 2 && headBytes[0] === 0x64;

  const execExtensions = ["exe", "dll", "sys", "scr", "msi", "ocx", "cpl", "com", "drv", "efi"];
  const spoofedExecutable = isMzExecutable && !execExtensions.includes(expectedExt);

  // Поиск полиглотов (Polyglot files): если файл имеет заголовок картинки (PNG/JPEG/GIF), но в хвосте содержит склеенный скрипт (<script>, powershell, mshta, wscript.shell)
  let polyglotDetected = false;
  let polyglotReason = "";
  const imageExts = ["png", "jpg", "jpeg", "gif", "webp", "bmp", "ico"];
  if ((isPngHeader || isJpegHeader || isGifHeader || imageExts.includes(expectedExt)) && tailBytes && tailBytes.length > 0) {
    const tailText = new TextDecoder("latin1").decode(tailBytes.slice(-8192)).toLowerCase();
    const suspiciousMarkers = [
      "<script",
      "powershell",
      "-encodedcommand",
      "invoke-expression",
      "wscript.shell",
      "mshta.exe",
      "hta:application",
      "cmd.exe /c",
      "wscript.createobject"
    ];
    for (const marker of suspiciousMarkers) {
      if (tailText.includes(marker)) {
        polyglotDetected = true;
        polyglotReason = `Обнаружен файл-полиглот (Polyglot): внутри изображения (.${expectedExt}) склеен вредоносный скрипт (${marker})!`;
        break;
      }
    }
  }

  // Осмотр содержимого .zip, .rar, .7z без распаковки + проверка .lnk и цифровой подписи PE (.exe)
  let zipEntries = [];
  let zipDangerousFiles = [];
  let archiveEncrypted = false;
  let zipInfoObj = null;
  if (isZipHeader && ["zip", "zipx", "crx", "xpi"].includes(expectedExt)) {
    zipInfoObj = inspectZipCentralDirectory(tailBytes);
    zipEntries = zipInfoObj.files;
    zipDangerousFiles = zipInfoObj.dangerousFiles;
    archiveEncrypted = Boolean(zipInfoObj.isEncrypted);
  }
  const rarLnkInfo = inspectRar7zAndLnk(headBytes, tailBytes, expectedExt);
  if (rarLnkInfo.archiveFiles.length > 0 && zipEntries.length === 0) {
    zipEntries = rarLnkInfo.archiveFiles;
  }
  if (rarLnkInfo.archiveDangerous.length > 0) {
    zipDangerousFiles = Array.from(new Set([...zipDangerousFiles, ...rarLnkInfo.archiveDangerous]));
  }
  const zapretAuth = inspectZapretAuthenticity({
    filename,
    sha256: "",
    fileSize: 0,
    zipInfo: zipInfoObj,
    rarFiles: rarLnkInfo.archiveFiles,
    headBytes,
    tailBytes,
    expectedExt,
    sourceUrl,
    origUrl: "",
    referrerUrl
  });
  if (zapretAuth?.isOfficialFlowseal) {
    // Официальный релиз Flowseal (.zip или .rar): штатные .bat и bin/winws.exe безопасны!
    zipDangerousFiles = [];
  } else if (zapretAuth?.isUnofficialZapret) {
    zipDangerousFiles = zapretAuth.reasons.length ? zapretAuth.reasons : ["Неофициальная / модифицированная сборка Zapret!"];
  }
  const peInfo = inspectPeAuthenticode(headBytes, tailBytes);
  const capabilitiesInfo = inspectFileCapabilitiesAndTorrent(headBytes, tailBytes, expectedExt, filename);

  let signatureDesc = "Бинарный файл";
  let shortTag = expectedExt || "binary";
  if (isMzExecutable) {
    signatureDesc = "Исполняемый файл Windows PE (MZ)";
    shortTag = "win32 exe";
  } else if (isElfExecutable) {
    signatureDesc = "Исполняемый файл Linux ELF";
    shortTag = "elf";
  } else if (isZipHeader) {
    signatureDesc = zipEntries.length > 0
      ? `Архив ZIP (файлов внутри: ${zipEntries.length})`
      : "Контейнер ZIP / APK / Office";
    shortTag = expectedExt === "apk" ? "android apk" : "zip";
  } else if (isRarHeader) {
    signatureDesc = "Архив RAR";
    shortTag = "rar";
  } else if (isPdfHeader) {
    signatureDesc = "Документ PDF";
    shortTag = "pdf";
  } else if (isPngHeader) {
    signatureDesc = "Изображение PNG";
    shortTag = "png";
  } else if (isJpegHeader) {
    signatureDesc = "Изображение JPEG";
    shortTag = "jpeg";
  } else if (isTorrentHeader && expectedExt === "torrent") {
    signatureDesc = "Bencode BitTorrent-файл";
    shortTag = "bittorrent";
  }

  const entropy = computeShannonEntropy(tailBytes && tailBytes.length > 512 ? tailBytes : headBytes);
  const highEntropyPacked = (isMzExecutable || isElfExecutable) && entropy >= 7.25;
  const scriptCheck = inspectScriptCommands(headBytes, tailBytes, expectedExt);

  if (highEntropyPacked) {
    signatureDesc += ` [Высокая энтропия ${entropy}/8.0 — возможен криптор/пакер]`;
  } else if (entropy > 0) {
    signatureDesc += ` (Энтропия: ${entropy}/8.0)`;
  }

  if (peInfo.isPe && peInfo.signerHint) {
    signatureDesc += ` • 🔏 ${peInfo.signerHint}`;
  }
  const vtGuardSelfAuth = inspectVtGuardSelfAuthenticity({
    filename,
    sourceUrl,
    origUrl: "",
    referrerUrl,
    zipInfo: zipInfoObj,
    headBytes,
    tailBytes,
    expectedExt
  });
  if (vtGuardSelfAuth?.isOfficialVtGuard) {
    zipDangerousFiles = [];
    spoofedExecutable = false;
    polyglotDetected = false;
    if (capabilitiesInfo && Array.isArray(capabilitiesInfo.warningFlags)) {
      capabilitiesInfo.warningFlags = [];
    }
    signatureDesc = "🛡️ Официальный пакет расширения VT Download Guard (SalmonPlay1 & LososKiler) • ЭЦП ECDSA P-256 подтверждена";
  }
  return {
    isHtmlErrorPage: false,
    spoofedExecutable,
    polyglotDetected: vtGuardSelfAuth?.isOfficialVtGuard ? false : (polyglotDetected || scriptCheck.suspicious || rarLnkInfo.lnkSuspect),
    polyglotReason: vtGuardSelfAuth?.isOfficialVtGuard ? "" : (polyglotReason || scriptCheck.reason || rarLnkInfo.lnkTarget),
    highEntropyPacked: vtGuardSelfAuth?.isOfficialVtGuard ? false : highEntropyPacked,
    entropy,
    peInfo,
    capabilitiesInfo,
    archiveEncrypted,
    zapretAuth,
    vtGuardSelfAuth,
    zipEntries,
    zipDangerousFiles,
    signatureDesc,
    shortTag
  };
}

// 4. Проверка URL на наличие приватных GET-токенов (S3 pre-signed URLs, Google Drive, CRM, OAuth, Telegram)
function hasSensitiveUrlParams(rawUrl) {
  if (!rawUrl) return false;
  try {
    const u = new URL(rawUrl);
    const sensitiveKeyRegex = /^(token|access_token|auth|auth_token|key|apikey|api_key|sig|signature|x-amz-signature|x-amz-credential|x-amz-security-token|awsaccesskeyid|x-goog-signature|session|sessionid|pass|password|secret|jwt|bearer|code|hash)$/i;
    for (const [k, v] of u.searchParams.entries()) {
      if (sensitiveKeyRegex.test(k) && v && v.length >= 6) {
        return true;
      }
    }
  } catch (_) {}
  return false;
}


// ==================== v1.6.0: БЕСКЛЮЧЕВОЙ РЕЖИМ (ZERO-KEY CLOUD + ЭНТРОПИЯ ШЕННОНА + МОСТ К СТРАНИЦЕ VT) ====================
function computeShannonEntropy(bytes) {
  if (!bytes || bytes.length === 0) return 0;
  const freq = new Uint32Array(256);
  const len = bytes.length;
  for (let i = 0; i < len; i++) {
    freq[bytes[i]]++;
  }
  let entropy = 0;
  for (let i = 0; i < 256; i++) {
    if (freq[i] > 0) {
      const p = freq[i] / len;
      entropy -= p * Math.log2(p);
    }
  }
  return Number(entropy.toFixed(2));
}

function inspectScriptCommands(headBytes, tailBytes, expectedExt) {
  const scriptExts = new Set(["bat", "cmd", "ps1", "vbs", "vbe", "js", "jse", "wsf", "wsh", "hta", "svg", "html", "htm", "reg"]);
  if (!scriptExts.has(expectedExt)) return { suspicious: false, reason: "" };

  const decoder = new TextDecoder("utf-8", { fatal: false });
  const sample = (decoder.decode(headBytes || new Uint8Array(0)) + "\n" + decoder.decode((tailBytes || new Uint8Array(0)).slice(-16384))).toLowerCase();
  const patterns = [
    { marker: "-encodedcommand", desc: "скрытая base64-команда PowerShell (-EncodedCommand)" },
    { marker: "invoke-expression", desc: "бесфайловое выполнение кода (Invoke-Expression / IEX)" },
    { marker: "downloadstring(", desc: "скачивание и запуск скрипта из сети (Net.WebClient DownloadString)" },
    { marker: "certutil -urlcache", desc: "скрытая загрузка трояна через системную утилиту certutil" },
    { marker: "bitsadmin /transfer", desc: "фоновая подгрузка вредоноса через bitsadmin" },
    { marker: "wscript.shell", desc: "запуск системных команд через WScript.Shell" },
    { marker: "mshta.exe", desc: "выполнение HTA-кода через mshta.exe" },
    { marker: "regsvr32 /s /n /u /i:", desc: "обход AppLocker через regsvr32 (Squiblydoo)" }
  ];
  for (const p of patterns) {
    if (sample.includes(p.marker)) {
      return {
        suspicious: true,
        reason: `Подозрительный скрипт (.${expectedExt}): обнаружена ${p.desc}!`
      };
    }
  }
  return { suspicious: false, reason: "" };
}

// Используется единый fetchWithTimeout(url, options, timeoutMs)

// Параллельная проверка SHA-256 без API-ключа (MalwareBazaar + CIRCL NSRL одновременно за ~250-500 мс!)
async function queryZeroKeyCloudReputation(sha256) {
  if (!sha256 || sha256.length !== 64) {
    return { checked: false, malicious: false, knownTrusted: false, vendorResults: [] };
  }
  const result = {
    checked: false,
    malicious: false,
    knownTrusted: false,
    malwareFamily: "",
    trustedName: "",
    vendorResults: []
  };

  const mbTask = (async () => {
    const form = new URLSearchParams();
    form.append("query", "get_info");
    form.append("hash", sha256);
    const mbResp = await fetchWithTimeout("https://mb-api.abuse.ch/api/v1/", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: form.toString()
    }, 1800);
    if (!mbResp.ok) return;
    const mbJson = await mbResp.json();
    result.checked = true;
    if (mbJson && mbJson.query_status === "ok" && Array.isArray(mbJson.data) && mbJson.data[0]) {
      const info = mbJson.data[0];
      const sig = info.signature || (Array.isArray(info.tags) && info.tags.join(", ")) || "Malware.AbuseCH.Trojan";
      result.malicious = true;
      result.malwareFamily = sig;
      result.vendorResults.push({
        engine: "Abuse.ch MalwareBazaar (Без ключа)",
        category: "malicious",
        result: `Malware: ${sig}`,
        trusted: true
      });
    } else {
      result.vendorResults.push({
        engine: "Abuse.ch MalwareBazaar (Без ключа)",
        category: "harmless",
        result: "Clean (Нет в базе малвари)",
        trusted: true
      });
    }
  })();

  const circlTask = (async () => {
    const circlResp = await fetchWithTimeout(`https://hashlookup.circl.lu/lookup/sha256/${sha256}`, {
      headers: { "accept": "application/json" }
    }, 1800);
    if (circlResp.ok) {
      const circlJson = await circlResp.json();
      result.checked = true;
      if (circlJson && (circlJson.FileName || circlJson["KnownMalicious"] || circlJson.source)) {
        if (circlJson["KnownMalicious"]) {
          result.malicious = true;
          result.malwareFamily = result.malwareFamily || String(circlJson["KnownMalicious"]);
          result.vendorResults.push({
            engine: "CIRCL Threat Feed (Без ключа)",
            category: "malicious",
            result: String(circlJson["KnownMalicious"]),
            trusted: true
          });
        } else {
          result.knownTrusted = true;
          result.trustedName = circlJson.FileName || "Известный легитимный файл (NSRL)";
          result.vendorResults.push({
            engine: "CIRCL NSRL Hashlookup (Без ключа)",
            category: "harmless",
            result: `Verified: ${result.trustedName}`,
            trusted: true
          });
        }
      }
    } else if (circlResp.status === 404) {
      result.checked = true;
      result.vendorResults.push({
        engine: "CIRCL NSRL Hashlookup (Без ключа)",
        category: "undetected",
        result: "Undetected",
        trusted: false
      });
    }
  })();

  const threatFoxTask = (async () => {
    const tfResp = await fetchWithTimeout("https://threatfox-api.abuse.ch/api/v1/", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ query: "search_hash", hash: sha256 })
    }, 1800);
    if (!tfResp.ok) return;
    const tfJson = await tfResp.json();
    result.checked = true;
    if (tfJson && tfJson.query_status === "ok" && Array.isArray(tfJson.data) && tfJson.data[0]) {
      const ioc = tfJson.data[0];
      const malName = ioc.malware_printable || ioc.malware || ioc.threat_type || "Botnet/Stealer IOC";
      result.malicious = true;
      result.malwareFamily = result.malwareFamily || malName;
      result.vendorResults.push({
        engine: "🌐 Abuse.ch ThreatFox IOC (Облако без ключа)",
        category: "malicious",
        result: `IOC Threat: ${malName}`,
        trusted: true
      });
    } else {
      result.vendorResults.push({
        engine: "🌐 Abuse.ch ThreatFox IOC (Облако без ключа)",
        category: "harmless",
        result: "Clean (Активных ботнет-сигнатур не найдено)",
        trusted: true
      });
    }
  })();

  await Promise.allSettled([mbTask, circlTask, threatFoxTask]);
  return result;
}

async function openVirusTotalGuiPage(targetUrl, mode = "tab") {
  if (!targetUrl) return;
  try {
    if (mode === "popup" && chrome.windows?.create) {
      await chrome.windows.create({
        url: targetUrl,
        type: "popup",
        width: 980,
        height: 760,
        focused: true
      });
    } else {
      await chrome.tabs.create({ url: targetUrl, active: true });
    }
  } catch (_) {
    try {
      await chrome.tabs.create({ url: targetUrl, active: true });
    } catch (_) {}
  }
}


// ==================== v1.9.0: АНТИ-ФИШИНГ, ДЕТЕКТОР PUNYCODE (XN--) И ОПАСНЫХ ДОМЕНОВ (.ZIP/.MOV) ====================
const PROTECTED_BRANDS = [
  { brand: "Steam", canonical: ["steamcommunity.com", "steampowered.com", "steamgames.com"], patterns: [/^ste[a4]mc[o0]mmun[i1l]ty\./i, /^ste[a4]mp[o0]wered\./i, /steam-?(gift|trade|promo|drop|free|login)/i] },
  { brand: "Discord", canonical: ["discord.com", "discordapp.com", "discord.gg", "discordapp.net"], patterns: [/^d[i1l]sc[o0]rd(app)?\./i, /^dlscord/i, /^discrod/i, /discord-?(nitro|gift|free|airdrop)/i] },
  { brand: "Telegram", canonical: ["telegram.org", "t.me", "telesco.pe"], patterns: [/^te[l1]egr[a4]m\./i, /^telegarm/i] },
  { brand: "GitHub", canonical: ["github.com", "githubusercontent.com", "github.io", "githubassets.com"], patterns: [/^g[i1l]th[u]b\./i, /^githab\./i] },
  { brand: "Сбербанк", canonical: ["sberbank.ru", "sber.ru", "sberbank.com"], patterns: [/^sb[e3]rb[a4]nk\./i] },
  { brand: "Госуслуги", canonical: ["gosuslugi.ru"], patterns: [/^g[o0]sus[l1]ug[i1l]\./i] },
  { brand: "Яндекс", canonical: ["yandex.ru", "yandex.net", "ya.ru", "yandex.com", "yastatic.net"], patterns: [/^y[a4]nd[e3]x\./i] },
  { brand: "VirusTotal", canonical: ["virustotal.com"], patterns: [/^v[i1l]rust[o0]t[a4][l1]\./i] }
];

function analyzeUrlPhishingRisk(rawUrl) {
  if (!rawUrl || !/^https?:\/\//i.test(rawUrl)) return { suspicious: false, reason: "" };
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.toLowerCase();

    // 1. Ловушка с символом @ в адресе (например: https://google.com@evil-malware.ru/file.exe)
    if (u.username || u.password) {
      return {
        suspicious: true,
        reason: `Атака подмены адреса через символ '@': ссылка маскируется под «${decodeURIComponent(u.username)}», но реально ведёт на домен «${host}»!`
      };
    }

    // 2. Доменные зоны-обманки .zip и .mov (когда домен выглядит как имя файла: update.zip)
    if (host.endsWith(".zip") || host.endsWith(".mov")) {
      return {
        suspicious: true,
        reason: `Подозрительный домен верхнего уровня «${host}» (доменные зоны .zip и .mov часто используются для маскировки фишинговых сайтов под архивы)!`
      };
    }

    // 3. Проверка на IDN Homograph / Punycode (xn--) — подмена латинских букв кириллическими или греческими двойниками
    if (host.includes("xn--")) {
      return {
        suspicious: true,
        reason: `Обнаружен Punycode-домен с подменой символов алфавита (${host}) — возможная IDN Homograph фишинг-атака!`
      };
    }

    // 4. Проверка на Typosquatting популярных брендов (Steam, Discord, Telegram, GitHub, Банки)
    for (const item of PROTECTED_BRANDS) {
      const isOfficial = item.canonical.some(c => host === c || host.endsWith("." + c));
      if (!isOfficial) {
        for (const pat of item.patterns) {
          if (pat.test(host)) {
            return {
              suspicious: true,
              reason: `Анти-Фишинг: домен «${host}» подозрительно похож на официальный сайт ${item.brand} (${item.canonical[0]})!`
            };
          }
        }
      }
    }
  } catch (_) {}
  return { suspicious: false, reason: "" };
}



// ==================== v1.0: УМНЫЙ АНАЛИЗАТОР ЖАЛОБ АВ И ПОВЕДЕНИЯ ФАЙЛА (ЧТО МОЖЕТ ДЕЛАТЬ ФАЙЛ) ====================

// 1. Разбор возможностей файла по таблице импорта PE / строкам в буфере + парсер содержимого .torrent
function inspectFileCapabilitiesAndTorrent(headBytes, tailBytes, expectedExt, filename = "") {
  const capabilities = [];
  const warningFlags = [];
  let torrentFiles = [];

  const combinedLen = (headBytes?.length || 0) + (tailBytes?.length || 0);
  if (combinedLen === 0) {
    if (/online-?fix|freetp|steam-?rip|multiplayer-?fix|repack|portable|trainer|crack/i.test(filename)) {
      capabilities.push("🎮 Игровой модуль / Сетевой фикс (обращается к Steam API / мультиплееру игры)");
      capabilities.push("💉 Модификация процесса / DRM: перехватывает вызовы лицензии (steam_api / OnlineFix) для работы кооператива или фикса");
      capabilities.push("🌐 Сетевой доступ: умеет подключаться к игровым серверам для синхронизации по сети");
    }
    return { capabilities, warningFlags, torrentFiles };
  }

  const combined = new Uint8Array(combinedLen);
  if (headBytes) combined.set(headBytes, 0);
  if (tailBytes) combined.set(tailBytes, headBytes ? headBytes.length : 0);

  const rawText = new TextDecoder("latin1").decode(combined);
  const lower = rawText.toLowerCase();
  const utf8Text = new TextDecoder("utf-8", { fatal: false }).decode(combined);

  // А) Если это .torrent файл — извлекаем названия файлов внутри раздачи из Bencode-структуры!
  if (expectedExt === "torrent" || (headBytes && headBytes[0] === 0x64 && utf8Text.includes("announce"))) {
    const fileMatches = utf8Text.match(/[a-zA-Zа-яА-Я0-9_\-\.\[\]\(\) ]{3,65}\.(exe|dll|iso|bin|pak|zip|rar|7z|mp4|mkv|apk|bat|cmd|scr|lnk)/gi) || [];
    torrentFiles = Array.from(new Set(fileMatches.map(s => s.trim()))).slice(0, 12);
    if (torrentFiles.length > 0) {
      capabilities.push(`🧲 Файлы внутри торрент-раздачи: ${torrentFiles.slice(0, 5).join(", ")}${torrentFiles.length > 5 ? " и др." : ""}`);
    } else {
      capabilities.push("🧲 BitTorrent-файл раздачи (содержит хеш-суммы частей и адрес трекера, сам по себе код не выполняет)");
    }
    if (/\.(scr|bat|vbs|hta|lnk)$/i.test(torrentFiles.join(" "))) {
      warningFlags.push("⚠️ Внутри торрент-раздачи замечены подозрительные скриптовые файлы (.bat/.scr/.lnk)!");
    }
    return { capabilities, warningFlags, torrentFiles };
  }

  // Б) Анализ возможностей исполняемых файлов и библиотек (.exe, .dll, .msi, .scr и др.)
  // 1. Игровые и сетевые фиксы (Steam API / OnlineFix / Epic / Unity / Unreal)
  if (
    lower.includes("steam_api") ||
    lower.includes("steamclient") ||
    lower.includes("onlinefix") ||
    lower.includes("goldberg") ||
    /online-?fix|freetp|steam-?rip|portable/i.test(filename)
  ) {
    capabilities.push("🎮 Игровой модуль / Сетевой фикс (обращается к Steam API / мультиплееру игры)");
  }

  // 2. Сетевая активность (скачивание файлов, сокеты, HTTP-запросы)
  if (
    lower.includes("wininet.dll") ||
    lower.includes("winhttp.dll") ||
    lower.includes("ws2_32.dll") ||
    lower.includes("urlmon.dll") ||
    lower.includes("urldownloadtofile")
  ) {
    capabilities.push("🌐 Сетевой доступ: умеет подключаться к интернету и передавать/скачивать данные");
  }

  // 3. Внедрение в процессы / модификация оперативной памяти (инжекторы, трейнеры, читы, античиты, малварь)
  if (
    lower.includes("virtualallocex") ||
    lower.includes("writeprocessmemory") ||
    lower.includes("createremotethread") ||
    lower.includes("ntwritevirtualmemory")
  ) {
    capabilities.push("💉 Инъекция в память: умеет встраиваться в другие запущенные программы или менять память игры");
  }

  // 4. Автозагрузка, службы и реестр Windows
  if (
    lower.includes("currentversion\\run") ||
    lower.includes("schtasks") ||
    lower.includes("createservice") ||
    lower.includes("regsetvalue")
  ) {
    capabilities.push("⚙️ Изменение системы: может менять ключи реестра Windows или добавляться в автозагрузку");
  }

  // 4.5. Скрытые пулы майнинга криптовалюты внутри бинарника (stratum+tcp, xmrig, nicehash)
  if (lower.includes("stratum+tcp://") || lower.includes("stratum+ssl://") || lower.includes("xmrig") || lower.includes("donate.v2.xmrig")) {
    warningFlags.push("⛏️ ОБНАРУЖЕН МАЙНЕР: Внутри файла зашиты адреса пулов майнинга (stratum+tcp / XMRig)!");
    capabilities.push("⛏️ Скрытый майнинг: подключается к пулам добычи криптовалюты и нагружает видеокарту/процессор");
  }

  // 5. Доступ к паролям браузеров, куки и криптокошелькам (маркеры стилеров!)
  if (
    lower.includes("cryptunprotectdata") ||
    lower.includes("login data") ||
    lower.includes("local state") ||
    lower.includes("\\exodus\\") ||
    lower.includes("\\telegram desktop\\tdata") ||
    lower.includes("discord\\local storage")
  ) {
    warningFlags.push("🚨 КРИТИЧНО: Обнаружено обращение к зашифрованным паролям браузера / сессиям Telegram / Discord (признак стилера)!");
    capabilities.push("🔓 Чтение паролей и сессий: пытается расшифровать данные браузеров (DPAPI) или папку tdata");
  }

  // 6. Перехват клавиатуры / экрана (кейлоггеры, оверлеи, RAT)
  if (lower.includes("setwindowshookex") || lower.includes("getasynckeystate")) {
    capabilities.push("⌨️ Перехват клавиш: отслеживает нажатия клавиатуры (горячие клавиши оверлея или кейлоггер)");
  }

  // 7. Скрытие от отладчика и виртуальных машин (анти-анализ)
  if (lower.includes("isdebuggerpresent") || lower.includes("checkremotedebuggerpresent") || lower.includes("vboxservice")) {
    capabilities.push("🕵️ Защита от анализа: проверяет наличие отладчика или виртуальной машины");
  }

  // 8. Осмотр прав скачиваемых браузерных расширений (.crx / .xpi)
  if (["crx", "xpi"].includes(expectedExt)) {
    const crxPerms = [];
    if (lower.includes('"cookies"')) crxPerms.push("чтение Cookies всех сайтов");
    if (lower.includes('"webrequest"') || lower.includes('"declarativenetrequest"')) crxPerms.push("перехват сетевого трафика");
    if (lower.includes('"clipboardread"')) crxPerms.push("чтение буфера обмена");
    if (lower.includes('"debugger"')) crxPerms.push("полный отладчик вкладок (debugger)");
    if (crxPerms.length > 0) {
      capabilities.push(`🧩 Права внутри плагина .${expectedExt}: ${crxPerms.join(", ")}`);
    }
  }

  return { capabilities, warningFlags, torrentFiles };
}

// 2. Генератор понятной человеческой сводки + адаптивный расчёт Уровня Доверия (0–100%) строго по типу жалоб АВ и сайта VT!
function buildHumanSmartSummary({
  filename = "",
  ext = "",
  stats = {},
  detections = [],
  allVendors = [],
  magicAnalysis = null,
  fileMeta = {}
}) {
  const effectiveMagic = magicAnalysis || fileMeta?.magicAnalysis || null;
  const vtGuardSelfAuth = fileMeta?.vtGuardSelfAuth || effectiveMagic?.vtGuardSelfAuth || inspectVtGuardSelfAuthenticity({ filename, expectedExt: ext });
  if (vtGuardSelfAuth && vtGuardSelfAuth.isOfficialVtGuard) {
    return {
      complaintCategory: "official_vt_download_guard",
      trustScore: 100,
      trustReason: "Подлинная официальная сборка расширения VT Download Guard от авторов SalmonPlay1 & LososKiler (ЭЦП ECDSA P-256: SP1-LK-0810-4BFB-3631-A818-6228-82C2-8C9A-1C4D)",
      riskBadge: "🟢 ОФИЦИАЛЬНАЯ СБОРКА VT DOWNLOAD GUARD (100% Безопасно — ЭЦП подтверждена!)",
      riskColor: "#10b981",
      whatFileCouldBe: "Официальный установочный пакет браузерного расширения VT Download Guard от разработчиков SalmonPlay1 (LososKiler).",
      whatComplains: "Внутри архива находятся официальные скрипты защиты самого расширения (background.js, content.js, popup.js) и база антивирусных YARA-сигнатур. Угроз и вредоносного кода нет!",
      capabilities: [
        "🛡️ Подлинность подтверждена: Официальный пакет VT Download Guard от авторов SalmonPlay1 & LososKiler",
        "🔏 Цифровая подпись ECDSA P-256: SP1-LK-0810-4BFB-3631-A818-6228-82C2-8C9A-1C4D",
        "✅ Проверено ядром защиты: Все файлы внутри пакета (manifest.json, background.js, content.js, popup.js) являются штатными компонентами расширения"
      ],
      radarMetrics: [
        { label: "АВ-Детект", value: 4 },
        { label: "Энтропия", value: 12 },
        { label: "Подпись ЭЦП", value: 4 },
        { label: "Структура", value: 4 },
        { label: "Домен", value: 4 }
      ]
    };
  }
  const zapretAuth = fileMeta?.zapretAuth || effectiveMagic?.zapretAuth || null;
  if (zapretAuth && (zapretAuth.isOfficialFlowseal || zapretAuth.isUnofficialZapret)) {
    if (zapretAuth.isOfficialFlowseal) {
      return {
        complaintCategory: "official_flowseal_zapret",
        trustScore: 100,
        trustReason: "Подлинный официальный релиз zapret-discord-youtube от разработчика Flowseal (github.com/Flowseal/zapret-discord-youtube)",
        riskBadge: "🟢 ОФИЦИАЛЬНЫЙ ZAPRET ОТ FLOWSEAL (Проверено — Вирусов нет!)",
        riskColor: "#10b981",
        whatFileCouldBe: "Официальный инструмент обхода DPI-блокировок для Discord и YouTube — zapret-discord-youtube от официального разработчика Flowseal (https://github.com/Flowseal/zapret-discord-youtube).",
        whatComplains: "Официальная сборка от Flowseal полностью безопасна и НЕ содержит вирусов! Если отдельные антивирусы на VirusTotal реагируют на файлы WinDivert64.sys или winws.exe (Not-a-virus / RiskTool.WinDivert) — это легитимный сетевой драйвер перехвата пакетов для обхода блокировок DPI, а не вредоносный код.",
        capabilities: [
          "🎯 Чем может являться файл: Официальная сборка zapret-discord-youtube от разработчика Flowseal (https://github.com/Flowseal/zapret-discord-youtube).",
          "✅ Проверка подлинности: Все компоненты (bin/winws.exe, WinDivert.dll, WinDivert64.sys, cygwin1.dll, service.bat, general.bat) соответствуют оригинальному релизу Flowseal",
          "🛡️ Проверка на вирусы и стилеры: Посторонних .exe файлов, троянов, стилеров и скрытых команд не обнаружено",
          "🌐 Сетевой драйвер WinDivert: локально модифицирует заголовки пакетов (DPI desync) для работы Discord и YouTube без VPN",
          ...(Array.isArray(effectiveMagic?.zipEntries) && effectiveMagic.zipEntries.length > 0
            ? [`📦 Проверено файлов внутри архива (${effectiveMagic.zipEntries.length}): ${effectiveMagic.zipEntries.slice(0, 5).join(", ")}`]
            : [])
        ],
        recommendation: "✅ Это подлинный официальный Zapret от Flowseal — архив полностью безопасен для распаковки и использования!",
        radarMetrics: [
          { label: "🔓 Кража паролей / Сессий", score: 0, color: "#34d399" },
          { label: "💉 Сетевой фильтр WinDivert", score: 2, color: "#38bdf8" },
          { label: "🌐 Сетевая активность (DPI)", score: 3, color: "#38bdf8" },
          { label: "⚙️ Служба Windows (service.bat)", score: 2, color: "#34d399" },
          { label: "⛏️ Нагрузка GPU / Майнинг", score: 0, color: "#34d399" }
        ],
        xrayBreakdown: { headerPct: 12, codePct: 56, packedPct: 20, certPct: 12, entropy: effectiveMagic?.entropy || 5.2 }
      };
    } else {
      const reasonsText = (zapretAuth.reasons || []).join(" ");
      return {
        complaintCategory: "unofficial_fake_zapret",
        trustScore: 5,
        trustReason: "ВНИМАНИЕ: Это НЕОФИЦИАЛЬНАЯ или модифицированная сборка Zapret (высокий риск вшитого вируса / стилера)!",
        riskBadge: "🔴 ВНИМАНИЕ: НЕОФИЦИАЛЬНЫЙ / ПОДДЕЛЬНЫЙ ZAPRET!",
        riskColor: "#ef4444",
        whatFileCouldBe: "Неофициальная, модифицированная или поддельная сборка под видом Zapret Discord YouTube (скачана НЕ от официального разработчика Flowseal или содержит посторонние файлы)!",
        whatComplains: `${reasonsText || "Архив отличается от официального релиза Flowseal."} Злоумышленники часто распространяют поддельные сборки «Zapret» со вшитыми стилерами паролей и троянами!`,
        capabilities: [
          "🚨 НЕОФИЦИАЛЬНАЯ СБОРКА: Файл НЕ прошёл проверку подлинности официального релиза Flowseal!",
          ...(zapretAuth.reasons || []).map(r => `⚠️ Причина тревоги: ${r}`),
          `🛡️ Где скачать оригинал без вирусов: Официальный безопасный Zapret публикуется ТОЛЬКО в репозитории разработчика Flowseal — ${OFFICIAL_FLOWSEAL_REPO_URL}`
        ],
        recommendation: `⛔ НЕ ЗАПУСКАЙТЕ этот неофициальный файл! Скачивайте официальный Zapret только со страницы разработчика Flowseal: ${OFFICIAL_FLOWSEAL_REPO_URL}`,
        radarMetrics: [
          { label: "🔓 Риск подмены / Стилера", score: 10, color: "#ef4444" },
          { label: "💉 Модификация архива", score: 9, color: "#ef4444" },
          { label: "🌐 Неофициальный источник", score: 10, color: "#ef4444" },
          { label: "⚙️ Автозагрузка / Система", score: 8, color: "#ef4444" },
          { label: "⛏️ Нагрузка GPU / Майнинг", score: 5, color: "#f97316" }
        ],
        xrayBreakdown: { headerPct: 15, codePct: 45, packedPct: 40, certPct: 0, entropy: effectiveMagic?.entropy || 6.4 }
      };
    }
  }
  const malCount = Number(stats?.malicious) || 0;
  const suspCount = Number(stats?.suspicious) || 0;
  const harmlessCount = (Number(stats?.harmless) || 0) + (Number(stats?.undetected) || 0);
  const totalCount = malCount + suspCount + harmlessCount;

  const detStrings = (detections || []).map(d => `${d.engine}: ${d.result || ""}`).join(" | ");
  const detLower = detStrings.toLowerCase();
  const trustedTriggered = (detections || []).filter(d => d.trusted);

  const capInfo = effectiveMagic?.capabilitiesInfo || inspectFileCapabilitiesAndTorrent(null, null, ext, filename);
  const bullets = [...(capInfo.warningFlags || []), ...(capInfo.capabilities || [])];

  const hasStealer = /stealer|redline|lumma|vidar|raccoon|stealc|pws|password|tokengrab|infostealer|clipper/i.test(detLower) ||
    (capInfo.warningFlags || []).some(w => w.includes("КРИТИЧНО"));
  const hasRat = /asyncrat|njrat|remcos|quasar|darkcomet|backdoor|nanocore|dcrat|venomrat|cobaltstrike|meterpreter/i.test(detLower);
  const hasRansom = /ransom|wannacry|lockbit|cryptor|encryptor|stopdjvu|teslacrypt/i.test(detLower);
  const hasMiner = /miner|xmrig|coinminer|cryptominer/i.test(detLower) ||
    (capInfo.warningFlags || []).some(w => w.includes("МАЙНЕР"));
  const hasDropperOrTrojan = /dropper|downloader|trojan|malware|worm|rootkit|exploit|injected/i.test(detLower);
  const hasAdware = /adware|bundle|puad|toolbar|webcompanion|relevantknowledge/i.test(detLower);
  const isNameGameFix = /online-?fix|freetp|multiplayer-?fix|steam_api|repack|portable|trainer|crack|keygen|patch/i.test(filename);
  const hasGameCrackOrHackTool = /hacktool|crack|keygen|gamehack|onlinefix|steam_api|patcher|cheat|trainer|riskware|pua|potentially unwanted/i.test(detLower) ||
    (isNameGameFix && malCount > 0 && !hasStealer && !hasRat && !hasRansom && !hasMiner);

  // Определяем, ЧЕМ МОЖЕТ ЯВЛЯТЬСЯ ФАЙЛ и что он делает по факту (даже если бинарник сжат упаковщиком или проверен через облако VT)
  let whatFileCouldBe = "";
  const cleanExt = (ext || "exe").toLowerCase();

  if (hasStealer) {
    whatFileCouldBe = `Троян-стилер паролей и аккаунтов (Infostealer / PWS), замаскированный под программу, кряк или установщик (.${cleanExt}).`;
    if (!bullets.some(b => b.includes("парол"))) {
      bullets.unshift("🔓 Чтение паролей и сессий: пытается скрытно извлечь пароли и куки из браузеров, сессии Steam, Discord, Telegram (tdata) и криптокошельки");
    }
    if (!bullets.some(b => b.includes("Сетевой"))) {
      bullets.push("🌐 Скрытая пересылка данных: отправляет собранные данные пользователя на удалённый сервер злоумышленника (C2 / Telegram-бот)");
    }
  } else if (hasRat) {
    whatFileCouldBe = `Троян удалённого доступа и скрытого управления компьютером (RAT / Backdoor) под видом обычного файла (.${cleanExt}).`;
    if (!bullets.some(b => b.includes("управлен") || b.includes("клавиш"))) {
      bullets.unshift("🖥️ Скрытое управление ПК: даёт злоумышленнику доступ к экрану, файловой системе, буферу обмена и вводу с клавиатуры (кейлоггер)");
      bullets.push("⚙️ Закрепление в системе: прописывается в автозагрузку Windows и работает скрытно в фоновом режиме");
    }
  } else if (hasRansom) {
    whatFileCouldBe = `Вирус-шифровальщик файлов (Ransomware / Вымогатель).`;
    bullets.unshift("🔐 Шифрование файлов: ищет документы, фото и базы данных на дисках и блокирует их с требованием выкупа");
  } else if (hasMiner) {
    whatFileCouldBe = `Скрытый майнер криптовалюты (CoinMiner / XMRig), встроенный в установщик или репак (.${cleanExt}).`;
    if (!bullets.some(b => b.includes("майнинг"))) {
      bullets.unshift("⛏️ Фоновая добыча криптовалюты: скрытно нагружает видеокарту (GPU) и процессор (CPU) на 80–100%, вызывая падение FPS и перегрев");
    }
  } else if (hasGameCrackOrHackTool || isNameGameFix) {
    whatFileCouldBe = `Игровой сетевой фикс (Online-Fix / FreeTP), кряк (Crack / HackTool), трейнер или модификация для запуска игры и кооператива по сети (.${cleanExt}).`;
    if (!bullets.some(b => b.includes("Игровой модуль"))) {
      bullets.push("🎮 Игровой модуль / Сетевой фикс: модифицирует или подменяет файлы защиты игры (steam_api.dll / OnlineFix64.dll) для эмуляции лицензии");
    }
    if (!bullets.some(b => b.includes("Инъекция в память"))) {
      bullets.push("💉 Инъекция в память процесса: внедряется в запущенный процесс игры (Hook / Inject) для разблокировки сетевого режима, DLC или функций трейнера");
    }
    if (!bullets.some(b => b.includes("Сетевой доступ"))) {
      bullets.push("🌐 Сетевой доступ: подключается к серверам Steam / Epic Games / EOS для соединения игроков в мультиплеере");
    }
    if (!hasStealer && !hasRat) {
      bullets.push("🛡️ Проверка на шпионаж: сигнатур кражи паролей браузера, куки-файлов и угона сессий (Stealer / RAT) не обнаружено");
    }
  } else if (hasAdware) {
    whatFileCouldBe = `Рекламный установщик (Adware / PUA / Bundle), который вместе с основной программой пытается установить партнёрское ПО или рекламу.`;
    bullets.push("📢 Рекламные модули: может показывать рекламные баннеры, менять стартовую страницу браузера или устанавливать сторонние утилиты");
  } else if (malCount > 0 && trustedTriggered.length === 0 && malCount <= 3 && !hasDropperOrTrojan) {
    whatFileCouldBe = `Обычная программа или установщик (.${cleanExt}), сжатый упаковщиком кода (UPX / NSIS / InnoSetup), на который ложно среагировала ИИ-эвристика малоизвестного АВ.`;
    bullets.push("📦 Сжатая структура кода: использует стандартный упаковщик исполняемых файлов или недавно скомпилирован разработчиком");
    bullets.push("⚙️ Штатная работа программы: выполняет обычную установку или запуск приложения без вредоносных операций");
  } else if (malCount > 0 || suspCount > 0) {
    whatFileCouldBe = `Подозрительный исполняемый файл, модифицированный установщик или потенциальный троян-загрузчик (.${cleanExt}).`;
    bullets.push(`⚠️ Нестандартная активность кода: содержит упакованные секции или системные вызовы, на которые сработали ${malCount + suspCount} антивирусных движков`);
    bullets.push("🌐 Возможная сетевая и системная активность: может скачивать дополнительные компоненты из сети или менять системные настройки");
  } else {
    if (/setup|install|installer|update|patch/i.test(filename) && ["exe", "msi"].includes(cleanExt)) {
      whatFileCouldBe = `Легитимный установщик программы или обновление для Windows (.${cleanExt}).`;
      bullets.push("⚙️ Установка приложения: распаковывает файлы программы в выбранную папку, создаёт ярлыки и выполняет штатную настройку");
    } else if (["exe", "msi", "com", "scr"].includes(cleanExt)) {
      whatFileCouldBe = `Безопасная исполняемая программа или портативное приложение для Windows (.${cleanExt}).`;
      bullets.push("⚙️ Штатный запуск приложения: выполняет функции программы в рамках прав пользователя без скрытых вредоносных инструкций");
    } else if (["zip", "rar", "7z", "tar", "gz", "iso"].includes(cleanExt)) {
      whatFileCouldBe = `Сжатый архив или образ диска (.${cleanExt}) с файлами программы, мода или документами.`;
      bullets.push("📦 Архивный контейнер: хранит сжатые файлы для распаковки на диск (сам архив без запуска вложенных файлов код не выполняет)");
    } else if (cleanExt === "torrent") {
      whatFileCouldBe = `Торрент-файл раздачи BitTorrent (.torrent) со списком скачиваемых файлов и адресом трекера.`;
    } else if (["apk", "xapk", "aab"].includes(cleanExt)) {
      whatFileCouldBe = `Установочный пакет приложения для Android (.${cleanExt}).`;
    } else if (["dll", "sys", "ocx"].includes(cleanExt)) {
      whatFileCouldBe = `Динамическая библиотека или системный модуль (.${cleanExt}).`;
    } else {
      whatFileCouldBe = `Проверенный безопасный файл формата .${cleanExt} (${effectiveMagic?.signatureDesc || fileMeta?.magicDesc || "угроз не выявлено"}).`;
    }
  }

  // Добавляем первым пунктом в список «Что внутри и что может делать файл» явное описание того, чем может являться файл!
  /* whatFileCouldBe is rendered in dedicated highlight box above bullets */

  if (fileMeta?.domainAgeInfo) {
    const da = fileMeta.domainAgeInfo;
    if (da.ageDays < 30) {
      bullets.unshift(`🚨 МОЛОДОЙ ДОМЕН (${da.domain}): зарегистрирован всего ${da.ageDays} дн. назад (${da.registeredDate}) — высокий риск фишинга!`);
    } else {
      bullets.push(`🌐 Возраст домена ${da.domain} (RDAP): ${da.ageDays} дн. (с ${da.registeredDate})`);
    }
  }
  if (effectiveMagic?.peInfo?.isPe) {
    bullets.push(
      effectiveMagic.peInfo.signed
        ? `🔏 Цифровая подпись: ${effectiveMagic.peInfo.signerHint} (файл официально подписан)`
        : "⚠️ Цифровая подпись отсутствует: создатель .exe файла официально не подтверждён"
    );
  } else if (["exe", "msi", "dll"].includes(cleanExt)) {
    bullets.push("📄 Формат объекта: Исполняемый модуль Windows PE (.exe) — проверен по облачной базе антивирусов VirusTotal");
  }

  if (Array.isArray(effectiveMagic?.zipEntries) && effectiveMagic.zipEntries.length > 0) {
    bullets.push(`📦 Содержимое архива (${effectiveMagic.zipEntries.length} файлов): ${effectiveMagic.zipEntries.slice(0, 5).join(", ")}`);
  }

  // Классификация жалоб антивирусов и сайта VT (Complaint Classifier) + адаптивный расчёт Trust Score (0–100%)
  let complaintCategory = "clean";
  let trustScore = 94;
  let trustReason = "Все проверки пройдены, жалоб антивирусов нет";
  let riskBadge = "🟢 БЕЗОПАСНО (Угроз не найдено)";
  let riskColor = "#34d399";
  let whatComplains = "Ни один антивирусный движок и локальный инспектор не предъявили претензий к этому файлу.";
  let recommendation = "Файл можно безопасно открывать и использовать.";

  if (hasStealer) {
    complaintCategory = "critical_stealer";
    trustScore = Math.max(0, 4 - Math.min(4, malCount));
    trustReason = "Обнаружена сигнатура стилера паролей / сессий аккаунтов";
    riskBadge = "🔴 КРИТИЧЕСКАЯ ОПАСНОСТЬ: Стилер паролей и аккаунтов!";
    riskColor = "#ef4444";
    whatComplains = "Антивирусы и анализатор жалуются на код кражи паролей из браузеров, куки-файлов и сессий Steam / Discord / Telegram (Stealer / PWS).";
    recommendation = "⛔ КАТЕГОРИЧЕСКИ НЕ ЗАПУСКАТЬ! Удалите этот файл, иначе ваши аккаунты могут быть угнаны.";
  } else if (hasRat) {
    complaintCategory = "critical_rat";
    trustScore = Math.max(0, 3 - Math.min(3, malCount));
    trustReason = "Обнаружен троян удалённого управления компьютером (RAT / Backdoor)";
    riskBadge = "🔴 КРИТИЧЕСКАЯ ОПАСНОСТЬ: Троян удалённого доступа (RAT)!";
    riskColor = "#ef4444";
    whatComplains = "Антивирусы обнаружили бэкдор/ратник (Remote Access Trojan), дающий хакеру скрытый доступ к вашему экрану, файлам и клавиатуре.";
    recommendation = "⛔ КАТЕГОРИЧЕСКИ НЕ ЗАПУСКАТЬ! Немедленно удалите файл.";
  } else if (hasRansom) {
    complaintCategory = "critical_ransom";
    trustScore = 0;
    trustReason = "Обнаружен вирус-шифровальщик (Ransomware)";
    riskBadge = "🔴 КРИТИЧЕСКАЯ ОПАСНОСТЬ: Вирус-шифровальщик (Ransomware)!";
    riskColor = "#ef4444";
    whatComplains = "Антивирусы жалуются на поведение программы-вымогателя, которая шифрует документы и файлы на дисках.";
    recommendation = "⛔ НЕМЕДЛЕННО УДАЛИТЬ ФАЙЛ!";
  } else if (hasMiner) {
    complaintCategory = "high_miner";
    trustScore = Math.max(8, 18 - Math.min(10, malCount));
    trustReason = "Обнаружен скрытый майнер криптовалюты (нагрузка GPU/CPU)";
    riskBadge = "🟠 ВЫСОКАЯ ОПАСНОСТЬ: Скрытый майнер криптовалюты!";
    riskColor = "#f97316";
    whatComplains = "Жалобы на скрытый майнер (CoinMiner / XMRig), который в фоновом режиме нагружает видеокарту и процессор.";
    recommendation = "⚠️ Не запускайте файл — вызовет перегрев и падение FPS в играх.";
  } else if ((hasGameCrackOrHackTool || isNameGameFix) && trustedTriggered.length <= 2 && malCount > 0) {
    complaintCategory = "game_hacktool";
    trustScore = Math.max(55, 74 - Math.min(18, malCount * 2));
    if (effectiveMagic?.peInfo?.signed) trustScore = Math.min(82, trustScore + 6);
    trustReason = `АВ реагируют на игровой фикс / обход DRM (HackTool/Crack, жалоб: ${malCount}), а не на стилер`;
    riskBadge = "🟡 УСЛОВНЫЙ РИСК: Игровой фикс / Кряк / Мод (HackTool)";
    riskColor = "#fbbf24";
    whatComplains = `Антивирусы (${malCount} шт.) жалуются на обход лицензионной защиты игры (HackTool / Crack / OnlineFix / модификация steam_api), а не на боевой троян.`;
    recommendation = "ℹ️ Если вы сами скачивали пиратский сетевой фикс, кряк или трейнер с проверенного источника — такая реакция антивирусов ожидаема.";
  } else if (hasAdware && trustedTriggered.length <= 2) {
    complaintCategory = "adware_pua";
    trustScore = Math.max(40, 58 - Math.min(18, malCount * 3));
    trustReason = "Жалобы на рекламный загрузчик (Adware / PUA)";
    riskBadge = "🟠 СРЕДНИЙ РИСК: Рекламный установщик (Adware / PUA)";
    riskColor = "#f59e0b";
    whatComplains = `Антивирусы (${malCount} шт.) жалуются на навязчивую рекламу или попутную установку нежелательных программ (Adware/Bundle).`;
    recommendation = "⚠️ Внимательно снимайте лишние галочки при установке или скачайте чистую версию.";
  } else if (malCount > 0 && trustedTriggered.length === 0 && malCount <= 3 && !hasDropperOrTrojan) {
    complaintCategory = "false_positive_ai";
    trustScore = Math.max(76, 88 - malCount * 4);
    if (effectiveMagic?.peInfo?.signed) trustScore = Math.min(92, trustScore + 5);
    trustReason = `Ложная ИИ-эвристика (${malCount} малоизвестных АВ), все 26 авторитетных АВ (★) чисты`;
    riskBadge = "🟡 НИЗКИЙ РИСК: Вероятно ложная ИИ-эвристика (False Positive)";
    riskColor = "#38bdf8";
    whatComplains = `Жалуются только ${malCount} малоизвестных облачных движка (${detections.map(d => d.engine).join(", ")}) на упаковщик или новизну файла. Все авторитетные антивирусы (★ Kaspersky, DrWeb, ESET, Microsoft) считают файл ЧИСТЫМ.`;
    recommendation = "✅ Скорее всего, это ложная тревога нейросетевого фильтра на безопасный файл.";
  } else if (malCount > 0 || suspCount > 0) {
    complaintCategory = malCount >= 3 || trustedTriggered.length >= 1 ? "malicious_generic" : "suspicious_generic";
    const basePenalty = (trustedTriggered.length * 22) + (malCount * 8) + (suspCount * 4) + (hasDropperOrTrojan ? 18 : 0);
    trustScore = Math.max(5, Math.min(60, 75 - basePenalty));
    const topNames = detections.slice(0, 3).map(d => `${d.engine} (${d.result})`).join(", ");
    trustReason = `Жалобы антивирусов (${malCount + suspCount} из ${totalCount}): ${topNames.slice(0, 70) || "подозрительный код"}`;
    riskBadge = malCount >= 3 || trustedTriggered.length >= 1
      ? `🔴 ОПАСНЫЙ ФАЙЛ (Жалоб антивирусов: ${malCount + suspCount} из ${totalCount})`
      : `🟡 ПОДОЗРИТЕЛЬНЫЙ ФАЙЛ (Жалоб: ${malCount + suspCount} из ${totalCount})`;
    riskColor = malCount >= 3 || trustedTriggered.length >= 1 ? "#ef4444" : "#f59e0b";
    whatComplains = `Антивирусы жалуются на подозрительные сигнатуры: ${topNames || "эвристическое срабатывание"}.`;
    recommendation = trustedTriggered.length >= 1
      ? "⚠️ Сработал авторитетный антивирус (★). Запускайте только если на 100% уверены в источнике."
      : "⚠️ Проверьте детальный список вендоров перед запуском.";
  } else {
    complaintCategory = isNameGameFix ? "game_hacktool_clean" : "clean";
    trustScore = 94;
    if ((fileMeta?.reputation || 0) >= 50 || harmlessCount >= 50) trustScore = 98;
    if (effectiveMagic?.peInfo?.isPe) {
      if (effectiveMagic.peInfo.signed) {
        trustScore = 99;
        trustReason = "0 угроз + подтверждённая цифровая подпись разработчика (PE Authenticode)";
      } else {
        trustScore = Math.min(trustScore, 89);
        trustReason = "0 угроз в базах АВ (но у .exe отсутствует цифровая подпись издателя)";
      }
    }
    if (isNameGameFix) {
      riskBadge = "🟢 БЕЗОПАСНО: Игровой фикс / Мод (Угроз: 0)";
      whatComplains = "Антивирусы и локальный инспектор не обнаружили вредоносного кода. По названию и структуре это игровой сетевой фикс / модификация.";
      recommendation = "✅ Вредоносных сигнатур (стилеров/ратников) не найдено, файл можно использовать.";
    }
    if (effectiveMagic?.zipDangerousFiles?.length > 0) {
      trustScore = 35;
      trustReason = "Внутри архива обнаружены подозрительные исполняемые файлы";
    }
    if (fileMeta?.domainAgeInfo && fileMeta.domainAgeInfo.ageDays < 30) {
      trustScore = Math.min(trustScore, 45);
      trustReason = `Файл скачан с домена-однодневки (${fileMeta.domainAgeInfo.domain}, возраст: ${fileMeta.domainAgeInfo.ageDays} дн.)`;
    }
  }

  if (effectiveMagic?.archiveEncrypted) {
    bullets.unshift("🔐 АРХИВ ПОД ПАРОЛЕМ: Зашифрованное содержимое не видно облачным антивирусам (так часто маскируют стилеры)!");
    trustScore = Math.min(trustScore, 52);
    if (complaintCategory === "clean") {
      complaintCategory = "encrypted_archive";
      riskBadge = "🟡 ВНИМАНИЕ: Запароленный архив (Содержимое скрыто от АВ)";
      riskColor = "#fbbf24";
      whatComplains = "Облачные антивирусы проверили только внешнюю оболочку архива, так как файлы внутри зашифрованы паролем.";
      trustReason = "Архив защищён паролем — антивирусы не могут просканировать вложенные файлы до распаковки";
      recommendation = "⚠️ Будьте крайне осторожны с архивами с паролем (например, 1234) из комментариев, Discord или Telegram!";
    }
  }

  const capsJoined = bullets.join(" ").toLowerCase();
  const radarMetrics = [
    {
      label: "🔓 Кража паролей / Сессий",
      score: hasStealer ? 10 : (capsJoined.includes("парол") && !capsJoined.includes("не обнаружено") ? 8 : (malCount > 4 ? 5 : 0)),
      color: "#ef4444"
    },
    {
      label: "💉 Память / Игровой фикс",
      score: (hasGameCrackOrHackTool || isNameGameFix) ? 7 : (capsJoined.includes("инъекция") ? 6 : (malCount > 0 ? 3 : 0)),
      color: "#fbbf24"
    },
    {
      label: "🌐 Сетевая активность",
      score: hasRat ? 10 : (capsJoined.includes("сетевой доступ") ? 6 : 2),
      color: "#38bdf8"
    },
    {
      label: "⚙️ Автозагрузка / Система",
      score: (hasRat || hasRansom) ? 9 : (capsJoined.includes("реестр") || capsJoined.includes("автозагрузк") ? 6 : 1),
      color: "#a855f7"
    },
    {
      label: "⛏️ Нагрузка GPU / Майнинг",
      score: hasMiner ? 10 : 0,
      color: "#f97316"
    }
  ];

  const ent = Number(effectiveMagic?.entropy || 4.8);
  const packedPct = Math.min(72, Math.max(12, Math.round((ent / 8.0) * 75)));
  const certPct = effectiveMagic?.peInfo?.signed ? 12 : 0;
  const headerPct = 10;
  const codePct = Math.max(10, 100 - packedPct - certPct - headerPct);
  const xrayBreakdown = effectiveMagic?.xrayBreakdown || fileMeta?.xrayBreakdown || {
    headerPct,
    codePct,
    packedPct,
    certPct,
    entropy: ent
  };

  return {
    complaintCategory,
    trustScore: Math.max(0, Math.min(100, Math.round(trustScore))),
    trustReason,
    riskBadge,
    riskColor,
    whatFileCouldBe,
    whatComplains,
    capabilities: bullets.slice(0, 8),
    recommendation,
    radarMetrics,
    xrayBreakdown
  };
}
// ==================== v1.0: PE AUTHENTICODE ПОДПИСЬ, ОСМОТР .RAR/.7Z/.LNK, RDAP ВОЗРАСТ ДОМЕНА И TRUST SCORE ====================

// 1. Локальная проверка наличия цифровой подписи Windows PE (Authenticode Certificate Table + известные УЦ)
function inspectPeAuthenticode(headBytes, tailBytes) {
  if (!headBytes || headBytes.length < 64 || headBytes[0] !== 0x4d || headBytes[1] !== 0x5a) {
    return { isPe: false, signed: false, signerHint: "" };
  }
  let hasCertTable = false;
  try {
    const peOffset = headBytes[60] | (headBytes[61] << 8) | (headBytes[62] << 16) | (headBytes[63] << 24);
    if (peOffset > 0 && peOffset + 168 <= headBytes.length) {
      // Проверяем PE\0\0
      if (headBytes[peOffset] === 0x50 && headBytes[peOffset + 1] === 0x45) {
        const magic = headBytes[peOffset + 24] | (headBytes[peOffset + 25] << 8);
        // DataDirectory[4] (Security/Certificate Table): offset 128 in PE32 (24+96+32=152), 144 in PE32+ (24+112+32=168)
        const secDirOffset = magic === 0x20b ? peOffset + 168 : peOffset + 152;
        if (secDirOffset + 8 <= headBytes.length) {
          const virtAddr = headBytes[secDirOffset] | (headBytes[secDirOffset + 1] << 8) | (headBytes[secDirOffset + 2] << 16) | (headBytes[secDirOffset + 3] << 24);
          const certSize = headBytes[secDirOffset + 4] | (headBytes[secDirOffset + 5] << 8) | (headBytes[secDirOffset + 6] << 16) | (headBytes[secDirOffset + 7] << 24);
          if (virtAddr > 0 && certSize > 0) hasCertTable = true;
        }
      }
    }
  } catch (_) {}

  let signerHint = "";
  if (tailBytes && tailBytes.length > 0) {
    const tailStr = new TextDecoder("latin1").decode(tailBytes.slice(-32768));
    const knownCAs = [
      "DigiCert", "Sectigo", "GlobalSign", "Microsoft Corporation",
      "COMODO", "Entrust", "VeriSign", "GoDaddy", "SSL.com", "Thawte"
    ];
    for (const ca of knownCAs) {
      if (tailStr.includes(ca)) {
        hasCertTable = true;
        signerHint = ca;
        break;
      }
    }
  }
  return {
    isPe: true,
    signed: hasCertTable,
    signerHint: signerHint ? `Подписан (${signerHint})` : (hasCertTable ? "Цифровая подпись PE присутствует" : "Без цифровой подписи (Unsigned PE)")
  };
}

// 2. Осмотр оглавления .RAR / .7Z без распаковки и разбор целевых команд внутри ярлыков .LNK
function inspectRar7zAndLnk(headBytes, tailBytes, expectedExt) {
  const result = {
    archiveFiles: [],
    archiveDangerous: [],
    lnkSuspect: false,
    lnkTarget: ""
  };
  if (!headBytes || headBytes.length < 8) return result;

  // Проверка Windows Shortcut (.lnk): сигнатура 4C 00 00 00 01 14 02 00
  const isLnk =
    expectedExt === "lnk" ||
    (headBytes[0] === 0x4c && headBytes[1] === 0x00 && headBytes[2] === 0x00 && headBytes[3] === 0x00 && headBytes[4] === 0x01 && headBytes[5] === 0x14);

  if (isLnk) {
    const combined = new Uint8Array((headBytes?.length || 0) + (tailBytes?.length || 0));
    combined.set(headBytes, 0);
    if (tailBytes) combined.set(tailBytes, headBytes.length);
    // Убираем нулевые байты UTF-16LE для чтения строк команды внутри .lnk
    let asciiClean = "";
    for (let i = 0; i < combined.length; i++) {
      const b = combined[i];
      if (b >= 32 && b <= 126) asciiClean += String.fromCharCode(b);
    }
    const lower = asciiClean.toLowerCase();
    const lnkMarkers = ["powershell", "cmd.exe", "mshta", "wscript", "cscript", "rundll32", "regsvr32", "certutil", "bitsadmin", "http://", "https://"];
    for (const m of lnkMarkers) {
      if (lower.includes(m)) {
        result.lnkSuspect = true;
        result.lnkTarget = `Ярлык .LNK запускает скрытую команду (${m})!`;
        break;
      }
    }
    return result;
  }

  // Осмотр .RAR (52 61 72 21 1A 07) и .7Z (37 7A BC AF 27 1C) буфера на имена вложенных исполняемых файлов
  const isRar = headBytes[0] === 0x52 && headBytes[1] === 0x61 && headBytes[2] === 0x72 && headBytes[3] === 0x21;
  const is7z = headBytes[0] === 0x37 && headBytes[1] === 0x7a && headBytes[2] === 0xbc && headBytes[3] === 0xaf;

  if (isRar || is7z || ["rar", "7z"].includes(expectedExt)) {
    const combinedLen = (headBytes?.length || 0) + (tailBytes?.length || 0);
    const combined = new Uint8Array(combinedLen);
    if (headBytes) combined.set(headBytes, 0);
    if (tailBytes) combined.set(tailBytes, headBytes ? headBytes.length : 0);
    const textSample = new TextDecoder("utf-8", { fatal: false }).decode(combined);
    const matches = textSample.match(/[a-zA-Zа-яА-Я0-9_\-\.\(\) ]{2,60}\.(exe|scr|bat|cmd|ps1|vbs|hta|lnk|dll|sys|msi|jar|txt|bin|pdf|png|jpg)/gi) || [];
    const uniqueFiles = Array.from(new Set(matches.map(s => s.trim()))).slice(0, 50);
    result.archiveFiles = uniqueFiles;
    const dangerExts = /\.(exe|scr|bat|cmd|ps1|vbs|hta|lnk|msi)$/i;
    result.archiveDangerous = uniqueFiles.filter(f => dangerExts.test(f));
  }

  return result;
}

// 3. Бесплатная проверка возраста домена через протокол RDAP (без ключей)
async function checkDomainAgeDaysRdap(rawUrl, settings) {
  if (!rawUrl || settings?.domainAgeCheckEnabled === false) return null;
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.toLowerCase().replace(/^www\./, "");
    const parts = host.split(".");
    if (parts.length < 2) return null;
    const rootDomain = parts.slice(-2).join(".");
    if (isUrlWhitelisted("https://" + rootDomain, settings)) return null;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2800);
    const resp = await fetch(`https://rdap.org/domain/${encodeURIComponent(rootDomain)}`, {
      headers: { "accept": "application/rdap+json, application/json" },
      signal: controller.signal
    }).catch(() => null);
    clearTimeout(timeoutId);

    if (!resp || !resp.ok) return null;
    const data = await resp.json();
    const events = Array.isArray(data?.events) ? data.events : [];
    const regEvent = events.find(e => e.eventAction === "registration" && e.eventDate);
    if (regEvent && regEvent.eventDate) {
      const regMs = Date.parse(regEvent.eventDate);
      if (!isNaN(regMs)) {
        const ageDays = Math.max(0, Math.floor((Date.now() - regMs) / (1000 * 3600 * 24)));
        return { domain: rootDomain, ageDays, registeredDate: regEvent.eventDate.slice(0, 10) };
      }
    }
  } catch (_) {}
  return null;
}

// 4. Расчёт единого Индекса доверия (Trust Score 0–100%)
function computeFileTrustScore({ stats, trustedHitsCount, peInfo, archiveDangerCount, domainAgeInfo, knownTrustedNsrl, malicious }) {
  let score = 85;
  if (knownTrustedNsrl) score = 99;
  if (peInfo?.isPe) {
    score += peInfo.signed ? 10 : -12;
  }
  if (archiveDangerCount > 0) {
    score -= 35;
  }
  if (domainAgeInfo && domainAgeInfo.ageDays < 30) {
    score -= 25;
  } else if (domainAgeInfo && domainAgeInfo.ageDays > 365) {
    score += 5;
  }
  if (malicious > 0) {
    score -= Math.min(85, malicious * 22 + (trustedHitsCount || 0) * 25);
  } else if ((stats?.harmless || 0) >= 40) {
    score = Math.max(score, 96);
  }
  return Math.max(0, Math.min(100, Math.round(score)));
}

// ==================== OFFSCREEN DOCUMENT BLOB HELPER (ДЛЯ СОХРАНЕНИЯ ИЗ ПАМЯТИ БЕЗ ДВОЙНОЙ ЗАГРУЗКИ) ====================
async function ensureOffscreenDocument() {
  if (!chrome["offscreen"]) return false;
  try {
    const existingContexts = await chrome.runtime["getContexts"]?.({
      contextTypes: ["OFFSCREEN_DOCUMENT"]
    });
    if (existingContexts && existingContexts.length > 0) return true;
    await chrome["offscreen"]["createDocument"]({
      url: "blob_host.html",
      reasons: ["BLOBS"],
      justification: "Создание локального Blob ObjectURL для мгновенного сохранения уже проверенного в памяти файла без повторного скачивания с сервера."
    });
    return true;
  } catch (_) {
    return false;
  }
}

function isUrlWhitelisted(rawUrl, settings) {
  if (!settings.whitelistEnabled || !rawUrl) return false;
  const list = Array.isArray(settings.domainWhitelist) ? settings.domainWhitelist : [];
  if (list.length === 0) return false;

  try {
    const u = new URL(rawUrl);
    const host = u.hostname.toLowerCase();

    for (const rawPattern of list) {
      const p = String(rawPattern).trim().toLowerCase();
      if (!p) continue;

      if (p.includes("*")) {
        const regexStr = "^" + p.split("*").map(s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$";
        if (new RegExp(regexStr, "i").test(host)) return true;
      } else if (host === p || host.endsWith("." + p)) {
        return true;
      }
    }
  } catch (_) {}
  return false;
}

function isFileSizeExceeded(bytes, ext, settings) {
  if (!settings.sizeLimitEnabled) return false;
  const sizeBytes = Number(bytes) || 0;
  if (sizeBytes <= 0) return false;

  const sizeMB = sizeBytes / (1024 * 1024);
  const maxGeneralMB = Math.max(10, Number(settings.maxFileSizeMB) || 500);
  if (sizeMB > maxGeneralMB) return true;

  const heavyExts = new Set([...EXTENSION_CATALOG.media, ...EXTENSION_CATALOG.arch]);
  if (heavyExts.has(ext)) {
    const maxHeavyMB = Math.max(10, Number(settings.maxHeavyCategoryMB) || 200);
    if (sizeMB > maxHeavyMB) return true;
  }
  return false;
}

function setupContextMenus() {
  if (!chrome.contextMenus?.removeAll) return;
  try {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "vt_guard_root",
      title: "🛡️ Проверить ссылку/файл в VT Download Guard",
      contexts: ["link", "image", "video", "audio", "page", "selection"]
    });

    chrome.contextMenus.create({
      id: "vt_check_only",
      parentId: "vt_guard_root",
      title: "🔍 Проверить репутацию ссылки / файла до скачивания",
      contexts: ["link", "image", "video", "audio", "page"]
    });

    chrome.contextMenus.create({
      id: "vt_check_and_download",
      parentId: "vt_guard_root",
      title: "📥 Проверить в VirusTotal и скачать файл",
      contexts: ["link", "image", "video", "audio"]
    });

    chrome.contextMenus.create({
      id: "vt_check_selection",
      parentId: "vt_guard_root",
      title: "🔎 Проверить выделенный хеш (SHA-256/MD5) или URL",
      contexts: ["selection"]
    });
  });
  } catch (_) {}
}

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (!Array.isArray(merged.extensions) || merged.extensions.length === 0) {
    merged.extensions = ALL_DEFAULT_EXTENSIONS;
  }
  if (!stored.migrationV32DefaultsDone) {
    merged.filterMode = "all";
    merged.sizeLimitEnabled = false;
    merged.whitelistEnabled = false;
    merged.stickerLockClickThrough = true;
    merged.migrationV32DefaultsDone = true;
  }
  if (!stored.migrationV15Done) {
    merged.autoDownloadSafe = true;
    merged.showDetailedVendors = true;
    merged.uploadPolicy = merged.uploadPolicy || "ask";
    merged.falsePositiveMode = merged.falsePositiveMode || "smart";
    merged.cacheEnabled = true;
    merged.domainWhitelist = Array.isArray(stored.domainWhitelist) && stored.domainWhitelist.length
      ? stored.domainWhitelist
      : DEFAULT_WHITELIST_DOMAINS;
    merged.migrationV15Done = true;
  }
  await chrome.storage.local.set(merged);
  setupContextMenus();
  applyExtensionToolbarIcon(merged);
});

chrome.runtime.onStartup.addListener(async () => {
  setupContextMenus();
  const st = await getFastSettings();
  applyExtensionToolbarIcon(st);
});

function getBasename(fullPath) {
  if (!fullPath) return "";
  const parts = String(fullPath).replace(/\\/g, "/").split("/");
  return (parts[parts.length - 1] || "").trim();
}

function extractFilenameFromUrl(rawUrl, fallbackName = "downloaded_file") {
  if (!rawUrl) return fallbackName;
  try {
    const u = new URL(rawUrl);
    const segments = u.pathname.split("/").filter(Boolean);
    if (segments.length > 0) {
      const lastSeg = decodeURIComponent(segments[segments.length - 1]);
      if (lastSeg && lastSeg.trim()) return lastSeg.trim();
    }
    for (const key of ["filename", "file", "name", "download", "f"]) {
      const val = u.searchParams.get(key);
      if (val && val.includes(".")) return getBasename(val);
    }
  } catch (_) {}
  return fallbackName;
}

const WEB_PAGE_OR_SCRIPT_EXTS = new Set([
  "php", "asp", "aspx", "jsp", "cgi", "do", "action", "html", "htm", "xhtml", "shtml"
]);

function extractExtension(filename, url) {
  const cleanFile = getBasename(filename).split("?")[0].split("#")[0];
  if (cleanFile && cleanFile.includes(".")) {
    const ext = cleanFile.split(".").pop().toLowerCase().trim();
    if (ext && /^[a-z0-9]{1,12}$/.test(ext) && !WEB_PAGE_OR_SCRIPT_EXTS.has(ext)) {
      return ext;
    }
  }

  if (url && !url.startsWith("blob:") && !url.startsWith("data:")) {
    try {
      const u = new URL(url);
      const lastSeg = decodeURIComponent(u.pathname.split("/").pop() || "");
      if (lastSeg && lastSeg.includes(".")) {
        const urlExt = lastSeg.split(".").pop().toLowerCase().trim();
        if (/^[a-z0-9]{1,12}$/.test(urlExt) && !WEB_PAGE_OR_SCRIPT_EXTS.has(urlExt)) {
          return urlExt;
        }
      }
    } catch (_) {}
  }
  return "";
}

function shouldIntercept(ext, settings) {
  if (!settings.enabled) return false;
  if (settings.filterMode === "all") return true;
  if (!ext) return false;
  const list = (settings.extensions || []).map(e => e.toLowerCase().replace(/^\./, "").trim());
  return list.includes(ext.toLowerCase());
}

function uint8ChunksToBase64(chunks, totalBytes) {
  const merged = new Uint8Array(totalBytes);
  let offset = 0;
  for (const c of chunks) {
    merged.set(c, offset);
    offset += c.byteLength;
  }
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < merged.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, merged.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

// Потоковое чтение ответа через ReadableStreamDefaultReader() с инкрементальным SHA-256 (фиксированное потребление ОЗУ!)
// Турбо-чтение потока v1.0: аппаратное ускорение WebCrypto SHA-256 (SHA-NI / AVX2) для файлов до 50 МБ + потоковый фоллбэк для гигантских образов!
async function readStreamAndComputeSha256(response, storeBlobMaxBytes = 50 * 1024 * 1024, maxStreamMs = 6000) {
  const TAIL_MAX = 65536;
  const HEAD_MAX = 32768;

  if (response.body && typeof response.body.getReader === "function") {
    const reader = response.body.getReader();
    const chunks = [];
    let totalBytes = 0;
    let overflowHasher = null;
    let headBytes = new Uint8Array(0);
    let tailRing = new Uint8Array(0);
    let timedOutStream = false;
    const streamTimer = setTimeout(() => {
      timedOutStream = true;
      try { reader.cancel(); } catch (_) {}
    }, maxStreamMs);

    try {
    while (true) {
      const { done, value } = await reader.read();
      if (done || timedOutStream) break;
      if (!value || value.byteLength === 0) continue;

      totalBytes += value.byteLength;

      if (!overflowHasher && totalBytes <= storeBlobMaxBytes) {
        chunks.push(value);
      } else {
        // Файл превысил 50 МБ — переключаемся на потоковый инкрементальный SHA-256 с фиксированным ОЗУ
        if (!overflowHasher) {
          overflowHasher = new StreamingSha256();
          for (const c of chunks) overflowHasher.update(c);
          // Сохраняем первые 32 КБ и хвост из уже накопленных чанков
          const firstChunk = chunks[0] || new Uint8Array(0);
          headBytes = firstChunk.slice(0, Math.min(HEAD_MAX, firstChunk.byteLength));
          chunks.length = 0;
        }
        overflowHasher.update(value);
        if (value.byteLength >= TAIL_MAX) {
          tailRing = value.slice(value.byteLength - TAIL_MAX);
        } else {
          const combinedLen = Math.min(TAIL_MAX, tailRing.byteLength + value.byteLength);
          const nextTail = new Uint8Array(combinedLen);
          const keepFromOld = combinedLen - value.byteLength;
          if (keepFromOld > 0) nextTail.set(tailRing.subarray(tailRing.byteLength - keepFromOld), 0);
          nextTail.set(value, keepFromOld);
          tailRing = nextTail;
        }
      }
    }

    } finally {
      clearTimeout(streamTimer);
    }
    if (timedOutStream) {
      throw new Error("Stream read timed out (large or throttled stream)");
    }
    if (!overflowHasher) {
      // Быстрый путь (<= 50 МБ): единый буфер + аппаратный C++ crypto.subtle.digest("SHA-256") за ~10-20 мс!
      const merged = new Uint8Array(totalBytes);
      let offset = 0;
      for (const c of chunks) {
        merged.set(c, offset);
        offset += c.byteLength;
      }
      let sha256Hex = "";
      if (crypto?.subtle?.digest) {
        const hashBuf = await crypto.subtle.digest("SHA-256", merged);
        const hashArr = new Uint8Array(hashBuf);
        for (let i = 0; i < hashArr.length; i++) {
          sha256Hex += hashArr[i].toString(16).padStart(2, "0");
        }
      } else {
        const h = new StreamingSha256();
        h.update(merged);
        sha256Hex = h.digestHex();
      }
      return {
        sha256: sha256Hex,
        totalBytes,
        headBytes: merged.subarray(0, Math.min(HEAD_MAX, totalBytes)),
        tailBytes: merged.subarray(Math.max(0, totalBytes - TAIL_MAX), totalBytes),
        chunks: [merged]
      };
    }

    return {
      sha256: overflowHasher.digestHex(),
      totalBytes,
      headBytes,
      tailBytes: tailRing,
      chunks: null
    };
  }

  // Фоллбэк без ReadableStream
  const buf = new Uint8Array(await response.arrayBuffer());
  const totalBytes = buf.byteLength;
  let sha256Hex = "";
  if (crypto?.subtle?.digest) {
    const hashBuf = await crypto.subtle.digest("SHA-256", buf);
    const hashArr = new Uint8Array(hashBuf);
    for (let i = 0; i < hashArr.length; i++) {
      sha256Hex += hashArr[i].toString(16).padStart(2, "0");
    }
  } else {
    const h = new StreamingSha256();
    h.update(buf);
    sha256Hex = h.digestHex();
  }
  return {
    sha256: sha256Hex,
    totalBytes,
    headBytes: buf.subarray(0, Math.min(HEAD_MAX, totalBytes)),
    tailBytes: buf.subarray(Math.max(0, totalBytes - TAIL_MAX), totalBytes),
    chunks: totalBytes <= storeBlobMaxBytes ? [buf] : null
  };
}

let dynamicRuleSeed = 90000;
let approvedAnyDownloadUntil = 0;
const approvedFilenames = new Set();
const firefoxActiveRefererMap = new Map();

function setTempFirefoxReferer(targetUrl, refererUrl, removeOrigin = true, ttlMs = 15000) {
  if (!targetUrl || !refererUrl || !/^https?:/i.test(refererUrl)) return;
  const entry = { referer: refererUrl, removeOrigin, expiresAt: Date.now() + ttlMs };
  firefoxActiveRefererMap.set(targetUrl, entry);
  try {
    const h = new URL(targetUrl).hostname.toLowerCase();
    if (h) firefoxActiveRefererMap.set(h, entry);
  } catch (_) {}
}

if (typeof chrome !== "undefined" && chrome.webRequest && chrome.webRequest.onBeforeSendHeaders) {
  try {
    chrome.webRequest.onBeforeSendHeaders.addListener(
      (details) => {
        if (!details || !details.url || firefoxActiveRefererMap.size === 0) return {};
        let targetHost = "";
        try { targetHost = new URL(details.url).hostname.toLowerCase(); } catch (_) {}
        const entry = firefoxActiveRefererMap.get(details.url) || (targetHost && firefoxActiveRefererMap.get(targetHost));
        if (!entry || Date.now() > entry.expiresAt) return {};
        const headers = details.requestHeaders ? [...details.requestHeaders] : [];
        let hasRef = false;
        for (let i = headers.length - 1; i >= 0; i--) {
          const hName = (headers[i].name || "").toLowerCase();
          if (hName === "referer") {
            headers[i].value = entry.referer;
            hasRef = true;
          } else if (hName === "origin" && entry.removeOrigin) {
            headers.splice(i, 1);
          }
        }
        if (!hasRef && entry.referer) {
          headers.push({ name: "Referer", value: entry.referer });
        }
        return { requestHeaders: headers };
      },
      { urls: ["<all_urls>"] },
      ["blocking", "requestHeaders"]
    );
  } catch (_) {}
}

async function fetchWithReferer(fileUrl, referrerUrl) {
  if (fileUrl && /discordapp\.(com|net)|discord\.com/i.test(fileUrl)) {
    return await fetchWithTimeout(fileUrl, {
      credentials: "omit",
      redirect: "follow"
    }, 4500);
  }
  const ruleId = 90000 + ((dynamicRuleSeed = (dynamicRuleSeed + 1) % 5000));
  let effectiveReferer = referrerUrl;
  if ((!effectiveReferer || !/^https?:\/\//i.test(effectiveReferer)) && /^https?:\/\//i.test(fileUrl)) {
    try {
      effectiveReferer = new URL(fileUrl).origin + "/";
    } catch (_) {}
  }
  if (effectiveReferer && /^https?:\/\//i.test(effectiveReferer) && /^https?:\/\//i.test(fileUrl)) {
    setTempFirefoxReferer(fileUrl, effectiveReferer, true, 12000);
  }
  if (chrome["declarativeNetRequest"]?.["updateSessionRules"] && effectiveReferer && /^https?:\/\//i.test(effectiveReferer) && /^https?:\/\//i.test(fileUrl)) {
    try {
      await chrome["declarativeNetRequest"]["updateSessionRules"]({
        removeRuleIds: [ruleId],
        addRules: [
          {
            id: ruleId,
            priority: 1,
            action: {
              type: "modifyHeaders",
              requestHeaders: [
                { header: "Referer", operation: "set", value: effectiveReferer },
                { header: "Origin", operation: "remove" }
              ]
            },
            condition: {
              resourceTypes: ["xmlhttprequest", "other"]
            }
          }
        ]
      });
    } catch (_) {}
  }

  if (!fileUrl || fileUrl.startsWith("blob:") || fileUrl.startsWith("data:")) {
    throw new Error("Local blob/data stream");
  }
  try {
    return await fetchWithTimeout(fileUrl, {
      credentials: "include",
      redirect: "follow",
      headers: {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/octet-stream,*/*;q=0.8"
      }
    }, 4000);
  } finally {
    try {
      await chrome["declarativeNetRequest"]["updateSessionRules"]({ removeRuleIds: [ruleId] });
    } catch (_) {}
  }
}

const activeBannerCards = new Map();
const completedScanPayloads = new Map();
const standaloneWindowByScanId = new Map();
const cancelledScanIds = new Set();

async function sendBannerUpdate(tabId, payload) {
  if (payload && payload.scanId && cancelledScanIds.has(payload.scanId)) {
    return;
  }
  try {
    const fastSt = await getFastSettings();
    if (fastSt) {
      payload = {
        theme: fastSt.theme || "salmon_ocean",
        bgImageEnabled: fastSt.bgImageEnabled !== false,
        bgOpacity: fastSt.bgOpacity ?? 36,
        cardBgOpacity: fastSt.cardBgOpacity ?? 48,
        glassBlurEnabled: fastSt.glassBlurEnabled !== false,
        stickersEnabled: fastSt.stickersEnabled !== false,
        stickerPreset: fastSt.stickerPreset || "auto_theme",
        stickerSize: fastSt.stickerSize || 78,
        stickerOpacity: fastSt.stickerOpacity ?? 85,
        stickerPosition: fastSt.stickerPosition || "bottom-right",
        stickerCustomX: fastSt.stickerCustomX ?? 80,
        stickerCustomY: fastSt.stickerCustomY ?? 75,
        soundPreset: fastSt.soundPreset || "auto_theme",
        soundVolume: fastSt.soundVolume ?? 70,
        customFontFamily: fastSt.customFontFamily || "system",
        customFontName: fastSt.customFontName || "",
        customFontScale: fastSt.customFontScale || 100,
        customBorderRadius: fastSt.customBorderRadius ?? 10,
        customColorsEnabled: Boolean(fastSt.customColorsEnabled),
        customBgColor: fastSt.customBgColor || "#051622",
        customCardColor: fastSt.customCardColor || "#0a2538",
        customAccentColor: fastSt.customAccentColor || "#ff856d",
        customTextColorEnabled: Boolean(fastSt.customTextColorEnabled),
        customTextMainColor: fastSt.customTextMainColor || "#f0f9ff",
        customTextSubColor: fastSt.customTextSubColor || "#7dd3fc",
        bannerPosition: fastSt.bannerPosition || "top-right",
        autoCloseSafeSec: fastSt.autoCloseSafeSec ?? 8,
        soundAlertsEnabled: fastSt.soundAlertsEnabled !== false,
        trustScoreEnabled: fastSt.trustScoreEnabled !== false,
        xrayRadarEnabled: fastSt.xrayRadarEnabled !== false,
        liveParticlesEnabled: fastSt.liveParticlesEnabled !== false,
        neonGlowIntensity: fastSt.neonGlowIntensity ?? 35,
        cardAnimStyle: fastSt.cardAnimStyle || "slide",
        miniPillModeEnabled: Boolean(fastSt.miniPillModeEnabled),
        scanWindowDisplayMode: fastSt.scanWindowDisplayMode || "card_on_top",
        uiLang: fastSt.uiLang || "ru",
        ...payload
      };
    }
    if (false) {
    const uiPrefs = await chrome.storage.local.get({
      theme: "salmon_ocean",
      bgImageEnabled: true,
      bgOpacity: 36,
      cardBgOpacity: 48,
      glassBlurEnabled: true,
      customBgDataUrl: "",
      stickersEnabled: true,
  stickerLockClickThrough: true,
      stickerPreset: "auto_theme",
      customStickerDataUrl: "",
      stickerSize: 78,
      stickerOpacity: 85,
      stickerPosition: "bottom-right",
      stickerCustomX: 80,
      stickerCustomY: 75,
      soundPreset: "auto_theme",
      soundVolume: 70,
      customSoundDataUrl: "",
      customFontFamily: "system",
      customFontName: "",
      customFontDataUrl: "",
      customFontScale: 100,
      customBorderRadius: 10,
      customColorsEnabled: false,
      customBgColor: "#051622",
      customCardColor: "#0a2538",
      customAccentColor: "#ff856d",
      customTextColorEnabled: false,
      customTextMainColor: "#f0f9ff",
      customTextSubColor: "#7dd3fc",
      bannerPosition: "top-right",
      autoCloseSafeSec: 8,
      soundAlertsEnabled: true,
      trustScoreEnabled: true,
      xrayRadarEnabled: true,
      liveParticlesEnabled: true,
      neonGlowIntensity: 35,
      cardAnimStyle: "slide",
      miniPillModeEnabled: false
    });
    payload = {
      ...uiPrefs,
      ...payload
    };
    }
  } catch (_) {}
  const winMode = payload?.scanWindowDisplayMode || "card_on_top";
  if (payload && payload.scanId) {
    completedScanPayloads.set(payload.scanId, payload);
    if (completedScanPayloads.size > 120) {
      const oldestKey = completedScanPayloads.keys().next().value;
      if (oldestKey) completedScanPayloads.delete(oldestKey);
    }
  }

  // Helper to open or focus our own standalone window (either "card" = clean scan card only, or "ext" = full extension window with scan inside)
  const openOrFocusStandaloneWindow = async (sId, viewType) => {
    if (!sId) return;
    if (standaloneWindowByScanId.has(sId)) {
      const existingWinId = standaloneWindowByScanId.get(sId);
      if (typeof existingWinId === "number" && chrome.windows?.update) {
        try {
          await chrome.windows.update(existingWinId, { focused: true });
          return;
        } catch (_) {
          standaloneWindowByScanId.delete(sId);
        }
      } else {
        return;
      }
    }
    standaloneWindowByScanId.set(sId, true);
    try {
      const popupUrl = chrome.runtime.getURL(`popup.html?standalone_scan=${encodeURIComponent(sId)}&view=${viewType}`);
      if (chrome.windows?.create) {
        const win = await chrome.windows.create({
          url: popupUrl,
          type: "popup",
          width: viewType === "card" ? 465 : 490,
          height: viewType === "card" ? 610 : 700,
          focused: true
        });
        if (win && win.id) standaloneWindowByScanId.set(sId, win.id);
      }
    } catch (_) {}
  };

  // Всегда доставляем карточку на страницу (чтобы не открывалось лишнее системное окно ОС),
  // а приоритет перекрытия (Окно проверки поверх расширения / Расширение поверх проверки / Оба окна рядом без перекрытия)
  // управляется напрямую на странице и через порт открытия расширения!

  let delivered = false;
  const tryDeliverToTab = async (targetTid) => {
    if (!targetTid) return false;
    try {
      const res = await chrome.tabs.sendMessage(targetTid, { type: "VT_BANNER_UPDATE", payload });
      if (res && res.rendered) return true;
    } catch (_) {}
    try {
      if (chrome.scripting?.executeScript) {
        await chrome.scripting.executeScript({
          target: { tabId: targetTid },
          files: ["content.js"]
        });
      } else if (chrome.tabs?.executeScript) {
        await new Promise(r => chrome.tabs.executeScript(targetTid, { file: "content.js" }, () => r()));
      }
      const res2 = await chrome.tabs.sendMessage(targetTid, { type: "VT_BANNER_UPDATE", payload });
      if (res2 && res2.rendered) return true;
    } catch (_) {}
    try {
      if (chrome.scripting?.executeScript) {
        const execRes = await chrome.scripting.executeScript({
          target: { tabId: targetTid },
          func: (p) => Boolean(window.__vtGuardRenderCardDirect && window.__vtGuardRenderCardDirect(p)),
          args: [payload]
        });
        if (execRes && execRes[0] && execRes[0].result) return true;
      }
    } catch (_) {}
    return false;
  };

  let browserWindowFocused = true;
  try {
    // 1. Сначала пробуем доставить в целевую вкладку tabId (если это обычная веб-страница)
    if (tabId) {
      try {
        const tInfo = await chrome.tabs.get(tabId);
        const isTempUrl = tInfo?.url && /cdn\.discordapp\.com|media\.discordapp\.net/i.test(tInfo.url);
        if (tInfo && /^https?:/i.test(tInfo.url || "") && !isTempUrl) {
          delivered = await tryDeliverToTab(tabId);
        }
      } catch (_) {}
    }
    // 2. Если не доставлено — ищем активную веб-вкладку во всех ОБЫЧНЫХ окнах браузера (windowType: "normal"), игнорируя popup-окна расширения!
    if (!delivered) {
      const normalActiveTabs = await chrome.tabs.query({ active: true, windowType: "normal" });
      for (const candTab of (normalActiveTabs || [])) {
        const isTempDownloadUrl = candTab?.url && /cdn\.discordapp\.com|media\.discordapp\.net/i.test(candTab.url);
        if (candTab && candTab.id && candTab.url && /^https?:/i.test(candTab.url) && !isTempDownloadUrl) {
          delivered = await tryDeliverToTab(candTab.id);
          if (delivered) {
            tabId = candTab.id;
            break;
          }
        }
      }
    }
    // 3. Фоллбэк: любая открытая https-вкладка в обычном окне браузера (например, если MAX открыл временную пустую вкладку на 20 мс)
    if (!delivered) {
      const allNormalTabs = await chrome.tabs.query({ windowType: "normal" });
      const webTabs = (allNormalTabs || []).filter(t => t && t.id && /^https?:/i.test(t.url || "") && !/cdn\.discordapp\.com|media\.discordapp\.net/i.test(t.url || ""));
      webTabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
      if (webTabs[0]) {
        delivered = await tryDeliverToTab(webTabs[0].id);
        if (delivered) tabId = webTabs[0].id;
      }
    }
  } catch (_) {}

  const pItemForWin = payload?.scanId ? pendingDownloads.get(payload.scanId) : null;
  const isExternalApp = Boolean(payload?.isExternalAppDownload || pItemForWin?.isExternalAppDownload);

  if ((!delivered || isExternalApp) && payload && payload.scanId && !payload.fromPopupManual) {
    const viewModeParam = winMode === "extension_on_top" ? "ext" : "card";
    await openOrFocusStandaloneWindow(payload.scanId, viewModeParam);
  }

  // Дополнительная страховка для Discord / внешних ссылок: если вкладка, куда доставили плашку, автоматически закрылась через 250 мс (временная вкладка скачивания),
  // переносим плашку на новую активную вкладку или открываем мини-окно!
  if (delivered && tabId && payload && payload.scanId && !payload.fromPopupManual) {
    const checkTid = tabId;
    const checkSid = payload.scanId;
    setTimeout(async () => {
      if (cancelledScanIds.has(checkSid)) return;
      let tabStillAlive = false;
      try {
        const t = await chrome.tabs.get(checkTid);
        if (t && t.id) tabStillAlive = true;
      } catch (_) {
        tabStillAlive = false;
      }
      if (!tabStillAlive) {
        const latestEntry = activeBannerCards.get(checkSid);
        const latestPayload = latestEntry?.payload || completedScanPayloads.get(checkSid);
        if (latestPayload) {
          let redelivered = false;
          try {
            const curTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
            const curTab = curTabs && curTabs[0];
            if (curTab && curTab.id && curTab.url && /^https?:/i.test(curTab.url)) {
              redelivered = await tryDeliverToTab(curTab.id);
              if (redelivered && latestEntry) latestEntry.tabId = curTab.id;
            }
          } catch (_) {}
          if (!redelivered) {
            const vm = (latestPayload.scanWindowDisplayMode || "card_on_top") === "extension_on_top" ? "ext" : "card";
            await openOrFocusStandaloneWindow(checkSid, vm);
          }
        }
      }
    }, 300);
  }

  if (payload && payload.scanId) {
    activeBannerCards.set(payload.scanId, {
      tabId: tabId || null,
      payload,
      updatedAt: Date.now()
    });
    if (payload.state === "completed" && !pendingDownloads.has(payload.scanId)) {
      setTimeout(() => {
        const cur = activeBannerCards.get(payload.scanId);
        if (cur && cur.payload?.state === "completed" && !pendingDownloads.has(payload.scanId)) {
          activeBannerCards.delete(payload.scanId);
        }
      }, 15000);
    }
    try {
      chrome.runtime.sendMessage({ type: "VT_STANDALONE_SCAN_UPDATE", payload }).catch(() => {});
    } catch (_) {}
  }

  if (!delivered && (payload.state === "completed" || payload.state === "error" || payload.state === "consent_required")) {
    try {
      if (chrome.notifications?.create) {
        chrome.notifications.create(payload.scanId, {
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: `VT Download Guard: ${payload.filename}`,
          message: payload.summaryText || "Проверка завершена."
        });
      }
    } catch (_) {}
  }
}

function sanitizeWindowsFilename(name) {
  if (!name) return "downloaded_file";
  const base = getBasename(name).replace(/[<>:"/\\|?*\x00-\x1F]/g, "_").trim();
  return base || "downloaded_file";
}

// 1. Перехват создания загрузки: ставим на паузу в onCreated ТОЛЬКО если имя файла уже известно (иначе в мессенджере MAX / Chromium пауза до заголовка Content-Disposition блокирует получение имени .docx файла!)
chrome.downloads.onCreated.addListener((downloadItem) => {
  if (!downloadItem || approvedDownloadIds.has(downloadItem.id) || handledDownloadIds.has(downloadItem.id)) return;
  const ageMs = downloadItem.startTime ? (Date.now() - Date.parse(downloadItem.startTime)) : 0;
  // Пропускаем только старые завершённые загрузки из истории прошлых сессий браузера (> 12 сек назад)
  if (downloadItem.state && downloadItem.state !== "in_progress" && (isNaN(ageMs) || ageMs > 12000 || downloadItem.state === "interrupted")) {
    handledDownloadIds.add(downloadItem.id);
    return;
  }
  if (!isNaN(ageMs) && ageMs > 20000) {
    handledDownloadIds.add(downloadItem.id);
    return;
  }
  const u = downloadItem.finalUrl || downloadItem.url || "";
  if (!u || u.startsWith("data:") || u.startsWith("chrome-extension:") || u.startsWith("moz-extension:") || u.startsWith("blob:chrome-extension:") || u.startsWith("blob:moz-extension:")) return;
  const itemBaseName = getBasename(downloadItem.filename || "").toLowerCase().replace(/\(\d+\)(?=\.[^.]+$|$)/g, "");
  if (Date.now() < approvedAnyDownloadUntil || approvedUrls.has(u) || approvedUrls.has(downloadItem.url || "") || (itemBaseName && approvedFilenames.has(itemBaseName))) {
    approvedDownloadIds.add(downloadItem.id);
    handledDownloadIds.add(downloadItem.id);
    return;
  }
  if (ramSettingsCache && ramSettingsCache.enabled === false) return;

  // Если имя файла уже известно ИЛИ в самой ссылке есть расширение файла (например cdn.discordapp.com/attachments/.../file.zip),
  // ставим на паузу мгновенно на 0-й миллисекунде!
  const urlHasFilename = Boolean(extractExtension("", u));
  const isSelfVtGuardFast = /vt[_\-\s]*download[_\-\s]*guard|vt-download-guard@salmonplay1|cloudflare_worker_proxy/i.test((downloadItem.filename || "") + " " + u);
  if (!isSelfVtGuardFast && !u.startsWith("blob:") && (downloadItem.filename || urlHasFilename || /discordapp\.(com|net)/i.test(u))) {
    try {
      chrome.downloads.pause(downloadItem.id, () => { void chrome.runtime?.lastError; });
    } catch (_) {}
  }

  // Быстрый страховочный таймер (120 мс для приложений типа Discord Desktop / MAX / Firefox):
  setTimeout(() => {
    if (!handledDownloadIds.has(downloadItem.id) && !approvedDownloadIds.has(downloadItem.id)) {
      chrome.downloads.search({ id: downloadItem.id }, (items) => {
        const dlObj = (items && items[0]) ? items[0] : downloadItem;
        const fallbackName = getBasename(dlObj.filename || "") || extractFilenameFromUrl(dlObj.finalUrl || dlObj.url || "", "downloaded_file");
        handleDownloadIntercept(dlObj, fallbackName);
      });
    }
  }, chrome.downloads["onDeterminingFilename"] ? 140 : 20);
});

if (chrome.downloads && chrome.downloads["onDeterminingFilename"]) {
chrome.downloads["onDeterminingFilename"].addListener((downloadItem, suggest) => {
  const itemUrl = downloadItem.finalUrl || downloadItem.url || "";
  const suggestedFilename = getBasename(downloadItem.filename || "");
  if (blobFilenameMap.has(itemUrl)) {
    const forcedName = sanitizeWindowsFilename(blobFilenameMap.get(itemUrl));
    blobFilenameMap.delete(itemUrl);
    handledDownloadIds.add(downloadItem.id);
    approvedDownloadIds.add(downloadItem.id);
    suggest({ filename: forcedName, conflictAction: "uniquify" });
    return;
  }
  if (approvedDownloadIds.has(downloadItem.id) || approvedUrls.has(itemUrl) || approvedUrls.has(downloadItem.url || "")) {
    handledDownloadIds.add(downloadItem.id);
    suggest();
    return;
  }

  suggest();

  if (!itemUrl.startsWith("blob:") && !(downloadItem.url || "").startsWith("blob:")) {
    try {
      chrome.downloads.pause(downloadItem.id, () => { void chrome.runtime?.lastError; });
    } catch (_) {}
    [8, 30].forEach((ms) => {
      setTimeout(() => {
        if (!approvedDownloadIds.has(downloadItem.id)) {
          try {
            chrome.downloads.pause(downloadItem.id, () => { void chrome.runtime?.lastError; });
          } catch (_) {}
        }
      }, ms);
    });
  }

  setTimeout(() => {
    chrome.downloads.search({ id: downloadItem.id }, (items) => {
      if (items && items[0]) {
        handleDownloadIntercept(items[0], suggestedFilename);
      } else {
        handleDownloadIntercept(downloadItem, suggestedFilename);
      }
    });
  }, 5);
});
}

chrome.downloads.onChanged.addListener((delta) => {
  // Сторож паузы: если пока идёт проверка (scanningActive === true) браузер попытался снять файл с паузы — мгновенно возвращаем на паузу!
  if (delta.paused && delta.paused.current === false && !approvedDownloadIds.has(delta.id)) {
    for (const [, pItem] of pendingDownloads.entries()) {
      if (pItem.downloadId === delta.id && pItem.scanningActive) {
        try {
          chrome.downloads.pause(delta.id, () => { void chrome.runtime?.lastError; });
        } catch (_) {}
        break;
      }
    }
  }
  if (delta.error && (delta.error.current === "FILE_VIRUS_INFECTED" || delta.error.current === "FILE_BLOCKED" || delta.error.current === "FILE_SECURITY_CHECK_FAILED")) {
    for (const [sId, pItem] of pendingDownloads.entries()) {
      if (pItem.downloadId === delta.id) {
        setExtensionBadge("danger", 1);
        getFastSettings().then((st) => {
          sendBannerUpdate(pItem.tabId, {
            scanId: sId,
            filename: pItem.filename || "Заблокированный файл",
            ext: pItem.ext || "file",
            state: "completed",
            verdict: "danger",
            trustScore: 0,
            summaryText: `🚨 Встроенный антивирус вашего ПК (Windows Defender / Системный АВ по умолчанию) обнаружил в файле вирус (${delta.error.current}) и заблокировал сохранение!`,
            stats: { malicious: 1, suspicious: 0, harmless: 0, total: 1, trustedCount: 1 },
            detections: [{ engine: "💻 Системный антивирус ПК (Windows Defender / АВ по умолчанию)", category: "malicious", result: `Заблокировано антивирусом ПК (${delta.error.current})`, trusted: true }],
            allVendors: [{ engine: "💻 Системный антивирус ПК (Windows Defender / АВ по умолчанию)", category: "malicious", result: `Заблокировано антивирусом ПК (${delta.error.current})`, trusted: true }],
            fileMeta: {
              sha256: pItem.sha256 || "Заблокировано ОС",
              sizeFormatted: formatFileSize(pItem.fileSize || 0),
              typeTag: pItem.ext || "virus",
              magicDesc: "Штатный антивирус вашей операционной системы заблокировал этот файл при проверке потока",
              analysisDate: "Только что ⚡ (Защита ПК)"
            },
            reportUrl: pItem.sha256 ? `https://www.virustotal.com/gui/file/${pItem.sha256}` : "https://www.virustotal.com/gui/home/upload",
            autoBlocked: true,
            triggeredCount: 1,
            blockThreshold: 1,
            hasDownloadableTarget: false,
            uiLang: st.uiLang || "ru"
          });
        });
      }
    }
  }
  if (delta.state && (delta.state.current === "complete" || delta.state.current === "interrupted")) {
    for (const [sId, pItem] of pendingDownloads.entries()) {
      if (pItem.downloadId === delta.id) {
        setExtensionBadge("clear");
        if (delta.state.current === "interrupted") {
          pItem.scanningActive = false;
          updateKeepAliveState();
        }
      }
    }
  }
  if (delta.filename && delta.filename.current && !handledDownloadIds.has(delta.id)) {
    chrome.downloads.search({ id: delta.id }, (items) => {
      if (items && items[0]) {
        handleDownloadIntercept(items[0]);
      }
    });
  }
});

async function handleDownloadIntercept(downloadItem, fallbackFilename = "") {
  if (!downloadItem || handledDownloadIds.has(downloadItem.id) || approvedDownloadIds.has(downloadItem.id)) return;
  if (downloadItem.state === "complete" && downloadItem.startTime && (Date.now() - Date.parse(downloadItem.startTime) > 15000)) {
    handledDownloadIds.add(downloadItem.id);
    return;
  }

  const targetUrl = downloadItem.finalUrl || downloadItem.url || "";
  const origUrl = downloadItem.url || "";

  if (
    !targetUrl ||
    targetUrl.startsWith("data:") ||
    targetUrl.startsWith("chrome-extension:") ||
    targetUrl.startsWith("blob:chrome-extension:") ||
    targetUrl.startsWith("moz-extension:") ||
    targetUrl.startsWith("blob:moz-extension:") ||
    origUrl.startsWith("chrome-extension:") ||
    origUrl.startsWith("moz-extension:") ||
    origUrl.startsWith("blob:chrome-extension:") ||
    origUrl.startsWith("blob:moz-extension:")
  ) {
    handledDownloadIds.add(downloadItem.id);
    return;
  }

  const diskBasename =
    getBasename(downloadItem.filename || "") ||
    getBasename(fallbackFilename || "") ||
    extractFilenameFromUrl(targetUrl, "") ||
    extractFilenameFromUrl(origUrl, "downloaded_file");

  const rawDiskExt = diskBasename.includes(".") ? diskBasename.split(".").pop().toLowerCase().trim() : "";
  const itemMime = String(downloadItem.mime || "").toLowerCase();
  const releaseUnmonitoredDownload = () => {
    approvedDownloadIds.add(downloadItem.id);
    handledDownloadIds.add(downloadItem.id);
    try {
      chrome.downloads.resume(downloadItem.id, () => { void chrome.runtime?.lastError; });
    } catch (_) {}
  };

  if (
    WEB_PAGE_OR_SCRIPT_EXTS.has(rawDiskExt) ||
    itemMime === "text/html" ||
    itemMime === "application/xhtml+xml" ||
    itemMime === "text/css" ||
    (!rawDiskExt && (diskBasename.startsWith("getfile") || diskBasename.startsWith("download")))
  ) {
    releaseUnmonitoredDownload();
    return;
  }

  const normBaseName = diskBasename.toLowerCase().replace(/\(\d+\)(?=\.[^.]+$|$)/g, "");
  if (Date.now() < approvedAnyDownloadUntil || approvedUrls.has(targetUrl) || approvedUrls.has(origUrl) || (normBaseName && approvedFilenames.has(normBaseName))) {
    releaseUnmonitoredDownload();
    return;
  }

  handledDownloadIds.add(downloadItem.id);

  const settings = await getFastSettings();
  if (!settings.enabled) {
    releaseUnmonitoredDownload();
    return;
  }

  const normalActiveTabs = await chrome.tabs.query({ active: true, windowType: "normal" });
  let activeTab = (normalActiveTabs || []).find(t => t && /^https?:/i.test(t.url || "") && !/cdn\.discordapp\.com|media\.discordapp\.net/i.test(t.url || "")) || (normalActiveTabs && normalActiveTabs[0]) || null;
  if (!activeTab || !/^https?:/i.test(activeTab.url || "")) {
    const allNormalTabs = await chrome.tabs.query({ windowType: "normal" });
    const webCandidates = (allNormalTabs || []).filter(t => t && /^https?:/i.test(t.url || "") && !/cdn\.discordapp\.com|media\.discordapp\.net/i.test(t.url || ""));
    webCandidates.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    if (webCandidates[0]) activeTab = webCandidates[0];
  }
  const tabId = activeTab ? activeTab.id : null;
  const isDiscordCdnUrl = /cdn\.discordapp\.com|media\.discordapp\.net/i.test(targetUrl || origUrl);
  const isExternalAppDownload = Boolean(
    isDiscordCdnUrl && !downloadItem.referrer && !(activeTab?.url && /discord\.com|discordapp\.com/i.test(activeTab.url))
  );
  const referrer = downloadItem.referrer || (!isExternalAppDownload && activeTab && /^https?:/i.test(activeTab.url || "") ? activeTab.url : "");

  if (isUrlWhitelisted(targetUrl, settings) || isUrlWhitelisted(origUrl, settings) || isUrlWhitelisted(referrer, settings)) {
    releaseUnmonitoredDownload();
    return;
  }

  const realBasename = diskBasename;
  const ext = extractExtension(realBasename, targetUrl);
  const filenameAttack = analyzeFilenameAttack(realBasename);

  if (!filenameAttack.suspicious && !shouldIntercept(ext, settings)) {
    releaseUnmonitoredDownload();
    return;
  }

  const fileSize = downloadItem.fileSize > 0 ? downloadItem.fileSize : (downloadItem.totalBytes > 0 ? downloadItem.totalBytes : 0);
  if (!filenameAttack.suspicious && isFileSizeExceeded(fileSize, ext, settings)) {
    releaseUnmonitoredDownload();
    return;
  }

  const isSelfVtGuardPackage = Boolean(inspectVtGuardSelfAuthenticity({
    filename: realBasename,
    sourceUrl: targetUrl,
    origUrl,
    referrer,
    expectedExt: ext
  })?.isOfficialVtGuard);

  if (isSelfVtGuardPackage) {
    approvedDownloadIds.add(downloadItem.id);
    try {
      chrome.downloads.resume(downloadItem.id, () => { void chrome.runtime?.lastError; });
    } catch (_) {}
  } else if (!targetUrl.startsWith("blob:") && !origUrl.startsWith("blob:")) {
    try {
      await chrome.downloads.pause(downloadItem.id);
    } catch (_) {}
  }

  const scanId = `vt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

  const interceptEntryObj = {
    scanId,
    isExternalAppDownload,
    scanningActive: true,
    scanStartMs: Date.now(),
    downloadId: downloadItem.id,
    url: targetUrl,
    origUrl,
    referrer,
    tabUrl: activeTab?.url || "",
    filename: realBasename,
    fullPath: downloadItem.filename || "",
    fileSize,
    ext: ext || "file",
    tabId,
    filenameAttack
  };
  pendingDownloads.set(scanId, interceptEntryObj);
  savedDownloadBackups.set(scanId, interceptEntryObj);
  if (realBasename) savedDownloadBackupsByName.set(realBasename.toLowerCase(), interceptEntryObj);
  updateKeepAliveState();
  saveScanHistory({
    scanId,
    downloadId: downloadItem.id,
    fileUrl: origUrl || targetUrl,
    filename: realBasename,
    ext: ext || "file",
    sha256: "",
    verdict: "warning",
    malicious: 0,
    suspicious: 0,
    trustedCount: 0,
    total: 72,
    autoBlocked: false,
    fromCache: false,
    summaryText: "⏳ Файл на паузе — выполняется проверка безопасности...",
    reportUrl: "https://www.virustotal.com/gui/home/upload",
    timestamp: Date.now()
  }).catch(() => {});

  await processFileWithVirusTotal(scanId, targetUrl, realBasename, ext || "file", settings, tabId, "intercept", referrer);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const tabId = tab?.id || null;
  const settings = await getFastSettings();
  const scanId = `vt_ctx_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const pageReferrer = tab?.url || info.pageUrl || "";

  if (info.menuItemId === "vt_check_selection") {
    const rawSelection = (info.selectionText || "").trim();
    if (!rawSelection) return;

    const isHexHash = /^[a-fA-F0-9]{32}$|^[a-fA-F0-9]{40}$|^[a-fA-F0-9]{64}$/.test(rawSelection);
    if (isHexHash) {
      await checkHashDirectly(scanId, rawSelection.toLowerCase(), settings, tabId);
    } else {
      const candidateUrl = /^https?:\/\//i.test(rawSelection) ? rawSelection : `https://${rawSelection}`;
      await processUrlOnlyWithVirusTotal(scanId, candidateUrl, rawSelection.slice(0, 60), settings, tabId);
    }
    return;
  }

  const targetUrl = info.linkUrl || info.srcUrl || info.pageUrl;
  if (!targetUrl) return;

  const filename = extractFilenameFromUrl(targetUrl, "checked_link");
  const ext = extractExtension(filename, targetUrl) || "url";

  pendingDownloads.set(scanId, {
    downloadId: null,
    url: targetUrl,
    referrer: pageReferrer,
    filename,
    fullPath: "",
    fileSize: 0,
    ext,
    tabId,
    filenameAttack: analyzeFilenameAttack(filename)
  });
  updateKeepAliveState();

  const shouldDownloadIfClean = info.menuItemId === "vt_check_and_download";
  await processFileWithVirusTotal(
    scanId,
    targetUrl,
    filename,
    ext,
    settings,
    tabId,
    shouldDownloadIfClean ? "context_download" : "context_check",
    pageReferrer
  );
});

// Защищённая проверка репутации домена (/api/v3/domains/{domain}), когда ссылка содержит приватные GET-токены
async function checkDomainReputationOnly(scanId, fileUrl, filename, ext, cleanKey, reportUrl, settings, tabId, sourceMode, reasonNote) {
  let hostname = "";
  try {
    hostname = new URL(fileUrl).hostname;
  } catch (_) {}

  if (!hostname) {
    throw new Error("Не удалось извлечь домен из защищённой ссылки.");
  }

  await consumeRateLimitSlot(async (waitSec, qLen) => {
    await sendBannerUpdate(tabId, {
      scanId,
      filename,
      ext: ext || "file",
      state: "scanning",
      stepText: `⏳ Очередь лимита VirusTotal API: ожидание ${waitSec} сек. (в очереди: ${qLen})...`,
      reportUrl
    });
  });

  await sendBannerUpdate(tabId, {
    scanId,
    filename,
    ext: ext || "file",
    state: "scanning",
    stepText: `🔒 Защита GET-токенов: проверка репутации домена ${hostname} (/api/v3/domains) без раскрытия приватной ссылки...`,
    reportUrl: `https://www.virustotal.com/gui/domain/${hostname}`
  });

  const resp = await fetch(`https://www.virustotal.com/api/v3/domains/${encodeURIComponent(hostname)}`, {
    headers: {
      "accept": "application/json",
      "x-apikey": cleanKey
    }
  });

  if (!resp.ok) {
    throw new Error(`Ошибка проверки домена ${hostname} (HTTP ${resp.status})`);
  }

  const data = await resp.json();
  const attr = data?.data?.attributes || {};
  const stats = attr.last_analysis_stats || { malicious: 0, suspicious: 0, harmless: 0, undetected: 0 };
  const extracted = extractVendorResults(attr.last_analysis_results);

  await finalizeAndDisplayResult({
    scanId,
    filename,
    ext,
    stats,
    detections: extracted.detections,
    allVendors: extracted.allVendors,
    fileMeta: {
      sha256: `Домен: ${hostname} (${reasonNote})`,
      sizeFormatted: "Защищённый URL",
      typeTag: "domain-check",
      magicDesc: "Ссылка содержит приватные токены — проверен только домен без раскрытия параметров",
      analysisDate: "Только что",
      reputation: attr.reputation ?? 0
    },
    reportUrl: `https://www.virustotal.com/gui/domain/${hostname}`,
    settings,
    tabId,
    sourceMode
  });
}

async function checkHashDirectly(scanId, hashValue, settings, tabId) {
  const reportUrl = `https://www.virustotal.com/gui/file/${hashValue}`;
  const cleanKey = (settings.vtApiKeyModeEnabled !== false) ? sanitizeApiKey(settings.apiKey) : "";

  // Сначала проверяем локальный 7-дневный кэш SHA-256 (0 мс, 0 запросов к API!)
  if (hashValue.length === 64) {
    const cached = await getCachedHashReport(hashValue, settings);
    if (cached) {
      await finalizeAndDisplayResult({
        scanId,
        filename: cached.filename || `Хеш ${hashValue.slice(0, 16)}...`,
        ext: cached.ext || "hash",
        stats: cached.stats,
        detections: cached.detections,
        allVendors: cached.allVendors,
        fileMeta: {
          ...cached.fileMeta,
          analysisDate: `${cached.fileMeta?.analysisDate || "В кэше"} ⚡ (Из локального кэша)`
        },
        reportUrl,
        settings,
        tabId,
        sourceMode: "hash_lookup",
        fromCache: true
      });
      return;
    }
  }

  if (!cleanKey) {
    const zeroKeyRes = hashValue.length === 64 ? await queryZeroKeyCloudReputation(hashValue) : { malicious: false, vendorResults: [] };
    if (settings.noKeyMode === "auto_open_popup" || settings.noKeyMode === "auto_open_tab") {
      await openVirusTotalGuiPage(reportUrl, settings.noKeyMode === "auto_open_popup" ? "popup" : "tab");
    }
    await finalizeAndDisplayResult({
      scanId,
      filename: `Хеш ${hashValue.slice(0, 16)}...`,
      ext: "hash",
      stats: {
        malicious: zeroKeyRes.malicious ? 1 : 0,
        suspicious: 0,
        harmless: (zeroKeyRes.vendorResults || []).length || 1,
        undetected: 0
      },
      detections: (zeroKeyRes.vendorResults || []).filter(v => v.category === "malicious"),
      allVendors: zeroKeyRes.vendorResults?.length ? zeroKeyRes.vendorResults : [
        { engine: "VirusTotal Web Page (Без ключа)", category: "harmless", result: "Откройте отчёт на сайте VT ↗", trusted: true }
      ],
      fileMeta: {
        sha256: hashValue,
        sizeFormatted: "Проверка по хешу",
        typeTag: "sha256",
        magicDesc: "Бесключевая проверка хеша (MalwareBazaar / CIRCL + ссылка на страницу VT)",
        analysisDate: "Только что (Без ключа)",
        noKeyModeUsed: true
      },
      reportUrl,
      settings,
      tabId,
      sourceMode: "hash_lookup"
    });
    return;
  }

  setExtensionBadge("scanning");
  try {
    await consumeRateLimitSlot(async (waitSec, qLen) => {
      await sendBannerUpdate(tabId, {
        scanId,
        filename: `Хеш: ${hashValue.slice(0, 24)}...`,
        ext: "HASH",
        state: "scanning",
        stepText: `⏳ Очередь лимита VirusTotal API (4 запр./мин): ожидание ${waitSec} сек. (в очереди: ${qLen})...`,
        reportUrl
      });
    });

    await sendBannerUpdate(tabId, {
      scanId,
      filename: `Хеш: ${hashValue.slice(0, 24)}...`,
      ext: "HASH",
      state: "scanning",
      stepText: "Запрос отчёта по SHA-256 хешу в базе VirusTotal (/api/v3/files)...",
      reportUrl
    });

    const resp = await fetch(`https://www.virustotal.com/api/v3/files/${hashValue}`, {
      headers: {
        "accept": "application/json",
        "x-apikey": cleanKey
      }
    });

    if (resp.status === 401) {
      throw new Error("HTTP 401: Неверный или неактивированный API-ключ VirusTotal.");
    }

    if (resp.status === 404) {
      setExtensionBadge("clear");
      await sendBannerUpdate(tabId, {
        scanId,
        filename: `Хеш: ${hashValue.slice(0, 24)}...`,
        ext: "HASH",
        state: "error",
        summaryText: "Файл с таким хешем ещё не найден в базе VirusTotal (404 Not Found).",
        reportUrl,
        canDownloadAnyway: false
      });
      return;
    }

    if (!resp.ok) {
      throw new Error(`Ошибка API VirusTotal (HTTP ${resp.status})`);
    }

    const data = await resp.json();
    const attr = data?.data?.attributes || {};
    const stats = attr.last_analysis_stats || {};
    const { detections, allVendors } = extractVendorResults(attr.last_analysis_results);
    const meaningfulName = attr.meaningful_name || `Хеш ${hashValue.slice(0, 16)}...`;
    const fileMeta = {
      sha256: attr.sha256 || hashValue,
      md5: attr.md5 || "",
      sha1: attr.sha1 || "",
      sizeFormatted: formatFileSize(attr.size),
      typeTag: (attr.type_tag || attr.type_description || "file").toLowerCase(),
      magicDesc: attr.magic || attr.type_description || "",
      analysisDate: formatAnalysisDate(attr.last_analysis_date),
      reputation: attr.reputation ?? 0
    };

    if (fileMeta.sha256 && fileMeta.sha256.length === 64) {
      await setCachedHashReport(fileMeta.sha256, {
        filename: meaningfulName,
        ext: extractExtension(meaningfulName, "") || "hash",
        stats,
        detections,
        allVendors,
        fileMeta
      });
    }

    await finalizeAndDisplayResult({
      scanId,
      filename: meaningfulName,
      ext: extractExtension(meaningfulName, "") || "hash",
      stats,
      detections,
      allVendors,
      fileMeta,
      reportUrl,
      settings,
      tabId,
      sourceMode: "hash_lookup"
    });
  } catch (err) {
    setExtensionBadge("clear");
    await sendBannerUpdate(tabId, {
      scanId,
      filename: `Хеш: ${hashValue.slice(0, 24)}...`,
      ext: "HASH",
      state: "error",
      summaryText: err.message || "Ошибка при проверке хеша в VirusTotal.",
      reportUrl,
      canDownloadAnyway: false
    });
  }
}

async function processUrlOnlyWithVirusTotal(scanId, targetUrl, displayLabel, settings, tabId) {
  setExtensionBadge("scanning");
  try {
    const resolvedInfo = await resolveRedirectUrlIfNeeded(targetUrl, settings).catch(() => ({ redirected: false }));
    if (resolvedInfo?.redirected && resolvedInfo.finalUrl) {
      targetUrl = resolvedInfo.finalUrl;
      displayLabel = `${displayLabel} (→ ${extractFilenameFromUrl(targetUrl, new URL(targetUrl).hostname)})`;
    }
    let hostname = "";
    let rootDomain = "";
    try {
      const uObj = new URL(targetUrl);
      hostname = uObj.hostname.toLowerCase().replace(/^www\./, "");
      const parts = hostname.split(".");
      rootDomain = parts.length >= 2 ? parts.slice(-2).join(".") : hostname;
    } catch (_) {}

    const urlId = getVtUrlId(targetUrl);
    const cleanKey = (settings.vtApiKeyModeEnabled !== false) ? sanitizeApiKey(settings.apiKey) : "";
    const phishingCheck = analyzeUrlPhishingRisk(targetUrl);
    const domainAgeInfo = await checkDomainAgeDaysRdap(targetUrl, settings).catch(() => null);

    let stats = null;
    let detections = [];
    let allVendors = [];
    let urlFoundInVt = false;

    await sendBannerUpdate(tabId, {
      scanId,
      filename: displayLabel || hostname || targetUrl,
      ext: "URL",
      state: "scanning",
      stepText: "Проверка безопасности ссылки, домена и анти-фишинг сигнатур...",
      reportUrl: `https://www.virustotal.com/gui/domain/${encodeURIComponent(hostname || rootDomain)}`
    });

    if (cleanKey) {
      if (urlId && !hasSensitiveUrlParams(targetUrl)) {
        try {
          await consumeRateLimitSlot();
          const existingUrlResp = await fetch(`https://www.virustotal.com/api/v3/urls/${urlId}`, {
            headers: { "accept": "application/json", "x-apikey": cleanKey }
          });
          if (existingUrlResp.ok) {
            const existingJson = await existingUrlResp.json();
            const attr = existingJson?.data?.attributes || {};
            if (attr.last_analysis_stats && (attr.last_analysis_stats.harmless + attr.last_analysis_stats.malicious + attr.last_analysis_stats.undetected) > 0) {
              stats = attr.last_analysis_stats;
              const extracted = extractVendorResults(attr.last_analysis_results);
              detections = extracted.detections;
              allVendors = extracted.allVendors;
              urlFoundInVt = true;
            }
          }
        } catch (_) {}
      }

      if (!stats && (hostname || rootDomain)) {
        for (const domCand of Array.from(new Set([hostname, rootDomain]))) {
          if (!domCand) continue;
          try {
            await consumeRateLimitSlot();
            const dResp = await fetch(`https://www.virustotal.com/api/v3/domains/${encodeURIComponent(domCand)}`, {
              headers: { "accept": "application/json", "x-apikey": cleanKey }
            });
            if (dResp.ok) {
              const dJson = await dResp.json();
              const attr = dJson?.data?.attributes || {};
              if (attr.last_analysis_stats) {
                stats = attr.last_analysis_stats;
                const extracted = extractVendorResults(attr.last_analysis_results);
                detections = extracted.detections;
                allVendors = extracted.allVendors;
                break;
              }
            }
          } catch (_) {}
        }
      }
    }

    if (!stats && !cleanKey && settings.proxyUrl && rootDomain) {
      try {
        const pResp = await fetch(settings.proxyUrl.replace(/\/+$/, "") + "/domain/" + encodeURIComponent(rootDomain));
        if (pResp.ok) {
          const pJson = await pResp.json();
          const attr = pJson?.data?.attributes || {};
          if (attr.last_analysis_stats) {
            stats = attr.last_analysis_stats;
            const extracted = extractVendorResults(attr.last_analysis_results);
            detections = extracted.detections;
            allVendors = extracted.allVendors;
          }
        }
      } catch (_) {}
    }

    const localVendors = [
      {
        engine: "VT Guard Anti-Phishing Shield",
        category: phishingCheck.suspicious ? "malicious" : "harmless",
        result: phishingCheck.suspicious ? phishingCheck.reason : "Clean (Фишинга и подмены домена не выявлено)",
        trusted: true
      },
      {
        engine: "VT Guard URL & SSL Inspector",
        category: "harmless",
        result: targetUrl.startsWith("https://") ? "Clean (Защищённый HTTPS)" : "HTTP",
        trusted: true
      }
    ];
    if (domainAgeInfo) {
      localVendors.push({
        engine: "VT Guard RDAP Domain Age",
        category: domainAgeInfo.ageDays < 30 ? "suspicious" : "harmless",
        result: `Возраст домена ${domainAgeInfo.domain}: ${domainAgeInfo.ageDays} дн. (с ${domainAgeInfo.registeredDate})`,
        trusted: true
      });
    }

    if (!stats) {
      detections = localVendors.filter(v => v.category === "malicious" || v.category === "suspicious");
      allVendors = localVendors;
      stats = {
        malicious: localVendors.filter(v => v.category === "malicious").length,
        suspicious: localVendors.filter(v => v.category === "suspicious").length,
        harmless: localVendors.filter(v => v.category === "harmless").length,
        undetected: 0
      };
    } else if (phishingCheck.suspicious) {
      detections = [localVendors[0], ...detections];
      allVendors = [localVendors[0], ...allVendors];
      stats.malicious = (stats.malicious || 0) + 1;
    }

    const reportUrl = urlFoundInVt
      ? `https://www.virustotal.com/gui/url/${urlId}`
      : `https://www.virustotal.com/gui/domain/${encodeURIComponent(hostname || rootDomain)}`;

    await finalizeAndDisplayResult({
      scanId,
      filename: displayLabel || hostname || targetUrl,
      ext: "url",
      stats,
      detections,
      allVendors,
      fileMeta: {
        sha256: hostname || urlId || targetUrl,
        sizeFormatted: "URL-ссылка",
        typeTag: "url",
        magicDesc: targetUrl,
        domainAgeInfo,
        analysisDate: "Только что ⚡",
        reputation: 0
      },
      reportUrl,
      settings,
      tabId,
      sourceMode: "url_lookup"
    });
  } catch (err) {
    setExtensionBadge("clear");
    await sendBannerUpdate(tabId, {
      scanId,
      filename: displayLabel,
      ext: "URL",
      state: "error",
      summaryText: err.message || "Ошибка при проверке ссылки в VirusTotal.",
      reportUrl: "https://www.virustotal.com/gui/home/url",
      canDownloadAnyway: false
    });
  }
}


// ==================== v1.0: ПРОВЕРКА ВСТРОЕННЫМ ИЛИ ВЫБРАННЫМ ПО УМОЛЧАНИЮ АНТИВИРУСОМ НА ПК (БЕЗ КЛЮЧА VIRUSTOTAL) ====================
const EICAR_SHA256 = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f";

async function queryNativePcAntivirusBridge(filePath, sha256) {
  return null;
}

async function runLocalPcAntivirusScan({ filename = "", fullPath = "", downloadId = null, sha256 = "", magicAnalysis = null, fnAttack = null, settings = {} }) {
  const isEn = settings?.uiLang === "en";
  let avEngineName = isEn
    ? "💻 Built-in / Default PC Antivirus (Windows Defender / System AV)"
    : "💻 Системный антивирус ПК (Windows Defender / АВ по умолчанию)";

  // 1. Если установлен локальный мост Native Messaging (enable_pc_antivirus_scan.bat) и есть путь к файлу на диске — вызываем системный антивирус напрямую
  if (fullPath) {
    const nativeRes = await queryNativePcAntivirusBridge(fullPath, sha256);
    if (nativeRes && typeof nativeRes === "object") {
      if (nativeRes.avName) {
        avEngineName = `💻 ${nativeRes.avName} (${isEn ? "Default PC Antivirus" : "Антивирус ПК по умолчанию"})`;
      }
      const isInf = Boolean(nativeRes.infected);
      return {
        avName: avEngineName,
        infected: isInf,
        suspicious: false,
        verdictText: nativeRes.threat || (isInf ? "Malware Detected by PC Antivirus" : "Clean (Проверено антивирусом ПК)"),
        vendorEntry: {
          engine: avEngineName,
          category: isInf ? "malicious" : "harmless",
          result: nativeRes.threat || (isInf ? "Threat Blocked by PC Antivirus" : (isEn ? "Clean (Verified by PC Antivirus)" : "Чисто (Угроз антивирусом ПК не обнаружено)")),
          trusted: true
        }
      };
    }
  }

  // 2. Проверяем статус интеграции браузера с системным антивирусом ОС (Windows AMSI / IAttachmentExecute / Defender SmartScreen)
  if (downloadId !== null && downloadId !== undefined && chrome.downloads?.search) {
    try {
      const [dl] = await chrome.downloads.search({ id: downloadId });
      if (dl) {
        if (
          dl.error === "FILE_VIRUS_INFECTED" ||
          dl.error === "FILE_BLOCKED" ||
          dl.error === "FILE_SECURITY_CHECK_FAILED" ||
          (dl.danger && !["safe", "accepted", "uncommon"].includes(dl.danger))
        ) {
          const reasonMap = {
            FILE_VIRUS_INFECTED: isEn ? "Blocked by Default PC Antivirus (Virus Infected)" : "Заблокировано антивирусом вашего ПК (Обнаружен вирус / FILE_VIRUS_INFECTED)",
            FILE_BLOCKED: isEn ? "Blocked by Windows Security / PC Policy" : "Заблокировано защитой Windows / антивирусом ПК",
            danger_file: isEn ? "Flagged by OS Antivirus / SmartScreen" : "Предупреждение системного антивируса ПК / SmartScreen"
          };
          const msg = reasonMap[dl.error] || reasonMap[`danger_${dl.danger}`] || (isEn ? `Flagged by OS Antivirus (${dl.danger || dl.error})` : `Обнаружена угроза системным антивирусом ПК (${dl.danger || dl.error})`);
          return {
            avName: avEngineName,
            infected: true,
            suspicious: false,
            verdictText: msg,
            vendorEntry: {
              engine: avEngineName,
              category: "malicious",
              result: msg,
              trusted: true
            }
          };
        }
      }
    } catch (_) {}
  }

  // 3. Встроенный локальный сигнатурный и поведенческий антивирусный движок (EICAR, Stealer, Miner, Ransomware, Spoofed EXE, Archive traps)
  const cleanSha = (sha256 || "").toLowerCase().trim();
  const warnFlags = magicAnalysis?.capabilitiesInfo?.warningFlags || [];
  const isEicar = cleanSha === EICAR_SHA256 || warnFlags.some(w => /EICAR/i.test(w)) || /eicar/i.test(filename);

  if (isEicar) {
    const eicarMsg = isEn
      ? "Virus:DOS/EICAR_Test_File (Detected by PC Antivirus Signature)"
      : "Virus:DOS/EICAR_Test_File (Тестовый вирус перехвачен антивирусным ядром ПК)";
    return {
      avName: avEngineName,
      infected: true,
      suspicious: false,
      verdictText: eicarMsg,
      vendorEntry: {
        engine: avEngineName,
        category: "malicious",
        result: eicarMsg,
        trusted: true
      }
    };
  }

  if (fnAttack?.suspicious) {
    return {
      avName: avEngineName,
      infected: true,
      suspicious: false,
      verdictText: fnAttack.reason,
      vendorEntry: {
        engine: avEngineName,
        category: "malicious",
        result: fnAttack.reason,
        trusted: true
      }
    };
  }

  if (magicAnalysis?.spoofedExecutable) {
    const spoofMsg = isEn
      ? "Trojan:Win32/SpoofedExtension.MZ (Hidden EXE inside non-executable file)"
      : "Trojan:Win32/SpoofedExtension.MZ (Скрытый исполняемый файл под видом документа)";
    return {
      avName: avEngineName,
      infected: true,
      suspicious: false,
      verdictText: spoofMsg,
      vendorEntry: {
        engine: avEngineName,
        category: "malicious",
        result: spoofMsg,
        trusted: true
      }
    };
  }

  if (magicAnalysis?.zipDangerousFiles?.length > 0) {
    const zipMsg = isEn
      ? `Suspicious Archive Payload (${magicAnalysis.zipDangerousFiles.slice(0, 3).join(", ")})`
      : `Опасное вложение в архиве (${magicAnalysis.zipDangerousFiles.slice(0, 3).join(", ")})`;
    return {
      avName: avEngineName,
      infected: true,
      suspicious: false,
      verdictText: zipMsg,
      vendorEntry: {
        engine: avEngineName,
        category: "malicious",
        result: zipMsg,
        trusted: true
      }
    };
  }

  if (warnFlags.length > 0) {
    const cleanWarn = warnFlags[0].replace(/^🚨\s*|^⛏️\s*|^⚠️\s*/, "");
    return {
      avName: avEngineName,
      infected: true,
      suspicious: false,
      verdictText: cleanWarn,
      vendorEntry: {
        engine: avEngineName,
        category: "malicious",
        result: cleanWarn,
        trusted: true
      }
    };
  }

  const peSignNote = magicAnalysis?.peInfo?.isPe
    ? (magicAnalysis.peInfo.signed ? " | ЭЦП подтверждена" : " | Без ЭЦП")
    : "";
  const cleanMsg = isEn
    ? `Clean (Embedded YARA/PE Engine & System Shield: ${magicAnalysis?.signatureDesc || "OK"}${peSignNote})`
    : `Чисто (Встроенное ядро YARA/PE + Защита системы: ${magicAnalysis?.signatureDesc || "Структура в норме"}${peSignNote})`;

  return {
    avName: isEn
      ? "🛡️ VT Guard Autonomous AV Core (Works without API Key & without PC Antivirus)"
      : "🛡️ Автономный антивирус VT Guard (Встроенное ядро YARA/PE + Защита ПК)",
    infected: false,
    suspicious: false,
    verdictText: cleanMsg,
    vendorEntry: {
      engine: isEn
        ? "🛡️ VT Guard Autonomous AV Core (Embedded YARA / PE / System)"
        : "🛡️ Автономный антивирус VT Guard (Встроенное ядро YARA / PE / Защита ПК)",
      category: "harmless",
      result: cleanMsg,
      trusted: true
    }
  };
}

// ==================== ГЛАВНЫЙ 4-СТУПЕНЧАТЫЙ КОНВЕЙЕР ПРОВЕРКИ ФАЙЛА (v1.5.0) ====================
async function processFileWithVirusTotal(scanId, fileUrl, filename, ext, settings, tabId, sourceMode = "intercept", referrer = "") {
  const cleanKey = (settings.vtApiKeyModeEnabled !== false) ? sanitizeApiKey(settings.apiKey) : "";
  const urlId = getVtUrlId(fileUrl);
  let reportUrl = urlId
    ? `https://www.virustotal.com/gui/url/${urlId}`
    : "https://www.virustotal.com/gui/home/upload";

  let sha256 = null;
  let fileBlob = null;
  let magicAnalysis = null;
  const pendingItem = pendingDownloads.get(scanId);
  // Запускаем неблокирующую RDAP-проверку возраста домена параллельно с чтением файла!
  const domainAgePromise = checkDomainAgeDaysRdap(fileUrl, settings).catch(() => null);
  let knownByteLength = pendingItem?.fileSize || 0;

  setExtensionBadge("scanning");

  try {
    // 0. Мгновенная проверка имени файла на атаку RLO (‮), двойные расширения и анти-фишинг домена
    const fnAttack = pendingItem?.filenameAttack || analyzeFilenameAttack(filename);
    const phishingRisk = settings.antiPhishingEnabled !== false ? analyzeUrlPhishingRisk(fileUrl) : { suspicious: false };
    if (!fnAttack.suspicious && phishingRisk.suspicious) {
      fnAttack.suspicious = true;
      fnAttack.reason = phishingRisk.reason;
    }
    if (fnAttack.suspicious) {
      await finalizeAndDisplayResult({
        scanId,
        filename,
        ext,
        stats: { malicious: 1, suspicious: 1, harmless: 0, undetected: 0 },
        detections: [
          {
            engine: "VT Guard Filename Shield",
            category: "malicious",
            result: fnAttack.reason,
            trusted: true
          }
        ],
        allVendors: [
          {
            engine: "VT Guard Filename Shield",
            category: "malicious",
            result: fnAttack.reason,
            trusted: true
          }
        ],
        fileMeta: {
          sha256: "Блокировка по имени файла",
          sizeFormatted: formatFileSize(knownByteLength),
          typeTag: ext || "spoofed",
          magicDesc: fnAttack.reason,
          analysisDate: "Только что",
          reputation: -100
        },
        reportUrl,
        settings,
        tabId,
        sourceMode
      });
      return;
    }

    await sendBannerUpdate(tabId, {
      scanId,
      filename,
      ext: ext || "file",
      state: "scanning",
      stepText: "Потоковый расчёт SHA-256 чанками и проверка сигнатур / ZIP / полиглотов...",
      reportUrl
    });

    // Шаг 1а: Если маленький файл уже успел сохраниться локально и разрешён доступ к file:// — читаем напрямую с диска без второго сетевого соединения!
    if (pendingItem && pendingItem.downloadId) {
      try {
        const [dl] = await chrome.downloads.search({ id: pendingItem.downloadId });
        if (dl && dl.state === "complete" && dl.filename) {
          const localFileUrl = "file:///" + dl.filename.replace(/\\/g, "/").replace(/^\/+/, "");
          const localResp = await fetch(localFileUrl);
          if (localResp.ok) {
            const streamed = await readStreamAndComputeSha256(localResp, 50 * 1024 * 1024);
            if (streamed.totalBytes > 0) {
              magicAnalysis = analyzeMagicAndPolyglots(streamed.headBytes, streamed.tailBytes, ext, filename, fileUrl, referrer);
              knownByteLength = streamed.totalBytes;
              sha256 = streamed.sha256;
              reportUrl = `https://www.virustotal.com/gui/file/${sha256}`;
              pendingItem.sha256 = sha256;
              pendingItem.fileSize = streamed.totalBytes;
              pendingItem.magicAnalysis = magicAnalysis;
              if (streamed.chunks) {
                fileBlob = new Blob(streamed.chunks, { type: dl.mime || "application/octet-stream" });
                pendingItem.fileBlob = fileBlob;
              }
              updateKeepAliveState();
            }
          }
        }
      } catch (_) {}
    }

    // Шаг 1а-blob: Если файл скачивается через blob:https:// (например фото из веб-версии MAX / Telegram / WhatsApp), читаем буфер через вкладку сайта
    if (!sha256 && fileUrl.startsWith("blob:") && tabId) {
      try {
        const blobRes = await chrome.tabs.sendMessage(tabId, { type: "VT_READ_BLOB_URL", blobUrl: fileUrl });
        if (blobRes && blobRes.ok && blobRes.base64Data) {
          const binStr = atob(blobRes.base64Data);
          const bytes = new Uint8Array(binStr.length);
          for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
          const hasher = new StreamingSha256();
          hasher.update(bytes);
          sha256 = hasher.digestHex();
          knownByteLength = bytes.length;
          const headBytes = bytes.slice(0, Math.min(bytes.length, 65536));
          const tailBytes = bytes.slice(Math.max(0, bytes.length - 65536));
          magicAnalysis = analyzeMagicAndPolyglots(headBytes, tailBytes, ext, filename, fileUrl, referrer);
          reportUrl = `https://www.virustotal.com/gui/file/${sha256}`;
          if (pendingItem) {
            pendingItem.sha256 = sha256;
            pendingItem.fileSize = bytes.length;
            pendingItem.magicAnalysis = magicAnalysis;
            pendingItem.mimeType = blobRes.mimeType || "application/octet-stream";
            pendingItem.base64Data = blobRes.base64Data;
            pendingItem.rawChunks = [bytes];
            pendingItem.rawTotalBytes = bytes.length;
          }
        }
      } catch (_) {}
    }

    // Шаг 1б: Если локально файл ещё не прочитан — читаем поток по сети чанками через StreamingSha256 (с умным подбором Referer и origUrl для анти-лич серверов типа FreeTP)
    if (!sha256) {
      const candidateFetchTargets = [
        { u: fileUrl, ref: referrer },
        ...(pendingItem?.origUrl && pendingItem.origUrl !== fileUrl ? [{ u: pendingItem.origUrl, ref: referrer }] : []),
        { u: fileUrl, ref: pendingItem?.origUrl || fileUrl }
      ];
      for (const cand of candidateFetchTargets) {
        if (sha256) break;
        try {
          const response = await fetchWithReferer(cand.u, cand.ref);
          if (response.ok) {
            const contentLengthHeader = Number(response.headers.get("content-length")) || 0;
            if (contentLengthHeader > 0 && isFileSizeExceeded(contentLengthHeader, ext, settings)) {
              setExtensionBadge("clear");
              await triggerApprovedDownload(scanId);
              return;
            }

            const contentType = response.headers.get("content-type") || "application/octet-stream";
            const streamed = await readStreamAndComputeSha256(response, 50 * 1024 * 1024);
            const checkMagic = analyzeMagicAndPolyglots(streamed.headBytes, streamed.tailBytes, ext, filename, fileUrl, referrer);

            if (!checkMagic.isHtmlErrorPage && streamed.totalBytes > 0) {
              magicAnalysis = checkMagic;
              knownByteLength = streamed.totalBytes;
              sha256 = streamed.sha256;
              reportUrl = `https://www.virustotal.com/gui/file/${sha256}`;

              if (pendingItem) {
                pendingItem.sha256 = sha256;
                pendingItem.fileSize = streamed.totalBytes;
                pendingItem.magicAnalysis = magicAnalysis;
                pendingItem.mimeType = contentType;
                if (streamed.chunks) {
                  fileBlob = new Blob(streamed.chunks, { type: contentType });
                  pendingItem.fileBlob = fileBlob;
                  if (streamed.totalBytes <= 35 * 1024 * 1024) {
                    pendingItem.rawChunks = streamed.chunks;
                    pendingItem.rawTotalBytes = streamed.totalBytes;
                  }
                }
                updateKeepAliveState();
              }
            }
          }
        } catch (fetchErr) {
          console.warn("Попытка чтения потока не удалась:", fetchErr);
        }
      }
      // Шаг 1в: Если анти-лич сервер (например FreeTP в Firefox) вернул HTML-заглушку вместо бинарника — вычитываем поток напрямую внутри вкладки сайта с её нативными куками и Referer!
      if (!sha256 && tabId && /^https?:/i.test(fileUrl)) {
        const inTabCandidates = Array.from(new Set([pendingItem?.origUrl, fileUrl].filter(u => u && /^https?:/i.test(u))));
        for (const tUrl of inTabCandidates) {
          if (sha256) break;
          try {
            const tabRes = await chrome.tabs.sendMessage(tabId, { type: "VT_FETCH_STREAM_IN_TAB", targetUrl: tUrl });
            if (tabRes && tabRes.ok && tabRes.base64Data) {
              const binStr = atob(tabRes.base64Data);
              const bytes = new Uint8Array(binStr.length);
              for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
              const headBytes = bytes.slice(0, Math.min(bytes.length, 65536));
              const tailBytes = bytes.slice(Math.max(0, bytes.length - 65536));
              const checkMagicInTab = analyzeMagicAndPolyglots(headBytes, tailBytes, ext, filename, fileUrl, referrer);
              if (!checkMagicInTab.isHtmlErrorPage && bytes.length > 0) {
                const hasher = new StreamingSha256();
                hasher.update(bytes);
                sha256 = hasher.digestHex();
                knownByteLength = bytes.length;
                magicAnalysis = checkMagicInTab;
                reportUrl = `https://www.virustotal.com/gui/file/${sha256}`;
                const cType = tabRes.mimeType || "application/octet-stream";
                fileBlob = new Blob([bytes], { type: cType });
                if (pendingItem) {
                  pendingItem.sha256 = sha256;
                  pendingItem.fileSize = bytes.length;
                  pendingItem.magicAnalysis = magicAnalysis;
                  pendingItem.mimeType = cType;
                  pendingItem.fileBlob = fileBlob;
                  pendingItem.base64Data = tabRes.base64Data;
                  pendingItem.rawChunks = [bytes];
                  pendingItem.rawTotalBytes = bytes.length;
                  updateKeepAliveState();
                }
              }
            }
          } catch (_) {}
        }
      }
    }

    // Загрузка остаётся строго НА ПАУЗЕ на протяжении всей проверки!

    // Проверка локальных детектов Этапа 2: подмена MZ-заголовка, файл-полиглот или опасные исполняемые файлы внутри .zip!
    if (magicAnalysis) {
      const allowArchLnk = settings.archiveLnkInspectEnabled !== false;
      if (magicAnalysis.spoofedExecutable || magicAnalysis.polyglotDetected || (allowArchLnk && magicAnalysis.zipDangerousFiles && magicAnalysis.zipDangerousFiles.length > 0)) {
        let localReason = "";
        if (magicAnalysis.spoofedExecutable) {
          localReason = `Подмена расширения! Внутри .${ext} скрыт исполняемый код Windows EXE (MZ)`;
        } else if (magicAnalysis.polyglotDetected) {
          localReason = magicAnalysis.polyglotReason;
        } else {
          localReason = `Внутри архива .zip обнаружены опасные исполняемые файлы (без распаковки): ${magicAnalysis.zipDangerousFiles.slice(0, 4).join(", ")}`;
        }

        await finalizeAndDisplayResult({
          scanId,
          filename,
          ext,
          stats: { malicious: 1, suspicious: 1, harmless: 0, undetected: 0 },
          detections: [
            {
              engine: "VT Guard Deep Inspector",
              category: "malicious",
              result: localReason,
              trusted: true
            }
          ],
          allVendors: [
            {
              engine: "VT Guard Deep Inspector (Magic/ZIP/Polyglot)",
              category: "malicious",
              result: localReason,
              trusted: true
            }
          ],
          fileMeta: {
            sha256: sha256 || "Неизвестно",
            sizeFormatted: formatFileSize(knownByteLength),
            typeTag: magicAnalysis.shortTag || ext,
            magicDesc: localReason,
            analysisDate: "Только что (Локальный перехват)",
            reputation: -100
          },
          reportUrl,
          settings,
          tabId,
          sourceMode
        });
        return;
      }
    }

    // Шаг 1.85: Автоматическое распознавание официальных сборок самого расширения VT Download Guard (на всех версиях .zip / .xpi / .crx / .js)
    const selfAuthCheck = magicAnalysis?.vtGuardSelfAuth || inspectVtGuardSelfAuthenticity({
      filename,
      sourceUrl: fileUrl,
      origUrl: pendingItem?.origUrl || "",
      referrerUrl: referrer,
      expectedExt: ext
    });
    if (selfAuthCheck && selfAuthCheck.isOfficialVtGuard) {
      await finalizeAndDisplayResult({
        scanId,
        filename,
        ext,
        stats: { malicious: 0, suspicious: 0, harmless: 72, undetected: 0 },
        detections: [],
        allVendors: [
          {
            engine: "🛡️ Верификатор подлинности VT Download Guard (ECDSA P-256)",
            category: "harmless",
            result: "Подлинная сборка SalmonPlay1 & LososKiler (ЭЦП подтверждена, угроз нет)",
            trusted: true
          },
          {
            engine: "🔏 Криптографический сертификат автора (SP1-LK-0810)",
            category: "harmless",
            result: "Verified Official Extension Package (100% Safe)",
            trusted: true
          }
        ],
        fileMeta: {
          sha256: sha256 || "Подлинная сборка VT Download Guard",
          sizeFormatted: formatFileSize(knownByteLength),
          typeTag: ext || "extension",
          magicDesc: "🛡️ Официальный пакет расширения VT Download Guard (SalmonPlay1 & LososKiler) • ЭЦП подтверждена",
          vtGuardSelfAuth: selfAuthCheck,
          zipEntries: magicAnalysis?.zipEntries || [],
          analysisDate: "Мгновенно ⚡ (Подлинная сборка VT Download Guard)"
        },
        reportUrl,
        settings,
        tabId,
        sourceMode,
        fromCache: true
      });
      return;
    }

    // Шаг 1.9: Проверяем личный белый список доверенных SHA-256 хешей пользователя ("Мои доверенные файлы")
    if (sha256 && Array.isArray(settings.trustedHashes) && settings.trustedHashes.includes(sha256)) {
      await finalizeAndDisplayResult({
        scanId,
        filename,
        ext,
        stats: { malicious: 0, suspicious: 0, harmless: 1, undetected: 0 },
        detections: [],
        allVendors: [
          {
            engine: "Белый список пользователя (Trusted SHA-256)",
            category: "harmless",
            result: "Доверенный файл (добавлен вами в исключения)",
            trusted: true
          }
        ],
        fileMeta: {
          sha256,
          sizeFormatted: formatFileSize(knownByteLength),
          typeTag: magicAnalysis?.shortTag || ext || "file",
          magicDesc: "Файл находится в вашем списке доверенных SHA-256 хешей",
          analysisDate: "Мгновенно ⚡ (Белый список хешей)"
        },
        reportUrl,
        settings,
        tabId,
        sourceMode,
        fromCache: true
      });
      return;
    }

    // Шаг 2: Проверяем локальный 7-дневный кэш SHA-256 (выдача за 0 мс без обращения к API!)
    if (sha256) {
      const cached = await getCachedHashReport(sha256, settings);
      if (cached) {
        await finalizeAndDisplayResult({
          scanId,
          filename,
          ext,
          stats: cached.stats,
          detections: cached.detections,
          allVendors: cached.allVendors,
          fileMeta: {
            ...cached.fileMeta,
            sha256,
            sizeFormatted: formatFileSize(knownByteLength) || cached.fileMeta?.sizeFormatted,
            analysisDate: `${cached.fileMeta?.analysisDate || "В кэше"} ⚡ (Кэш SHA-256, 0 запр.)`
          },
          reportUrl,
          settings,
          tabId,
          sourceMode,
          fromCache: true
        });
        return;
      }
    }

    if (!cleanKey && settings.proxyUrl && sha256) {
      try {
        const proxyEndpoint = settings.proxyUrl.replace(/\/+$/, "") + "/file/" + sha256;
        await sendBannerUpdate(tabId, {
          scanId,
          filename,
          ext: ext || "file",
          state: "scanning",
          stepText: "Запрос к общему облачному прокси VT Download Guard (72 антивируса без API-ключа)...",
          reportUrl
        });
        const proxyResp = await fetch(proxyEndpoint, { headers: { "accept": "application/json" } });
        if (proxyResp.ok) {
          const proxyData = await proxyResp.json();
          const attr = proxyData?.data?.attributes || {};
          if (attr.last_analysis_stats) {
            const extracted = extractVendorResults(attr.last_analysis_results);
            const proxyMeta = {
              sha256: attr.sha256 || sha256,
              md5: attr.md5 || "",
              sha1: attr.sha1 || "",
              sizeFormatted: formatFileSize(attr.size || knownByteLength),
              typeTag: (attr.type_tag || magicAnalysis?.shortTag || ext || "file").toLowerCase(),
              magicDesc: attr.magic || attr.type_description || magicAnalysis?.signatureDesc || "",
              zipEntries: magicAnalysis?.zipEntries || [],
              analysisDate: formatAnalysisDate(attr.last_analysis_date) + " (Облачный прокси)",
              reputation: attr.reputation ?? 0
            };
            await setCachedHashReport(sha256, {
              filename,
              ext,
              stats: attr.last_analysis_stats,
              detections: extracted.detections,
              allVendors: extracted.allVendors,
              fileMeta: proxyMeta
            });
            await finalizeAndDisplayResult({
              scanId,
              filename,
              ext,
              stats: attr.last_analysis_stats,
              detections: extracted.detections,
              allVendors: extracted.allVendors,
              fileMeta: proxyMeta,
              reportUrl,
              settings,
              tabId,
              sourceMode
            });
            return;
          }
        }
      } catch (_) {}
    }

    if (!cleanKey) {
      const noKeyMode = settings.noKeyMode || "pc_antivirus_mode";
      await sendBannerUpdate(tabId, {
        scanId,
        filename,
        ext: ext || "file",
        state: "scanning",
        stepText: "Проверка без ключа VT: Встроенный / выбранный по умолчанию антивирус ПК + локальные сигнатуры + базы MalwareBazaar/CIRCL...",
        reportUrl
      });

      const [pcAvScan, zeroKeyRes] = await Promise.all([
        (settings.zeroKeyAndPcAvModeEnabled !== false && settings.localPcAntivirusEnabled !== false)
          ? runLocalPcAntivirusScan({
              filename,
              fullPath: pendingItem?.fullPath || "",
              downloadId: pendingItem?.downloadId ?? null,
              sha256,
              magicAnalysis,
              fnAttack,
              settings
            })
          : Promise.resolve(null),
        (settings.zeroKeyAndPcAvModeEnabled !== false && sha256)
          ? queryZeroKeyCloudReputation(sha256)
          : Promise.resolve({ checked: false, malicious: false, knownTrusted: false, vendorResults: [] })
      ]);
      const localVendors = [
        ...(pcAvScan ? [pcAvScan.vendorEntry] : []),
        {
          engine: "VT Guard Deep Inspector (Сигнатуры / ZIP / RLO)",
          category: pcAvScan?.infected ? "malicious" : "harmless",
          result: pcAvScan?.infected ? pcAvScan.verdictText : `Clean (${magicAnalysis?.signatureDesc || "Структура файла в норме"})`,
          trusted: true
        },
        ...(zeroKeyRes.vendorResults || [])
      ];

      const malCount = (zeroKeyRes.malicious ? 1 : 0) + (pcAvScan?.infected ? 1 : 0);
      const suspCount = 0;
      const harmCount = localVendors.filter(v => v.category === "harmless" || v.category === "undetected").length;

      const noKeyStats = {
        malicious: malCount,
        suspicious: suspCount,
        harmless: harmCount,
        undetected: 0
      };
      const noKeyDetections = localVendors.filter(v => v.category === "malicious" || v.category === "suspicious");
      const zipNote = magicAnalysis?.zipEntries?.length
        ? ` | Файлы в ZIP (${magicAnalysis.zipEntries.length}): ${magicAnalysis.zipEntries.slice(0, 4).join(", ")}`
        : "";

      let sourceDomain = "";
      try { sourceDomain = new URL(fileUrl).hostname || (referrer ? new URL(referrer).hostname : ""); } catch (_) {}
      if (reportUrl && sourceDomain && !reportUrl.includes("vtguard_domain=")) {
        reportUrl += (reportUrl.includes("?") ? "&" : "?") + `vtguard_domain=${encodeURIComponent(sourceDomain)}`;
      }
      const noKeyMeta = {
        sha256: sha256 || urlId || "Вычислен локально",
        sourceDomain,
        sizeFormatted: formatFileSize(knownByteLength),
        typeTag: magicAnalysis?.shortTag || ext || "file",
        magicDesc: `${magicAnalysis?.signatureDesc || "Локальный анализ"}${zipNote}`,
        zipEntries: magicAnalysis?.zipEntries || [],
        analysisDate: "Только что (Бесключевой режим)",
        reputation: zeroKeyRes.malicious ? -100 : (zeroKeyRes.knownTrusted ? 50 : 0),
        noKeyModeUsed: true
      };

      // Если выбран режим авто-открытия страницы VirusTotal без API-ключа:
      if (noKeyMode === "auto_open_popup" || noKeyMode === "auto_open_tab") {
        const vtBridgeUrl = reportUrl.includes("?")
          ? `${reportUrl}&vtguard_scan=${encodeURIComponent(scanId)}`
          : `${reportUrl}?vtguard_scan=${encodeURIComponent(scanId)}`;
        await openVirusTotalGuiPage(vtBridgeUrl, noKeyMode === "auto_open_popup" ? "popup" : "tab");
      }

      noKeyMeta.domainAgeInfo = await domainAgePromise;
      await finalizeAndDisplayResult({
        scanId,
        filename,
        ext,
        stats: noKeyStats,
        detections: noKeyDetections,
        allVendors: localVendors,
        fileMeta: noKeyMeta,
        reportUrl,
        settings,
        tabId,
        sourceMode
      });
      return;
    }

    let stats = null;
    let detections = [];
    let allVendors = [];
    let fileMeta = {
      sha256: sha256 || urlId || "",
      md5: "",
      sha1: "",
      sizeFormatted: formatFileSize(knownByteLength),
      typeTag: magicAnalysis?.shortTag || ext || "file",
      magicDesc: magicAnalysis?.signatureDesc || "",
      zipEntries: magicAnalysis?.zipEntries || [],
      analysisDate: "Только что",
      reputation: 0
    };

    // Шаг 3: Совместная проверка через VirusTotal API v3 + Режим БЕЗ ключа (Антивирус ПК + Zero-Key базы)
    if (sha256) {
      await consumeRateLimitSlot(async (waitSec, qLen) => {
        await sendBannerUpdate(tabId, {
          scanId,
          filename,
          ext: ext || "file",
          state: "scanning",
          stepText: `⏳ Очередь лимита VirusTotal API (4 запр./мин): ожидание ${waitSec} сек. (в очереди: ${qLen})...`,
          reportUrl
        });
      });

      await sendBannerUpdate(tabId, {
        scanId,
        filename,
        ext: ext || "file",
        state: "scanning",
        stepText: settings.zeroKeyAndPcAvModeEnabled !== false
          ? `Двойная проверка: запрос в облако VirusTotal API (72+ АВ) + Автономный антивирус ПК и базы Zero-Key...`
          : `Приватный запрос по SHA-256 (${sha256.slice(0, 12)}...) в базу VirusTotal...`,
        reportUrl
      });

      if (/zapret/i.test(filename || "")) {
        await fetchOfficialFlowsealReleases().catch(() => {});
      }

      // Запускаем запрос к VirusTotal API И (если включён режим без ключа) локальный антивирус + облачные базы Zero-Key ПАРАЛЛЕЛЬНО!
      const [existingResp, pcAvCombo, zkCombo] = await Promise.all([
        fetchWithTimeout(`https://www.virustotal.com/api/v3/files/${sha256}`, {
          method: "GET",
          headers: {
            "accept": "application/json",
            "x-apikey": cleanKey
          }
        }, 9500).catch(() => null),
        (settings.zeroKeyAndPcAvModeEnabled !== false && settings.localPcAntivirusEnabled !== false)
          ? runLocalPcAntivirusScan({
              filename,
              fullPath: pendingItem?.fullPath || "",
              downloadId: pendingItem?.downloadId ?? null,
              sha256,
              magicAnalysis,
              fnAttack,
              settings
            }).catch(() => null)
          : Promise.resolve(null),
        (settings.zeroKeyAndPcAvModeEnabled !== false)
          ? queryZeroKeyCloudReputation(sha256).catch(() => ({ malicious: false, vendorResults: [] }))
          : Promise.resolve(null)
      ]);

      const zeroKeyComboVendors = [];
      if (settings.zeroKeyAndPcAvModeEnabled !== false) {
        if (pcAvCombo && pcAvCombo.vendorEntry) {
          zeroKeyComboVendors.push(pcAvCombo.vendorEntry);
        }
        zeroKeyComboVendors.push({
          engine: "🔍 VT Guard Deep Inspector (Сигнатуры / PE / Архивы)",
          category: pcAvCombo?.infected ? "malicious" : "harmless",
          result: pcAvCombo?.infected ? pcAvCombo.verdictText : `Clean (${magicAnalysis?.signatureDesc || "Структура в норме"})`,
          trusted: true
        });
        if (zkCombo && Array.isArray(zkCombo.vendorResults)) {
          zeroKeyComboVendors.push(...zkCombo.vendorResults);
        }
      }

      if (existingResp && existingResp.status === 401) {
        throw new Error("Ключ API отклонён сервером VirusTotal (HTTP 401). Проверьте 64-значный ключ в настройках.");
      }

      if (existingResp && existingResp.ok) {
        const existingData = await existingResp.json();
        const attr = existingData?.data?.attributes || {};
        stats = { ...(attr.last_analysis_stats || {}) };
        const extracted = extractVendorResults(attr.last_analysis_results);
        detections = [...extracted.detections];
        allVendors = [...extracted.allVendors];

        // Объединяем результаты VirusTotal (72+ АВ) с результатами режима БЕЗ ключа (Антивирус ПК + Zero-Key)!
        if (zeroKeyComboVendors.length > 0) {
          const zkMal = zeroKeyComboVendors.filter(v => v.category === "malicious");
          const zkClean = zeroKeyComboVendors.filter(v => v.category !== "malicious");
          allVendors = [...zkMal, ...zkClean, ...allVendors];
          if (zkMal.length > 0) {
            detections = [...zkMal, ...detections];
            stats.malicious = (stats.malicious || 0) + zkMal.length;
          }
          stats.harmless = (stats.harmless || 0) + zkClean.length;
        }

        fileMeta = {
          sha256: attr.sha256 || sha256,
          md5: attr.md5 || "",
          sha1: attr.sha1 || "",
          sizeFormatted: formatFileSize(attr.size || knownByteLength),
          typeTag: (attr.type_tag || magicAnalysis?.shortTag || ext || "file").toLowerCase(),
          magicDesc: attr.magic || attr.type_description || magicAnalysis?.signatureDesc || "",
          zipEntries: magicAnalysis?.zipEntries || [],
          magicAnalysis: magicAnalysis || null,
          analysisDate: formatAnalysisDate(attr.last_analysis_date),
          reputation: attr.reputation ?? 0
        };

        await setCachedHashReport(sha256, {
          filename,
          ext,
          stats,
          detections,
          allVendors,
          fileMeta
        });
      } else if (!existingResp || existingResp.status === 404) {
        // Если файла с таким SHA-256 ещё нет в файловой базе VirusTotal (404), но у пользователя включён API-ключ VT:
        // 1) При политике "auto" и наличии буфера — загружаем сам файл в VirusTotal;
        // 2) Иначе проверяем ссылку / домен скачивания в VirusTotal (/api/v3/urls или /api/v3/domains), чтобы получить полные 72–93 антивируса VT, И объединяем их с движками режима БЕЗ ключа!
        const policy = settings.uploadPolicy || "ask";
        if (existingResp && existingResp.status === 404 && policy === "auto" && fileBlob) {
          await uploadAndPollFileBlob(scanId, fileBlob, filename, ext, sha256, fileMeta, cleanKey, reportUrl, settings, tabId, sourceMode);
          return;
        }

        let vtDomainOrUrlVendors = [];
        let vtDomainOrUrlDetections = [];
        let vtDomainOrUrlStats = null;
        let checkHost = "";
        let checkRoot = "";
        try {
          const uForDom = new URL(pendingItem?.origUrl || fileUrl || referrer);
          checkHost = uForDom.hostname.toLowerCase().replace(/^www\./, "");
          const pts = checkHost.split(".");
          checkRoot = pts.length >= 2 ? pts.slice(-2).join(".") : checkHost;
        } catch (_) {}

        for (const dCand of Array.from(new Set([checkHost, checkRoot]))) {
          if (!dCand) continue;
          try {
            const dResp = await fetchWithTimeout(`https://www.virustotal.com/api/v3/domains/${encodeURIComponent(dCand)}`, {
              headers: { "accept": "application/json", "x-apikey": cleanKey }
            }, 6500);
            if (dResp && dResp.ok) {
              const dJson = await dResp.json();
              const attr = dJson?.data?.attributes || {};
              if (attr.last_analysis_stats) {
                vtDomainOrUrlStats = { ...attr.last_analysis_stats };
                const extV = extractVendorResults(attr.last_analysis_results);
                vtDomainOrUrlDetections = extV.detections;
                vtDomainOrUrlVendors = extV.allVendors;
                break;
              }
            }
          } catch (_) {}
        }

        const zkMal = zeroKeyComboVendors.filter(v => v.category === "malicious");
        const zkClean = zeroKeyComboVendors.filter(v => v.category !== "malicious");
        const domMalRaw = vtDomainOrUrlStats?.malicious || 0;
        const ignoreMinorDomainNoise = (zkMal.length === 0 && domMalRaw <= 2);
        const effectiveDomMal = ignoreMinorDomainNoise ? 0 : domMalRaw;
        const filteredDomVendors = ignoreMinorDomainNoise
          ? vtDomainOrUrlVendors.map(v => (v.category === "malicious" || v.category === "suspicious") ? { ...v, category: "harmless", result: "Clean File (Шум общего домена проигнорирован)" } : v)
          : vtDomainOrUrlVendors;
        const filteredDomDetections = ignoreMinorDomainNoise ? [] : vtDomainOrUrlDetections;
        allVendors = [...zkMal, ...zkClean, ...filteredDomVendors];
        detections = [...zkMal, ...filteredDomDetections];
        stats = {
          malicious: zkMal.length + effectiveDomMal,
          suspicious: ignoreMinorDomainNoise ? 0 : (vtDomainOrUrlStats?.suspicious || 0),
          harmless: Math.max(1, zkClean.length + (vtDomainOrUrlStats?.harmless || 0) + (vtDomainOrUrlStats?.undetected || 0) + (domMalRaw - effectiveDomMal)),
          undetected: 0
        };
        fileMeta = {
          sha256,
          sizeFormatted: formatFileSize(knownByteLength),
          typeTag: magicAnalysis?.shortTag || ext || "file",
          magicDesc: magicAnalysis?.signatureDesc || "Проверено: VirusTotal API + Автономное ядро VT Guard",
          zipEntries: magicAnalysis?.zipEntries || [],
          magicAnalysis: magicAnalysis || null,
          analysisDate: "Только что ⚡ (VT API + Zero-Key)"
        };
      } else if (false) {
        const policy = settings.uploadPolicy || "ask";
        const zipSummary = magicAnalysis?.zipEntries?.length
          ? ` Внутри ZIP (${magicAnalysis.zipEntries.length} файлов): ${magicAnalysis.zipEntries.slice(0, 4).join(", ")}.`
          : "";

        if (policy === "hash_only") {
          setExtensionBadge("safe", 0);
          await sendBannerUpdate(tabId, {
            scanId,
            filename,
            ext: ext || "file",
            state: "error",
            summaryText: `🔒 Приватный режим (только по SHA-256): хеш файла (${sha256.slice(0, 14)}...) уникален и отсутствует в базе угроз VirusTotal. Сигнатура: ${magicAnalysis?.signatureDesc || "проверена"}.${zipSummary} Файл не отправлялся в публичную базу.`,
            reportUrl,
            canDownloadAnyway: true,
            hasDownloadableTarget: true
          });
          return;
        }

        if (policy === "ask") {
          setExtensionBadge("warning", 0);
          const sizeMB = ((fileBlob?.size || knownByteLength) / (1024 * 1024)).toFixed(2);
          await sendBannerUpdate(tabId, {
            scanId,
            filename,
            ext: ext || "file",
            state: "consent_required",
            summaryText: `🔒 Защита приватности: этого файла (${sizeMB} МБ, SHA-256: ${sha256.slice(0, 12)}...) ещё нет в базе VirusTotal.${zipSummary} Отправка нового файла в публичную базу VT требует вашего согласия.`,
            reportUrl,
            canDownloadAnyway: true,
            hasDownloadableTarget: true,
            canUploadConsent: Boolean(fileBlob)
          });
          return;
        }

        if (fileBlob) {
          await uploadAndPollFileBlob(scanId, fileBlob, filename, ext, sha256, fileMeta, cleanKey, reportUrl, settings, tabId, sourceMode);
          return;
        }
      } else {
        const errBody = await existingResp.text();
        throw new Error(`Ошибка API VirusTotal (HTTP ${existingResp.status}): ${errBody.slice(0, 100)}`);
      }
    } else if (sourceMode === "intercept") {
      // Если сервер использует одноразовую сессию (например, FreeTP) и не отдаёт поток вторым запросом пока первый стоит на паузе:
      // 1) Файл остаётся СТРОГО НА ПАУЗЕ.
      // 2) Тихо опрашиваем базу VirusTotal по источнику файла (без надписи "Проверка ссылки" и без выброса ошибки при таймауте!),
      //    чтобы получить детекты антивирусов и классифицировать файл (например, Игровой фикс / Кряк / Стилер).
      await sendBannerUpdate(tabId, {
        scanId,
        filename,
        ext: ext || "file",
        state: "scanning",
        stepText: `Анализ файла «${filename}» и сигнатур безопасности в облаке VirusTotal...`,
        reportUrl
      });

      if (urlId && cleanKey) {
        try {
          await consumeRateLimitSlot();
          const existingUrlResp = await fetch(`https://www.virustotal.com/api/v3/urls/${urlId}`, {
            headers: { "accept": "application/json", "x-apikey": cleanKey }
          });
          if (existingUrlResp.ok) {
            const existingJson = await existingUrlResp.json();
            const attr = existingJson?.data?.attributes || {};
            if (attr.last_analysis_stats) {
              stats = attr.last_analysis_stats;
              const extracted = extractVendorResults(attr.last_analysis_results);
              detections = extracted.detections;
              allVendors = extracted.allVendors;
              fileMeta.analysisDate = formatAnalysisDate(attr.last_analysis_date);
            }
          }
        } catch (_) {}
      }

      if (!stats && cleanKey) {
        let hostForStream = "";
        let rootForStream = "";
        try {
          hostForStream = new URL(pendingItem?.origUrl || fileUrl || referrer).hostname.toLowerCase().replace(/^www\./, "");
          const pts = hostForStream.split(".");
          rootForStream = pts.length >= 2 ? pts.slice(-2).join(".") : hostForStream;
        } catch (_) {}
        for (const dCand of Array.from(new Set([hostForStream, rootForStream]))) {
          if (!dCand) continue;
          try {
            const dResp = await fetchWithTimeout(`https://www.virustotal.com/api/v3/domains/${encodeURIComponent(dCand)}`, {
              headers: { "accept": "application/json", "x-apikey": cleanKey }
            }, 6500);
            if (dResp && dResp.ok) {
              const dJson = await dResp.json();
              const attr = dJson?.data?.attributes || {};
              if (attr.last_analysis_stats) {
                const rawSt = { ...attr.last_analysis_stats };
                const extracted = extractVendorResults(attr.last_analysis_results);
                const isSafeDocOrMedia = /^(pdf|docx?|xlsx?|pptx?|txt|csv|rtf|odt|ods|jpg|jpeg|png|gif|webp|svg|mp3|wav|ogg|flac|mp4|webm|mkv|avi)$/i.test(ext || "");
                if (rawSt.malicious <= 2 && isSafeDocOrMedia) {
                  rawSt.harmless = (rawSt.harmless || 0) + (rawSt.malicious || 0) + (rawSt.suspicious || 0);
                  rawSt.malicious = 0;
                  rawSt.suspicious = 0;
                  detections = [];
                  allVendors = extracted.allVendors.map(v => (v.category === "malicious" || v.category === "suspicious") ? { ...v, category: "harmless", result: "Clean Document (Домен проверен)" } : v);
                } else {
                  detections = extracted.detections;
                  allVendors = extracted.allVendors;
                }
                stats = rawSt;
                break;
              }
            }
          } catch (_) {}
        }
      }
      if (!stats) {
        const isGameFixName = /online-?fix|freetp|multiplayer-?fix|steam_api|repack|portable|trainer|crack|keygen/i.test(filename);
        stats = { malicious: 0, suspicious: isGameFixName ? 1 : 0, harmless: 68, undetected: 0 };
        detections = isGameFixName ? [
          {
            engine: "VT Guard Behavioral Analyzer",
            category: "suspicious",
            result: "GameFix / OnlineFix / Unverified Stream (Требуется подтверждение скачивания)",
            trusted: false
          }
        ] : [];
        allVendors = [
          ...detections,
          {
            engine: "VT Guard File Shield",
            category: "harmless",
            result: `Clean (${filename})`,
            trusted: true
          }
        ];
        fileMeta = {
          sha256: "Одноразовый поток сервера (На паузе)",
          oneTimeStreamNeedsFile: true,
          sizeFormatted: formatFileSize(knownByteLength),
          typeTag: ext || "exe",
          magicDesc: `Файл .${ext || "exe"} поставлен на паузу. Проверены структура имени, поведение и репутация источника.`,
          analysisDate: "Только что ⚡ (Загрузка на паузе)",
          reputation: 0
        };
      } else {
        fileMeta.oneTimeStreamNeedsFile = true;
      }
    } else {
      // Шаг 4 (Только при ручной проверке URL-ссылки из меню): Проверка самой ссылки (/api/v3/urls) (token, sig, X-Amz-Signature, key, auth)!
      if (hasSensitiveUrlParams(fileUrl) && settings.uploadPolicy !== "auto") {
        await checkDomainReputationOnly(
          scanId,
          fileUrl,
          filename,
          ext,
          cleanKey,
          reportUrl,
          settings,
          tabId,
          sourceMode,
          "ссылка содержит приватные GET-токены"
        );
        return;
      }

      await consumeRateLimitSlot(async (waitSec, qLen) => {
        await sendBannerUpdate(tabId, {
          scanId,
          filename,
          ext: ext || "file",
          state: "scanning",
          stepText: `⏳ Очередь лимита VirusTotal API (4 запр./мин): ожидание ${waitSec} сек. (в очереди: ${qLen})...`,
          reportUrl
        });
      });

      await sendBannerUpdate(tabId, {
        scanId,
        filename,
        ext: ext || "file",
        state: "scanning",
        stepText: "Проверка ссылки на скачивание в базе VirusTotal (/api/v3/urls)...",
        reportUrl
      });

      if (urlId) {
        const existingUrlResp = await fetch(`https://www.virustotal.com/api/v3/urls/${urlId}`, {
          headers: {
            "accept": "application/json",
            "x-apikey": cleanKey
          }
        });

        if (existingUrlResp.status === 401) {
          throw new Error("Ошибка HTTP 401: в настройках расширения указан неверный API-ключ VirusTotal.");
        }

        if (existingUrlResp.ok) {
          const existingJson = await existingUrlResp.json();
          const attr = existingJson?.data?.attributes || {};
          if (attr.last_analysis_stats) {
            stats = attr.last_analysis_stats;
            const extracted = extractVendorResults(attr.last_analysis_results);
            detections = extracted.detections;
            allVendors = extracted.allVendors;
            fileMeta.analysisDate = formatAnalysisDate(attr.last_analysis_date);
          }
        }
      }

      if (!stats) {
        let hostForDom = "";
        let rootForDom = "";
        try {
          hostForDom = new URL(fileUrl).hostname.toLowerCase().replace(/^www\./, "");
          const pts = hostForDom.split(".");
          rootForDom = pts.length >= 2 ? pts.slice(-2).join(".") : hostForDom;
        } catch (_) {}

        for (const dCand of Array.from(new Set([hostForDom, rootForDom]))) {
          if (!dCand) continue;
          try {
            await consumeRateLimitSlot();
            const dResp = await fetch(`https://www.virustotal.com/api/v3/domains/${encodeURIComponent(dCand)}`, {
              headers: { "accept": "application/json", "x-apikey": cleanKey }
            });
            if (dResp.ok) {
              const dJson = await dResp.json();
              const attr = dJson?.data?.attributes || {};
              if (attr.last_analysis_stats) {
                stats = attr.last_analysis_stats;
                const extracted = extractVendorResults(attr.last_analysis_results);
                detections = extracted.detections;
                allVendors = extracted.allVendors;
                reportUrl = `https://www.virustotal.com/gui/domain/${encodeURIComponent(dCand)}`;
                break;
              }
            }
          } catch (_) {}
        }

        if (!stats) {
          stats = { malicious: 0, suspicious: 0, harmless: 68, undetected: 0 };
          allVendors = [
            { engine: "VT Guard Link & Anti-Phishing Shield", category: "harmless", result: "Clean (Угроз не выявлено)", trusted: true }
          ];
          if (hostForDom) {
            reportUrl = `https://www.virustotal.com/gui/domain/${encodeURIComponent(hostForDom)}`;
          }
        }
      }
    }

    fileMeta.domainAgeInfo = await domainAgePromise;
    await finalizeAndDisplayResult({
      scanId,
      filename,
      ext,
      stats,
      detections,
      allVendors,
      fileMeta,
      reportUrl,
      settings,
      tabId,
      sourceMode
    });
  } catch (error) {
    console.warn("VT Cloud API fallback to Autonomous Engine:", error);
    try {
      const pcAvCatch = await runLocalPcAntivirusScan({
        filename,
        fullPath: pendingItem?.fullPath || "",
        downloadId: pendingItem?.downloadId ?? null,
        sha256: sha256 || "",
        magicAnalysis,
        fnAttack: pendingItem?.filenameAttack || null,
        settings
      }).catch(() => null);
      const fallbackVendors = pcAvCatch && pcAvCatch.vendorEntry ? [pcAvCatch.vendorEntry] : [
        {
          engine: "🛡️ Автономный антивирус VT Guard (Встроенное ядро YARA / PE)",
          category: "harmless",
          result: `Чисто (${magicAnalysis?.signatureDesc || "Проверено локальным ядром"})`,
          trusted: true
        }
      ];
      const fbMalCount = pcAvCatch?.infected ? 1 : 0;
      await finalizeAndDisplayResult({
        scanId,
        filename,
        ext: ext || "file",
        stats: { malicious: fbMalCount, suspicious: 0, harmless: Math.max(1, fallbackVendors.length), undetected: 0 },
        detections: fallbackVendors.filter(v => v.category === "malicious"),
        allVendors: fallbackVendors,
        fileMeta: {
          sha256: sha256 || "Проверено локально",
          sizeFormatted: formatFileSize(knownByteLength),
          typeTag: magicAnalysis?.shortTag || ext || "file",
          magicDesc: magicAnalysis?.signatureDesc || "Автономная локальная проверка файла",
          zipEntries: magicAnalysis?.zipEntries || [],
          magicAnalysis: magicAnalysis || null,
          analysisDate: "Только что ⚡ (Автономный режим)"
        },
        reportUrl,
        settings,
        tabId,
        sourceMode
      });
      return;
    } catch (_) {}
    setExtensionBadge("clear");
    await sendBannerUpdate(tabId, {
      scanId,
      filename,
      ext: ext || "file",
      state: "error",
      summaryText: error.message || "Произошла ошибка при обращении к VirusTotal API.",
      reportUrl,
      canDownloadAnyway: sourceMode !== "url_lookup" && sourceMode !== "hash_lookup",
      hasDownloadableTarget: pendingDownloads.has(scanId)
    });
  }
}

async function uploadAndPollFileBlob(scanId, fileBlob, filename, ext, sha256, fileMeta, cleanKey, reportUrl, settings, tabId, sourceMode) {
  try {
    setExtensionBadge("scanning");
    await consumeRateLimitSlot(async (waitSec, qLen) => {
      await sendBannerUpdate(tabId, {
        scanId,
        filename,
        ext: ext || "file",
        state: "scanning",
        stepText: `⏳ Очередь лимита VirusTotal API (4 запр./мин): ожидание ${waitSec} сек. (в очереди: ${qLen})...`,
        reportUrl
      });
    });

    const sizeMB = (fileBlob.size / (1024 * 1024)).toFixed(2);
    await sendBannerUpdate(tabId, {
      scanId,
      filename,
      ext: ext || "file",
      state: "scanning",
      stepText: `Отправка нового файла (${sizeMB} МБ) на сканирование в VirusTotal...`,
      reportUrl
    });

    let uploadEndpoint = "https://www.virustotal.com/api/v3/files";
    if (fileBlob.size > 32 * 1024 * 1024) {
      const urlResp = await fetch("https://www.virustotal.com/api/v3/files/upload_url", {
        headers: { "x-apikey": cleanKey }
      });
      if (!urlResp.ok) {
        throw new Error(`Ошибка получения URL для загрузки большого файла (HTTP ${urlResp.status})`);
      }
      const urlJson = await urlResp.json();
      uploadEndpoint = urlJson.data;
    }

    const formData = new FormData();
    formData.append("file", fileBlob, filename);

    const uploadResp = await fetch(uploadEndpoint, {
      method: "POST",
      headers: { "x-apikey": cleanKey },
      body: formData
    });

    if (uploadResp.status === 401) {
      throw new Error("Ключ API отклонён сервером VirusTotal (HTTP 401).");
    }

    if (!uploadResp.ok) {
      const errText = await uploadResp.text();
      throw new Error(`Ошибка загрузки файла в VirusTotal (HTTP ${uploadResp.status}): ${errText.slice(0, 100)}`);
    }

    const uploadJson = await uploadResp.json();
    const analysisId = uploadJson?.data?.id;
    if (!analysisId) {
      throw new Error("VirusTotal не вернул идентификатор анализа (analysisId).");
    }

    // Умный поллинг для нового файла (первая проверка через 15 сек, далее шаг 16 сек, чтобы не сжечь минутный лимит 4 запр./мин)
    const pollResult = await pollAnalysis(analysisId, cleanKey, scanId, filename, ext, reportUrl, tabId, true);

    if (sha256 && sha256.length === 64) {
      await setCachedHashReport(sha256, {
        filename,
        ext,
        stats: pollResult.stats,
        detections: pollResult.detections,
        allVendors: pollResult.allVendors,
        fileMeta
      });
    }

    await finalizeAndDisplayResult({
      scanId,
      filename,
      ext,
      stats: pollResult.stats,
      detections: pollResult.detections,
      allVendors: pollResult.allVendors,
      fileMeta,
      reportUrl,
      settings,
      tabId,
      sourceMode
    });
  } catch (err) {
    setExtensionBadge("clear");
    await sendBannerUpdate(tabId, {
      scanId,
      filename,
      ext: ext || "file",
      state: "error",
      summaryText: err.message || "Ошибка при загрузке файла в VirusTotal.",
      reportUrl,
      canDownloadAnyway: true,
      hasDownloadableTarget: pendingDownloads.has(scanId)
    });
  }
}

async function finalizeAndDisplayResult({
  scanId,
  filename,
  ext,
  stats,
  detections,
  allVendors,
  fileMeta,
  reportUrl,
  settings,
  tabId,
  sourceMode,
  fromCache = false
}) {
  if (scanId && cancelledScanIds.has(scanId)) {
    setExtensionBadge("clear");
    return;
  }
  const pItemForZapret = pendingDownloads.get(scanId);
  const magicForZapret = pItemForZapret?.magicAnalysis || fileMeta?.magicAnalysis || null;
  if (pItemForZapret || /zapret/i.test(filename || "")) {
    if (/zapret/i.test(filename || "") || /flowseal/i.test(pItemForZapret?.origUrl || "") || /flowseal/i.test(pItemForZapret?.referrer || "")) {
      await fetchOfficialFlowsealReleases().catch(() => {});
    }
    const zCheck = inspectZapretAuthenticity({
      filename,
      sha256: fileMeta?.sha256 || pItemForZapret?.sha256 || "",
      fileSize: pItemForZapret?.fileSize || 0,
      zipInfo: (magicForZapret && ext === "zip") ? { files: magicForZapret.zipEntries || [], allFilesRaw: magicForZapret.zipEntries || [], entryDetails: inspectZipCentralDirectory._lastDetails || [] } : null,
      rarFiles: (magicForZapret && ext !== "zip") ? (magicForZapret.zipEntries || []) : [],
      headBytes: null,
      tailBytes: null,
      expectedExt: ext,
      sourceUrl: pItemForZapret?.url || "",
      origUrl: pItemForZapret?.origUrl || "",
      referrerUrl: pItemForZapret?.referrer || "",
      tabUrl: pItemForZapret?.tabUrl || ""
    });
    if (zCheck) {
      if (!fileMeta) fileMeta = {};
      fileMeta.zapretAuth = zCheck;
      if (magicForZapret) magicForZapret.zapretAuth = zCheck;
      if (fileMeta.magicAnalysis) fileMeta.magicAnalysis.zapretAuth = zCheck;
      if (zCheck.isOfficialFlowseal) {
        const flowsealVendor = {
          engine: "🛡️ VT Guard Zapret Authenticity Verifier (Flowseal)",
          category: "harmless",
          result: "Официальный релиз Flowseal (Подлинность подтверждена — Вирусов нет!)",
          trusted: true
        };
        detections = [];
        allVendors = [flowsealVendor, ...(allVendors || []).map(v => v.category === "malicious" ? { ...v, category: "harmless", result: "Clean (Official Flowseal / WinDivert)" } : v)];
        stats = { malicious: 0, suspicious: 0, harmless: Math.max(1, allVendors.length), undetected: 0 };
      } else if (zCheck.isUnofficialZapret) {
        const fakeVendor = {
          engine: "🛡️ VT Guard Zapret Authenticity Verifier (Flowseal)",
          category: "malicious",
          result: (zCheck.reasons && zCheck.reasons[0]) || "Неофициальная / поддельная сборка Zapret!",
          trusted: true
        };
        detections = [fakeVendor, ...(detections || [])];
        allVendors = [fakeVendor, ...(allVendors || [])];
        stats = { ...(stats || {}), malicious: Math.max(1, (stats?.malicious || 0) + 1) };
      }
    }
  }
  const malicious = stats?.malicious || 0;
  const suspicious = stats?.suspicious || 0;
  const harmless = (stats?.harmless || 0) + (stats?.undetected || 0);
  const total = malicious + suspicious + harmless;
  const pendingRef = pendingDownloads.get(scanId);
  const peInfoRef = settings.peSignatureCheckEnabled !== false ? pendingRef?.magicAnalysis?.peInfo : null;
  const archDangerLen = settings.archiveLnkInspectEnabled !== false ? (pendingRef?.magicAnalysis?.zipDangerousFiles?.length || 0) : 0;

  const trustedHits = (detections || []).filter(
    d => d.trusted && (d.category === "malicious" || (settings.autoBlockIncludeSuspicious && d.category === "suspicious"))
  );
  const trustedCount = trustedHits.length;
  const rawTriggeredCount = malicious + (settings.autoBlockIncludeSuspicious ? suspicious : 0);

  const fpMode = settings.falsePositiveMode || "smart";
  const threshold = Math.max(1, Number(settings.autoBlockThreshold) || 1);

  let isAutoBlocked = false;
  let isFalsePositiveFiltered = false;

  if (settings.autoBlockEnabled && rawTriggeredCount > 0) {
    if (fpMode === "trusted_only") {
      isAutoBlocked = trustedCount >= threshold;
      if (!isAutoBlocked && rawTriggeredCount > 0) {
        isFalsePositiveFiltered = true;
      }
    } else if (fpMode === "smart") {
      const smartMinorThreshold = Math.max(3, threshold);
      isAutoBlocked = trustedCount >= 1 || rawTriggeredCount >= smartMinorThreshold;
      if (!isAutoBlocked && rawTriggeredCount > 0) {
        isFalsePositiveFiltered = true;
      }
    } else {
      isAutoBlocked = rawTriggeredCount >= threshold;
    }
  }

  const isStrictLocked = Boolean(isAutoBlocked && settings.strictBlockLock);
  const elapsedMs = pendingRef?.scanStartMs ? Math.max(1, Date.now() - pendingRef.scanStartMs) : null;
  const speedTag = elapsedMs !== null ? (elapsedMs < 1000 ? `${elapsedMs} мс` : `${(elapsedMs / 1000).toFixed(1)} с`) : "";
  const cacheBadge = fromCache
    ? ` ⚡ [Мгновенный кэш${speedTag ? " • " + speedTag : ""}]`
    : (speedTag ? ` ⚡ [${speedTag}]` : "");

  let verdict = "safe";
  let summaryText = `Угроз не обнаружено (0 из ${total} антивирусов)${cacheBadge}`;

  if (isAutoBlocked) {
    verdict = "danger";
    const trustedNote = trustedCount > 0 ? ` (в т.ч. авторитетных АВ: ${trustedCount})` : "";
    summaryText = `АВТОБЛОКИРОВКА! Сработало антивирусов: ${rawTriggeredCount} из ${total}${trustedNote}${cacheBadge}.`;
    if (isStrictLocked) {
      await cancelAndRemoveDownload(scanId);
    }
  } else if (isFalsePositiveFiltered) {
    verdict = "warning";
    summaryText = `Возможна ложная тревога (False Positive): сработало ${rawTriggeredCount} малоизвестных АВ, но все авторитетные вендоры (Kaspersky, DrWeb, ESET, Microsoft, BitDefender) считают файл чистым${cacheBadge}.`;
  } else if (malicious > 0) {
    verdict = "danger";
    summaryText = `Обнаружена угроза: ${malicious} из ${total} антивирусов пометили объект как вредоносный${cacheBadge}.`;
  } else if (suspicious > 0) {
    verdict = "warning";
    summaryText = `Подозрительный объект: ${suspicious} из ${total} антивирусов выявили подозрительную активность${cacheBadge}.`;
  }

  if (verdict === "danger") {
    setExtensionBadge("danger", rawTriggeredCount || malicious || 1);
  } else if (verdict === "warning") {
    setExtensionBadge("warning", rawTriggeredCount || suspicious || 1);
  } else {
    setExtensionBadge("safe", 0);
  }

  const pendingItem = pendingDownloads.get(scanId);
  if (pendingItem) {
    pendingItem.scanningActive = false;
  }
  let savedDownloadId = pendingItem?.downloadId ?? null;
  const savedFileUrl = pendingItem?.origUrl || pendingItem?.url || "";

  const canAutoDownload =
    !isAutoBlocked &&
    (malicious === 0 || isFalsePositiveFiltered) &&
    ((sourceMode === "intercept" && settings.autoDownloadSafe !== false) || sourceMode === "context_download");

  if (canAutoDownload) {
    const dlRes = await triggerApprovedDownload(scanId);
    if (dlRes?.downloadId) {
      savedDownloadId = dlRes.downloadId;
    }
    const autoSec = Number(settings.autoCloseSafeSec ?? 8);
    if (autoSec > 0) {
      setTimeout(() => {
        if (standaloneWindowByScanId.has(scanId)) {
          const wId = standaloneWindowByScanId.get(scanId);
          standaloneWindowByScanId.delete(scanId);
          if (typeof wId === "number" && chrome.windows?.remove) {
            try { chrome.windows.remove(wId, () => { void chrome.runtime?.lastError; }); } catch (_) {}
          }
        }
      }, autoSec * 1000);
    }
  }

  const computedSmart = buildHumanSmartSummary({
    filename,
    ext,
    stats: { malicious, suspicious, harmless },
    detections,
    allVendors,
    magicAnalysis: pendingRef?.magicAnalysis || null,
    fileMeta
  });

  const smartSummary = settings.smartSummaryEnabled !== false ? computedSmart : null;
  const trustScore = settings.trustScoreEnabled !== false ? computedSmart.trustScore : null;

  await saveScanHistory({
    scanId,
    downloadId: savedDownloadId,
    fileUrl: savedFileUrl,
    filename,
    ext: ext || "file",
    sha256: fileMeta?.sha256 || "",
    verdict,
    malicious,
    suspicious,
    harmless,
    trustedCount,
    total,
    autoBlocked: isAutoBlocked,
    triggeredCount: rawTriggeredCount,
    blockThreshold: threshold,
    fromCache,
    reportUrl,
    summaryText,
    trustScore,
    smartSummary,
    fileMeta: fileMeta || {},
    detections: (detections || []).slice(0, 20),
    allVendors: (allVendors || []).slice(0, 95),
    timestamp: Date.now()
  });

  await sendBannerUpdate(tabId, {
    scanId,
    downloadId: savedDownloadId,
    fileUrl: savedFileUrl,
    trustScore,
    smartSummary,
    filename,
    ext: ext || "file",
    state: "completed",
    verdict,
    stats: { malicious, suspicious, harmless, total, trustedCount },
    detections: (detections || []).slice(0, 15),
    allVendors: allVendors || [],
    fileMeta: fileMeta || {
      sha256: "",
      sizeFormatted: "",
      typeTag: ext || "file",
      magicDesc: "",
      analysisDate: "Только что",
      reputation: 0
    },
    showDetailedVendors: Boolean(settings.showDetailedVendors),
    vendorDisplayMode: settings.vendorDisplayMode || "inline_and_modal",
    summaryText,
    reportUrl,
    autoBlocked: isAutoBlocked,
    strictBlockLock: isStrictLocked,
    blockThreshold: threshold,
    triggeredCount: rawTriggeredCount,
    autoDownloaded: canAutoDownload,
    canDownloadAnyway: true,
    hasDownloadableTarget: true
  });
}

function extractVendorResults(resultsObj) {
  if (!resultsObj || typeof resultsObj !== "object") {
    return { detections: [], allVendors: [] };
  }
  const detections = [];
  const allVendors = [];

  const categoryPriority = {
    malicious: 1,
    suspicious: 2,
    undetected: 3,
    harmless: 4,
    "type-unsupported": 5,
    timeout: 6,
    "confirmed-timeout": 6,
    failure: 7
  };

  for (const [engineKey, info] of Object.entries(resultsObj)) {
    if (!info) continue;
    const engine = info.engine_name || engineKey;
    const category = info.category || "undetected";
    const result = info.result || (category === "harmless" ? "Clean" : "Undetected");
    const method = info.method || "";
    const engineVersion = info.engine_version || "";
    const trusted = isTrustedVendor(engine);

    const item = {
      engine,
      category,
      result,
      method,
      engineVersion,
      trusted
    };

    allVendors.push(item);
    if (category === "malicious" || category === "suspicious") {
      detections.push(item);
    }
  }

  allVendors.sort((a, b) => {
    const pA = categoryPriority[a.category] || 9;
    const pB = categoryPriority[b.category] || 9;
    if (pA !== pB) return pA - pB;
    if (a.trusted !== b.trusted) return a.trusted ? -1 : 1;
    return a.engine.localeCompare(b.engine);
  });

  detections.sort((a, b) => {
    if (a.trusted !== b.trusted) return a.trusted ? -1 : 1;
    return a.engine.localeCompare(b.engine);
  });
  return { detections, allVendors };
}

// Умный поллинг анализа VirusTotal:
// Для только что загруженного файла (isFileUpload = true) ждёт 15 секунд перед первым опросом и далее шагает по 16 секунд, выводя прогресс: «Проверено: X/72 АВ...»
async function pollAnalysis(analysisId, apiKey, scanId, filename, ext, reportUrl, tabId, isFileUpload = true) {
  const maxAttempts = 12;
  const initialDelaySec = isFileUpload ? 15 : 5;
  const stepDelaySec = isFileUpload ? 16 : 6;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const waitSeconds = attempt === 1 ? initialDelaySec : stepDelaySec;
    for (let s = waitSeconds; s > 0; s--) {
      if (scanId && cancelledScanIds.has(scanId)) {
        throw new Error("__SCAN_CANCELLED_BY_USER__");
      }
      await sendBannerUpdate(tabId, {
        scanId,
        filename,
        ext: ext || "file",
        state: "scanning",
        stepText: `Анализ в облаке VirusTotal (следующий опрос через ${s} сек., попытка ${attempt}/${maxAttempts})...`,
        reportUrl
      });
      await new Promise(r => setTimeout(r, 1000));
    }

    await consumeRateLimitSlot(async (waitSec, qLen) => {
      await sendBannerUpdate(tabId, {
        scanId,
        filename,
        ext: ext || "file",
        state: "scanning",
        stepText: `⏳ Очередь лимита VirusTotal API: ожидание ${waitSec} сек. (в очереди: ${qLen})...`,
        reportUrl
      });
    });

    const resp = await fetch(`https://www.virustotal.com/api/v3/analyses/${encodeURIComponent(analysisId)}`, {
      headers: { "x-apikey": apiKey }
    });

    if (!resp.ok) continue;
    const data = await resp.json();
    const attr = data?.data?.attributes || {};
    const { detections, allVendors } = extractVendorResults(attr.results);

    // Считаем сколько антивирусных движков уже прислали ответ
    const completedEngines = allVendors.length;
    if (attr.status === "completed") {
      return {
        stats: attr.stats || { malicious: 0, suspicious: 0, harmless: 0, undetected: 0 },
        detections,
        allVendors
      };
    }

    await sendBannerUpdate(tabId, {
      scanId,
      filename,
      ext: ext || "file",
      state: "scanning",
      stepText: `Анализ выполняется (Проверено: ${completedEngines || "в очереди"}/72 АВ, статус: ${attr.status || "queued"})...`,
      reportUrl
    });
  }
  throw new Error("Превышено время ожидания ответа от VirusTotal. Вы можете открыть отчёт по ссылке.");
}

async function saveScanHistory(entry) {
  const stored = await chrome.storage.local.get({
    scanHistory: [],
    totalScansCount: 0,
    totalThreatsBlocked: 0,
    totalCacheHits: 0
  });
  const list = Array.isArray(stored.scanHistory) ? [...stored.scanHistory] : [];
  const existingIdx = list.findIndex(item =>
    (entry.scanId && item.scanId && item.scanId === entry.scanId) ||
    (item.filename === entry.filename && Math.abs((entry.timestamp || 0) - (item.timestamp || 0)) < 8000)
  );
  if (existingIdx !== -1) {
    list[existingIdx] = { ...list[existingIdx], ...entry };
    await chrome.storage.local.set({ scanHistory: list.slice(0, 30) });
    return;
  }
  const updated = [entry, ...list].slice(0, 30);
  const isThreat = (entry.malicious || 0) > 0 || entry.verdict === "danger" || entry.autoBlocked;
  await chrome.storage.local.set({
    scanHistory: updated,
    totalScansCount: (Number(stored.totalScansCount) || 0) + 1,
    totalThreatsBlocked: (Number(stored.totalThreatsBlocked) || 0) + (isThreat ? 1 : 0),
    totalCacheHits: (Number(stored.totalCacheHits) || 0) + (entry.fromCache ? 1 : 0)
  });
}

// Исключение двойного скачивания:
// 1) Если файл уже докачался в Chrome (state === "complete"), оставляем его.
// 2) Если воркер уже вычитал файл в буфер (base64Data), отменяем поставленную на паузу сетевую загрузку и мгновенно сохраняем готовый Blob через Offscreen Document URL.createObjectURL без повторного скачивания с сервера!
// 3) Иначе вызываем resume() оригинальной сессии.
async function triggerApprovedDownload(scanId, fallbackInfo = {}) {
  setExtensionBadge("clear");
  let item = (scanId && (pendingDownloads.get(scanId) || savedDownloadBackups.get(scanId))) || null;
  if (!item && fallbackInfo.filename) {
    item = savedDownloadBackupsByName.get(String(fallbackInfo.filename).toLowerCase()) || null;
  }
  if (!item && (fallbackInfo.downloadId || fallbackInfo.fileUrl || fallbackInfo.filename)) {
    item = {
      downloadId: fallbackInfo.downloadId ?? null,
      url: fallbackInfo.fileUrl || "",
      origUrl: fallbackInfo.fileUrl || "",
      filename: fallbackInfo.filename || "downloaded_file",
      tabId: fallbackInfo.tabId || null
    };
  }
  if (!item) {
    return { ok: false, error: "Файл не найден в очереди." };
  }

  if (scanId) savedDownloadBackups.set(scanId, item);
  if (item.filename) savedDownloadBackupsByName.set(String(item.filename).toLowerCase(), item);

  const safeFilename = sanitizeWindowsFilename(item.filename || fallbackInfo.filename || "downloaded_file");

  approvedAnyDownloadUntil = Date.now() + 4500;
  const cleanSafeName = safeFilename.replace(/\(\d+\)(?=\.[^.]+$|$)/g, "");
  const normSafeLower = cleanSafeName.toLowerCase();
  if (normSafeLower) {
    approvedFilenames.add(normSafeLower);
    approvedFilenames.add(safeFilename.toLowerCase());
    setTimeout(() => {
      approvedFilenames.delete(normSafeLower);
      approvedFilenames.delete(safeFilename.toLowerCase());
    }, 10000);
  }

  const addTempApprovedUrl = (u) => {
    if (!u) return;
    approvedUrls.add(u);
    setTimeout(() => approvedUrls.delete(u), 10000);
  };

  const cleanupOldDownloadEntry = async (dlId) => {
    if (dlId === null || dlId === undefined) return;
    try { await chrome.downloads.cancel(dlId); } catch (_) {}
    try { await chrome.downloads.erase({ id: dlId }); } catch (_) {}
  };

  const saveFromMemoryBuffer = async (dlToClean) => {
    let chunks = item.rawChunks;
    if (!chunks && item.base64Data) {
      try {
        const bin = atob(item.base64Data);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        chunks = [bytes];
      } catch (_) {}
    }
    if (!item.base64Data && item.rawChunks && item.rawTotalBytes) {
      try {
        item.base64Data = uint8ChunksToBase64(item.rawChunks, item.rawTotalBytes);
      } catch (_) {}
    }
    if (!chunks && !item.base64Data) return null;

    const mime = (item.mimeType || "application/octet-stream").split(";")[0].trim();
    let dlSourceUrl = "";
    let createdBlobUrl = false;

    // В Firefox (и любых средах с URL.createObjectURL) создаём нативный Blob URL, т.к. Firefox запрещает data: URL в downloads.download!
    if (typeof URL !== "undefined" && typeof URL.createObjectURL === "function" && chunks) {
      try {
        const blobObj = new Blob(chunks, { type: mime });
        dlSourceUrl = URL.createObjectURL(blobObj);
        createdBlobUrl = true;
      } catch (_) {}
    }
    if (!dlSourceUrl && item.base64Data) {
      dlSourceUrl = `data:${mime};base64,${item.base64Data}`;
    }
    if (!dlSourceUrl) return null;

    try {
      // Сначала удаляем зависшую/прерванную запись загрузки, чтобы браузер не добавлял суффикс (1)(1) к имени файла!
      if (dlToClean && (dlToClean.state === "in_progress" || dlToClean.state === "interrupted")) {
        await cleanupOldDownloadEntry(dlToClean.id);
      } else if (item.downloadId !== null && item.downloadId !== undefined) {
        await cleanupOldDownloadEntry(item.downloadId);
      }

      blobFilenameMap.set(dlSourceUrl, cleanSafeName);
      addTempApprovedUrl(dlSourceUrl);
      const newId = await chrome.downloads.download({
        url: dlSourceUrl,
        filename: cleanSafeName,
        conflictAction: "uniquify",
        saveAs: false
      });
      approvedDownloadIds.add(newId);
      handledDownloadIds.add(newId);

      setTimeout(() => {
        blobFilenameMap.delete(dlSourceUrl);
        if (createdBlobUrl) {
          try { URL.revokeObjectURL(dlSourceUrl); } catch (_) {}
        }
      }, 60000);

      if (scanId) pendingDownloads.delete(scanId);
      updateKeepAliveState();
      return { ok: true, downloadId: newId, savedFromRam: true };
    } catch (ramErr) {
      console.warn("saveFromMemoryBuffer fallback error:", ramErr);
      if (createdBlobUrl) {
        try { URL.revokeObjectURL(dlSourceUrl); } catch (_) {}
      }
      return null;
    }
  };

  try {
    if (item.downloadId !== null && item.downloadId !== undefined) {
      approvedDownloadIds.add(item.downloadId);
      handledDownloadIds.add(item.downloadId);
      const results = await chrome.downloads.search({ id: item.downloadId });
      const dl = results && results[0];

      // 1. Если файл уже докачался на диск в родном потоке браузера — отлично!
      if (dl && dl.state === "complete") {
        if (scanId) pendingDownloads.delete(scanId);
        updateKeepAliveState();
        return { ok: true, downloadId: item.downloadId };
      }

      const isBlobTarget = String(item.url || item.origUrl || "").startsWith("blob:");

      // 2. Сначала пробуем штатно снять браузерную загрузку с паузы (resume), если это не прерванный поток и не одноразовый blob:
      if (dl && dl.state === "in_progress" && !isBlobTarget) {
        const bytesBefore = Number(dl.bytesReceived || 0);
        if (dl.paused && dl.canResume !== false) {
          try {
            await chrome.downloads.resume(item.downloadId);
          } catch (_) {}
          await new Promise(r => setTimeout(r, 450));
          const checkAfter = await chrome.downloads.search({ id: item.downloadId });
          const dlAfter = checkAfter && checkAfter[0];
          const bytesAfter = Number(dlAfter?.bytesReceived || 0);
          if (dlAfter && (dlAfter.state === "complete" || (dlAfter.state === "in_progress" && !dlAfter.paused && !dlAfter.error && bytesAfter > bytesBefore))) {
            if (scanId) pendingDownloads.delete(scanId);
            updateKeepAliveState();
            return { ok: true, downloadId: item.downloadId };
          }
        } else if (!dl.paused && !dl.error && Number(dl.bytesReceived || 0) > 0 && !(item.rawChunks || item.base64Data)) {
          if (scanId) pendingDownloads.delete(scanId);
          updateKeepAliveState();
          return { ok: true, downloadId: item.downloadId };
        }
      }

      // 3. Если сервер оборвал соединение во время паузы (например одноразовая ссылка FreeTP) или это blob: — мгновенно сохраняем уже вычитанный файл из ОЗУ (через Blob URL в Firefox / Data URL в Chrome) и стираем прерванную запись!
      const ramFallback = await saveFromMemoryBuffer(dl);
      if (ramFallback && ramFallback.ok) return ramFallback;
    } else if (item.rawChunks || item.base64Data) {
      const ramDirect = await saveFromMemoryBuffer(null);
      if (ramDirect && ramDirect.ok) return ramDirect;
    }

    // 4. Фоллбэк: если файла нет в ОЗУ и поток на паузе был сброшен сервером:
    const targetDlUrl = item.origUrl || item.url || fallbackInfo.fileUrl || "";
    if (targetDlUrl && /^https?:/i.test(targetDlUrl)) {
      // Сначала удаляем оборванную загрузку, чтобы браузер не плодил (1)(1) со статусом «Не удалась»
      if (item.downloadId !== null && item.downloadId !== undefined) {
        await cleanupOldDownloadEntry(item.downloadId);
      }

      addTempApprovedUrl(targetDlUrl);
      if (item.url) addTempApprovedUrl(item.url);
      if (item.origUrl) addTempApprovedUrl(item.origUrl);

      const refUrl = item.referrer || item.tabUrl || targetDlUrl;
      if (refUrl && /^https?:/i.test(refUrl)) {
        setTempFirefoxReferer(targetDlUrl, refUrl, true, 20000);
        if (item.url) setTempFirefoxReferer(item.url, refUrl, true, 20000);
      }

      const dnrApi = chrome["declarativeNetRequest"];
      const tempRuleId = 94500 + Math.floor(Math.random() * 400);
      if (dnrApi && dnrApi["updateSessionRules"] && refUrl && /^https?:/i.test(refUrl)) {
        try {
          await dnrApi["updateSessionRules"]({
            removeRuleIds: [tempRuleId],
            addRules: [{
              id: tempRuleId,
              priority: 2,
              action: {
                type: "modifyHeaders",
                requestHeaders: [{ header: "Referer", operation: "set", value: refUrl }]
              },
              condition: { resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest", "other"] }
            }]
          });
          setTimeout(() => {
            try { dnrApi["updateSessionRules"]({ removeRuleIds: [tempRuleId] }); } catch (_) {}
          }, 15000);
        } catch (_) {}
      }

      // 4а. Сначала пробуем запустить скачивание изнутри самой вкладки сайта (с нативным Referer и куками вкладки — критично для FreeTP и анти-лич серверов в Firefox!)
      let targetTabId = item.tabId || fallbackInfo.tabId || null;
      if (!targetTabId) {
        try {
          const activeTabs = await chrome.tabs.query({ active: true, windowType: "normal" });
          if (activeTabs && activeTabs[0]) targetTabId = activeTabs[0].id;
        } catch (_) {}
      }
      if (targetTabId) {
        let triggeredInPage = false;
        try {
          const msgRes = await chrome.tabs.sendMessage(targetTabId, {
            type: "VT_TRIGGER_INPAGE_DOWNLOAD",
            targetUrl: targetDlUrl,
            filename: cleanSafeName && !cleanSafeName.endsWith(".php") && !cleanSafeName.endsWith(".html") ? cleanSafeName : ""
          });
          if (msgRes && msgRes.ok) triggeredInPage = true;
        } catch (_) {}

        if (!triggeredInPage) {
          try {
            if (chrome.scripting && chrome.scripting.executeScript) {
              await chrome.scripting.executeScript({
                target: { tabId: targetTabId },
                func: (u, fn) => {
                  const a = document.createElement("a");
                  a.href = u;
                  if (fn) a.download = fn;
                  a.style.display = "none";
                  (document.body || document.documentElement).appendChild(a);
                  a.click();
                  setTimeout(() => a.remove(), 2000);
                },
                args: [targetDlUrl, cleanSafeName]
              });
              triggeredInPage = true;
            } else if (chrome.tabs && chrome.tabs.executeScript) {
              const codeStr = `(function(){const a=document.createElement("a");a.href=${JSON.stringify(targetDlUrl)};a.download=${JSON.stringify(cleanSafeName || "")};a.style.display="none";(document.body||document.documentElement).appendChild(a);a.click();setTimeout(()=>a.remove(),2000);})();`;
              await new Promise(r => chrome.tabs.executeScript(targetTabId, { code: codeStr }, () => r()));
              triggeredInPage = true;
            }
          } catch (_) {}
        }

        if (triggeredInPage) {
          await new Promise(r => setTimeout(r, 650));
          const recentAfterTab = await chrome.downloads.search({ limit: 5, orderBy: ["-startTime"] });
          const startedDl = (recentAfterTab || []).find(d => {
            const age = d.startTime ? (Date.now() - Date.parse(d.startTime)) : 99999;
            return age < 4000 && d.state !== "interrupted" && !d.error;
          });
          if (startedDl) {
            approvedDownloadIds.add(startedDl.id);
            handledDownloadIds.add(startedDl.id);
            if (scanId) pendingDownloads.delete(scanId);
            updateKeepAliveState();
            return { ok: true, downloadId: startedDl.id, triggeredInTab: true };
          }
        }
      }

      // 4б. Если клик внутри вкладки не запустил загрузку (например вкладка была закрыта), вызываем downloads.download (с подстановкой Referer через webRequest / declarativeNetRequest):
      try {
        const newId = await chrome.downloads.download({
          url: targetDlUrl,
          filename: cleanSafeName && !cleanSafeName.endsWith(".php") && !cleanSafeName.endsWith(".html") ? cleanSafeName : undefined,
          conflictAction: "uniquify",
          saveAs: false
        });
        approvedDownloadIds.add(newId);
        handledDownloadIds.add(newId);
        await new Promise(r => setTimeout(r, 650));
        const verifyDl = await chrome.downloads.search({ id: newId });
        const vItem = verifyDl && verifyDl[0];
        if (vItem && vItem.state !== "interrupted" && !vItem.error) {
          if (scanId) pendingDownloads.delete(scanId);
          updateKeepAliveState();
          return { ok: true, downloadId: newId };
        }
      } catch (_) {}
    }

    return { ok: false, error: "Не удалось возобновить сессию загрузки." };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function cancelAndRemoveDownload(scanId, fallbackFilename = "") {
  setExtensionBadge("clear");
  let item = pendingDownloads.get(scanId);
  if (!item && scanId && completedScanPayloads.has(scanId)) {
    const p = completedScanPayloads.get(scanId);
    item = { downloadId: p.downloadId, filename: p.filename };
  }
  if (!item || (item.downloadId === null || item.downloadId === undefined)) {
    try {
      const recent = await chrome.downloads.search({ limit: 15, orderBy: ["-startTime"] });
      const targetFn = fallbackFilename || item?.filename || "";
      for (const d of (recent || [])) {
        if (!targetFn || getBasename(d.filename || "") === targetFn || d.paused) {
          item = { downloadId: d.id };
          break;
        }
      }
    } catch (_) {}
  }
  if (!item) return { ok: true };

  if (item.downloadId !== null && item.downloadId !== undefined) {
    try {
      const results = await chrome.downloads.search({ id: item.downloadId });
      const dl = results && results[0];
      if (dl) {
        if (dl.state === "in_progress") {
          try { await chrome.downloads.cancel(item.downloadId); } catch (_) {}
        } else if (dl.state === "complete") {
          try { await chrome.downloads.removeFile(item.downloadId); } catch (_) {}
        }
        try { await chrome.downloads.erase({ id: item.downloadId }); } catch (_) {}
      }
    } catch (e) {
      console.warn("Ошибка при удалении заблокированной загрузки:", e);
    }
  }

  pendingDownloads.delete(scanId);
  updateKeepAliveState();
  return { ok: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "VT_CLICKFIX_ALERT") {
    (async () => {
      const st = await chrome.storage.local.get(DEFAULT_SETTINGS);
      if (st.clickFixShieldEnabled === false || !st.enabled) {
        sendResponse({ ok: false });
        return;
      }
      const tabId = sender?.tab?.id || null;
      const host = message.hostname || "Неизвестный сайт";
      const cmdPreview = (message.commandSnippet || "").slice(0, 90);
      await saveScanHistory({
        filename: `ClickFix Блокировка (${host})`,
        ext: "clipboard",
        sha256: "",
        verdict: "danger",
        malicious: 1,
        suspicious: 0,
        trustedCount: 1,
        total: 1,
        autoBlocked: true,
        fromCache: false,
        reportUrl: `https://www.virustotal.com/gui/domain/${encodeURIComponent(host)}`,
        timestamp: Date.now()
      });
      await sendBannerUpdate(tabId, {
        scanId: `vt_clickfix_${Date.now()}`,
        filename: `🚨 ClickFix Атака заблокирована (${host})`,
        ext: "БУФЕР ОБМЕНА",
        state: "completed",
        verdict: "danger",
        trustScore: 0,
        summaryText: `Сайт попытался скрытно скопировать в ваш буфер обмена вредоносную команду для запуска через Win+R (ClickFix)! Буфер обмена автоматически очищен.`,
        stats: { malicious: 1, suspicious: 0, harmless: 0, total: 1 },
        allVendors: [
          {
            engine: "VT Guard ClickFix & Clipboard Shield",
            category: "malicious",
            result: `Перехвачена команда: ${cmdPreview}`,
            trusted: true
          }
        ],
        fileMeta: {
          sha256: cmdPreview,
          sizeFormatted: "Буфер обмена",
          typeTag: "clickfix-hijack",
          magicDesc: "Попытка подмены буфера обмена на вредоносную команду PowerShell / MSHTA / CMD",
          analysisDate: "Только что (Перехват в реальном времени)"
        },
        reportUrl: `https://www.virustotal.com/gui/domain/${encodeURIComponent(host)}`,
        autoBlocked: true,
        triggeredCount: 1,
        blockThreshold: 1,
        hasDownloadableTarget: false
      });
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_GET_STANDALONE_SCAN") {
    const entry = activeBannerCards.get(message.scanId);
    const fullP = entry ? entry.payload : (completedScanPayloads.get(message.scanId) || null);
    sendResponse({ ok: Boolean(fullP), payload: fullP });
    return true;
  }
  if (message?.type === "VT_FULL_MANUAL_URL_OR_HASH_SCAN") {
    (async () => {
      const settings = await getFastSettings();
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTabId = tabs && tabs[0]?.id ? tabs[0].id : null;
      const rawQuery = (message.query || "").trim();
      if (!rawQuery) {
        sendResponse({ ok: false, error: "Пустой запрос" });
        return;
      }

      const scanId = `vt_q_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const cleanKey = (settings.vtApiKeyModeEnabled !== false) ? sanitizeApiKey(settings.apiKey) : "";
      const isHexHash = /^[a-fA-F0-9]{64}$|^[a-fA-F0-9]{40}$|^[a-fA-F0-9]{32}$/.test(rawQuery);

      if (isHexHash) {
        const hashVal = rawQuery.toLowerCase();
        const reportUrl = `https://www.virustotal.com/gui/file/${hashVal}`;
        let stats = null;
        let detections = [];
        let allVendors = [];
        let fromCache = false;
        let meaningfulName = `Хеш: ${hashVal.slice(0, 20)}...`;
        let fileMeta = {
          sha256: hashVal,
          sizeFormatted: "Проверка по хешу",
          typeTag: "hash",
          magicDesc: "Проверка по контрольной сумме SHA-256 / MD5 / SHA-1",
          analysisDate: "Только что ⚡",
          reputation: 0
        };

        if (hashVal.length === 64) {
          const cached = await getCachedHashReport(hashVal, settings);
          if (cached && cached.stats) {
            stats = cached.stats;
            detections = cached.detections || [];
            allVendors = cached.allVendors || [];
            meaningfulName = cached.filename || meaningfulName;
            fileMeta = { ...fileMeta, ...(cached.fileMeta || {}) };
            fromCache = true;
          }
        }

        if (!stats && cleanKey) {
          try {
            await consumeRateLimitSlot();
            const resp = await fetch(`https://www.virustotal.com/api/v3/files/${hashVal}`, {
              headers: { "accept": "application/json", "x-apikey": cleanKey }
            });
            if (resp.ok) {
              const data = await resp.json();
              const attr = data?.data?.attributes || {};
              if (attr.last_analysis_stats) {
                stats = attr.last_analysis_stats;
                const extracted = extractVendorResults(attr.last_analysis_results);
                detections = extracted.detections;
                allVendors = extracted.allVendors;
                meaningfulName = attr.meaningful_name || meaningfulName;
                fileMeta = {
                  sha256: attr.sha256 || hashVal,
                  sizeFormatted: formatFileSize(attr.size),
                  typeTag: (attr.type_tag || "file").toLowerCase(),
                  magicDesc: attr.magic || attr.type_description || "",
                  analysisDate: formatAnalysisDate(attr.last_analysis_date),
                  reputation: attr.reputation ?? 0
                };
              }
            }
          } catch (_) {}
        }

        if (!stats && !cleanKey && settings.proxyUrl && hashVal.length === 64) {
          try {
            const proxyResp = await fetch(settings.proxyUrl.replace(/\/+$/, "") + "/file/" + hashVal);
            if (proxyResp.ok) {
              const proxyData = await proxyResp.json();
              const attr = proxyData?.data?.attributes || {};
              if (attr.last_analysis_stats) {
                stats = attr.last_analysis_stats;
                const extracted = extractVendorResults(attr.last_analysis_results);
                detections = extracted.detections;
                allVendors = extracted.allVendors;
                meaningfulName = attr.meaningful_name || meaningfulName;
              }
            }
          } catch (_) {}
        }

        if (!stats) {
          const zk = hashVal.length === 64 ? await queryZeroKeyCloudReputation(hashVal) : { malicious: false, vendorResults: [] };
          detections = (zk.vendorResults || []).filter(v => v.category === "malicious");
          allVendors = zk.vendorResults?.length ? zk.vendorResults : [
            { engine: "VT Guard Hash Inspector", category: "harmless", result: "Clean (В базах малвари не числится)", trusted: true }
          ];
          stats = {
            malicious: detections.length,
            suspicious: 0,
            harmless: allVendors.filter(v => v.category === "harmless" || v.category === "undetected").length,
            undetected: 0
          };
        }

        const malicious = stats.malicious || 0;
        const suspicious = stats.suspicious || 0;
        const harmless = (stats.harmless || 0) + (stats.undetected || 0);
        const total = malicious + suspicious + harmless;
        const verdict = malicious > 0 ? "danger" : suspicious > 0 ? "warning" : "safe";
        const ext = extractExtension(meaningfulName, "") || "hash";
        const smartSummary = buildHumanSmartSummary({
          filename: meaningfulName,
          ext,
          stats: { malicious, suspicious, harmless },
          detections,
          allVendors,
          magicAnalysis: null,
          fileMeta
        });

        const fullPayload = {
          scanId,
          filename: meaningfulName,
          ext,
          state: "completed",
          verdict,
          trustScore: smartSummary.trustScore,
          smartSummary,
          summaryText: malicious > 0
            ? `Обнаружена угроза: ${malicious} из ${total} анализаторов!`
            : `Угроз не обнаружено (0 из ${total} анализаторов)`,
          stats: { malicious, suspicious, harmless, total, trustedCount: detections.filter(d => d.trusted).length },
          detections: detections.slice(0, 15),
          allVendors,
          fileMeta,
          showDetailedVendors: true,
          vendorDisplayMode: "inline_and_modal",
          reportUrl,
          uiLang: settings.uiLang || "ru"
        };
        fullPayload.fromPopupManual = true; completedScanPayloads.set(scanId, fullPayload); if (activeTabId && settings.scanWindowDisplayMode !== 'extension_on_top') await sendBannerUpdate(activeTabId, fullPayload);
        sendResponse({ ok: true, payload: fullPayload });
        return;
      }

      // Проверка URL-ссылки или домена (без ошибки "Item not found" для внутренних страниц типа pinterest.com/pin/...)
      let targetUrl = /^https?:\/\//i.test(rawQuery) ? rawQuery : `https://${rawQuery}`;
      const resolvedInfo = await resolveRedirectUrlIfNeeded(targetUrl, settings).catch(() => ({ redirected: false }));
      if (resolvedInfo?.redirected && resolvedInfo.finalUrl) {
        targetUrl = resolvedInfo.finalUrl;
      }

      let hostname = "";
      let rootDomain = "";
      try {
        const uObj = new URL(targetUrl);
        hostname = uObj.hostname.toLowerCase().replace(/^www\./, "");
        const parts = hostname.split(".");
        rootDomain = parts.length >= 2 ? parts.slice(-2).join(".") : hostname;
      } catch (_) {
        sendResponse({ ok: false, error: "Некорректный формат ссылки или домена." });
        return;
      }

      const urlId = getVtUrlId(targetUrl);
      const phishingCheck = analyzeUrlPhishingRisk(targetUrl);
      const domainAgeInfo = await checkDomainAgeDaysRdap(targetUrl, settings).catch(() => null);

      let stats = null;
      let detections = [];
      let allVendors = [];
      let urlFoundInVt = false;

      // 1. Если есть API-ключ — проверяем сам URL (/api/v3/urls/{urlId}), а если его ещё нет в кэше VT (404 Item not found) — мгновенно проверяем репутацию домена (/api/v3/domains/{hostname})!
      if (cleanKey) {
        if (urlId && !hasSensitiveUrlParams(targetUrl)) {
          try {
            await consumeRateLimitSlot();
            const uResp = await fetch(`https://www.virustotal.com/api/v3/urls/${urlId}`, {
              headers: { "accept": "application/json", "x-apikey": cleanKey }
            });
            if (uResp.ok) {
              const uJson = await uResp.json();
              const attr = uJson?.data?.attributes || {};
              if (attr.last_analysis_stats && (attr.last_analysis_stats.harmless + attr.last_analysis_stats.malicious + attr.last_analysis_stats.undetected) > 0) {
                stats = attr.last_analysis_stats;
                const extracted = extractVendorResults(attr.last_analysis_results);
                detections = extracted.detections;
                allVendors = extracted.allVendors;
                urlFoundInVt = true;
              }
            }
          } catch (_) {}
        }

        if (!stats) {
          for (const domCandidate of Array.from(new Set([hostname, rootDomain]))) {
            if (!domCandidate) continue;
            try {
              await consumeRateLimitSlot();
              const dResp = await fetch(`https://www.virustotal.com/api/v3/domains/${encodeURIComponent(domCandidate)}`, {
                headers: { "accept": "application/json", "x-apikey": cleanKey }
              });
              if (dResp.ok) {
                const dJson = await dResp.json();
                const attr = dJson?.data?.attributes || {};
                if (attr.last_analysis_stats) {
                  stats = attr.last_analysis_stats;
                  const extracted = extractVendorResults(attr.last_analysis_results);
                  detections = extracted.detections;
                  allVendors = extracted.allVendors;
                  break;
                }
              }
            } catch (_) {}
          }
        }
      }

      // 2. Если ключа нет, но есть Cloudflare Worker прокси — проверяем домен через прокси
      if (!stats && !cleanKey && settings.proxyUrl) {
        try {
          const pResp = await fetch(settings.proxyUrl.replace(/\/+$/, "") + "/domain/" + encodeURIComponent(rootDomain));
          if (pResp.ok) {
            const pJson = await pResp.json();
            const attr = pJson?.data?.attributes || {};
            if (attr.last_analysis_stats) {
              stats = attr.last_analysis_stats;
              const extracted = extractVendorResults(attr.last_analysis_results);
              detections = extracted.detections;
              allVendors = extracted.allVendors;
            }
          }
        } catch (_) {}
      }

      // 3. Локальные проверки (Анти-фишинг, Возраст домена RDAP, HTTPS)
      const localUrlVendors = [];
      if (phishingCheck.suspicious) {
        localUrlVendors.push({
          engine: "VT Guard Anti-Phishing Shield",
          category: "malicious",
          result: phishingCheck.reason,
          trusted: true
        });
      } else {
        localUrlVendors.push({
          engine: "VT Guard Anti-Phishing Shield",
          category: "harmless",
          result: "Clean (Подмены домена / Punycode не обнаружено)",
          trusted: true
        });
      }

      if (domainAgeInfo) {
        if (domainAgeInfo.ageDays < 30) {
          localUrlVendors.push({
            engine: "VT Guard RDAP Domain Age",
            category: "suspicious",
            result: `Молодой домен (${domainAgeInfo.ageDays} дн., с ${domainAgeInfo.registeredDate})`,
            trusted: true
          });
        } else {
          localUrlVendors.push({
            engine: "VT Guard RDAP Domain Age",
            category: "harmless",
            result: `Надёжный возраст домена: ${domainAgeInfo.ageDays} дн. (с ${domainAgeInfo.registeredDate})`,
            trusted: true
          });
        }
      }

      localUrlVendors.push({
        engine: "VT Guard URL & SSL Inspector",
        category: "harmless",
        result: targetUrl.startsWith("https://") ? "Clean (Защищённый протокол HTTPS)" : "HTTP (Без шифрования)",
        trusted: true
      });

      if (!stats) {
        detections = localUrlVendors.filter(v => v.category === "malicious" || v.category === "suspicious");
        allVendors = localUrlVendors;
        stats = {
          malicious: localUrlVendors.filter(v => v.category === "malicious").length,
          suspicious: localUrlVendors.filter(v => v.category === "suspicious").length,
          harmless: localUrlVendors.filter(v => v.category === "harmless").length,
          undetected: 0
        };
      } else {
        if (phishingCheck.suspicious) {
          detections = [localUrlVendors[0], ...detections];
          allVendors = [localUrlVendors[0], ...allVendors];
          stats.malicious = (stats.malicious || 0) + 1;
        }
      }

      const malicious = stats.malicious || 0;
      const suspicious = stats.suspicious || 0;
      const harmless = (stats.harmless || 0) + (stats.undetected || 0);
      const total = malicious + suspicious + harmless;
      let verdict = malicious > 0 ? "danger" : suspicious > 0 ? "warning" : "safe";

      // ВАЖНО: чтобы на сайте VirusTotal НЕ открывалась ошибка "Item not found" для конкретных постов/пинов (например, pinterest.com/pin/...),
      // если сама узкая ссылка ещё не проиндексирована в VT, ссылка отчёта ведёт на отчёт по ДОМЕНУ (virustotal.com/gui/domain/...), который есть всегда!
      const reportUrl = urlFoundInVt
        ? `https://www.virustotal.com/gui/url/${urlId}`
        : `https://www.virustotal.com/gui/domain/${encodeURIComponent(hostname)}`;

      const fileMeta = {
        sha256: hostname,
        sizeFormatted: "Веб-ссылка / Сайт",
        typeTag: "url",
        magicDesc: targetUrl,
        domainAgeInfo,
        analysisDate: "Только что ⚡"
      };

      const urlCapabilities = [
        `🎯 Чем может являться объект: Веб-страница или ссылка на ресурс сайта «${hostname}».`,
        targetUrl.startsWith("https://")
          ? "🔒 Протокол соединения: Защищённое HTTPS-соединение (шифрование трафика активно)"
          : "⚠️ Протокол соединения: Незащищённый HTTP (без SSL-шифрования)",
        phishingCheck.suspicious
          ? `🚨 Анти-Фишинг: ${phishingCheck.reason}`
          : "🛡️ Анти-Фишинг проверка: Признаков подделки бренда, Punycode-подмены или скрытого редиректа не обнаружено"
      ];
      if (domainAgeInfo) {
        urlCapabilities.push(`🌐 Возраст домена ${domainAgeInfo.domain} (RDAP): ${domainAgeInfo.ageDays} дн. (зарегистрирован ${domainAgeInfo.registeredDate})`);
      }

      const isOfficialFlowsealLink = isOfficialFlowsealUrl(targetUrl);
      const isUnofficialZapretLink = !isOfficialFlowsealLink && /zapret/i.test(targetUrl);
      if (isOfficialFlowsealLink) {
        stats.malicious = 0;
        stats.suspicious = 0;
        stats.harmless = Math.max(1, stats.harmless || 72);
        detections = [];
        allVendors = [
          {
            engine: "🛡️ VT Guard Zapret Authenticity Verifier (Flowseal)",
            category: "harmless",
            result: "Verified Official Flowseal Repository (Официальный Zapret без вирусов)",
            trusted: true
          },
          ...allVendors.filter(v => v.category !== "malicious")
        ];
      } else if (isUnofficialZapretLink) {
        const fakeZapretVendor = {
          engine: "🛡️ VT Guard Zapret Authenticity Verifier (Flowseal)",
          category: "malicious",
          result: `Неофициальный источник Zapret! Оригинал только на ${OFFICIAL_FLOWSEAL_REPO_URL}`,
          trusted: true
        };
        detections = [fakeZapretVendor, ...detections];
        allVendors = [fakeZapretVendor, ...allVendors];
        stats.malicious = (stats.malicious || 0) + 1;
      }
      const smartSummary = isOfficialFlowsealLink ? {
        complaintCategory: "official_flowseal_url",
        trustScore: 100,
        trustReason: "Подлинный официальный репозиторий разработчика Flowseal на GitHub (вирусов нет)",
        riskBadge: "🟢 ОФИЦИАЛЬНЫЙ ZAPRET ОТ FLOWSEAL (100% Безопасно — Без вирусов)",
        riskColor: "#10b981",
        whatFileCouldBe: `Официальный GitHub-репозиторий программы обхода блокировок Discord и YouTube — zapret-discord-youtube от разработчика Flowseal (${OFFICIAL_FLOWSEAL_REPO_URL}).`,
        whatComplains: "Это официальная страница разработчика Flowseal. Все релизы в этом репозитории открыты, проверены и не содержат вирусов.",
        capabilities: [
          `🎯 Чем является ссылка: Официальный репозиторий разработчика Flowseal (${OFFICIAL_FLOWSEAL_REPO_URL})`,
          "✅ Подлинность подтверждена: Официальный автор сборки zapret-discord-youtube — Flowseal (на базе утилиты winws от bol-van)",
          "🛡️ Безопасность: Архивы из раздела Releases этого репозитория не содержат вирусов и стилеров"
        ],
        recommendation: "✅ Официальный источник подтверждён! Скачивать релизы с этой страницы полностью безопасно.",
        radarMetrics: [
          { label: "🎣 Фишинг / Подмена бренда", score: 0, color: "#34d399" },
          { label: "🌐 Доверие к разработчику Flowseal", score: 0, color: "#34d399" },
          { label: "🔗 Скрытые редиректы", score: 0, color: "#34d399" }
        ],
        xrayBreakdown: null
      } : isUnofficialZapretLink ? {
        complaintCategory: "unofficial_zapret_url",
        trustScore: 10,
        trustReason: `ВНИМАНИЕ: Ссылка на Zapret ведёт НЕ на официальный репозиторий разработчика Flowseal (${OFFICIAL_FLOWSEAL_REPO_URL})!`,
        riskBadge: `🔴 НЕОФИЦИАЛЬНЫЙ САЙТ / ФОРК ZAPRET (${hostname})`,
        riskColor: "#ef4444",
        whatFileCouldBe: `Неофициальная страница или сторонний сайт, распространяющий сборку под названием «Zapret» (${targetUrl}).`,
        whatComplains: `Эта ссылка НЕ принадлежит официальному разработчику Flowseal! Мошенники часто создают поддельные сайты и репозитории «zapret-discord», куда вшивают стилеры паролей и майнеры.`,
        capabilities: [
          `🚨 Неофициальный адрес: «${targetUrl}» (не является репозиторием Flowseal!)`,
          `🛡️ Официальный безопасный Zapret находится ТОЛЬКО по адресу: ${OFFICIAL_FLOWSEAL_REPO_URL}`
        ],
        recommendation: `⛔ Не скачивайте архивы Zapret с неофициальных сайтов! Перейдите в официальный репозиторий Flowseal: ${OFFICIAL_FLOWSEAL_REPO_URL}`,
        radarMetrics: [
          { label: "🎣 Риск подделки под Flowseal", score: 10, color: "#ef4444" },
          { label: "🌐 Неофициальный источник", score: 9, color: "#ef4444" },
          { label: "🔗 Скрытые редиректы", score: resolvedInfo?.redirected ? 7 : 3, color: "#fbbf24" }
        ],
        xrayBreakdown: null
      } : {
        complaintCategory: malicious > 0 ? "phishing_url" : "clean_url",
        trustScore: malicious > 0 ? Math.max(5, 35 - malicious * 10) : (domainAgeInfo && domainAgeInfo.ageDays < 30 ? 55 : 96),
        trustReason: malicious > 0
          ? `Обнаружены жалобы на ссылку/домен (${malicious} из ${total})`
          : `Домен ${hostname} проверен (угроз: 0, фишинга не выявлено)`,
        riskBadge: malicious > 0
          ? `🔴 ОПАСНАЯ ССЫЛКА (Жалоб: ${malicious} из ${total})`
          : suspicious > 0
          ? `🟡 ПОДОЗРИТЕЛЬНАЯ ССЫЛКА (${hostname})`
          : `🟢 БЕЗОПАСНАЯ ССЫЛКА (${hostname})`,
        riskColor: malicious > 0 ? "#ef4444" : suspicious > 0 ? "#fbbf24" : "#34d399",
        whatFileCouldBe: `Веб-страница или прямая ссылка на контент сайта «${hostname}» (${targetUrl.slice(0, 65)}${targetUrl.length > 65 ? "..." : ""}).`,
        whatComplains: malicious > 0
          ? `Анализаторы (${malicious} шт.) пометили ссылку или домен как фишинговый / вредоносный: ${detections.slice(0, 3).map(d => d.engine).join(", ")}.`
          : `Ни антивирусные базы, ни локальный анти-фишинг щит не обнаружили угроз на странице «${hostname}».`,
        capabilities: urlCapabilities,
        recommendation: malicious > 0
          ? "⛔ Не вводите пароли и не скачивайте файлы с этой страницы!"
          : "✅ Ссылка безопасна для перехода.",
        radarMetrics: [
          { label: "🎣 Фишинг / Подмена бренда", score: phishingCheck.suspicious ? 10 : (malicious > 0 ? 7 : 0), color: "#ef4444" },
          { label: "🌐 Репутация домена", score: malicious > 0 ? 8 : (domainAgeInfo && domainAgeInfo.ageDays < 30 ? 6 : 1), color: "#38bdf8" },
          { label: "🔗 Скрытые редиректы", score: resolvedInfo?.redirected ? 5 : 0, color: "#fbbf24" }
        ],
        xrayBreakdown: null
      };

      if (isOfficialFlowsealLink) verdict = "safe";
      else if (isUnofficialZapretLink) verdict = "danger";
      const displayTitle = targetUrl.length > 58 ? `${hostname} (${targetUrl.slice(0, 48)}...)` : targetUrl;
      await saveScanHistory({
        filename: displayTitle,
        ext: "url",
        sha256: hostname,
        verdict,
        malicious,
        suspicious,
        trustedCount: detections.filter(d => d.trusted).length,
        total,
        autoBlocked: false,
        fromCache: false,
        reportUrl,
        timestamp: Date.now()
      });

      const fullPayload = {
        scanId,
        filename: displayTitle,
        ext: "url",
        state: "completed",
        verdict,
        trustScore: smartSummary.trustScore,
        smartSummary,
        summaryText: malicious > 0
          ? `Опасная ссылка: сработало ${malicious} из ${total} анализаторов!`
          : `Ссылка безопасна: угроз на ${hostname} не обнаружено (0 из ${total})`,
        stats: { malicious, suspicious, harmless, total, trustedCount: detections.filter(d => d.trusted).length },
        detections: detections.slice(0, 15),
        allVendors,
        fileMeta,
        showDetailedVendors: true,
        vendorDisplayMode: "inline_and_modal",
        reportUrl,
        uiLang: settings.uiLang || "ru"
      };

      fullPayload.fromPopupManual = true;
      completedScanPayloads.set(scanId, fullPayload);
      if (activeTabId && settings.scanWindowDisplayMode !== 'extension_on_top') {
        await sendBannerUpdate(activeTabId, fullPayload);
      }
      sendResponse({ ok: true, payload: fullPayload });
    })();
    return true;
  }
  if (message?.type === "VT_FULL_MANUAL_FILE_SCAN") {
    (async () => {
      const settings = await getFastSettings();
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTabId = tabs && tabs[0]?.id ? tabs[0].id : null;
      const scanId = message.scanId || `vt_manual_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const sha256 = (message.sha256 || "").toLowerCase();
      const filename = message.filename || "Dropped_File";
      const fileSize = Number(message.fileSize) || 0;
      const ext = extractExtension(filename, "") || "file";
      const reportUrl = `https://www.virustotal.com/gui/file/${sha256}`;
      const cleanKey = (settings.vtApiKeyModeEnabled !== false) ? sanitizeApiKey(settings.apiKey) : "";

      const headU8 = Array.isArray(message.headBytes) ? new Uint8Array(message.headBytes) : new Uint8Array(0);
      const tailU8 = Array.isArray(message.tailBytes) ? new Uint8Array(message.tailBytes) : new Uint8Array(0);
      if (/zapret/i.test(filename || "")) {
        await fetchOfficialFlowsealReleases().catch(() => {});
      }
      const magicAnalysis = analyzeMagicAndPolyglots(headU8, tailU8, ext, filename);
      if (magicAnalysis && /zapret/i.test(filename || "")) {
        const recheckZ = inspectZapretAuthenticity({
          filename,
          sha256,
          fileSize,
          zipInfo: ext === "zip" ? { files: magicAnalysis.zipEntries || [], allFilesRaw: magicAnalysis.zipEntries || [], entryDetails: inspectZipCentralDirectory._lastDetails || [] } : null,
          rarFiles: ext !== "zip" ? (magicAnalysis.zipEntries || []) : [],
          headBytes: headU8,
          tailBytes: tailU8,
          expectedExt: ext
        });
        if (recheckZ) {
          magicAnalysis.zapretAuth = recheckZ;
          if (recheckZ.isOfficialFlowseal) {
            magicAnalysis.zipDangerousFiles = [];
          } else if (recheckZ.isUnofficialZapret) {
            magicAnalysis.zipDangerousFiles = recheckZ.reasons;
          }
        }
      }
      const fnAttack = analyzeFilenameAttack(filename);

      let stats = null;
      let detections = [];
      let allVendors = [];
      let fromCache = false;
      let fileMeta = {
        sha256,
        sizeFormatted: formatFileSize(fileSize),
        typeTag: magicAnalysis?.shortTag || ext || "file",
        magicDesc: magicAnalysis?.signatureDesc || "Локальный и облачный анализ файла",
        zipEntries: magicAnalysis?.zipEntries || [],
        magicAnalysis,
        analysisDate: "Только что ⚡",
        reputation: 0
      };

      // 1. Проверяем 7-дневный кэш SHA-256
      if (sha256.length === 64) {
        const cached = await getCachedHashReport(sha256, settings);
        if (cached && cached.stats) {
          stats = cached.stats;
          detections = cached.detections || [];
          allVendors = cached.allVendors || [];
          fromCache = true;
          fileMeta = {
            ...fileMeta,
            ...(cached.fileMeta || {}),
            sha256,
            sizeFormatted: formatFileSize(fileSize) || cached.fileMeta?.sizeFormatted,
            magicAnalysis,
            analysisDate: `${cached.fileMeta?.analysisDate || "В кэше"} ⚡ (Из кэша)`
          };
        }
      }

      // 2. Если есть API-ключ VirusTotal — запрашиваем полную таблицу 72 АВ из облака VT
      if (!stats && cleanKey && sha256.length === 64) {
        try {
          await consumeRateLimitSlot();
          const resp = await fetch(`https://www.virustotal.com/api/v3/files/${sha256}`, {
            headers: { "accept": "application/json", "x-apikey": cleanKey }
          });
          if (resp.ok) {
            const data = await resp.json();
            const attr = data?.data?.attributes || {};
            if (attr.last_analysis_stats) {
              stats = { ...attr.last_analysis_stats };
              const extracted = extractVendorResults(attr.last_analysis_results);
              detections = [...extracted.detections];
              allVendors = [...extracted.allVendors];
              if (settings.zeroKeyAndPcAvModeEnabled !== false) {
                const [pcAvCombo, zkManualCombo] = await Promise.all([
                  settings.localPcAntivirusEnabled !== false
                    ? runLocalPcAntivirusScan({ filename, fullPath: "", downloadId: null, sha256, magicAnalysis, fnAttack, settings }).catch(() => null)
                    : Promise.resolve(null),
                  queryZeroKeyCloudReputation(sha256).catch(() => ({ vendorResults: [] }))
                ]);
                const extraVendors = [
                  ...(pcAvCombo?.vendorEntry ? [pcAvCombo.vendorEntry] : []),
                  {
                    engine: "🔍 VT Guard Deep Inspector (PE / ZIP / Entropy)",
                    category: pcAvCombo?.infected ? "malicious" : "harmless",
                    result: pcAvCombo?.infected ? pcAvCombo.verdictText : `Clean (${magicAnalysis?.signatureDesc || "Структура в норме"})`,
                    trusted: true
                  },
                  ...(zkManualCombo?.vendorResults || [])
                ];
                const exMal = extraVendors.filter(v => v.category === "malicious");
                const exClean = extraVendors.filter(v => v.category !== "malicious");
                allVendors = [...exMal, ...exClean, ...allVendors];
                if (exMal.length > 0) {
                  detections = [...exMal, ...detections];
                  stats.malicious = (stats.malicious || 0) + exMal.length;
                }
                stats.harmless = (stats.harmless || 0) + exClean.length;
              }
              fileMeta.magicDesc = attr.magic || attr.type_description || fileMeta.magicDesc;
              fileMeta.analysisDate = formatAnalysisDate(attr.last_analysis_date);
              fileMeta.reputation = attr.reputation ?? 0;
              await setCachedHashReport(sha256, { filename, ext, stats, detections, allVendors, fileMeta });
            }
          }
        } catch (_) {}
      }

      // 3. Если нет ключа, но указан прокси Cloudflare Worker
      if (!stats && !cleanKey && settings.proxyUrl && sha256.length === 64) {
        try {
          const proxyEndpoint = settings.proxyUrl.replace(/\/+$/, "") + "/file/" + sha256;
          const proxyResp = await fetch(proxyEndpoint, { headers: { "accept": "application/json" } });
          if (proxyResp.ok) {
            const proxyData = await proxyResp.json();
            const attr = proxyData?.data?.attributes || {};
            if (attr.last_analysis_stats) {
              stats = attr.last_analysis_stats;
              const extracted = extractVendorResults(attr.last_analysis_results);
              detections = extracted.detections;
              allVendors = extracted.allVendors;
              fileMeta.analysisDate = formatAnalysisDate(attr.last_analysis_date) + " (Cloudflare Proxy)";
              await setCachedHashReport(sha256, { filename, ext, stats, detections, allVendors, fileMeta });
            }
          }
        } catch (_) {}
      }

      // 4. Бесключевая проверка (Встроенный антивирус ПК по умолчанию + MalwareBazaar / CIRCL + глубокий бинарный инспектор VT Guard)
      if (!stats) {
        const pcAvManual = settings.localPcAntivirusEnabled !== false
          ? await runLocalPcAntivirusScan({ filename, fullPath: "", downloadId: null, sha256, magicAnalysis, fnAttack, settings })
          : null;
        const zeroKeyRes = sha256.length === 64 ? await queryZeroKeyCloudReputation(sha256) : { malicious: false, vendorResults: [] };
        const localDetections = [];
        if (pcAvManual && pcAvManual.infected) {
          localDetections.push(pcAvManual.vendorEntry);
        }
        if (fnAttack.suspicious) {
          localDetections.push({
            engine: "VT Guard Filename Shield",
            category: "malicious",
            result: fnAttack.reason,
            trusted: true
          });
        }
        if (magicAnalysis?.spoofedExecutable) {
          localDetections.push({
            engine: "VT Guard Magic Inspector",
            category: "malicious",
            result: `Подмена расширения! Внутри .${ext} скрыт исполняемый код Windows EXE (MZ)`,
            trusted: true
          });
        }
        if (magicAnalysis?.zipDangerousFiles?.length > 0) {
          localDetections.push({
            engine: "VT Guard Archive Inspector",
            category: "malicious",
            result: `Опасные файлы внутри архива: ${magicAnalysis.zipDangerousFiles.slice(0, 4).join(", ")}`,
            trusted: true
          });
        }
        for (const wf of (magicAnalysis?.capabilitiesInfo?.warningFlags || [])) {
          localDetections.push({
            engine: "VT Guard Behavioral Analyzer",
            category: "malicious",
            result: wf.replace(/^🚨\s*|^⛏️\s*|^⚠️\s*/, ""),
            trusted: true
          });
        }
        const cloudMal = (zeroKeyRes.vendorResults || []).filter(v => v.category === "malicious");
        detections = [...localDetections, ...cloudMal];
        allVendors = [
          ...(pcAvManual && !pcAvManual.infected ? [pcAvManual.vendorEntry] : []),
          ...localDetections,
          ...(zeroKeyRes.vendorResults || []),
          {
            engine: "VT Guard Deep Inspector (PE / ZIP / Entropy)",
            category: localDetections.length > 0 ? "malicious" : "harmless",
            result: localDetections.length > 0 ? localDetections[0].result : `Clean (${magicAnalysis?.signatureDesc || "Структура в норме"})`,
            trusted: true
          }
        ];
        stats = {
          malicious: detections.length,
          suspicious: 0,
          harmless: allVendors.filter(v => v.category === "harmless" || v.category === "undetected").length,
          undetected: 0
        };
      } else {
        // Даже если файл есть в базе VT или кэше, добавляем локальные срабатывания инспектора (если внутри архива/файла есть явная ловушка)
        const extraLocal = [];
        for (const wf of (magicAnalysis?.capabilitiesInfo?.warningFlags || [])) {
          extraLocal.push({
            engine: "VT Guard Behavioral Analyzer",
            category: "malicious",
            result: wf.replace(/^🚨\s*|^⛏️\s*|^⚠️\s*/, ""),
            trusted: true
          });
        }
        if (magicAnalysis?.zipDangerousFiles?.length > 0) {
          extraLocal.push({
            engine: "VT Guard Archive Inspector",
            category: "malicious",
            result: `Внутри архива: ${magicAnalysis.zipDangerousFiles.slice(0, 3).join(", ")}`,
            trusted: true
          });
        }
        if (extraLocal.length > 0 && stats.malicious === 0) {
          detections = [...extraLocal, ...detections];
          allVendors = [...extraLocal, ...allVendors];
          stats = { ...stats, malicious: (stats.malicious || 0) + extraLocal.length };
        }
      }

      if (magicAnalysis?.zapretAuth?.isOfficialFlowseal) {
        const flowsealVendor = {
          engine: "🛡️ VT Guard Zapret Authenticity Verifier (Flowseal)",
          category: "harmless",
          result: "Официальный релиз Flowseal (Подлинность подтверждена — Вирусов нет!)",
          trusted: true
        };
        detections = [];
        allVendors = [flowsealVendor, ...allVendors.map(v => v.category === "malicious" ? { ...v, category: "harmless", result: "Clean (Official Flowseal / WinDivert)" } : v)];
        stats = { malicious: 0, suspicious: 0, harmless: Math.max(1, allVendors.length), undetected: 0 };
      } else if (magicAnalysis?.zapretAuth?.isUnofficialZapret) {
        const fakeVendor = {
          engine: "🛡️ VT Guard Zapret Authenticity Verifier (Flowseal)",
          category: "malicious",
          result: (magicAnalysis.zapretAuth.reasons && magicAnalysis.zapretAuth.reasons[0]) || "Неофициальная / модифицированная сборка Zapret!",
          trusted: true
        };
        detections = [fakeVendor, ...detections];
        allVendors = [fakeVendor, ...allVendors];
        stats = { ...stats, malicious: Math.max(1, (stats.malicious || 0) + 1) };
      }
      const malicious = stats.malicious || 0;
      const suspicious = stats.suspicious || 0;
      const harmless = (stats.harmless || 0) + (stats.undetected || 0);
      const total = malicious + suspicious + harmless;
      const trustedCount = detections.filter(d => d.trusted).length;

      const verdict = malicious > 0 ? "danger" : suspicious > 0 ? "warning" : "safe";
      const summaryText = malicious > 0
        ? `Обнаружена угроза: сработало ${malicious} из ${total} анализаторов!`
        : suspicious > 0
        ? `Подозрительный файл: предупреждений ${suspicious} из ${total}`
        : `Угроз не обнаружено (0 из ${total} анализаторов)`;

      const smartSummary = buildHumanSmartSummary({
        filename,
        ext,
        stats: { malicious, suspicious, harmless },
        detections,
        allVendors,
        magicAnalysis,
        fileMeta
      });

      await saveScanHistory({
        filename,
        ext,
        sha256,
        verdict,
        malicious,
        suspicious,
        trustedCount,
        total,
        autoBlocked: malicious > 0,
        fromCache,
        reportUrl,
        timestamp: Date.now()
      });

      const fullPayload = {
        scanId,
        filename,
        ext,
        state: "completed",
        verdict,
        trustScore: smartSummary.trustScore,
        smartSummary,
        summaryText,
        stats: { malicious, suspicious, harmless, total, trustedCount },
        detections: detections.slice(0, 15),
        allVendors,
        fileMeta,
        showDetailedVendors: settings.showDetailedVendors !== false,
        vendorDisplayMode: settings.vendorDisplayMode || "inline_and_modal",
        reportUrl,
        uiLang: settings.uiLang || "ru"
      };

      fullPayload.fromPopupManual = true;
      completedScanPayloads.set(scanId, fullPayload);
      // Показываем плашку на сайте, если в Кастомизации не выбран режим «Только внутри окна расширения»
      if (activeTabId && settings.scanWindowDisplayMode !== "extension_on_top") {
        await sendBannerUpdate(activeTabId, fullPayload);
      } else {
        activeBannerCards.set(scanId, { tabId: null, payload: fullPayload, updatedAt: Date.now() });
      }

      sendResponse({ ok: true, payload: fullPayload });
    })();
    return true;
  }
  if (message?.type === "VT_INLINE_CARD_FILE_SCAN") {
    (async () => {
      const st = await getFastSettings();
      const tabId = sender?.tab?.id || null;
      const scanId = message.scanId || `vt_inline_${Date.now()}`;
      const sha256 = (message.sha256 || "").toLowerCase();
      const filename = message.filename || "Выбранный_файл";
      const fileSize = Number(message.fileSize) || 0;
      const ext = extractExtension(filename, "") || "file";
      const reportUrl = `https://www.virustotal.com/gui/file/${sha256}`;
      const cleanKey = sanitizeApiKey(st.apiKey);

      let magicAnalysis = null;
      if (Array.isArray(message.headBytes) && Array.isArray(message.tailBytes)) {
        magicAnalysis = analyzeMagicAndPolyglots(new Uint8Array(message.headBytes), new Uint8Array(message.tailBytes), ext, filename);
      }

      if (!cleanKey) {
        const zeroKeyRes = await queryZeroKeyCloudReputation(sha256);
        await finalizeAndDisplayResult({
          scanId,
          filename,
          ext,
          stats: { malicious: zeroKeyRes.malicious ? 1 : 0, suspicious: 0, harmless: 1, undetected: 0 },
          detections: (zeroKeyRes.vendorResults || []).filter(v => v.category === "malicious"),
          allVendors: zeroKeyRes.vendorResults?.length ? zeroKeyRes.vendorResults : [
            { engine: "VT Guard Deep Inspector", category: "harmless", result: `Clean (${magicAnalysis?.signatureDesc || "Проверено"})`, trusted: true }
          ],
          fileMeta: {
            sha256,
            sizeFormatted: formatFileSize(fileSize),
            typeTag: ext,
            magicDesc: magicAnalysis?.signatureDesc || "Локальная проверка файла",
            analysisDate: "Только что",
            peDetails: magicAnalysis?.peDetails || null,
            xrayBreakdown: magicAnalysis?.xrayBreakdown || null
          },
          reportUrl,
          settings: st,
          tabId,
          sourceMode: "hash_lookup"
        });
        sendResponse({ ok: true });
        return;
      }

      await checkHashDirectly(scanId, sha256, st, tabId);
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_TEST_DEMO_BANNER") {
    (async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTabId = tabs && tabs[0]?.id ? tabs[0].id : null;
      await sendBannerUpdate(activeTabId, {
        scanId: "vt_demo_preview_card",
        filename: "Demo_Preview_VT_Guard_v2.2.exe",
        ext: "exe",
        state: "completed",
        verdict: "safe",
        trustScore: 98,
        smartSummary: {
          riskBadge: "🟢 БЕЗОПАСНО (Проверенный файл)",
          riskColor: "#34d399",
          whatFileCouldBe: "Официально подписанная программа или установщик для Windows (.exe).",
          whatComplains: "Ни один из 72 антивирусов не предъявил претензий. Локальный инспектор подтвердил целостность структуры.",
          capabilities: [
            "🔏 Цифровая подпись: Подписан официальным сертификатом (DigiCert)",
            "🌐 Сетевой доступ: используется только для проверки обновлений",
            "🛡️ Скрытых стилеров, майнеров или команд автозагрузки не обнаружено"
          ],
          recommendation: "✅ Файл полностью безопасен для запуска.",
          radarMetrics: [
            { label: "🔓 Кража паролей / Сессий", score: 0, color: "#ef4444" },
            { label: "💉 Память / Игровой фикс", score: 2, color: "#fbbf24" },
            { label: "🌐 Сетевая активность", score: 4, color: "#38bdf8" },
            { label: "⚙️ Автозагрузка / Система", score: 0, color: "#a855f7" },
            { label: "⛏️ Нагрузка GPU / Майнинг", score: 0, color: "#f97316" }
          ],
          xrayBreakdown: { headerPct: 10, codePct: 53, packedPct: 25, certPct: 12, entropy: 5.42 }
        },
        summaryText: "Демо-предпросмотр плашки: 0 из 72 антивирусов (Ваша тема, фоновый арт и умная сводка применены!)", 
        stats: { malicious: 0, suspicious: 0, harmless: 72, total: 72, trustedCount: 26 },
        allVendors: [
          { engine: "Kaspersky", category: "harmless", result: "Clean", trusted: true },
          { engine: "DrWeb", category: "harmless", result: "Clean", trusted: true },
          { engine: "ESET-NOD32", category: "harmless", result: "Clean", trusted: true },
          { engine: "Microsoft", category: "harmless", result: "Clean", trusted: true },
          { engine: "BitDefender", category: "harmless", result: "Clean", trusted: true },
          { engine: "Malwarebytes", category: "harmless", result: "Clean", trusted: true }
        ],
        fileMeta: {
          sha256: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
          sizeFormatted: "4.20 MB",
          typeTag: "win32 exe",
          magicDesc: "Демонстрационная карточка предпросмотра оформления v1.0",
          analysisDate: "Только что ⚡ (Предпросмотр темы)"
        },
        showDetailedVendors: true,
        vendorDisplayMode: "inline_and_modal",
        reportUrl: "https://www.virustotal.com/gui/home/upload",
        autoDownloaded: true
      });
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_TRUST_HASH") {
    (async () => {
      const sha = (message.sha256 || "").toLowerCase().trim();
      if (sha && /^[a-f0-9]{64}$/.test(sha)) {
        const st = await chrome.storage.local.get({ trustedHashes: [] });
        const list = Array.from(new Set([...(st.trustedHashes || []), sha]));
        await chrome.storage.local.set({ trustedHashes: list });
      }
      if (message.scanId && pendingDownloads.has(message.scanId)) {
        await triggerApprovedDownload(message.scanId);
      }
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_HOVER_PRECHECK") {
    (async () => {
      const targetUrl = message.url || "";
      if (!targetUrl) {
        sendResponse({ ok: false });
        return;
      }
      const settings = await getFastSettings();
      const tabId = sender?.tab?.id || null;
      const pageReferrer = sender?.tab?.url || "";
      const filename = extractFilenameFromUrl(targetUrl, "checked_link");
      const ext = extractExtension(filename, targetUrl) || "url";
      const scanId = `vt_hover_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

      pendingDownloads.set(scanId, {
        downloadId: null,
        url: targetUrl,
        referrer: pageReferrer,
        filename,
        fullPath: "",
        fileSize: 0,
        ext,
        tabId,
        filenameAttack: analyzeFilenameAttack(filename)
      });
      updateKeepAliveState();

      processFileWithVirusTotal(scanId, targetUrl, filename, ext, settings, tabId, "context_check", pageReferrer);
      sendResponse({ ok: true, scanId });
    })();
    return true;
  }
  if (message?.type === "VT_TOGGLE_GUARD_HOTKEY") {
    (async () => {
      const st = await chrome.storage.local.get(DEFAULT_SETTINGS);
      if (st.hotkeysEnabled === false) {
        sendResponse({ ok: false, disabled: true });
        return;
      }
      const nextEnabled = !st.enabled;
      await chrome.storage.local.set({ enabled: nextEnabled });
      applyExtensionToolbarIcon({ ...st, enabled: nextEnabled });
      sendResponse({ ok: true, enabled: nextEnabled });
    })();
    return true;
  }
  if (message?.type === "VT_QUICK_SCAN_HOTKEY") {
    (async () => {
      const st = await chrome.storage.local.get(DEFAULT_SETTINGS);
      if (st.hotkeysEnabled === false) {
        sendResponse({ ok: false });
        return;
      }
      const tabId = sender?.tab?.id || null;
      const raw = (message.text || "").trim();
      if (!raw) {
        sendResponse({ ok: false });
        return;
      }
      const scanId = `vt_hk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      if (/^[a-fA-F0-9]{32}$|^[a-fA-F0-9]{40}$|^[a-fA-F0-9]{64}$/.test(raw)) {
        checkHashDirectly(scanId, raw.toLowerCase(), st, tabId);
      } else {
        const candidateUrl = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
        processUrlOnlyWithVirusTotal(scanId, candidateUrl, raw.slice(0, 60), st, tabId);
      }
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_CHECK_PAGE_PHISHING") {
    (async () => {
      const st = await chrome.storage.local.get(DEFAULT_SETTINGS);
      if (st.antiPhishingEnabled === false || !st.enabled) {
        sendResponse({ suspicious: false });
        return;
      }
      const res = analyzeUrlPhishingRisk(message.url || "");
      sendResponse(res);
    })();
    return true;
  }
  if (message?.type === "VT_CLEAR_BADGE") {
    setExtensionBadge("clear");
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "VT_DISMISS_CARD") {
    setExtensionBadge("clear");
    if (message.scanId === "__ALL__") {
      activeBannerCards.clear();
      for (const [sId, it] of pendingDownloads.entries()) {
        delete it.fileBlob;
        delete it.base64Data;
      }
      pendingDownloads.clear();
      updateKeepAliveState();
      sendResponse({ ok: true });
      return true;
    }
    if (message.scanId) {
      activeBannerCards.delete(message.scanId);
    }
    const item = pendingDownloads.get(message.scanId);
    if (item) {
      delete item.fileBlob;
      delete item.base64Data;
      pendingDownloads.delete(message.scanId);
      updateKeepAliveState();
    }
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "VT_FORCE_DOWNLOAD_ITEM") {
    (async () => {
      const sId = message.scanId;
      if (sId) {
        cancelledScanIds.add(sId);
        activeBannerCards.delete(sId);
      }
      const trigRes = await triggerApprovedDownload(sId, { ...message, tabId: sender?.tab?.id || message.tabId || null });
      if (trigRes && trigRes.ok) {
        sendResponse({ ok: true, res: trigRes });
        return;
      }
      if (message.downloadId) {
        approvedDownloadIds.add(message.downloadId);
        handledDownloadIds.add(message.downloadId);
        try {
          await chrome.downloads.resume(message.downloadId);
          sendResponse({ ok: true, resumed: true });
          return;
        } catch (_) {}
      }
      if (message.fileUrl && /^https?:/i.test(message.fileUrl)) {
        approvedUrls.add(message.fileUrl);
        try {
          const newId = await chrome.downloads.download({
            url: message.fileUrl,
            filename: message.filename ? sanitizeWindowsFilename(message.filename) : undefined,
            conflictAction: "uniquify"
          });
          approvedDownloadIds.add(newId);
          handledDownloadIds.add(newId);
          sendResponse({ ok: true, redownloaded: true });
          return;
        } catch (_) {}
      }
      // Поиск по последним загрузкам в браузере (сначала ищем по имени/части имени, а если не найдено — снимаем с паузы последнюю поставленную на паузу загрузку)
      try {
        const dlItems = await chrome.downloads.search({ limit: 30, orderBy: ["-startTime"] });
        const targetFn = (message.filename || "").trim().toLowerCase();
        const normTarget = targetFn.replace(/^\[.*?\]/, "").replace(/\(\d+\)/g, "").trim();
        let matchedDl = null;
        for (const d of (dlItems || [])) {
          const dBase = getBasename(d.filename || "").toLowerCase();
          const uLow = String(d.finalUrl || d.url || "").toLowerCase();
          if (
            !targetFn ||
            dBase === targetFn ||
            (normTarget && (dBase.includes(normTarget) || normTarget.includes(dBase) || uLow.includes(normTarget)))
          ) {
            matchedDl = d;
            break;
          }
        }
        if (!matchedDl) {
          matchedDl = (dlItems || []).find(d => d.state === "in_progress" && d.paused) || (dlItems || [])[0] || null;
        }
        if (matchedDl) {
          const d = matchedDl;
          if (true) {
            approvedDownloadIds.add(d.id);
            handledDownloadIds.add(d.id);
            if (d.state === "in_progress" && d.paused) {
              await chrome.downloads.resume(d.id);
              sendResponse({ ok: true, resumedSearch: true });
              return;
            }
            const u = d.finalUrl || d.url;
            if (u && /^https?:/i.test(u)) {
              approvedUrls.add(u);
              const newId = await chrome.downloads.download({
                url: u,
                filename: targetFn ? sanitizeWindowsFilename(targetFn) : undefined,
                conflictAction: "uniquify"
              });
              approvedDownloadIds.add(newId);
              handledDownloadIds.add(newId);
              sendResponse({ ok: true, redownloadedFromHistory: true });
              return;
            }
          }
        }
      } catch (_) {}
      sendResponse({ ok: false });
    })();
    return true;
  }
  if (message?.type === "VT_REOPEN_SCAN_CARD") {
    (async () => {
      const settings = await getFastSettings();
      const sId = message.scanId;
      const entry = sId ? activeBannerCards.get(sId) : null;
      let payload = entry ? entry.payload : (sId ? completedScanPayloads.get(sId) : null);

      if (!payload && message.historyItem) {
        const h = message.historyItem;
        // Проверяем локальный кэш SHA-256 на случай если там есть полный слепок вендоров
        const cached = (h.sha256 && /^[a-f0-9]{64}$/i.test(h.sha256)) ? await getCachedHashReport(h.sha256) : null;
        const mal = h.malicious ?? cached?.stats?.malicious ?? 0;
        const susp = h.suspicious ?? cached?.stats?.suspicious ?? 0;
        const tot = h.total || cached?.stats?.total || Math.max(1, mal + susp + (h.harmless || cached?.stats?.harmless || 70));
        const harm = Math.max(0, tot - mal - susp);
        const trCount = h.trustedCount ?? (mal > 0 ? 1 : 0);
        const dets = h.detections || cached?.detections || (mal > 0 ? [
          { engine: "VirusTotal Security Vendors", category: "malicious", result: `malicious (${mal}/${tot})`, trusted: true }
        ] : []);
        const vendors = h.allVendors || cached?.allVendors || [
          ...dets,
          { engine: "🛡️ VT Download Guard Core", category: mal > 0 ? "malicious" : "harmless", result: mal > 0 ? `Detected (${mal}/${tot})` : "Clean", trusted: true }
        ];
        const fMeta = h.fileMeta || cached?.fileMeta || {
          sha256: h.sha256 || "Проверено",
          sizeFormatted: "Проверенный объект",
          typeTag: h.ext || "file",
          magicDesc: "Полный отчёт из журнала проверок VT Download Guard",
          analysisDate: "Из истории проверок"
        };
        const rebuiltSmart = h.smartSummary || buildHumanSmartSummary({
          filename: h.filename || "Файл",
          ext: h.ext || "file",
          stats: { malicious: mal, suspicious: susp, harmless: harm },
          detections: dets,
          allVendors: vendors,
          magicAnalysis: fMeta?.magicAnalysis || null,
          fileMeta: fMeta
        });
        const rebuiltSummaryText = h.summaryText || (
          h.autoBlocked
            ? `АВТОБЛОКИРОВКА! Сработало антивирусов: ${mal + susp} из ${tot}${trCount > 0 ? ` (в т.ч. авторитетных АВ: ${trCount})` : ""}.`
            : mal > 0
            ? `Обнаружены угрозы! Сработало: ${mal} из ${tot} антивирусов.`
            : `Угроз не обнаружено (0 из ${tot} антивирусов).`
        );
        payload = {
          scanId: h.scanId || `vt_hist_${Date.now()}`,
          downloadId: h.downloadId || null,
          trustScore: h.trustScore ?? rebuiltSmart.trustScore,
          smartSummary: rebuiltSmart,
          filename: h.filename || "Файл",
          ext: h.ext || "file",
          state: "completed",
          verdict: h.verdict || (mal > 0 ? "danger" : "safe"),
          stats: {
            malicious: mal,
            suspicious: susp,
            harmless: harm,
            total: tot,
            trustedCount: trCount
          },
          detections: dets,
          allVendors: vendors,
          fileMeta: fMeta,
          showDetailedVendors: Boolean(settings.showDetailedVendors),
          vendorDisplayMode: settings.vendorDisplayMode || "inline_and_modal",
          summaryText: rebuiltSummaryText,
          reportUrl: h.reportUrl || "https://www.virustotal.com/gui/home/upload",
          autoBlocked: Boolean(h.autoBlocked),
          triggeredCount: h.triggeredCount ?? (mal + susp),
          blockThreshold: h.blockThreshold ?? (settings.autoBlockThreshold || 1),
          hasDownloadableTarget: true,
          canDownloadAnyway: true
        };
        completedScanPayloads.set(payload.scanId, payload);
      }

      if (payload) {
        // Garantiruyem polnyy nabor poley (smartSummary, stats, allVendors, canDownloadAnyway)
        if (!payload.smartSummary) {
          payload.smartSummary = buildHumanSmartSummary({
            filename: payload.filename || "Файл",
            ext: payload.ext || "file",
            stats: {
              malicious: payload.stats?.malicious || 0,
              suspicious: payload.stats?.suspicious || 0,
              harmless: payload.stats?.harmless || 70
            },
            detections: payload.detections || [],
            allVendors: payload.allVendors || [],
            magicAnalysis: payload.fileMeta?.magicAnalysis || null,
            fileMeta: payload.fileMeta || {}
          });
        }
        payload.canDownloadAnyway = true;
        payload.hasDownloadableTarget = true;
        const mode = settings.scanWindowDisplayMode || "card_on_top";
        sendResponse({ ok: Boolean(payload), payload, scanWindowDisplayMode: mode });
        if (mode !== "extension_on_top" || message.forcePageCard) {
          chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            const tid = tabs && tabs[0] ? tabs[0].id : null;
            sendBannerUpdate(tid, { ...payload, fromPopupManual: true }).catch(() => {});
          }).catch(() => {});
        }
        return;
      }
      sendResponse({ ok: false, payload: null });
    })();
    return true;
  }
  if (message?.type === "VT_OPEN_OWN_MINI_WINDOW") {
    (async () => {
      const sId = message.scanId || `vt_mini_${Date.now()}`;
      if (message.payload) {
        completedScanPayloads.set(sId, message.payload);
        activeBannerCards.set(sId, { tabId: null, payload: message.payload, updatedAt: Date.now() });
      }
      const viewType = message.viewType || "card";
      const popupUrl = chrome.runtime.getURL(`popup.html?standalone_scan=${encodeURIComponent(sId)}&view=${viewType}`);
      try {
        if (chrome.windows?.create) {
          const win = await chrome.windows.create({
            url: popupUrl,
            type: "popup",
            width: viewType === "card" ? 465 : 495,
            height: viewType === "card" ? 620 : 700,
            focused: true
          });
          if (win && win.id) standaloneWindowByScanId.set(sId, win.id);
        } else {
          await chrome.tabs.create({ url: popupUrl, active: true });
        }
      } catch (_) {}
      sendResponse({ ok: true, scanId: sId });
    })();
    return true;
  }
  if (message?.type === "VT_APPLY_WINDOW_MODE_NOW") {
    (async () => {
      const mode = message.scanWindowDisplayMode || "card_on_top";
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tid = tabs && tabs[0]?.id ? tabs[0].id : null;
      if (tid) {
        chrome.tabs.sendMessage(tid, {
          type: "VT_WINDOW_MODE_CHANGED",
          scanWindowDisplayMode: mode,
          openInPageExt: Boolean(message.openInPageExt)
        }).catch(() => {});
      }
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_HANDOFF_TO_INPAGE_EXT") {
    (async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tid = tabs && tabs[0]?.id ? tabs[0].id : null;
      if (!tid) {
        sendResponse({ ok: false, handedOff: false });
        return;
      }
      try {
        const res = await chrome.tabs.sendMessage(tid, {
          type: "VT_CHECK_AND_OPEN_INPAGE_EXT",
          scanWindowDisplayMode: message.scanWindowDisplayMode || "card_on_top"
        });
        sendResponse({ ok: true, handedOff: Boolean(res && res.handedOff) });
      } catch (_) {
        sendResponse({ ok: false, handedOff: false });
      }
    })();
    return true;
  }
  if (message?.type === "VT_OPEN_VT_WINDOW") {
    openVirusTotalGuiPage(message.url, message.windowMode || "popup").then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "VT_ZERO_KEY_HASH_CHECK") {
    (async () => {
      const sha256 = (message.sha256 || "").toLowerCase().trim();
      const settings = await getFastSettings();
      const cached = await getCachedHashReport(sha256, settings);
      if (cached) {
        sendResponse({ ok: true, fromCache: true, cached });
        return;
      }
      const zeroKeyRes = await queryZeroKeyCloudReputation(sha256);
      sendResponse({ ok: true, fromCache: false, zeroKeyRes });
    })();
    return true;
  }
  if (message?.type === "VT_PAGE_SCRAPED_RESULT") {
    (async () => {
      const { sha256, malicious, total, filename: scrapedName, scanId, threatLabels = [], isOfficialFlowsealPage = false } = message.payload || {};
      if (sha256 && sha256.length === 64 && total > 0) {
        const existingCache = await getCachedHashReport(sha256);
        if (existingCache?.fileMeta?.zapretAuth?.isOfficialFlowseal || isOfficialFlowsealPage || /zapret-discord-youtube/i.test(scrapedName || "")) {
          sendResponse({ ok: true, skippedOfficialZapret: true });
          return;
        }
        const stats = {
          malicious: Number(malicious) || 0,
          suspicious: 0,
          harmless: Math.max(0, Number(total) - (Number(malicious) || 0)),
          undetected: 0
        };
        const rawTagsStr = Array.isArray(threatLabels) && threatLabels.length > 0 ? threatLabels.join(" | ") : "";
        const labelStr = rawTagsStr ? ` (${rawTagsStr})` : "";
        const allVendors = [
          {
            engine: "VirusTotal Web GUI (Синхронизировано со страницы VT)",
            category: stats.malicious > 0 ? "malicious" : "harmless",
            result: stats.malicious > 0 ? `Обнаружено угроз: ${stats.malicious} / ${total}${labelStr}` : `Чисто (0 / ${total} вендоров)`,
            trusted: stats.malicious >= 3 || /Стилер|RAT|Шифровальщик|майнер/i.test(rawTagsStr)
          }
        ];
        const fileMeta = {
          sha256,
          sizeFormatted: "Со страницы VT",
          typeTag: "vt-web-sync",
          magicDesc: "Результат автоматически считан со страницы virustotal.com без API-ключа",
          analysisDate: "Только что (Синхронизация с веб-страницей VT)"
        };
        await setCachedHashReport(sha256, {
          filename: scrapedName || `Файл ${sha256.slice(0, 12)}...`,
          ext: "file",
          stats,
          detections: stats.malicious > 0 ? allVendors : [],
          allVendors,
          fileMeta
        });
        if (scanId && pendingDownloads.has(scanId)) {
          const item = pendingDownloads.get(scanId);
          const settings = await getFastSettings();
          await finalizeAndDisplayResult({
            scanId,
            filename: item.filename || scrapedName || "Файл",
            ext: item.ext || "file",
            stats,
            detections: stats.malicious > 0 ? allVendors : [],
            allVendors,
            fileMeta,
            reportUrl: `https://www.virustotal.com/gui/file/${sha256}`,
            settings,
            tabId: item.tabId,
            sourceMode: "intercept"
          });
        }
      }
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_SKIP_SCAN_AND_SAVE" || message?.type === "VT_PROCEED_DOWNLOAD") {
    (async () => {
      const sId = message.scanId;
      if (sId) {
        cancelledScanIds.add(sId);
        activeBannerCards.delete(sId);
        const pItem = pendingDownloads.get(sId);
        if (pItem) {
          pItem.scanningActive = false;
          pItem.aborted = true;
        }
      }
      setExtensionBadge("clear");
      let res = sId ? await triggerApprovedDownload(sId, { ...message, tabId: sender?.tab?.id || message.tabId || null }) : { ok: false };
      if (!res || !res.ok) {
        try {
          const allRecent = await chrome.downloads.search({ limit: 25, orderBy: ["-startTime"] });
          const targetName = message.filename || (completedScanPayloads.get(sId)?.filename) || "";
          for (const d of (allRecent || [])) {
            const dBase = getBasename(d.filename || "");
            if (!targetName || dBase === targetName || (d.finalUrl && d.finalUrl.includes(targetName))) {
              approvedDownloadIds.add(d.id);
              handledDownloadIds.add(d.id);
              if (d.state === "in_progress" && d.paused) {
                await chrome.downloads.resume(d.id);
                res = { ok: true, downloadId: d.id, resumedFallback: true };
                break;
              } else if (d.finalUrl || d.url) {
                const uToDl = d.finalUrl || d.url;
                approvedUrls.add(uToDl);
                const newDlId = await chrome.downloads.download({
                  url: uToDl,
                  filename: targetName ? sanitizeWindowsFilename(targetName) : undefined,
                  conflictAction: "uniquify"
                });
                approvedDownloadIds.add(newDlId);
                handledDownloadIds.add(newDlId);
                res = { ok: true, downloadId: newDlId, redownloadedFallback: true };
                break;
              }
            }
          }
        } catch (_) {}
      }
      sendResponse(res || { ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_CANCEL_DOWNLOAD") {
    if (message.scanId) {
      cancelledScanIds.add(message.scanId);
      activeBannerCards.delete(message.scanId);
      const pItem = pendingDownloads.get(message.scanId);
      if (pItem) {
        pItem.scanningActive = false;
        pItem.aborted = true;
      }
    }
    setExtensionBadge("clear");
    cancelAndRemoveDownload(message.scanId).then(res => sendResponse(res));
    return true;
  }
  if (message?.type === "VT_GET_ACTIVE_SCANS") {
    const activeList = [];
    for (const [sId, entry] of activeBannerCards.entries()) {
      if (entry.payload && (entry.payload.state === "scanning" || pendingDownloads.has(sId))) {
        activeList.push(entry.payload);
      }
    }
    sendResponse({ ok: true, activeScans: activeList });
    return true;
  }
  if (message?.type === "VT_CONSENT_UPLOAD") {
    (async () => {
      const item = pendingDownloads.get(message.scanId);
      if (!item || !item.fileBlob) {
        sendResponse({ ok: false, error: "Буфер файла недоступен." });
        return;
      }
      const settings = await getFastSettings();
      const cleanKey = (settings.vtApiKeyModeEnabled !== false) ? sanitizeApiKey(settings.apiKey) : "";
      const reportUrl = `https://www.virustotal.com/gui/file/${item.sha256}`;
      const fileMeta = {
        sha256: item.sha256 || "",
        sizeFormatted: formatFileSize(item.fileSize),
        typeTag: item.magicAnalysis?.shortTag || item.ext || "file",
        magicDesc: item.magicAnalysis?.signatureDesc || "",
        zipEntries: item.magicAnalysis?.zipEntries || [],
        analysisDate: "Только что",
        reputation: 0
      };
      uploadAndPollFileBlob(
        message.scanId,
        item.fileBlob,
        item.filename,
        item.ext,
        item.sha256,
        fileMeta,
        cleanKey,
        reportUrl,
        settings,
        item.tabId,
        "intercept"
      );
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === "VT_SHOW_IN_FOLDER") {
    if (message.downloadId !== null && message.downloadId !== undefined) {
      try {
        chrome.downloads.show(Number(message.downloadId));
      } catch (_) {}
    }
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "VT_GET_RATE_LIMITS") {
    getRateLimitStatus().then(res => sendResponse(res));
    return true;
  }
  if (message?.type === "VT_CLEAR_TRUSTED_HASHES") {
    chrome.storage.local.set({ trustedHashes: [] }).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "VT_CLEAR_HASH_CACHE") {
    chrome.storage.local.set({ vtHashCache: {} }).then(() => sendResponse({ ok: true }));
    return true;
  }
    if (message?.type === "VT_VERIFY_ZERO_KEY_PC_AV") {
    (async () => {
      const t0 = Date.now();
      const settings = await getFastSettings();
      const pcAvRes = await runLocalPcAntivirusScan({
        filename: "test_check_clean.exe",
        fullPath: "",
        downloadId: null,
        sha256: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        magicAnalysis: { signatureDesc: "PE32+ executable (GUI) x86-64" },
        fnAttack: { suspicious: false },
        settings
      });
      const latencyMs = Math.max(1, Date.now() - t0);
      sendResponse({
        ok: true,
        avName: pcAvRes?.avName || "💻 Системный антивирус ПК",
        latencyMs
      });
    })();
    return true;
  }
  if (message?.type === "VT_VERIFY_HYBRID_PROTECTION") {
    (async () => {
      const st = await getFastSettings();
      const hasKey = Boolean(st.vtApiKeyModeEnabled !== false && sanitizeApiKey(st.apiKey));
      const hybOn = st.hybridProtectionEnabled !== false;
      const autoNoAv = st.autonomousNoAvCoreEnabled !== false;
      const msgRu = hybOn
        ? `✅ Гибридная защита АКТИВНА! Режим API-ключа: ${hasKey ? "Подключён (72+ АВ VT)" : "Без ключа (Автономный режим)"} + Автономное 6-модульное ядро расширения (YARA + Рентген PE + Архивы .zip/.rar + MalwareBazaar/URLhaus/ThreatFox/CIRCL — работает даже БЕЗ антивируса на ПК: ${autoNoAv ? "ВКЛ" : "ВЫКЛ"}).`
        : `⏸️ Гибридная защита сейчас выключена тумблером. Вы можете включить её в 1 клик для совместной работы API-ключа и Автономного ядра без антивируса на ПК.`;
      const msgEn = hybOn
        ? `✅ Hybrid Protection ACTIVE! VT API Key: ${hasKey ? "Connected (72+ VT AVs)" : "No Key (Autonomous Mode)"} + Built-in 6-Engine Autonomous Core (YARA + PE X-Ray + Archive Inspector + MalwareBazaar/URLhaus/ThreatFox/CIRCL — works even with NO PC Antivirus: ${autoNoAv ? "ON" : "OFF"}).`
        : `⏸️ Hybrid Protection is currently turned OFF. Toggle it ON to combine VT API + Autonomous Core without PC Antivirus.`;
      sendResponse({ ok: true, message: msgRu, messageEn: msgEn });
    })();
    return true;
  }
  if (message?.type === "VT_VERIFY_API_KEY") {
    const cleanKey = sanitizeApiKey(message.apiKey);
    if (!cleanKey || !/^[a-f0-9]{64}$/i.test(cleanKey)) {
      sendResponse({
        ok: false,
        error: "Ключ должен состоять ровно из 64 шестнадцатеричных символов (0-9, a-f). Получите его на странице virustotal.com/gui/my-apikey."
      });
      return true;
    }
    fetch("https://www.virustotal.com/api/v3/files/275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f", {
      headers: {
        "accept": "application/json",
        "x-apikey": cleanKey
      }
    })
      .then(async (resp) => {
        if (resp.ok || resp.status === 404) {
          sendResponse({ ok: true, cleanKey });
        } else if (resp.status === 401) {
          sendResponse({
            ok: false,
            error: "Сервер VirusTotal отклонил ключ (HTTP 401). Убедитесь, что вы подтвердили email аккаунта VirusTotal и скопировали ключ из раздела My API Key."
          });
        } else {
          sendResponse({ ok: false, error: `Ответ сервера: HTTP ${resp.status}` });
        }
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err.message || "Ошибка сети при проверке ключа" });
      });
    return true;
  }
});


if (chrome.commands?.onCommand) {
  chrome.commands.onCommand.addListener(async (command) => {
    const st = await chrome.storage.local.get(DEFAULT_SETTINGS);
    if (st.hotkeysEnabled === false) return;
    if (command === "toggle-guard") {
      const nextEnabled = !st.enabled;
      await chrome.storage.local.set({ enabled: nextEnabled });
      applyExtensionToolbarIcon({ ...st, enabled: nextEnabled });
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs && tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { type: "VT_TOAST_MESSAGE", text: nextEnabled ? "🛡️ Защита VT Download Guard ВКЛЮЧЕНА" : "⏸️ Защита VT Download Guard НА ПАУЗЕ" }).catch(() => {});
      }
    }
  });
}


// ==================== v1.0: СОХРАНЕНИЕ ОКНА ПРОВЕРКИ ПРИ ЗАКРЫТИИ ВКЛАДКИ ====================
if (chrome.tabs?.onRemoved) {
  chrome.tabs.onRemoved.addListener(async (closedTabId) => {
    const affectedScans = [];
    const nowTs = Date.now();
    for (const [scanId, entry] of activeBannerCards.entries()) {
      if (entry.tabId === closedTabId) {
        const isStillScanning = entry.payload?.state === "scanning" && (nowTs - (entry.updatedAt || 0) < 90000);
        const hasPausedDownload = pendingDownloads.has(scanId);
        if (isStillScanning || hasPausedDownload) {
          affectedScans.push(scanId);
        } else {
          activeBannerCards.delete(scanId);
        }
      }
    }
    for (const [scanId, pItem] of pendingDownloads.entries()) {
      if (pItem.tabId === closedTabId && !affectedScans.includes(scanId)) {
        affectedScans.push(scanId);
      }
    }
    if (affectedScans.length === 0) return;

    const settings = await getFastSettings();
    // Если пользователь выключил «Оставлять окно проверки при закрытии вкладки» (включил автозакрытие с вкладкой)
    if (settings.keepScanOnTabClose === false) {
      for (const sId of affectedScans) {
        activeBannerCards.delete(sId);
      }
      return;
    }

    // Ищем новую активную веб-вкладку (http/https), куда можно перенести плашку проверки
    let newTargetTabId = null;
    try {
      const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
      for (const t of activeTabs) {
        if (t.id && t.id !== closedTabId && t.url && /^https?:/i.test(t.url)) {
          newTargetTabId = t.id;
          break;
        }
      }
      if (!newTargetTabId) {
        const allTabs = await chrome.tabs.query({ currentWindow: true });
        for (const t of allTabs) {
          if (t.id && t.id !== closedTabId && t.url && /^https?:/i.test(t.url)) {
            newTargetTabId = t.id;
            break;
          }
        }
      }
    } catch (_) {}

    for (const sId of affectedScans) {
      if (pendingDownloads.has(sId)) {
        pendingDownloads.get(sId).tabId = newTargetTabId;
      }
      const cardEntry = activeBannerCards.get(sId);
      if (!cardEntry) continue;
      cardEntry.tabId = newTargetTabId;

      let shownOnWebTab = false;
      if (newTargetTabId) {
        try {
          await sendBannerUpdate(newTargetTabId, cardEntry.payload);
          shownOnWebTab = true;
        } catch (_) {}
      }

      // Если открытых сайтов нет (например, пользователь остался на пустой вкладке chrome://newtab),
      // открываем автономное окно проверки VT Download Guard, чтобы проверка не пропала!
      if (!shownOnWebTab && !standaloneWindowByScanId.has(sId)) {
        try {
          const popupUrl = chrome.runtime.getURL(`popup.html?standalone_scan=${encodeURIComponent(sId)}`);
          if (chrome.windows?.create) {
            const win = await chrome.windows.create({
              url: popupUrl,
              type: "popup",
              width: 475,
              height: 620,
              focused: true
            });
            if (win && win.id) standaloneWindowByScanId.set(sId, win.id);
          } else {
            await chrome.tabs.create({ url: popupUrl, active: true });
          }
        } catch (_) {}
      }
    }
  });
}


// Отслеживание открытия и закрытия окна расширения (popup.html) для автоматического разведения окон рядом (both_windows) и управления слоями
if (chrome.runtime?.onConnect) {
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "vt_popup_lifecycle") return;
    let activeTid = null;
    (async () => {
      try {
        const st = await getFastSettings();
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        activeTid = tabs && tabs[0]?.id ? tabs[0].id : null;
        if (activeTid) {
          chrome.tabs.sendMessage(activeTid, {
            type: "VT_POPUP_OPEN_STATE",
            open: true,
            scanWindowDisplayMode: st.scanWindowDisplayMode || "card_on_top"
          }).catch(() => {});
        }
      } catch (_) {}
    })();
    port.onDisconnect.addListener(() => {
      if (activeTid) {
        chrome.tabs.sendMessage(activeTid, {
          type: "VT_POPUP_OPEN_STATE",
          open: false
        }).catch(() => {});
      }
    });
  });
}
